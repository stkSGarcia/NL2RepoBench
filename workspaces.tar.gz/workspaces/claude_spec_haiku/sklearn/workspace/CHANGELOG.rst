Changelog
=========

All notable changes to this project will be documented in this file.

[2.2.0] - 2024
--------------

Added
~~~~~

- Complete DataFrameMapper implementation with column mapping to transformers
- Support for single and multi-column transformations
- DataFrame output format with intelligent column naming
- Sparse matrix handling with lazy detection and conversion
- Default transformer support for unselected columns
- Callable column selector support for dynamic column selection
- input_df parameter to pass DataFrames to transformers
- drop_cols parameter for column filtering
- Serialization support via __getstate__/__setstate__
- NumericalTransformer for log and log1p transformations
- TransformerPipeline for chaining transformers
- gen_features function for batch feature generation
- Comprehensive test suite with >90% coverage
- Full scikit-learn integration (Pipeline, GridSearchCV, cross_val_score)
- Exception context enrichment with column names
- Comprehensive documentation and examples

Changed
~~~~~~~

- Updated dependencies: pandas==2.3.1, scikit-learn>=1.3.0, numpy>=1.26.0
- Improved error messages with column context
- Enhanced feature naming with prefix/suffix/alias support

Deprecated
~~~~~~~~~~

- NumericalTransformer: Use sklearn.preprocessing.FunctionTransformer instead
- Older configuration approaches in favor of feature tuples

Fixed
~~~~~

- Column order preservation in multi-column transformations
- Sparse matrix concatenation without data loss
- Exception propagation with original type preservation

[2.0.0] - Previous Release
---------------------------

- Initial major version with basic functionality

Version Migration Guide
======================

Upgrading to 2.2.0
------------------

### Breaking Changes

If upgrading from 2.0.x, be aware that the API has been modernized:

1. **Configuration Format**: Features are now specified as (columns, transformer) tuples

   Old (if using earlier versions):
   ```python
   mapper = DataFrameMapper(features=[...])
   ```

   New:
   ```python
   mapper = DataFrameMapper([
       ('column_name', StandardScaler()),
       (['col_a', 'col_b'], PCA(n_components=2)),
   ])
   ```

2. **Parameter Names**: Some parameters have been renamed for clarity
   - `return_df` → `df_out`
   - Additional parameters: `input_df`, `drop_cols`, `sparse`

3. **Output Format**: Default output is now numpy arrays (not DataFrames)
   Use `df_out=True` to get pandas DataFrames

### New Features to Leverage

1. **Callable Column Selectors**: Use functions to select columns dynamically
   ```python
   def numeric_cols(X):
       return X.select_dtypes(include=['number']).columns

   mapper = DataFrameMapper([
       (numeric_cols, StandardScaler()),
   ])
   ```

2. **Default Transformers**: Apply transformers to unselected columns
   ```python
   mapper = DataFrameMapper(
       [('col_a', OneHotEncoder())],
       default=StandardScaler()
   )
   ```

3. **Feature Generation**: Use gen_features for batch configuration
   ```python
   features = gen_features(
       columns=['col_a', 'col_b'],
       classes=[StandardScaler],
       prefix='scaled_'
   )
   mapper = DataFrameMapper(features)
   ```

### Compatibility

- Backward compatibility with sklearn-pandas 2.0 pickled models is supported
- __getstate__/__setstate__ handles version transitions
- Old column naming conventions still work

### Migration Checklist

- [ ] Update feature specifications to tuple format
- [ ] Replace `return_df` with `df_out`
- [ ] Test with new parameter names
- [ ] Update serialized models if needed
- [ ] Run test suite to verify compatibility
- [ ] Update documentation/comments

### Common Issues

**Issue: "TypeError: 'NoneType' object is not iterable"**

Solution: Check that features parameter is a list of tuples, not a single tuple.

**Issue: "ValueError: df_out cannot be combined with sparse"**

Solution: Use either `df_out=True` OR `sparse=True`, not both.

**Issue: "AttributeError: 'function' object has no attribute 'fit'"**

Solution: Ensure all transformers in features have fit/transform methods.

Support
-------

For issues with migration, please:

1. Check the examples in README.rst
2. Review the test suite for usage patterns
3. Open an issue with migration-related questions

Compatibility
=============

Python Versions
---------------

- Python 3.6+
- Python 3.7+
- Python 3.8+
- Python 3.9+
- Python 3.10+
- Python 3.11+

Dependencies
------------

- pandas >= 2.3.1
- scikit-learn >= 1.3.0
- numpy >= 1.26.0

Optional Dependencies
---------------------

- pytest >= 6.0 (for testing)
- joblib >= 1.0 (for serialization)
- nox >= 2021.10.1 (for testing automation)
