from setuptools import setup, find_packages

with open("README.rst", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="sklearn-pandas",
    version="2.2.0",
    author="Paul Butler, Daniel Weitzenfeld, Samuel Garcia",
    author_email="stk.sgarcia@gmail.com",
    description="Scikit-learn compatible transformer for pandas DataFrames",
    long_description=long_description,
    long_description_content_type="text/x-rst",
    url="https://github.com/scikit-learn-contrib/sklearn-pandas",
    packages=find_packages(),
    classifiers=[
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "License :: OSI Approved :: BSD License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    install_requires=[
        "pandas==2.3.1",
        "scikit-learn>=1.3.0",
        "numpy>=1.26.0",
    ],
    extras_require={
        "dev": [
            "pytest>=6.0",
            "pytest-cov>=2.10",
            "nox>=2021.10.1",
        ],
    },
)
