"""
sklearn-pandas: Pandas DataFrame support for scikit-learn transformers.

This package provides DataFrameMapper for mapping pandas DataFrame columns
to scikit-learn transformers, along with helper classes and functions for
building machine learning pipelines.
"""

__version__ = '2.2.0'

from .dataframe_mapper import DataFrameMapper
from .transformers import NumericalTransformer
from .pipeline import TransformerPipeline
from .features_generator import gen_features
from .utils import (
    _handle_feature,
    _build_transformer,
    _build_feature,
    _call_fit,
    _elapsed_secs,
    _get_feature_names,
    add_column_names_to_exception,
    _get_mask,
    make_transformer_pipeline,
    DataWrapper,
)

__all__ = [
    'DataFrameMapper',
    'NumericalTransformer',
    'TransformerPipeline',
    'gen_features',
    '_handle_feature',
    '_build_transformer',
    '_build_feature',
    '_call_fit',
    '_elapsed_secs',
    '_get_feature_names',
    'add_column_names_to_exception',
    '_get_mask',
    'make_transformer_pipeline',
    'DataWrapper',
]
