def gen_features(columns, classes, prefix='', suffix='', default=None):
    """
    Generate feature transformation configurations.

    Parameters
    ----------
    columns : list
        Column names to generate features for.

    classes : list
        Transformer class specifications. Can be transformer classes or dicts with
        'class' key and other parameters.

    prefix : str, default=''
        Prefix to add to output column names.

    suffix : str, default=''
        Suffix to add to output column names.

    default : bool, None, or transformer
        Default transformer for unselected columns.

    Returns
    -------
    features : list
        List of (column, transformer, options) tuples suitable for DataFrameMapper.
    """
    features = []

    for col in columns:
        for cls_spec in classes:
            if isinstance(cls_spec, dict):
                transformer_class = cls_spec['class']
                params = {k: v for k, v in cls_spec.items() if k != 'class'}
                transformer = transformer_class(**params)
            else:
                transformer = cls_spec()

            opts = {}
            if prefix:
                opts['prefix'] = prefix
            if suffix:
                opts['suffix'] = suffix

            features.append((col, transformer, opts))

    return features
