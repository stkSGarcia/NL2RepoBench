import warnings
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.base import BaseEstimator, TransformerMixin


class DataFrameMapper(BaseEstimator, TransformerMixin):
    """
    Maps DataFrame columns to scikit-learn transformers.

    Parameters
    ----------
    features : list of tuples
        Feature definitions as (columns, transformer) or (columns, transformer, opts)
        where columns can be string, list of strings, or callable.

    default : bool, None, or transformer
        How to handle unselected columns.
        - False: drop them
        - None: pass through unchanged
        - transformer: apply to all unselected columns

    sparse : bool, default=False
        If True, return sparse matrices when possible.

    df_out : bool, default=False
        If True, return pandas DataFrame instead of numpy array.

    input_df : bool, default=False
        If True, pass DataFrame/Series to transformers instead of arrays.

    drop_cols : list, default=None
        Column names to drop from output.
    """

    def __init__(self, features, default=False, sparse=False, df_out=False,
                 input_df=False, drop_cols=None):
        self.features = features
        self.default = default
        self.sparse = sparse
        self.df_out = df_out
        self.input_df = input_df
        self.drop_cols = drop_cols or []

        if df_out and (sparse or (default and default is not False and default is not None)):
            raise ValueError("df_out cannot be combined with sparse or default transformer")

    def fit(self, X, y=None):
        """Fit all transformers on the data."""
        self._build(X)
        for feature in self._features:
            cols, transformer = feature[0], feature[1]
            col_subset = self._get_col_subset(X, cols)
            if transformer and transformer is not False:
                X_subset = col_subset if self.input_df else col_subset.values
                transformer.fit(X_subset, y)
        return self

    def transform(self, X):
        """Transform data using fitted transformers."""
        if not hasattr(self, '_features'):
            self._build(X)
        return self._transform(X)

    def fit_transform(self, X, y=None):
        """Fit transformers and transform data."""
        self._build(X)
        transformed_parts = []
        transformed_names = []

        for feature in self._features:
            cols, transformer = feature[0], feature[1]
            col_subset = self._get_col_subset(X, cols)

            if transformer and transformer is not False:
                X_subset = col_subset if self.input_df else col_subset.values
                X_transformed = transformer.fit_transform(X_subset, y)
            elif transformer is None:
                X_transformed = col_subset.values if isinstance(col_subset, pd.DataFrame) else col_subset
            else:
                continue

            transformed_parts.append(X_transformed)
            names = self._get_names(feature, X_transformed)
            transformed_names.extend(names)

        self._handle_default(X, y, transformed_parts, transformed_names)
        self.transformed_names_ = transformed_names

        return self._format_output(transformed_parts, transformed_names, X)

    def _transform(self, X):
        """Helper for transform logic."""
        transformed_parts = []
        transformed_names = []

        for feature in self._features:
            cols, transformer = feature[0], feature[1]
            col_subset = self._get_col_subset(X, cols)

            if transformer and transformer is not False:
                X_subset = col_subset if self.input_df else col_subset.values
                try:
                    X_transformed = transformer.transform(X_subset)
                except Exception as e:
                    col_names = cols if isinstance(cols, list) else [cols]
                    raise ValueError(f"{col_names}: {str(e)}") from e
            elif transformer is None:
                X_transformed = col_subset.values if isinstance(col_subset, pd.DataFrame) else col_subset
            else:
                continue

            transformed_parts.append(X_transformed)
            names = self._get_names(feature, X_transformed)
            transformed_names.extend(names)

        self._handle_default(X, None, transformed_parts, transformed_names)

        return self._format_output(transformed_parts, transformed_names, X)

    def _build(self, X):
        """Build and validate the transformer setup."""
        self._features = []
        for feature in self.features:
            if len(feature) == 2:
                cols, transformer = feature
                opts = {}
            else:
                cols, transformer, opts = feature
            self._features.append((cols, transformer, opts))

    def _get_col_subset(self, X, cols):
        """Extract columns from DataFrame."""
        if callable(cols):
            selected = cols(X)
            if isinstance(selected, pd.Index):
                cols = selected.tolist()
            else:
                cols = selected

        if isinstance(cols, list):
            return X[cols]
        else:
            return X[[cols]]

    def _selected_columns(self, X):
        """Get all columns selected by features."""
        selected = set()
        for feature in self._features:
            cols = feature[0]
            if callable(cols):
                selected.update(self._get_col_subset(X, cols).columns.tolist())
            elif isinstance(cols, list):
                selected.update(cols)
            else:
                selected.add(cols)
        return selected

    def _unselected_columns(self, X):
        """Get columns not selected by features."""
        selected = self._selected_columns(X)
        return [col for col in X.columns if col not in selected]

    def _get_names(self, feature, X_transformed):
        """Get output column names."""
        cols = feature[0]
        opts = feature[2] if len(feature) > 2 else {}

        if isinstance(X_transformed, sparse.spmatrix):
            n_features = X_transformed.shape[1]
        else:
            if len(X_transformed.shape) == 1:
                n_features = 1
            else:
                n_features = X_transformed.shape[1]

        if 'alias' in opts:
            return [opts['alias']]

        if callable(cols):
            col_names = cols.__name__
        elif isinstance(cols, list):
            col_names = '_'.join(str(c) for c in cols)
        else:
            col_names = str(cols)

        prefix = opts.get('prefix', '')
        suffix = opts.get('suffix', '')

        if n_features == 1:
            return [f"{prefix}{col_names}{suffix}"]
        else:
            return [f"{prefix}{col_names}_{i}{suffix}" for i in range(n_features)]

    def _handle_default(self, X, y, transformed_parts, transformed_names):
        """Handle default transformer for unselected columns."""
        if self.default and self.default is not False and self.default is not None:
            unselected = self._unselected_columns(X)
            if unselected:
                X_unselected = X[unselected]
                X_transformed = self.default.fit_transform(X_unselected.values, y)
                transformed_parts.append(X_transformed)
                transformed_names.extend(unselected)

    def _format_output(self, transformed_parts, transformed_names, X):
        """Format output based on sparse and df_out settings."""
        if not transformed_parts:
            if self.df_out:
                return pd.DataFrame()
            else:
                return np.array([]).reshape(X.shape[0], 0)

        has_sparse = any(sparse.issparse(part) for part in transformed_parts)

        if self.sparse and has_sparse:
            all_sparse = []
            for part in transformed_parts:
                if not sparse.issparse(part):
                    all_sparse.append(sparse.csr_matrix(part))
                else:
                    all_sparse.append(sparse.csr_matrix(part))
            result = sparse.hstack(all_sparse).tocsr()
        else:
            dense_parts = []
            for part in transformed_parts:
                if sparse.issparse(part):
                    dense_parts.append(part.toarray())
                else:
                    if len(part.shape) == 1:
                        dense_parts.append(part.reshape(-1, 1))
                    else:
                        dense_parts.append(part)
            result = np.hstack(dense_parts)

        if self.df_out:
            return pd.DataFrame(result, columns=transformed_names)

        return result

    def get_names(self):
        """Get transformed feature names."""
        if hasattr(self, 'transformed_names_'):
            return self.transformed_names_
        return []

    def __getstate__(self):
        """Get state for pickling."""
        state = self.__dict__.copy()
        return state

    def __setstate__(self, state):
        """Restore state from pickling."""
        self.__dict__.update(state)
