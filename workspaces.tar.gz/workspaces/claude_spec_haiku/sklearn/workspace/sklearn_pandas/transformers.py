import warnings
import numpy as np
import pandas as pd
from sklearn.base import BaseEstimator, TransformerMixin


class NumericalTransformer(BaseEstimator, TransformerMixin):
    """
    Applies log or log1p transformations to numerical data.

    DEPRECATED: Use sklearn.preprocessing.FunctionTransformer instead.

    Parameters
    ----------
    function : str
        The transformation function. Must be 'log' or 'log1p'.
    """

    SUPPORTED_FUNCTIONS = ['log', 'log1p']

    def __init__(self, function):
        assert function in self.SUPPORTED_FUNCTIONS, \
            f"function must be one of {self.SUPPORTED_FUNCTIONS}, got {function}"
        self.function = function
        warnings.warn(
            "NumericalTransformer is deprecated and will be removed in a future version. "
            "Use sklearn.preprocessing.FunctionTransformer instead.",
            DeprecationWarning,
            stacklevel=2
        )

    def fit(self, X, y=None):
        """Fit the transformer (no-op for this transformer)."""
        return self

    def transform(self, X):
        """Apply the transformation."""
        X_array = self._to_array(X)

        try:
            if self.function == 'log':
                if np.any(X_array <= 0):
                    raise ValueError(
                        f"Cannot apply log to data with zero or negative values. "
                        f"Found values <= 0: {X_array[X_array <= 0][:5]}"
                    )
                result = np.log(X_array)
            elif self.function == 'log1p':
                if np.any(X_array < -1):
                    raise ValueError(
                        f"Cannot apply log1p to data with values < -1. "
                        f"Found values < -1: {X_array[X_array < -1][:5]}"
                    )
                result = np.log1p(X_array)
        except Exception as e:
            raise ValueError(f"Error applying {self.function} transformation: {str(e)}") from e

        if isinstance(X, pd.DataFrame):
            return pd.DataFrame(result, columns=X.columns, index=X.index)
        elif isinstance(X, pd.Series):
            return pd.Series(result, index=X.index, name=X.name)

        return result

    def _to_array(self, X):
        """Convert input to numpy array."""
        if isinstance(X, pd.DataFrame):
            return X.values
        elif isinstance(X, pd.Series):
            return X.values.reshape(-1, 1)
        else:
            return np.asarray(X).reshape(-1, 1) if np.asarray(X).ndim == 1 else np.asarray(X)
