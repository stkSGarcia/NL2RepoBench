from sklearn.pipeline import Pipeline
from sklearn.utils.metaestimators import _BaseComposition


class TransformerPipeline(Pipeline):
    """
    Pipeline that chains multiple transformers together.

    All steps must implement fit() and transform() methods.
    Unlike sklearn.pipeline.Pipeline, no final estimator is required.

    Parameters
    ----------
    steps : list
        List of (name, transformer) tuples
    """

    def __init__(self, steps, memory=None, verbose=False):
        super().__init__(steps, memory=memory, verbose=verbose)
        self._validate_steps()

    def _validate_steps(self):
        """Validate that all steps have required methods."""
        for name, transformer in self.steps:
            if transformer is None:
                continue

            if not hasattr(transformer, 'fit'):
                raise TypeError(f"Step '{name}' must implement fit()")

            if not hasattr(transformer, 'transform'):
                raise TypeError(f"Step '{name}' must implement transform()")

    def fit(self, X, y=None, **fit_params):
        """Fit all transformers."""
        self.steps = list(self.steps)
        self._validate_steps()

        Xt = X
        for step_idx, (name, transformer) in enumerate(self.steps[:-1]):
            if transformer is None:
                continue

            fit_transform_one_cached = transformer.fit_transform(Xt, y)
            Xt = fit_transform_one_cached

        if len(self.steps) > 0:
            name, transformer = self.steps[-1]
            if transformer is not None:
                transformer.fit(Xt, y)

        return self

    def fit_transform(self, X, y=None, **fit_params):
        """Fit all transformers and transform data."""
        self.steps = list(self.steps)
        self._validate_steps()

        Xt = X
        for step_idx, (name, transformer) in enumerate(self.steps):
            if transformer is None:
                continue

            if step_idx == len(self.steps) - 1:
                Xt = transformer.fit_transform(Xt, y)
            else:
                Xt = transformer.fit_transform(Xt, y)

        return Xt

    def _pre_transform(self, X):
        """Transform through all but final step."""
        Xt = X
        for name, transformer in self.steps[:-1]:
            if transformer is None:
                continue
            Xt = transformer.transform(Xt)
        return Xt
