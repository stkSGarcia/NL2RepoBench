import time
import functools
import numpy as np
import pandas as pd
from .pipeline import TransformerPipeline


def _handle_feature(X, feature_definition):
    """
    Reshape and validate array output from transformers.

    Parameters
    ----------
    X : array-like
        Input data to reshape.

    feature_definition : tuple
        Feature definition tuple.

    Returns
    -------
    X : array-like
        Reshaped array.
    """
    if isinstance(X, pd.DataFrame):
        return X.values
    elif isinstance(X, pd.Series):
        return X.values.reshape(-1, 1)

    X = np.asarray(X)
    if X.ndim == 1:
        return X.reshape(-1, 1)
    return X


def _build_transformer(transformer_class, **params):
    """
    Build a transformer instance with parameters.

    Parameters
    ----------
    transformer_class : class
        Transformer class.

    **params
        Parameters to pass to transformer.

    Returns
    -------
    transformer : object
        Instantiated transformer.
    """
    return transformer_class(**params)


def _build_feature(columns, transformer, opts=None):
    """
    Construct a feature tuple.

    Parameters
    ----------
    columns : str or list
        Column name(s).

    transformer : object
        Transformer instance.

    opts : dict, optional
        Options dict.

    Returns
    -------
    feature : tuple
        (columns, transformer, opts) tuple.
    """
    opts = opts or {}
    return (columns, transformer, opts)


def _call_fit(transformer, X, y=None, **fit_params):
    """
    Call fit on a transformer with optional parameters.

    Parameters
    ----------
    transformer : object
        Transformer to fit.

    X : array-like
        Input data.

    y : array-like, optional
        Target data.

    **fit_params
        Additional parameters for fit.

    Returns
    -------
    transformer : object
        Fitted transformer.
    """
    transformer.fit(X, y, **fit_params)
    return transformer


def _elapsed_secs(start_time):
    """
    Calculate elapsed time in seconds.

    Parameters
    ----------
    start_time : float
        Start time from time.time().

    Returns
    -------
    elapsed : float
        Elapsed seconds.
    """
    return time.time() - start_time


def _get_feature_names(feature_definition, X_transformed):
    """
    Get output feature names from a transformer.

    Parameters
    ----------
    feature_definition : tuple
        Feature definition tuple.

    X_transformed : array-like
        Transformed output.

    Returns
    -------
    names : list
        Feature names.
    """
    cols = feature_definition[0]
    opts = feature_definition[2] if len(feature_definition) > 2 else {}

    if isinstance(X_transformed, np.ndarray):
        if X_transformed.ndim == 1:
            n_features = 1
        else:
            n_features = X_transformed.shape[1]
    else:
        n_features = 1

    if 'alias' in opts:
        return [opts['alias']]

    if callable(cols):
        col_names = cols.__name__
    elif isinstance(cols, list):
        col_names = '_'.join(str(c) for c in cols)
    else:
        col_names = str(cols)

    prefix = opts.get('prefix', '')
    suffix = opts.get('suffix', '')

    if n_features == 1:
        return [f"{prefix}{col_names}{suffix}"]
    else:
        return [f"{prefix}{col_names}_{i}{suffix}" for i in range(n_features)]


def add_column_names_to_exception(func):
    """
    Decorator that adds column context to exceptions.

    Parameters
    ----------
    func : callable
        Function to decorate.

    Returns
    -------
    wrapper : callable
        Wrapped function.
    """
    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except Exception as e:
            if 'col_names' in kwargs:
                col_names = kwargs['col_names']
                raise ValueError(f"{col_names}: {str(e)}") from e
            raise

    return wrapper


def _get_mask(X, columns):
    """
    Get boolean mask for selected columns.

    Parameters
    ----------
    X : DataFrame
        Input DataFrame.

    columns : str or list
        Column names.

    Returns
    -------
    mask : ndarray
        Boolean mask.
    """
    if isinstance(columns, list):
        return X.columns.isin(columns)
    else:
        return X.columns == columns


def make_transformer_pipeline(*transformers):
    """
    Create a TransformerPipeline from transformers.

    Parameters
    ----------
    *transformers
        Transformer instances.

    Returns
    -------
    pipeline : TransformerPipeline
        Pipeline of transformers.
    """
    steps = [(f"step_{i}", t) for i, t in enumerate(transformers)]
    return TransformerPipeline(steps)


class DataWrapper:
    """
    Wraps pandas DataFrame/Series for sklearn compatibility.

    Some sklearn transformers expect numpy arrays but we want to preserve
    pandas types for column tracking.
    """

    def __init__(self, data):
        self.data = data
        self.columns = data.columns if hasattr(data, 'columns') else None

    def __array__(self):
        if isinstance(self.data, pd.DataFrame):
            return self.data.values
        elif isinstance(self.data, pd.Series):
            return self.data.values.reshape(-1, 1)
        return np.asarray(self.data)

    def get_data(self):
        return self.data
