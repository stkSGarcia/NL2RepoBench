import nox

PYTHON_VERSIONS = ["3.6", "3.7", "3.8", "3.9", "3.10", "3.11"]
SKLEARN_VERSIONS = ["1.3.0", "1.4.0", "1.5.0"]
PANDAS_VERSIONS = ["2.3.1"]


@nox.session(python=PYTHON_VERSIONS)
def tests(session):
    session.install(".[dev]")
    session.run("pytest", *session.posargs)


@nox.session(python="3.9")
def coverage(session):
    session.install(".[dev]")
    session.run(
        "pytest",
        "--cov=sklearn_pandas",
        "--cov-report=term-missing",
        "--cov-report=html",
        "--cov-report=xml",
    )


@nox.session(python="3.9")
def lint(session):
    session.install("flake8", "black", "isort")
    session.run("flake8", "sklearn_pandas", "tests")
    session.run("black", "--check", "sklearn_pandas", "tests")
    session.run("isort", "--check-only", "sklearn_pandas", "tests")


@nox.session(python="3.9")
def format(session):
    session.install("black", "isort")
    session.run("black", "sklearn_pandas", "tests")
    session.run("isort", "sklearn_pandas", "tests")


@nox.parametrize("sklearn_version", SKLEARN_VERSIONS)
@nox.session(python="3.9")
def test_sklearn_versions(session, sklearn_version):
    session.install(f"scikit-learn=={sklearn_version}", ".[dev]")
    session.run("pytest", "-v", *session.posargs)


@nox.parametrize("pandas_version", PANDAS_VERSIONS)
@nox.session(python="3.9")
def test_pandas_versions(session, pandas_version):
    session.install(f"pandas=={pandas_version}", ".[dev]")
    session.run("pytest", "-v", *session.posargs)


@nox.session(python="3.9")
def docs(session):
    session.install("sphinx", "sphinx_rtd_theme", ".[dev]")
    session.run("sphinx-build", "-b", "html", "docs", "docs/_build")
