scikit-learn-pandas
===================

A Python library that bridges pandas DataFrames and scikit-learn transformers.

Features
--------

- **DataFrameMapper**: Map pandas DataFrame columns to scikit-learn transformers
- **NumericalTransformer**: Apply log and log1p transformations
- **TransformerPipeline**: Chain multiple transformers together
- **gen_features**: Batch generation of feature transformation configurations
- **Full scikit-learn integration**: Works seamlessly with sklearn pipelines, cross-validation, and grid search

Installation
-----------

.. code-block:: bash

   pip install sklearn-pandas

Quick Start
-----------

Basic Usage
~~~~~~~~~~~

.. code-block:: python

   import pandas as pd
   from sklearn.preprocessing import StandardScaler
   from sklearn_pandas import DataFrameMapper

   # Create sample data
   df = pd.DataFrame({
       'age': [20, 30, 40],
       'salary': [50000, 60000, 70000],
   })

   # Map columns to transformers
   mapper = DataFrameMapper([
       ('age', StandardScaler()),
       ('salary', StandardScaler()),
   ])

   # Fit and transform
   X_transformed = mapper.fit_transform(df)
   print(X_transformed)

Advanced Usage
~~~~~~~~~~~~~~

.. code-block:: python

   from sklearn.preprocessing import OneHotEncoder
   from sklearn_pandas import DataFrameMapper, gen_features

   # DataFrame with mixed types
   df = pd.DataFrame({
       'numeric1': [1, 2, 3],
       'numeric2': [4, 5, 6],
       'category': ['a', 'b', 'c'],
   })

   # Generate features for numeric columns
   numeric_features = gen_features(
       columns=['numeric1', 'numeric2'],
       classes=[StandardScaler],
       prefix='scaled_'
   )

   # Combine with categorical features
   mapper = DataFrameMapper(
       numeric_features + [
           ('category', OneHotEncoder(sparse_output=False)),
       ],
       df_out=True  # Return as DataFrame
   )

   result = mapper.fit_transform(df)
   print(result)

Real-World Example
~~~~~~~~~~~~~~~~~~

.. code-block:: python

   from sklearn.pipeline import Pipeline
   from sklearn.preprocessing import StandardScaler, OneHotEncoder
   from sklearn.ensemble import RandomForestClassifier
   from sklearn_pandas import DataFrameMapper

   # Prepare data
   df = pd.read_csv('data.csv')
   X = df.drop('target', axis=1)
   y = df['target']

   # Create mapper for feature transformation
   mapper = DataFrameMapper([
       (['age', 'salary'], StandardScaler()),
       ('region', OneHotEncoder(sparse_output=False)),
   ])

   # Build full pipeline
   pipeline = Pipeline([
       ('features', mapper),
       ('classifier', RandomForestClassifier()),
   ])

   # Train and evaluate
   pipeline.fit(X, y)
   score = pipeline.score(X, y)

API Reference
-------------

DataFrameMapper
~~~~~~~~~~~~~~~

Maps DataFrame columns to scikit-learn transformers.

**Parameters:**

- `features` (list): Feature definitions as (columns, transformer) tuples
- `default` (bool, None, or transformer): How to handle unselected columns
- `sparse` (bool): Return sparse matrices if True
- `df_out` (bool): Return pandas DataFrame if True
- `input_df` (bool): Pass DataFrames to transformers instead of arrays
- `drop_cols` (list): Columns to drop from output

**Methods:**

- `fit(X, y=None)`: Fit all transformers
- `transform(X)`: Transform data
- `fit_transform(X, y=None)`: Fit and transform
- `get_names()`: Get output column names

NumericalTransformer
~~~~~~~~~~~~~~~~~~~~

.. note::
   Deprecated. Use `sklearn.preprocessing.FunctionTransformer` instead.

Applies log or log1p transformations.

**Parameters:**

- `function` (str): 'log' or 'log1p'

TransformerPipeline
~~~~~~~~~~~~~~~~~~~

Chains multiple transformers together.

**Parameters:**

- `steps` (list): List of (name, transformer) tuples

gen_features
~~~~~~~~~~~~

Generate feature configurations for multiple columns.

**Parameters:**

- `columns` (list): Column names
- `classes` (list): Transformer classes
- `prefix` (str): Prefix for output columns
- `suffix` (str): Suffix for output columns

FAQ
---

**Q: Why use DataFrameMapper instead of ColumnTransformer?**

A: DataFrameMapper is simpler and more intuitive for straightforward transformations.
Use ColumnTransformer for more complex pipelines requiring different output types.

**Q: Can I use custom transformers?**

A: Yes! Any scikit-learn compatible transformer (with fit/transform) works.

**Q: How do I handle missing values?**

A: Use scikit-learn's imputation transformers in the pipeline.

**Q: Can I serialize fitted mappers?**

A: Yes! Use pickle or joblib to serialize/deserialize fitted mappers.

Contributing
-----------

See CONTRIBUTING.md for guidelines on how to contribute.

Version History
---------------

**2.2.0** (Current)

- Core DataFrameMapper implementation
- Full scikit-learn integration
- NumericalTransformer with deprecation warning
- TransformerPipeline for chaining transformers
- Comprehensive test suite

**2.0.0 - 2.1.x**

- Earlier versions with different APIs

License
-------

BSD 3-Clause License. See LICENSE file for details.

Support
-------

Issues and questions: https://github.com/scikit-learn-contrib/sklearn-pandas/issues
