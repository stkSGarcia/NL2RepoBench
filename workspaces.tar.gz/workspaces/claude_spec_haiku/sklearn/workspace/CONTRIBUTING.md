# Contributing to sklearn-pandas

Thank you for considering contributing to sklearn-pandas! This document provides guidelines and instructions for contributing.

## Code of Conduct

Be respectful and inclusive. All contributors are expected to follow the [Python Community Code of Conduct](https://www.python.org/psf/conduct/).

## How to Contribute

### Reporting Bugs

1. Use the GitHub issue tracker
2. Check if the issue already exists
3. Include:
   - Python version
   - pandas version
   - scikit-learn version
   - A minimal reproducible example

### Suggesting Enhancements

1. Open an issue with the `enhancement` label
2. Describe the use case
3. Provide examples of how the feature would be used

### Code Contributions

1. Fork the repository
2. Create a branch: `git checkout -b feature/your-feature`
3. Make your changes
4. Write tests for new functionality
5. Run the test suite: `pytest`
6. Commit with clear messages
7. Push to your fork
8. Create a pull request

## Development Setup

### Install Development Dependencies

```bash
pip install -e .[dev]
```

### Running Tests

```bash
# Run all tests
pytest

# Run with coverage
pytest --cov=sklearn_pandas

# Run specific test file
pytest tests/test_dataframe_mapper.py

# Run specific test
pytest tests/test_dataframe_mapper.py::TestDataFrameMapperBasic::test_simple_dataframe_no_transformer
```

### Code Quality

```bash
# Format code
nox -s format

# Run linting
nox -s lint

# Run tests
nox -s tests
```

## Coding Standards

### Style

- Follow [PEP 8](https://www.python.org/dev/peps/pep-0008/)
- Use clear variable names
- Add comments only for non-obvious logic
- Maximum line length: 100 characters

### Testing

- Write tests for all new code
- Aim for >90% code coverage
- Use descriptive test names
- Use pytest fixtures for common setup

### Documentation

- Add docstrings to all public functions and classes
- Use NumPy docstring format
- Include parameter descriptions and return values
- Add examples in docstrings where helpful

## Pull Request Process

1. Ensure all tests pass: `pytest`
2. Update CHANGELOG.rst
3. Update README.rst if adding features
4. Ensure code follows style guidelines
5. Provide a clear description of changes
6. Reference related issues

## Testing Different Versions

Test against multiple pandas and scikit-learn versions:

```bash
nox -s test_sklearn_versions
nox -s test_pandas_versions
```

## Performance Considerations

- Avoid unnecessary DataFrame copies
- Use vectorized NumPy operations
- Profile code for large DataFrames
- Document performance implications

## Documentation

Documentation should:

1. Be clear and concise
2. Include examples
3. Explain parameter choices
4. Document edge cases
5. Link to related resources

## Commit Message Guidelines

Format: `[type] brief description`

Types:
- `feat`: New feature
- `fix`: Bug fix
- `docs`: Documentation
- `style`: Code style
- `refactor`: Code refactoring
- `test`: Test addition/modification
- `chore`: Build, dependencies, etc.

Example:
```
feat: add custom parameter validation

- Added validation for transformer parameters
- Raises TypeError for invalid configurations
- Includes comprehensive tests
```

## Release Process

1. Update version in `setup.py` and `__init__.py`
2. Update `CHANGELOG.rst`
3. Create git tag: `git tag v2.2.0`
4. Push tag: `git push origin v2.2.0`
5. Build distribution: `python setup.py sdist bdist_wheel`
6. Upload to PyPI: `twine upload dist/*`

## Getting Help

- Check existing issues and pull requests
- Read the documentation
- Ask on GitHub discussions
- Check scikit-learn and pandas documentation for transformer/DataFrame questions

## Recognition

Contributors will be:
- Listed in CHANGELOG.rst
- Listed in GitHub contributors
- Acknowledged in release notes

Thank you for contributing! ✨
