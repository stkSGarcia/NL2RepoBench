# column-selection Specification

## Purpose
TBD - created by archiving change implement-sklearn-pandas. Update Purpose after archive.
## Requirements
### Requirement: String column selection
DataFrameMapper SHALL accept a single column name as a string in the feature definition.

#### Scenario: Select single column by name
- **WHEN** DataFrameMapper([('col_a', transformer)]) is used
- **THEN** only 'col_a' is selected and transformed

### Requirement: Multiple column selection
DataFrameMapper SHALL accept a list of column names to apply a transformer to multiple columns jointly.

#### Scenario: Select multiple columns
- **WHEN** DataFrameMapper([(['col_a', 'col_b'], transformer)]) is used
- **THEN** transformer receives both columns as input

### Requirement: Callable column selection
DataFrameMapper SHALL accept callable column selectors that return True/False for each column.

#### Scenario: Select by callable
- **WHEN** DataFrameMapper([(lambda cols: cols.startswith('feat_'), transformer)]) is used
- **THEN** all columns starting with 'feat_' are selected

### Requirement: sklearn make_column_selector support
DataFrameMapper SHALL work with sklearn.compose.make_column_selector for dtype-based selection.

#### Scenario: Select by dtype
- **WHEN** DataFrameMapper([(make_column_selector(dtype_include=float), transformer)]) is used
- **THEN** all float columns are selected and transformed

### Requirement: Column ordering preservation
Selected columns SHALL be processed in a consistent order across fit and transform.

#### Scenario: Consistent ordering
- **WHEN** fit() and transform() are called sequentially
- **THEN** columns are processed in the same order in both operations

