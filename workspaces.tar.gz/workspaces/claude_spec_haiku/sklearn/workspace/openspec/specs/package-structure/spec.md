# package-structure Specification

## Purpose
TBD - created by archiving change implement-sklearn-pandas. Update Purpose after archive.
## Requirements
### Requirement: Setup.py configuration
The project SHALL include a setup.py file declaring all dependencies and package metadata.

#### Scenario: Install package
- **WHEN** pip install is run on the project
- **THEN** all dependencies (pandas==2.3.1, scikit-learn>=1.3.0, numpy>=1.26.0, pytest) are installed

#### Scenario: Package metadata
- **WHEN** setup.py is examined
- **THEN** package name, version, author, and description are defined

### Requirement: Package initialization
The sklearn_pandas/__init__.py SHALL export all main classes and functions.

#### Scenario: Import main classes
- **WHEN** from sklearn_pandas import DataFrameMapper, NumericalTransformer, gen_features is executed
- **THEN** all classes are available without errors

#### Scenario: Wildcard import
- **WHEN** from sklearn_pandas import * is executed
- **THEN** all main classes and functions are imported (via __all__)

### Requirement: Module structure
The project SHALL organize code into logical modules: dataframe_mapper.py, transformers.py, features_generator.py, pipeline.py, cross_validation.py.

#### Scenario: Module imports
- **WHEN** internal modules are imported from their locations
- **THEN** they are accessible at their respective paths

### Requirement: Version number
The package SHALL declare a __version__ variable.

#### Scenario: Version access
- **WHEN** sklearn_pandas.__version__ is accessed
- **THEN** it returns the current version string (e.g., '2.2.0')

