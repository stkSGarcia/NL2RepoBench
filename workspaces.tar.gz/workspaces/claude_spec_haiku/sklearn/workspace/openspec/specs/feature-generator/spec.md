# feature-generator Specification

## Purpose
TBD - created by archiving change implement-sklearn-pandas. Update Purpose after archive.
## Requirements
### Requirement: Batch feature generation
The gen_features function SHALL generate feature transformation configurations for multiple columns using specified transformer classes.

#### Scenario: Generate features for multiple columns
- **WHEN** gen_features(columns=['col_a', 'col_b'], classes=[StandardScaler]) is called
- **THEN** a list of tuples is returned: [('col_a', [StandardScaler()], {}), ('col_b', [StandardScaler()], {})]

#### Scenario: Preserve column order
- **WHEN** gen_features with columns=['z', 'a', 'm'] is called
- **THEN** returned features maintain the input column order

### Requirement: Multiple transformer configurations
The gen_features function SHALL support different transformer parameters for different positions.

#### Scenario: Multiple class configurations
- **WHEN** gen_features(columns=['col_a', 'col_b', 'col_c'], classes=[{'class': Scaler, 'name': 'config1'}, {'class': Encoder}]) is called
- **THEN** transformers are configured with their respective parameters in order

### Requirement: Prefix and suffix support
The gen_features function SHALL add prefix and suffix parameters to feature definitions for output column naming.

#### Scenario: Add prefix and suffix
- **WHEN** gen_features(columns=['col_a'], classes=[Transformer], prefix='pre_', suffix='_suf') is called
- **THEN** returned tuple includes params={'prefix': 'pre_', 'suffix': '_suf'}

### Requirement: Default parameters
The gen_features function SHALL support optional parameters with sensible defaults.

#### Scenario: Default parameters
- **WHEN** gen_features(columns=['col_a'], classes=[Transformer]) is called without prefix/suffix
- **THEN** params dict is empty or contains only defaults

