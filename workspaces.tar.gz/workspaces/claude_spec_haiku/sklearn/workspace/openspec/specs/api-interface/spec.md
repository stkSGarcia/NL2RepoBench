# api-interface Specification

## Purpose
TBD - created by archiving change implement-sklearn-pandas. Update Purpose after archive.
## Requirements
### Requirement: Scikit-Learn compatible interface
All transformer classes SHALL implement fit(), transform(), and fit_transform() methods compatible with Scikit-Learn's TransformerMixin.

#### Scenario: Implement standard interface
- **WHEN** DataFrameMapper, NumericalTransformer, and TransformerPipeline are instantiated
- **THEN** all have fit(), transform(), and fit_transform() methods

#### Scenario: Integration with sklearn Pipeline
- **WHEN** any sklearn-pandas transformer is used in sklearn.pipeline.Pipeline
- **THEN** it works seamlessly with fit, transform, and cross-validation

### Requirement: Helper function exports
The sklearn_pandas module SHALL export helper functions: _handle_feature, _build_transformer, _call_fit, _get_feature_names, add_column_names_to_exception, _get_mask, make_transformer_pipeline.

#### Scenario: Access helper functions
- **WHEN** from sklearn_pandas import _handle_feature is executed
- **THEN** the function is available

### Requirement: Consistent naming conventions
The API SHALL use Scikit-Learn naming conventions (fit, transform, fit_transform, etc.).

#### Scenario: Method naming
- **WHEN** examining any class method
- **THEN** method names match Scikit-Learn conventions

### Requirement: Documentation strings
All classes and functions SHALL have clear docstrings describing parameters and return values.

#### Scenario: Access documentation
- **WHEN** help(DataFrameMapper) is called or __doc__ is accessed
- **THEN** comprehensive documentation is available

