# sparse-matrix-support Specification

## Purpose
TBD - created by archiving change implement-sklearn-pandas. Update Purpose after archive.
## Requirements
### Requirement: Sparse matrix output option
DataFrameMapper SHALL support returning sparse matrices when sparse=True.

#### Scenario: Enable sparse output
- **WHEN** DataFrameMapper([('col', transformer)], sparse=True) is used
- **THEN** if any transformer produces sparse output, result is scipy.sparse matrix format

### Requirement: Sparse matrix handling
When sparse=True, DataFrameMapper SHALL properly concatenate sparse matrices from multiple transformers.

#### Scenario: Concatenate sparse matrices
- **WHEN** multiple features generate sparse outputs and sparse=True
- **THEN** outputs are combined as a single sparse matrix

### Requirement: Dense matrix override
When sparse=False, DataFrameMapper SHALL convert sparse transformer outputs to dense matrices.

#### Scenario: Force dense output
- **WHEN** sparse=False and a transformer produces sparse output
- **THEN** the sparse matrix is converted to a dense numpy array

### Requirement: Sparse matrix type
The output sparse format SHALL be scipy.sparse.csr_matrix (Compressed Sparse Row).

#### Scenario: CSR matrix format
- **WHEN** sparse output is generated
- **THEN** output.format() returns 'csr'

