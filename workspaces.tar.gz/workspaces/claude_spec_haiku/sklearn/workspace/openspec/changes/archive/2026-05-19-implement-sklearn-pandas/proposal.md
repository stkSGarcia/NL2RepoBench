## Why

sklearn-pandas addresses the challenge of applying different transformers to different columns of a pandas DataFrame in a Scikit-Learn compatible way. Data scientists often need to apply distinct feature engineering workflows to heterogeneous tabular data (mixing categorical, numerical, and text features) while maintaining integration with Scikit-Learn's broader ecosystem (pipelines, cross-validation, grid search). This library bridges that gap by providing a DataFrameMapper that treats DataFrames as first-class objects in transformation workflows.

## What Changes

- **New Core Bridge**: Implement `DataFrameMapper` class that maps DataFrame columns to Scikit-Learn transformers, supporting single/multi-column transformations, sparse matrices, and DataFrame output preservation
- **Feature Definition Simplification**: Provide `gen_features` function for batch feature transformation configuration generation
- **Numerical Transformations**: Implement `NumericalTransformer` class supporting log and log1p transformations with proper boundary value handling
- **Pipeline Compatibility**: Create `TransformerPipeline` class that chains transformers while maintaining Scikit-Learn compatibility
- **Clear API Surface**: Export main classes and functions through `__init__.py` (DataFrameMapper, gen_features, NumericalTransformer, TransformerPipeline, _handle_feature, _build_transformer, _call_fit)
- **Complete Documentation**: Provide setup.py with dependencies, API documentation, usage examples, FAQs, and contribution guidelines
- **Python 3.6+ Compatibility**: Ensure library works with pandas 2.3.1+, scikit-learn 1.3.0+, and numpy 1.26.0+

## Capabilities

### New Capabilities

- `dataframe-mapper`: Core class that maps pandas DataFrame columns to Scikit-Learn transformers with support for single/multi-column transformations, default transformers, sparse matrices, and DataFrame output
- `feature-generator`: Function for batch generation of feature transformation configurations supporting multiple transformer classes and prefix/suffix naming
- `numerical-transformer`: Class providing log and log1p transformations with proper error handling for boundary values
- `transformer-pipeline`: Pipeline class that chains multiple transformers while maintaining Scikit-Learn compatibility (fit, transform, fit_transform)
- `package-structure`: Complete project structure with setup.py, dependencies, and installable package layout
- `api-interface`: Clear, consistent API design with fit/transform/fit_transform methods compatible with Scikit-Learn conventions
- `exception-handling`: Detailed exception context including column names to aid debugging during fit/transform operations
- `column-selection`: Support for dynamic column selection using callable filters and sklearn's make_column_selector
- `sparse-matrix-support`: Capability to handle and return sparse matrices from transformers
- `serialization`: Support for pickle-based serialization/deserialization of fitted pipelines and transformers

### Modified Capabilities

<!-- None - this is a new library with no existing specs to modify -->

## Impact

- **New Dependencies**: pandas (2.3.1), scikit-learn (1.3.0+), numpy (1.26.0+), pytest for testing
- **API Surface**: Exports from sklearn_pandas package: DataFrameMapper, gen_features, NumericalTransformer, TransformerPipeline, _handle_feature, _build_transformer, _call_fit
- **File Structure**: Creates sklearn_pandas/ package directory with __init__.py, dataframe_mapper.py, features_generator.py, pipeline.py, transformers.py, cross_validation.py
- **Testing**: Requires pytest test suite covering all core functionality with test fixtures for DataFrames
- **Configuration**: Requires setup.py, setup.cfg, pytest.ini, noxfile.py for CI/CD and testing
