## Context

The sklearn-pandas library bridges scikit-learn and pandas by enabling column-wise transformer mapping for DataFrames. This is a foundational library that enables data scientists to build complex feature engineering pipelines by specifying different transformations for different column subsets.

The implementation must handle:
- Heterogeneous column types (numeric, categorical, text, objects)
- Both single and multi-column transformations
- Integration with scikit-learn's ecosystem (Pipeline, cross-validation, etc.)
- Output format flexibility (numpy arrays, sparse matrices, or DataFrames)
- Backward compatibility with Python 3.6+ and various scikit-learn versions

## Goals / Non-Goals

**Goals:**
- Create a DataFrameMapper that maps DataFrame columns to transformers with full scikit-learn compatibility
- Support flexible feature transformation including single/multi-column and default transformers
- Provide helper functions (gen_features, NumericalTransformer, TransformerPipeline) for common patterns
- Enable both sparse and dense matrix outputs with DataFrame preservation option
- Implement proper exception handling with column context information
- Ensure serialization/deserialization via pickle/joblib
- Provide complete documentation, examples, and test coverage

**Non-Goals:**
- Advanced statistical functions beyond log/log1p transformations
- Custom sparse matrix formats beyond scipy.sparse.csr_matrix
- Integration with external ML frameworks (only scikit-learn and pandas)
- Performance optimization via GPU acceleration
- CLI tools or web interfaces

## Decisions

### Architecture: Modular transformer system

**Decision**: Separate code into logical modules (dataframe_mapper.py, transformers.py, features_generator.py, pipeline.py, cross_validation.py) with clear interfaces.

**Rationale**: Modularity improves maintainability, testability, and allows each component to evolve independently. Users can import specific functionality without loading the entire package.

**Alternative Considered**: Monolithic single-file implementation. Rejected because it would be difficult to test and maintain as features grow.

### DataFrameMapper: Column mapping via features list

**Decision**: Use a list of (columns, transformers, options) tuples as the features specification. Columns can be strings, lists, or callables.

**Rationale**: This design is flexible (single column, multiple columns, dynamic selection) and intuitive for data scientists familiar with column selection patterns. It matches sklearn.compose patterns.

**Alternative Considered**: Dict-based specification {col: transformer}. Rejected because it can't easily handle multi-column transformations.

### Transformer Chaining: TransformerPipeline extends sklearn Pipeline

**Decision**: Create TransformerPipeline as a Pipeline subclass that guarantees all steps are transformers (have both fit and transform), avoiding the need for a final estimator.

**Rationale**: Data science workflows often need pure transformation chains without classification/regression at the end. This reduces boilerplate and prevents confusion about required final steps.

**Alternative Considered**: Use sklearn.pipeline.Pipeline directly. Rejected because users must always add a dummy estimator.

### Sparse Matrix Handling: Lazy concatenation

**Decision**: When sparse=True, detect sparse outputs from transformers and concatenate them using scipy.sparse functions. When sparse=False, convert sparse outputs to dense.

**Rationale**: This gives maximum flexibility—users can opt-in to sparse matrices for memory efficiency but still work with dense matrices if needed. Lazy detection avoids assumptions about transformer output types.

**Alternative Considered**: Force all transformers to declare output type in advance. Rejected as too restrictive and hard to enforce.

### Feature Generator: Simple column-to-transformer mapper

**Decision**: gen_features produces feature tuples from column lists and transformer class specifications (possibly with per-column parameters).

**Rationale**: Reduces boilerplate for common patterns where the same (or similar) transformer applies to multiple columns. The dict-based class specification allows parametrization.

**Alternative Considered**: Class-based builder pattern. Rejected as over-engineered for the common case.

### Exception Context: Column enrichment during transform

**Decision**: Wrap transformer calls in try-except blocks. On error, prepend column name(s) to the exception message.

**Rationale**: Data scientists debug pipelines by column. Including column context in errors dramatically speeds up root-cause analysis.

**Alternative Considered**: Log column context separately. Rejected because users miss log output; it must be in the exception itself.

### Default Transformer Handling: Apply to unselected columns

**Decision**: If default is False, drop unselected columns. If default is a transformer, apply it to unselected columns as a group. If default is None, pass them through.

**Rationale**: This covers the three common use cases: (1) feature selection (drop unknown), (2) uniform transformation (apply transformer), (3) passthrough (keep as-is). Explicit is better than implicit.

**Alternative Considered**: Always drop unselected. Rejected because many workflows need passthrough or default transformation.

### Serialization: __getstate__/__setstate__ for sklearn compatibility

**Decision**: Implement __getstate__/__setstate__ to handle pickling. Map fitted state to/from dicts compatible with joblib.

**Rationale**: Data science workflows serialize models for production deployment. sklearn convention uses joblib. __getstate__/__setstate__ allows backward compatibility when fields are added in future versions.

**Alternative Considered**: Custom pickle reducer. Rejected as less compatible with sklearn ecosystem.

### NumericalTransformer: Deprecation warning but functional

**Decision**: Implement NumericalTransformer for backward compatibility and common use (log/log1p), but emit a deprecation warning recommending sklearn FunctionTransformer.

**Rationale**: Simplifies migration for users of older versions while guiding them to modern approaches.

**Alternative Considered**: Remove entirely. Rejected because breaking existing code is unfriendly.

## Risks / Trade-offs

**Risk: Performance on large DataFrames** → **Mitigation**: Use numpy operations where possible. Document that for >1GB DataFrames, consider dask-based solutions. Provide sparse matrix option for high-dimensional data.

**Risk: Pandas/scikit-learn version incompatibility** → **Mitigation**: Test against supported version ranges. Pin major versions in setup.py. Provide clear version migration guide.

**Risk: Ambiguous column order in multi-column transformers** → **Mitigation**: Document that column order in feature tuples determines processing order. Add tests validating order consistency across fit/transform.

**Risk: Silent failures with wrong transformer types** → **Mitigation**: Validate at initialization time that transformers have fit/transform. Raise TypeError early with clear messages.

**Risk: Sparse matrix interoperability** → **Mitigation**: Only support scipy.sparse.csr_matrix (standard in sklearn). Test interop with sklearn.sparse and common transformers (CountVectorizer, OneHotEncoder).

**Risk: Deep DataFrame copies on every fit** → **Mitigation**: Avoid unnecessary data copies. Only select needed columns once. Use iloc/loc efficiently.

## Assumptions

- Users have basic familiarity with sklearn's Pipeline and fit/transform interface
- Input DataFrames are well-formed (no unexpected null column names, reasonable size)
- Transformers in the features list implement sklearn's TransformerMixin interface
- Python 3.6+ with pandas 2.3.1+ and scikit-learn 1.3.0+
- Users will serialize pipelines with joblib, not pickle directly

## Implementation Approach

1. **Phase 1**: Implement core DataFrameMapper with column selection, basic transformation, and DataFrame output
2. **Phase 2**: Add default transformer handling, sparse matrix support, and exception context enrichment
3. **Phase 3**: Implement helper classes (NumericalTransformer, TransformerPipeline, gen_features)
4. **Phase 4**: Add serialization (__getstate__/__setstate__) and comprehensive tests
5. **Phase 5**: Documentation, examples, FAQ, and contribution guidelines
6. **Phase 6**: Setup.py, CI/CD (noxfile.py, CircleCI config), and release automation

## Open Questions

1. Should we support dask DataFrames for distributed processing? (Defer to Phase 2)
2. Should we add a method to export feature names post-transformation? (Likely yes, add get_feature_names())
3. Should we support sparse DataFrames (DataFrame with sparse dtypes)? (Defer to Phase 2)
4. How much validation of transformer compatibility should happen upfront vs. at fit time? (Balance covered in Phase 4 testing)
