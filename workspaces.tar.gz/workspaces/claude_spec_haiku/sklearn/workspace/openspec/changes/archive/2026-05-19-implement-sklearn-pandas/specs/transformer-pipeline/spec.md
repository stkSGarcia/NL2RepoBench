## ADDED Requirements

### Requirement: TransformerPipeline initialization
The TransformerPipeline class SHALL accept a list of (name, transformer) step tuples and validate them.

#### Scenario: Initialize valid pipeline
- **WHEN** TransformerPipeline([('step1', Transformer1()), ('step2', Transformer2())]) is called
- **THEN** the pipeline is created with steps in order

#### Scenario: Reject non-unique step names
- **WHEN** TransformerPipeline([('step', T1()), ('step', T2())]) is called
- **THEN** a ValueError is raised about non-unique names

#### Scenario: Reject step without transform
- **WHEN** a step lacks a transform method
- **THEN** a TypeError is raised indicating the step must implement transform

#### Scenario: Reject final step without fit
- **WHEN** the final step lacks a fit method
- **THEN** a TypeError is raised

### Requirement: Fit method
The TransformerPipeline SHALL fit all transformers in sequence on the input data.

#### Scenario: Fit pipeline
- **WHEN** fit(X, y) is called on TransformerPipeline
- **THEN** each transformer is fitted on the transformed output of the previous step

#### Scenario: Fit with y parameter
- **WHEN** fit(X, y) is called with y parameter
- **THEN** y is passed through to transformers that accept it

### Requirement: Transform method
The TransformerPipeline SHALL transform data through all steps in sequence.

#### Scenario: Transform data
- **WHEN** transform(X) is called after fit()
- **THEN** data is passed through all transformers in order and final result is returned

### Requirement: Fit-transform method
The TransformerPipeline SHALL fit and transform data in one operation.

#### Scenario: Fit-transform pipeline
- **WHEN** fit_transform(X, y) is called
- **THEN** all transformers are fitted and data is transformed through all steps

### Requirement: Step composition
The TransformerPipeline SHALL allow accessing and modifying individual steps.

#### Scenario: Access steps
- **WHEN** pipeline.steps is accessed
- **THEN** a list of (name, transformer) tuples is returned

### Requirement: Predict method if final step is estimator
If the final step has a predict method, TransformerPipeline SHALL delegate predict calls to it.

#### Scenario: Predict through pipeline
- **WHEN** predict(X) is called on a pipeline with an estimator as final step
- **THEN** data is transformed through all but final step, then predict is called
