## ADDED Requirements

### Requirement: Pickle serialization
All sklearn-pandas transformers SHALL be serializable and deserializable using pickle/joblib.

#### Scenario: Serialize transformer
- **WHEN** joblib.dump(fitted_mapper, filename) is called
- **THEN** the mapper is serialized to a file

#### Scenario: Deserialize transformer
- **WHEN** joblib.load(filename) is called on a serialized mapper
- **THEN** the loaded transformer is identical to the original

### Requirement: __getstate__ and __setstate__
DataFrameMapper SHALL implement __getstate__ and __setstate__ for proper serialization.

#### Scenario: State preservation
- **WHEN** a mapper is fitted, serialized, and deserialized
- **THEN** the deserialized mapper produces identical output to the original

### Requirement: Backward compatibility
The __setstate__ method SHALL handle state from older versions of sklearn-pandas.

#### Scenario: Load old version state
- **WHEN** state from an older sklearn-pandas version is deserialized
- **THEN** it is properly reconstructed with default values for new fields

### Requirement: Transform consistency after serialization
A deserialized mapper SHALL produce identical output to the original for the same input.

#### Scenario: Consistent results
- **WHEN** transform is called on both original and deserialized mappers
- **THEN** outputs are numerically identical
