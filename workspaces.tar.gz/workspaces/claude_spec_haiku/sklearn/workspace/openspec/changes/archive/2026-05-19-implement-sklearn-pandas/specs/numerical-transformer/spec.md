## ADDED Requirements

### Requirement: NumericalTransformer initialization
The NumericalTransformer class SHALL accept a function name and validate it against SUPPORTED_FUNCTIONS.

#### Scenario: Initialize with supported function
- **WHEN** NumericalTransformer('log') is instantiated
- **THEN** the transformer is created and a deprecation warning is issued

#### Scenario: Initialize with unsupported function
- **WHEN** NumericalTransformer('exp') is instantiated
- **THEN** an AssertionError is raised indicating only 'log' and 'log1p' are supported

### Requirement: Fit method
The NumericalTransformer SHALL implement a fit method that returns self.

#### Scenario: Fit operation
- **WHEN** fit(X) is called on NumericalTransformer
- **THEN** the transformer returns self without modifying state

### Requirement: Transform with log function
The NumericalTransformer SHALL apply natural logarithm transformation to all values in input data.

#### Scenario: Apply log transformation
- **WHEN** transform([1, 2, 3]) is called on NumericalTransformer('log')
- **THEN** result is [log(1), log(2), log(3)] with numpy applied

#### Scenario: Handle zero values in log
- **WHEN** transform contains a zero value and log is applied
- **THEN** the zero is handled appropriately (either skipped, use -inf, or user-specified handling)

### Requirement: Transform with log1p function
The NumericalTransformer SHALL apply log(1+x) transformation to all values.

#### Scenario: Apply log1p transformation
- **WHEN** transform([0, 1, 2]) is called on NumericalTransformer('log1p')
- **THEN** result is [log(1), log(2), log(3)]

#### Scenario: Handle negative values in log1p
- **WHEN** log1p encounters negative values
- **THEN** values are handled appropriately with clear error messages

### Requirement: Support pandas and numpy input
The NumericalTransformer SHALL accept both pandas.DataFrame/Series and numpy.ndarray as input.

#### Scenario: Transform pandas Series
- **WHEN** transform(pd.Series([1, 2, 3])) is called
- **THEN** the result is transformed correctly

#### Scenario: Transform numpy array
- **WHEN** transform(np.array([1, 2, 3])) is called
- **THEN** the result is transformed correctly

### Requirement: Error handling for boundary values
The NumericalTransformer SHALL provide clear error messages for problematic input.

#### Scenario: Clear error on invalid input
- **WHEN** transform receives input that cannot be transformed
- **THEN** a clear error message is raised indicating the column and issue
