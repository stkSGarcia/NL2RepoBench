## ADDED Requirements

### Requirement: Column context in exceptions
When an exception occurs during fit or transform, the exception message SHALL include the column name being processed.

#### Scenario: Transform exception with column
- **WHEN** a transformer raises an exception during transform on column 'col_a'
- **THEN** the exception message includes 'col_a: [original error message]'

#### Scenario: Fit exception with column
- **WHEN** a transformer raises an exception during fit on column 'feat1'
- **THEN** the exception message includes 'feat1: [original error message]'

### Requirement: Clear error messages
Error messages SHALL be clear and actionable, identifying the problematic column and transformer.

#### Scenario: Informative failure
- **WHEN** a transformer fails on a column
- **THEN** error message clearly states which column, which transformer, and what went wrong

### Requirement: Exception propagation
Exceptions from transformers SHALL be caught, enriched with context, and re-raised.

#### Scenario: Exception preservation
- **WHEN** a transformer raises an exception
- **THEN** the original exception type is preserved or wrapped appropriately
