## ADDED Requirements

### Requirement: DataFrameMapper initialization
The DataFrameMapper class SHALL accept a features list, default transformer, sparse flag, DataFrame output flag, input_df flag, and drop_cols parameter during initialization.

#### Scenario: Initialize with features and defaults
- **WHEN** DataFrameMapper is instantiated with features=[ ('col', transformer) ], default=False, sparse=False, df_out=False
- **THEN** the mapper stores these configurations and validates that df_out and (sparse or default) are not simultaneously True

#### Scenario: Initialize with default transformer
- **WHEN** DataFrameMapper is instantiated with default=StandardScaler()
- **THEN** the mapper applies the default transformer to columns not explicitly listed in features

### Requirement: Column mapping to transformers
The DataFrameMapper SHALL map DataFrame columns to Scikit-Learn transformers, supporting both single and multiple columns per transformer.

#### Scenario: Map single column
- **WHEN** fit_transform is called on DataFrameMapper([('col_a', StandardScaler())]) with a DataFrame
- **THEN** the transformer is applied to col_a and returns transformed data

#### Scenario: Map multiple columns
- **WHEN** fit_transform is called on DataFrameMapper([(['col_a', 'col_b'], PCA(2))]) with a DataFrame
- **THEN** PCA is applied jointly to col_a and col_b, returning 2 principal components

### Requirement: None transformer passthrough
The DataFrameMapper SHALL pass columns through unchanged when transformer is None.

#### Scenario: Passthrough with None
- **WHEN** fit_transform is called on DataFrameMapper([('col_a', None)], df_out=True)
- **THEN** col_a is returned unchanged in the output DataFrame

### Requirement: Sparse matrix output
The DataFrameMapper SHALL return sparse matrices when sparse=True and any transformer produces sparse output.

#### Scenario: Sparse matrix generation
- **WHEN** fit_transform is called on DataFrameMapper([('col_a', ToSparseTransformer())], sparse=True)
- **THEN** the output is a scipy.sparse.csr_matrix

#### Scenario: Dense matrix when sparse=False
- **WHEN** fit_transform is called on DataFrameMapper([('col_a', ToSparseTransformer())], sparse=False)
- **THEN** the output is converted to a dense numpy.ndarray

### Requirement: DataFrame output preservation
The DataFrameMapper SHALL return a pandas DataFrame when df_out=True, with intelligently named columns.

#### Scenario: Simple DataFrame output
- **WHEN** fit_transform is called on DataFrameMapper([('col_a', None)], df_out=True)
- **THEN** the output is a pandas.DataFrame with column name 'col_a'

#### Scenario: Multi-column transformed output naming
- **WHEN** fit_transform is called on DataFrameMapper([(['col_a', 'col_b'], transformer)], df_out=True) producing 2 outputs
- **THEN** columns are named 'col_a_col_b_0' and 'col_a_col_b_1'

### Requirement: Fit and transform methods
The DataFrameMapper SHALL implement fit(), transform(), and fit_transform() methods compatible with Scikit-Learn.

#### Scenario: Fit operation
- **WHEN** fit() is called on DataFrameMapper with a DataFrame
- **THEN** all transformers in features are fitted to their respective columns

#### Scenario: Transform operation
- **WHEN** transform() is called after fit() on new data
- **THEN** data is transformed using the fitted transformers

#### Scenario: Fit-transform operation
- **WHEN** fit_transform() is called on DataFrameMapper with a DataFrame
- **THEN** transformers are fitted and data is transformed in one operation

### Requirement: Input as DataFrame or Series
The DataFrameMapper SHALL accept input_df=True to pass selected columns as pandas DataFrame/Series to transformers.

#### Scenario: Input as DataFrame
- **WHEN** fit_transform is called with input_df=True
- **THEN** transformers receive pandas DataFrame/Series objects instead of numpy arrays

### Requirement: Column dropping
The DataFrameMapper SHALL support dropping specified columns via drop_cols parameter.

#### Scenario: Drop columns
- **WHEN** fit_transform is called with drop_cols=['drop_me']
- **THEN** 'drop_me' column is excluded from output

### Requirement: Default transformer for unselected columns
The DataFrameMapper SHALL apply a default transformer to all columns not explicitly in features.

#### Scenario: Default transformer application
- **WHEN** default=StandardScaler() and only 'col_a' is in features
- **THEN** StandardScaler is applied to all other columns as a group

#### Scenario: Default None passes through unselected
- **WHEN** default=None and only 'col_a' is in features
- **THEN** unselected columns are passed through unchanged
