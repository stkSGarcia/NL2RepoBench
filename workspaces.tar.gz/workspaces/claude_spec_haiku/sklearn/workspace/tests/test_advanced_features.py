import pytest
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, OneHotEncoder
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, f_classif
from scipy import sparse

from sklearn_pandas import DataFrameMapper


class TestAdvancedFeatures:
    """Test advanced DataFrameMapper features."""

    def test_pca_dimensionality_reduction(self, complex_dataframe):
        """Test PCA dimensionality reduction on multi-column features."""
        mapper = DataFrameMapper([
            (['col_a', 'col_d'], PCA(n_components=1))
        ])
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape == (5, 1)

    def test_select_kbest_feature_selection(self, iris_dataframe):
        """Test SelectKBest feature selection with y parameter."""
        X = iris_dataframe.drop('target', axis=1)
        y = iris_dataframe['target']

        mapper = DataFrameMapper([
            (['sepal length (cm)', 'sepal width (cm)', 'petal length (cm)', 'petal width (cm)'],
             SelectKBest(f_classif, k=2))
        ])
        result = mapper.fit_transform(X, y)
        assert result.shape == (150, 2)

    def test_sparse_matrix_output(self, complex_dataframe):
        """Test sparse matrix output (sparse=True)."""
        encoder = OneHotEncoder(sparse_output=True)
        mapper = DataFrameMapper([
            ('col_c', encoder)
        ], sparse=True)
        result = mapper.fit_transform(complex_dataframe)
        assert sparse.issparse(result)
        assert result.shape[0] == 5

    def test_sparse_to_dense_conversion(self, complex_dataframe):
        """Test sparse-to-dense conversion (sparse=False)."""
        encoder = OneHotEncoder(sparse_output=True)
        mapper = DataFrameMapper([
            ('col_c', encoder)
        ], sparse=False)
        result = mapper.fit_transform(complex_dataframe)
        assert isinstance(result, np.ndarray)
        assert not sparse.issparse(result)

    def test_default_false(self, complex_dataframe):
        """Test default=False drops unselected columns."""
        mapper = DataFrameMapper([
            ('col_a', None)
        ], default=False)
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape[1] == 1

    def test_default_none(self, complex_dataframe):
        """Test default=None passes through unselected columns."""
        mapper = DataFrameMapper([
            ('col_a', StandardScaler())
        ], default=None)
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape[1] == 4

    def test_default_transformer(self, complex_dataframe):
        """Test default transformer applied to unselected columns."""
        mapper = DataFrameMapper([
            ('col_c', OneHotEncoder(sparse_output=False))
        ], default=StandardScaler())
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape[0] == 5

    def test_input_df_parameter(self, complex_dataframe):
        """Test input_df parameter (DataFrame input to transformers)."""
        from sklearn.preprocessing import FunctionTransformer

        def check_input(X):
            assert isinstance(X, (pd.DataFrame, pd.Series))
            return X

        mapper = DataFrameMapper([
            ('col_a', FunctionTransformer(check_input))
        ], input_df=True)
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape[0] == 5

    def test_drop_cols_parameter(self, complex_dataframe):
        """Test drop_cols parameter."""
        mapper = DataFrameMapper([
            ('col_a', None),
            ('col_b', None),
        ], drop_cols=['col_b'])
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape[1] == 1

    def test_callable_column_selector(self, complex_dataframe):
        """Test callable column selectors."""
        def numeric_cols(X):
            return X.select_dtypes(include=['number']).columns

        mapper = DataFrameMapper([
            (numeric_cols, StandardScaler())
        ])
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape == (5, 3)

    def test_make_column_selector_integration(self, complex_dataframe):
        """Test make_column_selector integration."""
        try:
            from sklearn.compose import make_column_selector

            selector = make_column_selector(dtype_include=['number'])
            mapper = DataFrameMapper([
                (selector, StandardScaler())
            ])
            result = mapper.fit_transform(complex_dataframe)
            assert result.shape[0] == 5
        except ImportError:
            pytest.skip("make_column_selector not available")

    def test_column_order_preservation(self, complex_dataframe):
        """Test column order preservation."""
        mapper = DataFrameMapper([
            ('col_d', None),
            ('col_a', None),
            ('col_b', None),
        ])
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape == (5, 3)
