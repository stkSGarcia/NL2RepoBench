import pytest
import pandas as pd
from sklearn.preprocessing import LabelBinarizer

from sklearn_pandas import DataFrameMapper


class TestNaming:
    """Test output column naming features."""

    def test_transformed_names_simple(self, simple_dataframe):
        """Test transformed_names_ attribute for simple features."""
        mapper = DataFrameMapper([('col_a', None)])
        mapper.fit_transform(simple_dataframe)
        assert mapper.transformed_names_ == ['col_a']

    def test_transformed_names_label_binarizer(self, iris_dataframe):
        """Test transformed_names_ for LabelBinarizer."""
        mapper = DataFrameMapper([
            ('target', LabelBinarizer())
        ])
        mapper.fit_transform(iris_dataframe)
        assert len(mapper.transformed_names_) == 3

    def test_unicode_feature_name_generation(self):
        """Test Unicode feature name generation."""
        df = pd.DataFrame({
            'café': [1, 2, 3],
            'naïve': [4, 5, 6],
        })
        mapper = DataFrameMapper([
            ('café', None),
            ('naïve', None),
        ], df_out=True)
        result = mapper.fit_transform(df)
        assert 'café' in result.columns
        assert 'naïve' in result.columns

    def test_custom_alias_naming(self, simple_dataframe):
        """Test custom alias naming."""
        mapper = DataFrameMapper([
            ('col_a', None, {'alias': 'my_col'})
        ], df_out=True)
        result = mapper.fit_transform(simple_dataframe)
        assert 'my_col' in result.columns

    def test_prefix_and_suffix_naming(self, simple_dataframe):
        """Test prefix and suffix naming in output."""
        mapper = DataFrameMapper([
            ('col_a', None, {'prefix': 'pre_', 'suffix': '_suf'})
        ], df_out=True)
        result = mapper.fit_transform(simple_dataframe)
        assert 'pre_col_a_suf' in result.columns
