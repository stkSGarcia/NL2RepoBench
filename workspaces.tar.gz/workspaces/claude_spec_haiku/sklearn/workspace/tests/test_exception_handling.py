import pytest
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler

from sklearn_pandas import DataFrameMapper


class FailingTransformer:
    """A transformer that always fails."""

    def fit(self, X, y=None):
        raise ValueError("Intentional fit failure")

    def transform(self, X):
        raise ValueError("Intentional transform failure")

    def fit_transform(self, X, y=None):
        raise ValueError("Intentional fit_transform failure")


class TestExceptionHandling:
    """Test exception handling with column context."""

    def test_column_context_in_transform_exceptions(self, simple_dataframe):
        """Test column context in transform exceptions."""
        mapper = DataFrameMapper([('col_a', FailingTransformer())])
        mapper.fit(simple_dataframe)

        with pytest.raises(ValueError) as exc_info:
            mapper.transform(simple_dataframe)

        error_msg = str(exc_info.value)
        assert 'col_a' in error_msg or 'Intentional' in error_msg

    def test_column_context_in_fit_exceptions(self, simple_dataframe):
        """Test column context in fit exceptions."""
        mapper = DataFrameMapper([('col_a', FailingTransformer())])

        with pytest.raises(ValueError):
            mapper.fit(simple_dataframe)

    def test_failing_transformer_exception_handling(self, simple_dataframe):
        """Test FailingTransformer exception handling."""
        mapper = DataFrameMapper([('col_a', FailingTransformer())])

        with pytest.raises(ValueError):
            mapper.fit_transform(simple_dataframe)

    def test_exception_message_formatting(self, simple_dataframe):
        """Test exception message formatting."""
        class DescriptiveFailingTransformer:
            def fit(self, X, y=None):
                raise ValueError("Invalid value in column")

            def transform(self, X):
                raise ValueError("Cannot transform: negative value")

            def fit_transform(self, X, y=None):
                raise ValueError("Fit-transform failed")

        mapper = DataFrameMapper([('col_a', DescriptiveFailingTransformer())])

        with pytest.raises(ValueError):
            mapper.fit_transform(simple_dataframe)

    def test_multi_column_exception_context(self, complex_dataframe):
        """Test exception context for multi-column transformers."""
        mapper = DataFrameMapper([
            (['col_a', 'col_d'], FailingTransformer())
        ])

        with pytest.raises(ValueError):
            mapper.fit(complex_dataframe)

    def test_exception_preservation(self, simple_dataframe):
        """Test that exception type is preserved."""
        class CustomException(Exception):
            pass

        class CustomFailingTransformer:
            def fit(self, X, y=None):
                raise CustomException("Custom error")

            def transform(self, X):
                raise CustomException("Custom error")

            def fit_transform(self, X, y=None):
                raise CustomException("Custom error")

        mapper = DataFrameMapper([('col_a', CustomFailingTransformer())])

        with pytest.raises((ValueError, CustomException)):
            mapper.fit(simple_dataframe)
