import pytest
import pandas as pd
import numpy as np
from sklearn import datasets


@pytest.fixture
def simple_dataframe():
    """Simple DataFrame with single column."""
    return pd.DataFrame({
        'col_a': [1, 2, 3, 4, 5],
    })


@pytest.fixture
def complex_dataframe():
    """Complex DataFrame with multiple columns of different types."""
    return pd.DataFrame({
        'col_a': [1.0, 2.0, 3.0, 4.0, 5.0],
        'col_b': [10, 20, 30, 40, 50],
        'col_c': ['a', 'b', 'c', 'd', 'e'],
        'col_d': [1.5, 2.5, 3.5, 4.5, 5.5],
    })


@pytest.fixture
def complex_object_dataframe():
    """Complex DataFrame with 2D object columns."""
    return pd.DataFrame({
        'col_a': [[1, 2], [3, 4], [5, 6], [7, 8], [9, 10]],
        'col_b': [[1.0, 2.0], [3.0, 4.0], [5.0, 6.0], [7.0, 8.0], [9.0, 10.0]],
        'col_c': ['a', 'b', 'c', 'd', 'e'],
    })


@pytest.fixture
def iris_dataframe():
    """Iris dataset as DataFrame."""
    iris = datasets.load_iris()
    df = pd.DataFrame(iris.data, columns=iris.feature_names)
    df['target'] = iris.target
    return df


@pytest.fixture
def cars_dataframe():
    """Cars dataset for text classification example."""
    return pd.DataFrame({
        'text': [
            'A fast red car',
            'The blue car is slow',
            'Fast vehicles go quickly',
            'Slow cars move slowly',
            'Red and blue cars',
        ],
        'category': ['car', 'car', 'vehicle', 'car', 'car'],
        'speed': [10, 5, 20, 3, 8],
    })
