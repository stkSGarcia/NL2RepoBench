import pytest
import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, LabelBinarizer, OneHotEncoder
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, f_classif
from scipy import sparse

from sklearn_pandas import DataFrameMapper


class TestDataFrameMapperBasic:
    """Test basic DataFrameMapper functionality."""

    def test_simple_dataframe_no_transformer(self, simple_dataframe):
        """Test DataFrameMapper with simple DataFrame and None transformer."""
        mapper = DataFrameMapper([('col_a', None)])
        result = mapper.fit_transform(simple_dataframe)
        assert isinstance(result, np.ndarray)
        assert result.shape == (5, 1)
        np.testing.assert_array_equal(result, simple_dataframe[['col_a']].values)

    def test_complex_dataframe(self, complex_dataframe):
        """Test DataFrameMapper with complex DataFrame."""
        mapper = DataFrameMapper([
            ('col_a', StandardScaler()),
            ('col_d', StandardScaler()),
        ])
        result = mapper.fit_transform(complex_dataframe)
        assert isinstance(result, np.ndarray)
        assert result.shape == (5, 2)

    def test_none_transformer_passthrough(self, simple_dataframe):
        """Test that None transformer passes data through unchanged."""
        mapper = DataFrameMapper([('col_a', None)])
        X_transformed = mapper.fit_transform(simple_dataframe)
        np.testing.assert_array_equal(
            X_transformed,
            simple_dataframe[['col_a']].values
        )

    def test_single_column_transformation(self, simple_dataframe):
        """Test single column transformation with StandardScaler."""
        mapper = DataFrameMapper([('col_a', StandardScaler())])
        result = mapper.fit_transform(simple_dataframe)
        assert result.shape == (5, 1)

    def test_multi_column_transformation(self, complex_dataframe):
        """Test multi-column transformation with PCA."""
        mapper = DataFrameMapper([
            (['col_a', 'col_d'], PCA(n_components=1))
        ])
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape == (5, 1)

    def test_label_binarizer_string_categories(self, complex_dataframe):
        """Test LabelBinarizer with string categories."""
        mapper = DataFrameMapper([
            ('col_c', LabelBinarizer())
        ])
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape == (5, 5)

    def test_label_binarizer_integer_categories(self, iris_dataframe):
        """Test LabelBinarizer with integer categories."""
        mapper = DataFrameMapper([
            ('target', LabelBinarizer())
        ])
        result = mapper.fit_transform(iris_dataframe)
        assert result.shape[0] == 150
        assert result.shape[1] == 3

    def test_one_hot_encoder(self, complex_dataframe):
        """Test OneHotEncoder encoding."""
        encoder = OneHotEncoder(sparse_output=False)
        mapper = DataFrameMapper([
            ('col_c', encoder)
        ])
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape[0] == 5
        assert result.shape[1] > 1


class TestDataFrameMapperAdvanced:
    """Test advanced DataFrameMapper features."""

    def test_sparse_matrix_output(self, simple_dataframe):
        """Test sparse matrix output."""
        encoder = OneHotEncoder(sparse_output=True)
        mapper = DataFrameMapper([
            ('col_a', encoder)
        ], sparse=True)
        result = mapper.fit_transform(simple_dataframe)
        assert sparse.issparse(result)

    def test_sparse_to_dense_conversion(self, simple_dataframe):
        """Test sparse-to-dense conversion."""
        encoder = OneHotEncoder(sparse_output=True)
        mapper = DataFrameMapper([
            ('col_a', encoder)
        ], sparse=False)
        result = mapper.fit_transform(simple_dataframe)
        assert isinstance(result, np.ndarray)
        assert not sparse.issparse(result)

    def test_default_transformer_false(self, complex_dataframe):
        """Test default=False drops unselected columns."""
        mapper = DataFrameMapper([
            ('col_a', None),
        ], default=False)
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape[1] == 1

    def test_default_transformer_none(self, complex_dataframe):
        """Test default=None passes through unselected columns."""
        mapper = DataFrameMapper([
            ('col_a', StandardScaler()),
        ], default=None)
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape[1] == 4

    def test_default_transformer_instance(self, complex_dataframe):
        """Test default transformer application."""
        mapper = DataFrameMapper([
            ('col_a', StandardScaler()),
        ], default=StandardScaler())
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape[1] >= 4

    def test_input_df_parameter(self, complex_dataframe):
        """Test input_df parameter passes DataFrame to transformers."""
        from sklearn.preprocessing import FunctionTransformer

        def shape_check(X):
            assert isinstance(X, (pd.DataFrame, pd.Series))
            return X

        mapper = DataFrameMapper([
            ('col_a', FunctionTransformer(shape_check))
        ], input_df=True)
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape[0] == 5

    def test_drop_cols_parameter(self, complex_dataframe):
        """Test drop_cols parameter."""
        mapper = DataFrameMapper([
            ('col_a', None),
            ('col_b', None),
        ], drop_cols=['col_b'])
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape[1] == 1

    def test_callable_column_selector(self, complex_dataframe):
        """Test callable column selector."""
        def numeric_cols(X):
            return X.select_dtypes(include=['number']).columns

        mapper = DataFrameMapper([
            (numeric_cols, StandardScaler())
        ])
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape[0] == 5
        assert result.shape[1] == 3

    def test_column_order_preservation(self, complex_dataframe):
        """Test column order preservation."""
        mapper = DataFrameMapper([
            ('col_d', None),
            ('col_a', None),
            ('col_b', None),
        ])
        result = mapper.fit_transform(complex_dataframe)
        assert result.shape == (5, 3)


class TestDataFrameMapperNaming:
    """Test output naming features."""

    def test_transformed_names_simple(self, simple_dataframe):
        """Test transformed_names_ attribute for simple features."""
        mapper = DataFrameMapper([('col_a', None)])
        mapper.fit_transform(simple_dataframe)
        assert mapper.transformed_names_ == ['col_a']

    def test_transformed_names_label_binarizer(self, iris_dataframe):
        """Test transformed_names_ for LabelBinarizer."""
        mapper = DataFrameMapper([
            ('target', LabelBinarizer())
        ])
        mapper.fit_transform(iris_dataframe)
        assert len(mapper.transformed_names_) == 3

    def test_alias_naming(self, simple_dataframe):
        """Test custom alias naming."""
        mapper = DataFrameMapper([
            ('col_a', None, {'alias': 'my_col'})
        ], df_out=True)
        result = mapper.fit_transform(simple_dataframe)
        assert 'my_col' in result.columns

    def test_prefix_suffix_naming(self, simple_dataframe):
        """Test prefix and suffix naming."""
        mapper = DataFrameMapper([
            ('col_a', None, {'prefix': 'pre_', 'suffix': '_post'})
        ], df_out=True)
        result = mapper.fit_transform(simple_dataframe)
        assert 'pre_col_a_post' in result.columns


class TestDataFrameMapperOutput:
    """Test output format options."""

    def test_dataframe_output(self, simple_dataframe):
        """Test DataFrame output."""
        mapper = DataFrameMapper([('col_a', None)], df_out=True)
        result = mapper.fit_transform(simple_dataframe)
        assert isinstance(result, pd.DataFrame)

    def test_numpy_output_default(self, simple_dataframe):
        """Test numpy array output (default)."""
        mapper = DataFrameMapper([('col_a', None)])
        result = mapper.fit_transform(simple_dataframe)
        assert isinstance(result, np.ndarray)


class TestDataFrameMapperFitTransform:
    """Test fit/transform methods."""

    def test_fit_method(self, simple_dataframe):
        """Test fit method."""
        mapper = DataFrameMapper([('col_a', StandardScaler())])
        mapper.fit(simple_dataframe)
        assert hasattr(mapper, '_features')

    def test_transform_method(self, simple_dataframe):
        """Test transform method after fit."""
        mapper = DataFrameMapper([('col_a', StandardScaler())])
        mapper.fit(simple_dataframe)
        result = mapper.transform(simple_dataframe)
        assert isinstance(result, np.ndarray)

    def test_fit_transform_method(self, simple_dataframe):
        """Test fit_transform method."""
        mapper = DataFrameMapper([('col_a', StandardScaler())])
        result = mapper.fit_transform(simple_dataframe)
        assert isinstance(result, np.ndarray)
