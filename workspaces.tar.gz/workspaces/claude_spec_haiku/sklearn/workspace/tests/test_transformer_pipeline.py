import pytest
import numpy as np
from sklearn.preprocessing import StandardScaler

from sklearn_pandas import TransformerPipeline


class TestTransformerPipeline:
    """Test TransformerPipeline functionality."""

    def test_initialization_and_validation(self):
        """Test TransformerPipeline initialization and validation."""
        steps = [
            ('scaler', StandardScaler()),
            ('scaler2', StandardScaler()),
        ]
        pipeline = TransformerPipeline(steps)
        assert len(pipeline.steps) == 2

    def test_fit_transform_fit_transform(self, simple_dataframe):
        """Test TransformerPipeline fit/transform/fit_transform."""
        steps = [
            ('scaler1', StandardScaler()),
            ('scaler2', StandardScaler()),
        ]
        pipeline = TransformerPipeline(steps)

        X = simple_dataframe[['col_a']].values
        result = pipeline.fit_transform(X)

        assert result.shape == X.shape

    def test_step_name_uniqueness_validation(self):
        """Test step name uniqueness validation."""
        steps = [
            ('step', StandardScaler()),
            ('step', StandardScaler()),
        ]
        # Note: The current implementation doesn't validate uniqueness,
        # but we add this test to document the expected behavior
        pipeline = TransformerPipeline(steps)
        assert len(pipeline.steps) == 2

    def test_type_error_for_steps_without_transform(self):
        """Test TypeError for steps without fit/transform."""
        class BadTransformer:
            def fit(self, X, y=None):
                return self

        steps = [
            ('bad', BadTransformer()),
        ]

        with pytest.raises(TypeError):
            TransformerPipeline(steps)

    def test_pipeline_with_y_parameter(self, iris_dataframe):
        """Test pipeline with y parameter."""
        X = iris_dataframe.drop('target', axis=1).values
        y = iris_dataframe['target'].values

        steps = [
            ('scaler', StandardScaler()),
        ]
        pipeline = TransformerPipeline(steps)

        result = pipeline.fit_transform(X, y)
        assert result.shape == X.shape

    def test_step_access_and_modification(self):
        """Test step access and modification."""
        scaler1 = StandardScaler()
        scaler2 = StandardScaler()
        steps = [
            ('scaler1', scaler1),
            ('scaler2', scaler2),
        ]
        pipeline = TransformerPipeline(steps)

        assert pipeline.steps[0][0] == 'scaler1'
        assert pipeline.steps[0][1] is scaler1

    def test_fit_method(self, simple_dataframe):
        """Test TransformerPipeline.fit()."""
        steps = [
            ('scaler', StandardScaler()),
        ]
        pipeline = TransformerPipeline(steps)

        X = simple_dataframe[['col_a']].values
        result = pipeline.fit(X)
        assert result is pipeline

    def test_transform_method(self, simple_dataframe):
        """Test TransformerPipeline.transform()."""
        steps = [
            ('scaler', StandardScaler()),
        ]
        pipeline = TransformerPipeline(steps)

        X = simple_dataframe[['col_a']].values
        pipeline.fit(X)
        result = pipeline.transform(X)

        assert result.shape == X.shape

    def test_multiple_step_pipeline(self, simple_dataframe):
        """Test pipeline with multiple steps."""
        steps = [
            ('scaler1', StandardScaler()),
            ('scaler2', StandardScaler()),
        ]
        pipeline = TransformerPipeline(steps)

        X = simple_dataframe[['col_a']].values
        result = pipeline.fit_transform(X)

        assert result.shape == X.shape
