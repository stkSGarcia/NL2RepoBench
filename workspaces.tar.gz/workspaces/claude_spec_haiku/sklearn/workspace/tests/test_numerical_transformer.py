import pytest
import numpy as np
import pandas as pd
import warnings

from sklearn_pandas import NumericalTransformer


class TestNumericalTransformer:
    """Test NumericalTransformer functionality."""

    def test_deprecation_warning(self):
        """Test deprecation warning emission."""
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            NumericalTransformer('log')
            assert len(w) == 1
            assert issubclass(w[0].category, DeprecationWarning)

    def test_unsupported_function_validation(self):
        """Test unsupported function validation."""
        with pytest.raises(AssertionError):
            NumericalTransformer('exp')

    def test_log_transformation(self):
        """Test NumericalTransformer with 'log' function."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            transformer = NumericalTransformer('log')

        X = np.array([1, 2, 3, 4, 5]).reshape(-1, 1)
        result = transformer.fit_transform(X)

        expected = np.log(X)
        np.testing.assert_array_almost_equal(result, expected)

    def test_log1p_transformation(self):
        """Test NumericalTransformer with 'log1p' function."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            transformer = NumericalTransformer('log1p')

        X = np.array([0, 1, 2, 3, 4]).reshape(-1, 1)
        result = transformer.fit_transform(X)

        expected = np.log1p(X)
        np.testing.assert_array_almost_equal(result, expected)

    def test_boundary_value_handling_log_zero(self):
        """Test boundary value handling (zero in log)."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            transformer = NumericalTransformer('log')

        X = np.array([0, 1, 2]).reshape(-1, 1)
        with pytest.raises(ValueError):
            transformer.fit_transform(X)

    def test_boundary_value_handling_log_negative(self):
        """Test boundary value handling (negative in log)."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            transformer = NumericalTransformer('log')

        X = np.array([-1, 1, 2]).reshape(-1, 1)
        with pytest.raises(ValueError):
            transformer.fit_transform(X)

    def test_boundary_value_handling_log1p_negative(self):
        """Test boundary value handling (values < -1 in log1p)."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            transformer = NumericalTransformer('log1p')

        X = np.array([-2, 0, 1]).reshape(-1, 1)
        with pytest.raises(ValueError):
            transformer.fit_transform(X)

    def test_pandas_series_input(self):
        """Test transform with pandas Series."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            transformer = NumericalTransformer('log')

        X = pd.Series([1, 2, 3, 4, 5])
        result = transformer.fit_transform(X)

        expected = np.log(X.values.reshape(-1, 1))
        assert isinstance(result, pd.Series)
        np.testing.assert_array_almost_equal(result.values, expected.flatten())

    def test_pandas_dataframe_input(self):
        """Test transform with pandas DataFrame."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            transformer = NumericalTransformer('log')

        X = pd.DataFrame({'col': [1, 2, 3, 4, 5]})
        result = transformer.fit_transform(X)

        expected = np.log(X.values)
        assert isinstance(result, pd.DataFrame)
        np.testing.assert_array_almost_equal(result.values, expected)

    def test_fit_is_noop(self):
        """Test that fit is a no-op."""
        with warnings.catch_warnings():
            warnings.simplefilter("ignore")
            transformer = NumericalTransformer('log')

        X = np.array([1, 2, 3]).reshape(-1, 1)
        result = transformer.fit(X)
        assert result is transformer
