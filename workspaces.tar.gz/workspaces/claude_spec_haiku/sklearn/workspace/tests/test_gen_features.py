import pytest
from sklearn.preprocessing import StandardScaler

from sklearn_pandas import gen_features, DataFrameMapper


class TestGenFeatures:
    """Test gen_features functionality."""

    def test_gen_features_basic(self):
        """Test gen_features basic functionality."""
        features = gen_features(
            columns=['col_a', 'col_b'],
            classes=[StandardScaler]
        )

        assert len(features) == 2
        assert features[0][0] == 'col_a'
        assert features[1][0] == 'col_b'
        assert isinstance(features[0][1], StandardScaler)
        assert isinstance(features[1][1], StandardScaler)

    def test_gen_features_multiple_classes(self):
        """Test gen_features with multiple classes."""
        from sklearn.decomposition import PCA

        features = gen_features(
            columns=['col_a', 'col_b', 'col_c'],
            classes=[StandardScaler, PCA]
        )

        assert len(features) == 6
        assert isinstance(features[0][1], StandardScaler)
        assert isinstance(features[1][1], PCA)

    def test_gen_features_parametrized_classes(self):
        """Test gen_features with parametrized classes."""
        features = gen_features(
            columns=['col_a', 'col_b'],
            classes=[{'class': StandardScaler}]
        )

        assert len(features) == 2
        assert isinstance(features[0][1], StandardScaler)

    def test_gen_features_with_prefix_suffix(self):
        """Test gen_features with prefix/suffix."""
        features = gen_features(
            columns=['col_a'],
            classes=[StandardScaler],
            prefix='pre_',
            suffix='_suf'
        )

        assert len(features) == 1
        assert features[0][2]['prefix'] == 'pre_'
        assert features[0][2]['suffix'] == '_suf'

    def test_gen_features_in_dataframe_mapper(self, complex_dataframe):
        """Test gen_features output used with DataFrameMapper."""
        features = gen_features(
            columns=['col_a', 'col_b'],
            classes=[StandardScaler]
        )

        mapper = DataFrameMapper(features)
        result = mapper.fit_transform(complex_dataframe)

        assert result.shape[0] == 5
        assert result.shape[1] == 2

    def test_column_order_preservation(self):
        """Test column order preservation."""
        features = gen_features(
            columns=['z', 'a', 'm'],
            classes=[StandardScaler]
        )

        assert features[0][0] == 'z'
        assert features[1][0] == 'a'
        assert features[2][0] == 'm'

    def test_with_class_parameters(self):
        """Test gen_features with class parameters."""
        from sklearn.decomposition import PCA

        features = gen_features(
            columns=['col_a'],
            classes=[{'class': PCA, 'n_components': 1}]
        )

        assert len(features) == 1
        transformer = features[0][1]
        assert isinstance(transformer, PCA)
        assert transformer.n_components == 1
