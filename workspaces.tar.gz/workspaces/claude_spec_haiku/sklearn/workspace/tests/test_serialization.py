import pytest
import pickle
import tempfile
import os
from sklearn.preprocessing import StandardScaler

from sklearn_pandas import DataFrameMapper


class TestSerialization:
    """Test serialization/deserialization functionality."""

    def test_joblib_dump_load(self, simple_dataframe):
        """Test joblib.dump() and joblib.load() functionality."""
        try:
            import joblib
        except ImportError:
            pytest.skip("joblib not installed")

        mapper = DataFrameMapper([('col_a', StandardScaler())])
        mapper.fit(simple_dataframe)

        with tempfile.TemporaryDirectory() as tmpdir:
            path = os.path.join(tmpdir, 'mapper.pkl')
            joblib.dump(mapper, path)
            loaded = joblib.load(path)

            result_original = mapper.transform(simple_dataframe)
            result_loaded = loaded.transform(simple_dataframe)

            import numpy as np
            np.testing.assert_array_almost_equal(result_original, result_loaded)

    def test_identical_output_after_serialization(self, simple_dataframe):
        """Test identical output after serialization/deserialization."""
        mapper = DataFrameMapper([('col_a', StandardScaler())])
        mapper.fit(simple_dataframe)

        original_output = mapper.transform(simple_dataframe)

        pickled = pickle.dumps(mapper)
        loaded_mapper = pickle.loads(pickled)

        loaded_output = loaded_mapper.transform(simple_dataframe)

        import numpy as np
        np.testing.assert_array_almost_equal(original_output, loaded_output)

    def test_getstate_setstate_methods(self, simple_dataframe):
        """Test __getstate__ and __setstate__ methods."""
        mapper = DataFrameMapper([('col_a', StandardScaler())])
        mapper.fit(simple_dataframe)

        state = mapper.__getstate__()
        assert isinstance(state, dict)

        new_mapper = DataFrameMapper([('col_a', StandardScaler())])
        new_mapper.__setstate__(state)

        import numpy as np
        np.testing.assert_array_almost_equal(
            mapper.transform(simple_dataframe),
            new_mapper.transform(simple_dataframe)
        )

    def test_backward_compatibility(self, simple_dataframe):
        """Test backward compatibility with older state versions."""
        mapper = DataFrameMapper([('col_a', StandardScaler())])
        mapper.fit(simple_dataframe)

        pickled = pickle.dumps(mapper)
        loaded = pickle.loads(pickled)

        assert hasattr(loaded, 'features')
        assert hasattr(loaded, 'default')
        assert hasattr(loaded, 'sparse')
        assert hasattr(loaded, 'df_out')
