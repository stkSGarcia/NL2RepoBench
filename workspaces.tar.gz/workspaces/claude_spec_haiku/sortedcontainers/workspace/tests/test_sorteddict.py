import pytest
from sortedcontainers import SortedDict


class TestSortedDictBasics:

    def test_init_empty(self):
        sd = SortedDict()
        assert len(sd) == 0
        assert list(sd) == []

    def test_init_from_dict(self):
        sd = SortedDict({'z': 26, 'a': 1, 'm': 13})
        assert list(sd.keys()) == ['a', 'm', 'z']
        assert list(sd.values()) == [1, 13, 26]

    def test_init_from_pairs(self):
        sd = SortedDict([('z', 26), ('a', 1), ('m', 13)])
        assert list(sd.keys()) == ['a', 'm', 'z']

    def test_init_from_kwargs(self):
        sd = SortedDict(z=26, a=1, m=13)
        assert list(sd.keys()) == ['a', 'm', 'z']

    def test_getitem(self):
        sd = SortedDict({'a': 1, 'b': 2, 'c': 3})
        assert sd['a'] == 1
        assert sd['c'] == 3

    def test_getitem_missing(self):
        sd = SortedDict({'a': 1})
        with pytest.raises(KeyError):
            sd['missing']

    def test_setitem_new(self):
        sd = SortedDict()
        sd['b'] = 2
        sd['a'] = 1
        assert list(sd.keys()) == ['a', 'b']

    def test_setitem_update(self):
        sd = SortedDict({'a': 1, 'b': 2})
        sd['a'] = 10
        assert sd['a'] == 10

    def test_delitem(self):
        sd = SortedDict({'a': 1, 'b': 2, 'c': 3})
        del sd['b']
        assert list(sd.keys()) == ['a', 'c']
        assert sd['a'] == 1

    def test_delitem_missing(self):
        sd = SortedDict({'a': 1})
        with pytest.raises(KeyError):
            del sd['missing']

    def test_len(self):
        sd = SortedDict()
        assert len(sd) == 0
        sd['a'] = 1
        assert len(sd) == 1
        sd['b'] = 2
        assert len(sd) == 2

    def test_contains(self):
        sd = SortedDict({'a': 1, 'b': 2})
        assert 'a' in sd
        assert 'c' not in sd

    def test_iter(self):
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        assert list(sd) == ['a', 'b', 'c']

    def test_repr(self):
        sd = SortedDict({'a': 1, 'b': 2})
        assert 'SortedDict' in repr(sd)

    def test_bool(self):
        sd = SortedDict()
        assert not sd
        sd['a'] = 1
        assert sd


class TestSortedDictMethods:

    def test_get_default(self):
        sd = SortedDict({'a': 1})
        assert sd.get('a') == 1
        assert sd.get('missing') is None
        assert sd.get('missing', 'default') == 'default'

    def test_setdefault_existing(self):
        sd = SortedDict({'a': 1})
        assert sd.setdefault('a', 10) == 1
        assert sd['a'] == 1

    def test_setdefault_new(self):
        sd = SortedDict({'a': 1})
        assert sd.setdefault('b', 2) == 2
        assert sd['b'] == 2
        assert list(sd.keys()) == ['a', 'b']

    def test_update_dict(self):
        sd = SortedDict({'a': 1})
        sd.update({'c': 3, 'b': 2})
        assert list(sd.keys()) == ['a', 'b', 'c']

    def test_update_pairs(self):
        sd = SortedDict({'a': 1})
        sd.update([('c', 3), ('b', 2)])
        assert list(sd.keys()) == ['a', 'b', 'c']

    def test_update_kwargs(self):
        sd = SortedDict({'a': 1})
        sd.update(c=3, b=2)
        assert list(sd.keys()) == ['a', 'b', 'c']

    def test_pop_existing(self):
        sd = SortedDict({'a': 1, 'b': 2, 'c': 3})
        assert sd.pop('b') == 2
        assert list(sd.keys()) == ['a', 'c']

    def test_pop_missing_default(self):
        sd = SortedDict({'a': 1})
        assert sd.pop('missing', 'default') == 'default'

    def test_pop_missing_no_default(self):
        sd = SortedDict({'a': 1})
        with pytest.raises(KeyError):
            sd.pop('missing')

    def test_popitem(self):
        sd = SortedDict({'a': 1, 'b': 2, 'c': 3})
        key, value = sd.popitem()
        assert key == 'c'
        assert value == 3
        assert len(sd) == 2

    def test_popitem_empty(self):
        sd = SortedDict()
        with pytest.raises(KeyError):
            sd.popitem()

    def test_clear(self):
        sd = SortedDict({'a': 1, 'b': 2, 'c': 3})
        sd.clear()
        assert len(sd) == 0
        assert list(sd.keys()) == []

    def test_copy(self):
        sd = SortedDict({'a': 1, 'b': 2})
        sd2 = sd.copy()
        assert list(sd2.keys()) == ['a', 'b']
        sd2['c'] = 3
        assert 'c' not in sd


class TestSortedDictViews:

    def test_keys_view(self):
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        keys = sd.keys()
        assert list(keys) == ['a', 'b', 'c']
        assert len(keys) == 3
        assert 'a' in keys
        assert 'd' not in keys

    def test_keys_indexing(self):
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        keys = sd.keys()
        assert keys[0] == 'a'
        assert keys[-1] == 'c'

    def test_values_view(self):
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        values = sd.values()
        assert list(values) == [1, 2, 3]
        assert len(values) == 3
        assert 1 in values
        assert 10 not in values

    def test_values_indexing(self):
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        values = sd.values()
        assert values[0] == 1
        assert values[-1] == 3

    def test_items_view(self):
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        items = sd.items()
        assert list(items) == [('a', 1), ('b', 2), ('c', 3)]
        assert len(items) == 3
        assert ('a', 1) in items
        assert ('d', 4) not in items

    def test_items_indexing(self):
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        items = sd.items()
        assert items[0] == ('a', 1)
        assert items[-1] == ('c', 3)

    def test_view_dynamic_behavior(self):
        sd = SortedDict({'a': 1, 'b': 2})
        keys = sd.keys()
        assert len(keys) == 2
        sd['c'] = 3
        assert len(keys) == 3
        assert 'c' in keys


class TestSortedDictEdgeCases:

    def test_empty_dict(self):
        sd = SortedDict()
        assert len(sd) == 0
        assert list(sd.keys()) == []
        with pytest.raises(KeyError):
            sd.popitem()

    def test_single_item(self):
        sd = SortedDict({'a': 1})
        assert len(sd) == 1
        assert 'a' in sd
        key, value = sd.popitem()
        assert key == 'a'
        assert len(sd) == 0

    def test_numeric_keys(self):
        sd = SortedDict([(3, 'c'), (1, 'a'), (2, 'b')])
        assert list(sd.keys()) == [1, 2, 3]
        assert list(sd.values()) == ['a', 'b', 'c']

    def test_large_dataset(self):
        sd = SortedDict()
        for i in range(1000, 0, -1):
            sd[i] = i * 2
        assert len(sd) == 1000
        assert list(sd.keys())[:5] == [1, 2, 3, 4, 5]
        assert list(sd.keys())[-5:] == [996, 997, 998, 999, 1000]
