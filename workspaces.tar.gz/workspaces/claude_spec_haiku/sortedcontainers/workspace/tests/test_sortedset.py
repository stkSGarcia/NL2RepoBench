import pytest
from sortedcontainers import SortedSet


class TestSortedSetBasics:

    def test_init_empty(self):
        ss = SortedSet()
        assert len(ss) == 0
        assert list(ss) == []

    def test_init_from_iterable(self):
        ss = SortedSet([5, 3, 1, 4, 1, 5, 2])
        assert list(ss) == [1, 2, 3, 4, 5]

    def test_add_new(self):
        ss = SortedSet()
        ss.add(1)
        assert 1 in ss
        ss.add(3)
        ss.add(2)
        assert list(ss) == [1, 2, 3]

    def test_add_duplicate(self):
        ss = SortedSet([1, 2, 3])
        ss.add(2)
        assert list(ss) == [1, 2, 3]

    def test_discard_existing(self):
        ss = SortedSet([1, 2, 3, 4, 5])
        ss.discard(3)
        assert list(ss) == [1, 2, 4, 5]

    def test_discard_missing(self):
        ss = SortedSet([1, 2, 3])
        ss.discard(10)
        assert list(ss) == [1, 2, 3]

    def test_remove_existing(self):
        ss = SortedSet([1, 2, 3, 4, 5])
        ss.remove(3)
        assert list(ss) == [1, 2, 4, 5]

    def test_remove_missing(self):
        ss = SortedSet([1, 2, 3])
        with pytest.raises(KeyError):
            ss.remove(10)

    def test_pop(self):
        ss = SortedSet([1, 2, 3, 4, 5])
        val = ss.pop()
        assert val == 5
        assert list(ss) == [1, 2, 3, 4]

    def test_pop_empty(self):
        ss = SortedSet()
        with pytest.raises(KeyError):
            ss.pop()

    def test_clear(self):
        ss = SortedSet([1, 2, 3, 4, 5])
        ss.clear()
        assert len(ss) == 0
        assert list(ss) == []

    def test_contains(self):
        ss = SortedSet([1, 2, 3, 4, 5])
        assert 3 in ss
        assert 10 not in ss

    def test_iter(self):
        ss = SortedSet([5, 1, 3, 2, 4])
        assert list(ss) == [1, 2, 3, 4, 5]

    def test_reversed(self):
        ss = SortedSet([1, 2, 3, 4, 5])
        assert list(reversed(ss)) == [5, 4, 3, 2, 1]

    def test_len(self):
        ss = SortedSet()
        assert len(ss) == 0
        ss.add(1)
        assert len(ss) == 1
        ss.add(2)
        assert len(ss) == 2

    def test_repr(self):
        ss = SortedSet([1, 2, 3])
        assert 'SortedSet' in repr(ss)

    def test_bool(self):
        ss = SortedSet()
        assert not ss
        ss.add(1)
        assert ss


class TestSortedSetSequenceOps:

    def test_getitem_single(self):
        ss = SortedSet([1, 2, 3, 4, 5])
        assert ss[0] == 1
        assert ss[2] == 3
        assert ss[-1] == 5

    def test_getitem_slice(self):
        ss = SortedSet([1, 2, 3, 4, 5])
        result = ss[1:3]
        assert isinstance(result, SortedSet)
        assert list(result) == [2, 3]

    def test_copy(self):
        ss = SortedSet([1, 2, 3, 4, 5])
        ss2 = ss.copy()
        assert list(ss2) == [1, 2, 3, 4, 5]
        ss2.add(10)
        assert 10 not in ss
        assert 10 in ss2


class TestSortedSetSetOps:

    def test_union_basic(self):
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([3, 4, 5])
        result = ss1.union(ss2)
        assert list(result) == [1, 2, 3, 4, 5]

    def test_union_operator(self):
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([3, 4, 5])
        result = ss1 | ss2
        assert list(result) == [1, 2, 3, 4, 5]

    def test_union_ior(self):
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([3, 4, 5])
        ss1 |= ss2
        assert list(ss1) == [1, 2, 3, 4, 5]

    def test_update(self):
        ss1 = SortedSet([1, 2, 3])
        ss1.update([3, 4, 5])
        assert list(ss1) == [1, 2, 3, 4, 5]

    def test_intersection_basic(self):
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([3, 4, 5, 6])
        result = ss1.intersection(ss2)
        assert list(result) == [3, 4]

    def test_intersection_operator(self):
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([3, 4, 5, 6])
        result = ss1 & ss2
        assert list(result) == [3, 4]

    def test_intersection_iand(self):
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([3, 4, 5, 6])
        ss1 &= ss2
        assert list(ss1) == [3, 4]

    def test_difference_basic(self):
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([3, 4, 5, 6])
        result = ss1.difference(ss2)
        assert list(result) == [1, 2]

    def test_difference_operator(self):
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([3, 4, 5, 6])
        result = ss1 - ss2
        assert list(result) == [1, 2]

    def test_difference_isub(self):
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([3, 4, 5, 6])
        ss1 -= ss2
        assert list(ss1) == [1, 2]

    def test_symmetric_difference_basic(self):
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([3, 4, 5, 6])
        result = ss1.symmetric_difference(ss2)
        assert list(result) == [1, 2, 5, 6]

    def test_symmetric_difference_operator(self):
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([3, 4, 5, 6])
        result = ss1 ^ ss2
        assert list(result) == [1, 2, 5, 6]

    def test_symmetric_difference_ixor(self):
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([3, 4, 5, 6])
        ss1 ^= ss2
        assert list(ss1) == [1, 2, 5, 6]

    def test_isdisjoint(self):
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([4, 5, 6])
        ss3 = SortedSet([3, 4, 5])
        assert ss1.isdisjoint(ss2)
        assert not ss1.isdisjoint(ss3)


class TestSortedSetComparison:

    def test_equal(self):
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([3, 1, 2])
        assert ss1 == ss2

    def test_not_equal(self):
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([1, 2, 4])
        assert ss1 != ss2

    def test_less_than(self):
        ss1 = SortedSet([1, 2])
        ss2 = SortedSet([1, 2, 3])
        assert ss1 < ss2
        assert not ss2 < ss1

    def test_less_than_or_equal(self):
        ss1 = SortedSet([1, 2])
        ss2 = SortedSet([1, 2, 3])
        ss3 = SortedSet([1, 2])
        assert ss1 <= ss2
        assert ss1 <= ss3

    def test_greater_than(self):
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([1, 2])
        assert ss1 > ss2
        assert not ss2 > ss1

    def test_greater_than_or_equal(self):
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([1, 2])
        ss3 = SortedSet([1, 2, 3])
        assert ss1 >= ss2
        assert ss1 >= ss3


class TestSortedSetEdgeCases:

    def test_empty_set(self):
        ss = SortedSet()
        assert len(ss) == 0
        with pytest.raises(KeyError):
            ss.pop()

    def test_single_element(self):
        ss = SortedSet([42])
        assert len(ss) == 1
        assert 42 in ss
        assert ss[0] == 42

    def test_large_dataset(self):
        data = list(range(1000, 0, -1))
        ss = SortedSet(data)
        assert len(ss) == 1000
        assert ss[0] == 1
        assert ss[-1] == 1000
        assert list(ss) == list(range(1, 1001))

    def test_string_elements(self):
        ss = SortedSet(['zebra', 'apple', 'mango', 'banana'])
        assert list(ss) == ['apple', 'banana', 'mango', 'zebra']
        assert 'banana' in ss

    def test_mixed_numeric_operations(self):
        ss = SortedSet([1, 2, 3])
        result = ss.union([3, 4, 5])
        assert list(result) == [1, 2, 3, 4, 5]
