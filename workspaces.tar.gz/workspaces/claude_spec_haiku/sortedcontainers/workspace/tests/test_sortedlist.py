import pytest
from sortedcontainers import SortedList, SortedKeyList


class TestSortedListBasics:

    def test_init_empty(self):
        sl = SortedList()
        assert len(sl) == 0
        assert list(sl) == []

    def test_init_from_iterable(self):
        sl = SortedList([3, 1, 4, 1, 5, 9, 2, 6])
        assert list(sl) == [1, 1, 2, 3, 4, 5, 6, 9]

    def test_add_single(self):
        sl = SortedList()
        sl.add(5)
        assert list(sl) == [5]

    def test_add_multiple(self):
        sl = SortedList()
        for x in [3, 1, 4, 1, 5]:
            sl.add(x)
        assert list(sl) == [1, 1, 3, 4, 5]

    def test_getitem_single(self):
        sl = SortedList([1, 2, 3, 4, 5])
        assert sl[0] == 1
        assert sl[2] == 3
        assert sl[-1] == 5
        assert sl[-2] == 4

    def test_getitem_slice(self):
        sl = SortedList([1, 2, 3, 4, 5])
        assert sl[1:3] == [2, 3]
        assert sl[::2] == [1, 3, 5]
        assert sl[::-1] == [5, 4, 3, 2, 1]

    def test_getitem_out_of_range(self):
        sl = SortedList([1, 2, 3])
        with pytest.raises(IndexError):
            sl[10]

    def test_setitem(self):
        sl = SortedList([1, 2, 3, 4, 5])
        sl[2] = 10
        assert list(sl) == [1, 2, 4, 5, 10]

    def test_delitem_single(self):
        sl = SortedList([1, 2, 3, 4, 5])
        del sl[2]
        assert list(sl) == [1, 2, 4, 5]

    def test_delitem_slice(self):
        sl = SortedList([1, 2, 3, 4, 5])
        del sl[1:3]
        assert list(sl) == [1, 4, 5]

    def test_len(self):
        sl = SortedList()
        assert len(sl) == 0
        sl.add(1)
        assert len(sl) == 1
        sl.update([2, 3, 4, 5])
        assert len(sl) == 5

    def test_contains(self):
        sl = SortedList([1, 2, 3, 4, 5])
        assert 3 in sl
        assert 6 not in sl
        assert 0 not in sl

    def test_iter(self):
        sl = SortedList([5, 3, 1, 4, 2])
        assert list(sl) == [1, 2, 3, 4, 5]

    def test_reversed(self):
        sl = SortedList([1, 2, 3, 4, 5])
        assert list(reversed(sl)) == [5, 4, 3, 2, 1]

    def test_repr(self):
        sl = SortedList([1, 2, 3])
        assert 'SortedList' in repr(sl)


class TestSortedListBisect:

    def test_bisect_left(self):
        sl = SortedList([1, 2, 2, 3, 4, 4, 4, 5])
        assert sl.bisect_left(2) == 1
        assert sl.bisect_left(4) == 4
        assert sl.bisect_left(0) == 0
        assert sl.bisect_left(6) == 8

    def test_bisect_right(self):
        sl = SortedList([1, 2, 2, 3, 4, 4, 4, 5])
        assert sl.bisect_right(2) == 3
        assert sl.bisect_right(4) == 7
        assert sl.bisect_right(0) == 0
        assert sl.bisect_right(6) == 8

    def test_index(self):
        sl = SortedList([1, 2, 3, 4, 5])
        assert sl.index(3) == 2
        assert sl.index(1) == 0
        assert sl.index(5) == 4

    def test_index_not_found(self):
        sl = SortedList([1, 2, 3, 4, 5])
        with pytest.raises(ValueError):
            sl.index(10)

    def test_count(self):
        sl = SortedList([1, 2, 2, 2, 3, 4, 5])
        assert sl.count(2) == 3
        assert sl.count(1) == 1
        assert sl.count(10) == 0


class TestSortedListRemoval:

    def test_remove(self):
        sl = SortedList([1, 2, 3, 4, 5])
        sl.remove(3)
        assert list(sl) == [1, 2, 4, 5]

    def test_remove_not_found(self):
        sl = SortedList([1, 2, 3])
        with pytest.raises(ValueError):
            sl.remove(10)

    def test_discard(self):
        sl = SortedList([1, 2, 3, 4, 5])
        sl.discard(3)
        assert list(sl) == [1, 2, 4, 5]

    def test_discard_not_found(self):
        sl = SortedList([1, 2, 3])
        sl.discard(10)
        assert list(sl) == [1, 2, 3]

    def test_pop_default(self):
        sl = SortedList([1, 2, 3, 4, 5])
        assert sl.pop() == 5
        assert list(sl) == [1, 2, 3, 4]

    def test_pop_with_index(self):
        sl = SortedList([1, 2, 3, 4, 5])
        assert sl.pop(2) == 3
        assert list(sl) == [1, 2, 4, 5]

    def test_clear(self):
        sl = SortedList([1, 2, 3, 4, 5])
        sl.clear()
        assert len(sl) == 0
        assert list(sl) == []


class TestSortedListOperations:

    def test_update(self):
        sl = SortedList([1, 3, 5])
        sl.update([2, 4, 6])
        assert list(sl) == [1, 2, 3, 4, 5, 6]

    def test_irange(self):
        sl = SortedList([1, 2, 3, 4, 5])
        assert list(sl.irange(2, 4)) == [2, 3, 4]
        assert list(sl.irange(2, 4, inclusive=(False, False))) == [3]
        assert list(sl.irange(2)) == [2, 3, 4, 5]
        assert list(sl.irange(maximum=4)) == [1, 2, 3, 4]

    def test_islice(self):
        sl = SortedList([1, 2, 3, 4, 5])
        assert list(sl.islice(1, 4)) == [2, 3, 4]
        assert list(sl.islice(reverse=True)) == [5, 4, 3, 2, 1]
        assert list(sl.islice(1, 4, reverse=True)) == [4, 3, 2]

    def test_copy(self):
        sl = SortedList([1, 2, 3, 4, 5])
        sl2 = sl.copy()
        assert list(sl2) == [1, 2, 3, 4, 5]
        sl2.add(10)
        assert list(sl) == [1, 2, 3, 4, 5]
        assert list(sl2) == [1, 2, 3, 4, 5, 10]

    def test_add_operator(self):
        sl1 = SortedList([1, 3, 5])
        sl2 = SortedList([2, 4, 6])
        result = sl1 + sl2
        assert list(result) == [1, 2, 3, 4, 5, 6]
        assert list(sl1) == [1, 3, 5]

    def test_iadd_operator(self):
        sl1 = SortedList([1, 3, 5])
        sl2 = SortedList([2, 4, 6])
        sl1 += sl2
        assert list(sl1) == [1, 2, 3, 4, 5, 6]

    def test_mul_operator(self):
        sl = SortedList([1, 2, 3])
        result = sl * 2
        assert list(result) == [1, 1, 2, 2, 3, 3]

    def test_imul_operator(self):
        sl = SortedList([1, 2, 3])
        sl *= 2
        assert list(sl) == [1, 1, 2, 2, 3, 3]


class TestSortedKeyList:

    def test_key_function_basic(self):
        sk = SortedKeyList([3, 1, 4, 1, 5, 9], key=lambda x: -x)
        assert list(sk) == [9, 5, 4, 3, 1, 1]

    def test_key_function_string_length(self):
        sk = SortedKeyList(['apple', 'pie', 'a', 'longer'], key=len)
        assert list(sk) == ['a', 'pie', 'apple', 'longer']

    def test_key_function_with_add(self):
        sk = SortedKeyList([1, 5, 3], key=lambda x: -x)
        sk.add(2)
        assert list(sk) == [5, 3, 2, 1]

    def test_key_function_with_remove(self):
        sk = SortedKeyList([5, 3, 2, 1], key=lambda x: -x)
        sk.remove(3)
        assert list(sk) == [5, 2, 1]

    def test_key_function_copy(self):
        sk = SortedKeyList([1, 5, 3], key=lambda x: -x)
        sk2 = sk.copy()
        assert list(sk2) == [5, 3, 1]
        sk2.add(2)
        assert list(sk) == [5, 3, 1]
        assert list(sk2) == [5, 3, 2, 1]


class TestSortedListLargeDataset:

    def test_large_dataset_100k(self):
        import random
        data = list(range(100000))
        random.shuffle(data)
        sl = SortedList(data)
        assert len(sl) == 100000
        assert sl[0] == 0
        assert sl[-1] == 99999
        assert list(sl) == list(range(100000))

    def test_large_dataset_operations(self):
        sl = SortedList(range(1000))
        sl.add(500)
        assert sl.count(500) == 2
        sl.remove(500)
        assert sl.count(500) == 1
        sl.pop(500)
        assert sl.count(500) == 0


class TestSortedListEdgeCases:

    def test_empty_list_operations(self):
        sl = SortedList()
        assert len(sl) == 0
        with pytest.raises(ValueError):
            sl.remove(1)
        with pytest.raises(IndexError):
            sl[0]

    def test_single_element(self):
        sl = SortedList([42])
        assert len(sl) == 1
        assert sl[0] == 42
        assert 42 in sl

    def test_duplicates(self):
        sl = SortedList([1, 1, 1, 2, 2, 3])
        assert sl.count(1) == 3
        assert sl.count(2) == 2
        assert sl.index(1) == 0
        sl.remove(1)
        assert list(sl) == [1, 1, 2, 2, 3]
