SortedContainers
================

Pure-Python sorted container types with O(log n) operations.

Features
--------

- **SortedList**: A sorted list supporting O(log n) insertion, deletion, and lookup
- **SortedDict**: A sorted dictionary with ordered keys and efficient range queries
- **SortedSet**: A sorted set with both sequence access and complete set operations
- **SortedKeyList**: SortedList with custom key function support for complex sorting

Installation
------------

::

    pip install sortedcontainers

Quick Start
-----------

SortedList example::

    from sortedcontainers import SortedList

    sl = SortedList([5, 1, 3, 4, 2])
    print(sl)  # SortedList([1, 2, 3, 4, 5])

    sl.add(2)
    print(sl)  # SortedList([1, 2, 2, 3, 4, 5])

    print(sl.count(2))  # 2
    print(sl.index(3))  # 3

SortedDict example::

    from sortedcontainers import SortedDict

    sd = SortedDict({'z': 26, 'a': 1, 'm': 13})
    print(sd)  # SortedDict({'a': 1, 'm': 13, 'z': 26})
    print(list(sd.keys()))  # ['a', 'm', 'z']

SortedSet example::

    from sortedcontainers import SortedSet

    ss = SortedSet([5, 1, 3, 4, 2])
    print(ss)  # SortedSet([1, 2, 3, 4, 5])

    print(ss[0])  # 1
    print(ss[-1])  # 5

Performance
-----------

All operations maintain O(log n) time complexity for insertion, deletion, and lookup:

- ``SortedList.add(value)`` - O(log n)
- ``SortedList[index]`` - O(1)
- ``SortedList.remove(value)`` - O(log n)
- ``SortedDict[key]`` - O(1)
- ``SortedSet.add(value)`` - O(log n)

Documentation
-------------

Full documentation is available at: https://sortedcontainers.readthedocs.io

License
-------

Apache License 2.0

Contributing
------------

Contributions are welcome! Please refer to the documentation for development guidelines.
