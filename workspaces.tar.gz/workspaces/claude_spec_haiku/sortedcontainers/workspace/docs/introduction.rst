Introduction
=============

What is SortedContainers?
-------------------------

SortedContainers is a pure-Python implementation of sorted container types. It provides:

- **SortedList** - A list that maintains elements in sorted order with O(log n) insertion
- **SortedKeyList** - A SortedList with support for custom key functions
- **SortedDict** - A dictionary with sorted keys and ordered iteration
- **SortedSet** - A set with sorted elements and both sequence and set operations

Why SortedContainers?
---------------------

The Python standard library provides sorting capabilities (``sorted()``, ``bisect`` module) but no built-in sorted container types. SortedContainers fills this gap with:

1. **Performance** - O(log n) insertion, deletion, and lookup operations
2. **Pure Python** - No compilation required; works anywhere Python works
3. **API Compatibility** - Follows Python's standard library conventions
4. **Scalability** - Efficient handling of 100,000+ element datasets

Installation
------------

Install from PyPI::

    pip install sortedcontainers

Requirements
~~~~~~~~~~~~

- Python 3.10 or later
- No external dependencies (uses only standard library)

Quick Start
-----------

SortedList
~~~~~~~~~~

Create a sorted list::

    from sortedcontainers import SortedList

    sl = SortedList([5, 1, 3, 4, 2])
    print(sl)  # SortedList([1, 2, 3, 4, 5])

Add and remove elements (maintains sorted order automatically)::

    sl.add(2)
    print(sl)  # SortedList([1, 2, 2, 3, 4, 5])

    sl.remove(3)
    print(sl)  # SortedList([1, 2, 2, 4, 5])

Use sequence operations::

    print(sl[0])        # 1 (first element)
    print(sl[-1])       # 5 (last element)
    print(3 in sl)      # False
    print(len(sl))      # 5

SortedDict
~~~~~~~~~~

Create a sorted dictionary::

    from sortedcontainers import SortedDict

    sd = SortedDict({'z': 26, 'a': 1, 'm': 13})
    print(list(sd.keys()))      # ['a', 'm', 'z']
    print(list(sd.values()))    # [1, 13, 26]

Iterate in sorted key order::

    for key, value in sd.items():
        print(f'{key}: {value}')
    # a: 1
    # m: 13
    # z: 26

SortedSet
~~~~~~~~~

Create a sorted set::

    from sortedcontainers import SortedSet

    ss = SortedSet([5, 1, 3, 4, 1, 5, 2])
    print(ss)  # SortedSet([1, 2, 3, 4, 5])

Use sequence operations::

    print(ss[0])       # 1 (first element)
    print(ss[-1])      # 5 (last element)
    print(ss[1:3])     # SortedSet([2, 3])

Use set operations::

    ss1 = SortedSet([1, 2, 3])
    ss2 = SortedSet([3, 4, 5])
    print(ss1 | ss2)   # Union: SortedSet([1, 2, 3, 4, 5])
    print(ss1 & ss2)   # Intersection: SortedSet([3])
    print(ss1 - ss2)   # Difference: SortedSet([1, 2])

Performance Characteristics
---------------------------

All SortedContainers implementations use segmented list architecture internally:

================= =========== ============ ================
Operation         SortedList  SortedDict   SortedSet
================= =========== ============ ================
add/remove        O(log n)    O(log n)     O(log n)
__getitem__       O(1)        O(1)         O(1)
__contains__      O(log n)    O(log n)     O(log n)
__len__           O(1)        O(1)         O(1)
================= =========== ============ ================

Complexity vs. Alternatives
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. list-table:: Insertion Performance
   :header-rows: 1

   * - Approach
     - Time Complexity
     - Space Complexity
   * - Regular list + sort
     - O(n log n)
     - O(n)
   * - Bisect module manually
     - O(n)
     - O(n)
   * - SortedContainers
     - O(log n)
     - O(n)

Key Function Support
--------------------

Sort objects by custom criteria using ``SortedKeyList``::

    from sortedcontainers import SortedKeyList

    # Sort by string length
    words = SortedKeyList(['apple', 'pie', 'a', 'longer'], key=len)
    print(words)  # SortedKeyList(['a', 'pie', 'apple', 'longer'])

    # Sort by negative value (descending)
    numbers = SortedKeyList([5, 1, 3, 4, 2], key=lambda x: -x)
    print(numbers)  # SortedKeyList([5, 4, 3, 2, 1])

Use Cases
---------

SortedContainers is ideal for:

- **Algorithmic Trading** - Maintaining order books with frequent insertions
- **Data Analysis** - Working with sorted datasets without repeated sorting
- **Game Development** - Managing sorted lists of entities by score/priority
- **Database Indexing** - Implementing custom sorted indexes
- **Event Processing** - Maintaining events in temporal order
- **Scheduling** - Managing priority queues with complex operations

Limitations
-----------

- **Not thread-safe** - Use external locking for concurrent access
- **Not optimized for very large datasets** - Designed for up to 100,000+ elements; for larger datasets use specialized data structures
- **Python GIL constraints** - Cannot exploit multi-core CPU for single-threaded operations

Next Steps
----------

- See :doc:`sortedlist` for detailed SortedList documentation
- See :doc:`sorteddict` for detailed SortedDict documentation
- See :doc:`sortedset` for detailed SortedSet documentation
