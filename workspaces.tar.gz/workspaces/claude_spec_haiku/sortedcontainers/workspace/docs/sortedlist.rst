SortedList
==========

.. automodule:: sortedcontainers.sortedlist
   :members: SortedList, SortedKeyList
   :undoc-members:
   :show-inheritance:

Overview
--------

``SortedList`` is a list that maintains elements in sorted order. All insertions, deletions, and lookups are O(log n) using binary search.

Example Usage
~~~~~~~~~~~~~

Create a sorted list::

    from sortedcontainers import SortedList

    sl = SortedList([5, 1, 3, 4, 2])

Add elements (automatically maintains sorted order)::

    sl.add(2)
    assert list(sl) == [1, 2, 2, 3, 4, 5]

Remove elements::

    sl.remove(3)
    assert list(sl) == [1, 2, 2, 4, 5]

Use indexing and slicing::

    assert sl[0] == 1
    assert sl[-1] == 5
    assert sl[1:3] == [2, 2]

Search operations::

    idx = sl.bisect_left(2)
    idx = sl.bisect_right(2)
    count = sl.count(2)

Batch operations::

    sl.update([6, 7, 8])
    sl.clear()

API Reference
~~~~~~~~~~~~~

.. class:: SortedList([iterable])

   A list that maintains elements in sorted order.

   .. method:: add(value)

      Add a value to the list. O(log n).

   .. method:: remove(value)

      Remove first occurrence of value. O(log n).

   .. method:: discard(value)

      Remove value if present. O(log n).

   .. method:: pop([index])

      Remove and return element at index (default last). O(log n).

   .. method:: bisect_left(value)

      Find insertion point for value (leftmost). O(log n).

   .. method:: bisect_right(value)

      Find insertion point for value (rightmost). O(log n).

   .. method:: index(value[, start[, stop]])

      Find index of value. O(log n).

   .. method:: count(value)

      Count occurrences of value. O(log n).

   .. method:: update([iterable])

      Add elements from iterable. O(m log n).

   .. method:: irange([minimum[, maximum[, inclusive]]])

      Iterate over elements in range. O(log n).

   .. method:: islice([start[, stop[, reverse]]])

      Iterate over slice. O(k) where k is slice size.

   .. method:: clear()

      Remove all elements. O(1).

   .. method:: copy()

      Create shallow copy. O(n).

   .. method:: __len__()

      Return number of elements. O(1).

   .. method:: __getitem__(index)

      Get element by index. O(1).

   .. method:: __setitem__(index, value)

      Set element at index. O(log n).

   .. method:: __delitem__(index)

      Delete element at index. O(log n).

   .. method:: __contains__(value)

      Test membership. O(log n).

   .. method:: __iter__()

      Iterate in sorted order. O(n).

   .. method:: __reversed__()

      Iterate in reverse sorted order. O(n).

SortedKeyList
~~~~~~~~~~~~~

``SortedKeyList`` extends ``SortedList`` with support for custom key functions:

.. code-block:: python

    from sortedcontainers import SortedKeyList

    # Sort by string length
    sk = SortedKeyList(['apple', 'pie', 'a'], key=len)

    # Sort in descending order
    sk = SortedKeyList([5, 1, 3, 4, 2], key=lambda x: -x)

Performance Notes
~~~~~~~~~~~~~~~~~

- Insertion: O(log n) binary search + O(n) segment reorganization (amortized O(1))
- Deletion: O(log n) search + O(n) segment removal
- Lookup: O(1) indexing, O(log n) binary search
- Load factor (default 1000) controls segment size trade-off

The load factor can be tuned for workloads:
- Smaller factors: faster insertion, slower indexing
- Larger factors: slower insertion, faster indexing
