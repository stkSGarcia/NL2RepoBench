SortedContainers Documentation
==============================

Pure-Python sorted container types with O(log n) operations.

.. toctree::
   :hidden:

   introduction
   sortedlist
   sorteddict
   sortedset

Contents
--------

* **Introduction** - What is SortedContainers and why you need it
* **SortedList** - Sorted list implementation with sequence operations
* **SortedDict** - Sorted dictionary with ordered keys
* **SortedSet** - Sorted set with both sequence and set operations

Quick Links
-----------

- `Installation <introduction.html#installation>`_
- `Quick Start <introduction.html#quick-start>`_
- `API Reference <sortedlist.html>`_
- `GitHub Repository <https://github.com/example/sortedcontainers>`_

Key Features
------------

- **O(log n) insertion and deletion** - Fast operations using binary search
- **Full API compatibility** - Works with standard Python sequence, mapping, and set APIs
- **Pure Python** - No compilation or build tools required
- **Key function support** - Custom sorting with SortedKeyList
- **100,000+ elements** - Efficient handling of large datasets

Example Usage
-------------

SortedList::

    from sortedcontainers import SortedList

    sl = SortedList([5, 1, 3, 4, 2])
    sl.add(2)
    print(sl)  # SortedList([1, 2, 2, 3, 4, 5])

SortedDict::

    from sortedcontainers import SortedDict

    sd = SortedDict({'z': 26, 'a': 1, 'm': 13})
    print(list(sd.keys()))  # ['a', 'm', 'z']

SortedSet::

    from sortedcontainers import SortedSet

    ss = SortedSet([5, 1, 3, 4, 2])
    print(ss[0])  # 1
    print(ss[-1])  # 5

Performance
-----------

All operations achieve O(log n) time complexity:

- **add(value)** - O(log n) binary search + amortized O(1) insertion
- **[index]** - O(1) indexing
- **remove(value)** - O(log n) search + O(n) segment removal
- **bisect_left/right** - O(log n) binary search
