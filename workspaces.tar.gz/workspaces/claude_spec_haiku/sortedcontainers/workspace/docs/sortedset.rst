SortedSet
=========

.. automodule:: sortedcontainers.sortedset
   :members: SortedSet
   :undoc-members:
   :show-inheritance:

Overview
--------

``SortedSet`` is a set that maintains elements in sorted order. It combines sequence operations (indexing, slicing) with set operations (union, intersection, difference). All operations are O(log n) or better.

Example Usage
~~~~~~~~~~~~~

Create a sorted set::

    from sortedcontainers import SortedSet

    ss = SortedSet([5, 1, 3, 4, 1, 5, 2])
    assert list(ss) == [1, 2, 3, 4, 5]

Add and remove elements::

    ss.add(2)      # No duplicate (2 already exists)
    ss.discard(3)  # Remove 3
    ss.remove(1)   # Remove 1 (raises KeyError if not found)

Use sequence operations::

    assert ss[0] == 1       # First element
    assert ss[-1] == 5      # Last element
    assert ss[1:3]          # Slice returns new SortedSet

Use set operations::

    ss1 = SortedSet([1, 2, 3])
    ss2 = SortedSet([3, 4, 5])

    # Union
    assert ss1 | ss2 == SortedSet([1, 2, 3, 4, 5])

    # Intersection
    assert ss1 & ss2 == SortedSet([3])

    # Difference
    assert ss1 - ss2 == SortedSet([1, 2])

    # Symmetric difference
    assert ss1 ^ ss2 == SortedSet([1, 2, 4, 5])

API Reference
~~~~~~~~~~~~~

.. class:: SortedSet([iterable])

   A set that maintains elements in sorted order.

   .. method:: add(value)

      Add element if not present. O(log n).

   .. method:: remove(value)

      Remove element (raises KeyError if missing). O(log n).

   .. method:: discard(value)

      Remove element if present. O(log n).

   .. method:: pop()

      Remove and return last element. O(log n).

   .. method:: clear()

      Remove all elements. O(n).

   .. method:: copy()

      Create shallow copy. O(n).

   Sequence Operations
   ~~~~~~~~~~~~~~~~~~~

   .. method:: __getitem__(index)

      Get element by index. O(1).

   .. method:: __contains__(value)

      Test membership. O(log n).

   .. method:: __len__()

      Return number of elements. O(1).

   .. method:: __iter__()

      Iterate in sorted order. O(n).

   .. method:: __reversed__()

      Iterate in reverse order. O(n).

   Set Operations
   ~~~~~~~~~~~~~~

   .. method:: union(*others)

      Return union with other sets. O((n + m) log n).

   .. method:: __or__(other)

      Union operator ``|``. O((n + m) log n).

   .. method:: __ior__(other)

      In-place union ``|=``. O((n + m) log n).

   .. method:: update(*others)

      Update with union. O((n + m) log n).

   .. method:: intersection(*others)

      Return intersection with other sets. O(m log n).

   .. method:: __and__(other)

      Intersection operator ``&``. O(m log n).

   .. method:: __iand__(other)

      In-place intersection ``&=``. O(m log n).

   .. method:: intersection_update(*others)

      Update with intersection. O(m log n).

   .. method:: difference(*others)

      Return difference with other sets. O(m log n).

   .. method:: __sub__(other)

      Difference operator ``-``. O(m log n).

   .. method:: __isub__(other)

      In-place difference ``-=``. O(m log n).

   .. method:: difference_update(*others)

      Update with difference. O(m log n).

   .. method:: symmetric_difference(other)

      Return symmetric difference. O((n + m) log n).

   .. method:: __xor__(other)

      Symmetric difference operator ``^``. O((n + m) log n).

   .. method:: __ixor__(other)

      In-place symmetric difference ``^=``. O((n + m) log n).

   .. method:: symmetric_difference_update(other)

      Update with symmetric difference. O((n + m) log n).

   Comparison Operations
   ~~~~~~~~~~~~~~~~~~~~~

   .. method:: isdisjoint(other)

      Test if no common elements. O(m log n).

   .. method:: __le__(other)

      Test if subset of other. O(n).

   .. method:: __lt__(other)

      Test if proper subset. O(n).

   .. method:: __ge__(other)

      Test if superset of other. O(m).

   .. method:: __gt__(other)

      Test if proper superset. O(m).

   .. method:: __eq__(other)

      Test equality. O(n).

Performance Notes
~~~~~~~~~~~~~~~~~

- Add/remove: O(log n)
- Indexing: O(1)
- Membership: O(log n)
- Iteration: O(n)
- Set operations: O((n + m) log n) or O(m log n) depending on operation
- Slicing: Returns new SortedSet, O(k) where k is slice size

Comparison with Standard Set
~~~~~~~~~~~~~~~~~~~~~~~~~~~~

.. list-table::
   :header-rows: 1

   * - Operation
     - set
     - SortedSet
   * - add
     - O(1)
     - O(log n)
   * - remove
     - O(1)
     - O(log n)
   * - __contains__
     - O(1)
     - O(log n)
   * - __getitem__
     - ❌
     - O(1)
   * - Ordered iteration
     - ❌
     - ✓
   * - Range queries
     - ❌
     - ✓

Use Cases
~~~~~~~~~

- Maintaining sorted collections with frequent insertions
- Implementing score rankings that support indexing
- Creating deduplicated sorted lists from streamed data
- Building sorted caches or priority structures
- Combining set and sequence APIs for natural data representation
