import os
import sys

sys.path.insert(0, os.path.abspath('../src'))

project = 'SortedContainers'
copyright = '2024, Samuel Garcia'
author = 'Samuel Garcia'
version = '1.0.0'
release = '1.0.0'

extensions = [
    'sphinx.ext.autodoc',
    'sphinx.ext.intersphinx',
    'sphinx.ext.viewcode',
]

templates_path = ['_templates']
source_suffix = '.rst'
master_doc = 'index'
language = 'en'
exclude_patterns = ['_build']

pygments_style = 'sphinx'
html_theme = 'sphinx_rtd_theme'
html_static_path = []
html_sidebars = {
    '**': ['globaltoc.html', 'relations.html', 'sourcelink.html', 'searchbox.html']
}

intersphinx_mapping = {
    'python': ('https://docs.python.org/3', None),
}

autodoc_default_options = {
    'members': True,
    'undoc-members': True,
    'show-inheritance': True,
}
