SortedDict
==========

.. automodule:: sortedcontainers.sorteddict
   :members: SortedDict, SortedKeysView, SortedValuesView, SortedItemsView
   :undoc-members:
   :show-inheritance:

Overview
--------

``SortedDict`` is a dictionary that maintains keys in sorted order. All key operations are O(log n) using the underlying ``SortedList``.

Example Usage
~~~~~~~~~~~~~

Create a sorted dictionary::

    from sortedcontainers import SortedDict

    sd = SortedDict({'z': 26, 'a': 1, 'm': 13})

Keys are automatically sorted::

    assert list(sd.keys()) == ['a', 'm', 'z']
    assert list(sd.values()) == [1, 13, 26]

Set and get values::

    sd['b'] = 2
    assert sd['b'] == 2

Delete keys::

    del sd['m']
    assert 'm' not in sd

Iterate in sorted key order::

    for key, value in sd.items():
        print(f'{key}: {value}')

View Objects
~~~~~~~~~~~~

``SortedDict.keys()``, ``values()``, and ``items()`` return view objects that reflect real-time changes::

    sd = SortedDict({'a': 1, 'b': 2})
    keys = sd.keys()

    assert 'c' not in keys
    sd['c'] = 3
    assert 'c' in keys    # View is dynamic

API Reference
~~~~~~~~~~~~~

.. class:: SortedDict([mapping[, **kwargs]])

   A dictionary with sorted keys.

   .. method:: __getitem__(key)

      Get value by key. O(1).

   .. method:: __setitem__(key, value)

      Set value for key. O(log n).

   .. method:: __delitem__(key)

      Delete key. O(log n).

   .. method:: __contains__(key)

      Test key membership. O(log n).

   .. method:: get(key[, default])

      Get value with default. O(1).

   .. method:: pop(key[, default])

      Remove and return value. O(log n).

   .. method:: popitem()

      Remove and return last (key, value). O(log n).

   .. method:: setdefault(key[, default])

      Get value with default insertion. O(log n).

   .. method:: update([mapping[, **kwargs]])

      Update from mapping or kwargs. O(m log n).

   .. method:: clear()

      Remove all items. O(n).

   .. method:: copy()

      Create shallow copy. O(n).

   .. method:: keys()

      Return sorted keys view. O(1).

   .. method:: values()

      Return values view (in key order). O(1).

   .. method:: items()

      Return items view (in key order). O(1).

   .. method:: __len__()

      Return number of items. O(1).

   .. method:: __iter__()

      Iterate keys in sorted order. O(n).

View Objects
~~~~~~~~~~~~

**SortedKeysView** - Dynamic view of sorted keys::

    keys = sd.keys()
    assert keys[0] == 'a'      # Index access
    assert 'z' in keys         # Membership testing
    for k in keys:             # Iteration in order
        print(k)

**SortedValuesView** - Dynamic view of values in key order::

    values = sd.values()
    assert values[0] == 1      # First value
    assert 1 in values         # Membership testing

**SortedItemsView** - Dynamic view of (key, value) pairs::

    items = sd.items()
    assert items[0] == ('a', 1)    # First item
    assert ('a', 1) in items       # Membership testing

Performance Notes
~~~~~~~~~~~~~~~~~

- Key insertion: O(log n) binary search + O(n) segment reorganization
- Key deletion: O(log n) search + O(n) segment removal
- Value access: O(1) direct lookup
- Iteration: O(n) to visit all items in sorted key order
- View operations: O(1) for creation, O(log n) for indexing

Use Cases
~~~~~~~~~

- Maintaining dictionaries with natural ordering (e.g., usernames alphabetically)
- Implementing range queries on sorted keys
- Creating sorted caches with custom eviction policies
- Building indexes for fast key-range lookups
