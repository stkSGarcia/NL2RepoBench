## ADDED Requirements

### Requirement: SortedDict initialization and storage
The SortedDict class SHALL maintain key-value pairs with keys stored in sorted order, supporting optional iterable or keyword argument initialization.

#### Scenario: Initialize empty
- **WHEN** SortedDict() is called with no arguments
- **THEN** empty SortedDict is created

#### Scenario: Initialize with dict
- **WHEN** SortedDict({'c': 3, 'a': 1, 'b': 2}) is initialized
- **THEN** keys are stored sorted: ['a', 'b', 'c'] with values [1, 2, 3]

#### Scenario: Initialize with keyword arguments
- **WHEN** SortedDict(c=3, a=1, b=2) is initialized
- **THEN** keys are stored sorted with associated values

### Requirement: Getitem operations
The SortedDict class SHALL support efficient key lookup with getitem, get, and default value support.

#### Scenario: Get existing key
- **WHEN** accessing sorted_dict['a'] on SortedDict({'a': 1, 'b': 2})
- **THEN** value 1 is returned

#### Scenario: Get missing key
- **WHEN** accessing sorted_dict['z'] on SortedDict({'a': 1})
- **THEN** KeyError is raised

#### Scenario: Get with default
- **WHEN** sorted_dict.get('z', 'default') is called
- **THEN** 'default' is returned for missing key

#### Scenario: Setdefault
- **WHEN** sorted_dict.setdefault('z', 99) is called on SortedDict({'a': 1})
- **THEN** value 99 is set for key 'z', and 99 is returned

### Requirement: Setitem and update operations
The SortedDict class SHALL support setting single items and batch updates maintaining sorted order.

#### Scenario: Set single item
- **WHEN** sorted_dict['b'] = 2 is executed on SortedDict({'a': 1, 'c': 3})
- **THEN** key 'b' is inserted at correct sorted position with value 2

#### Scenario: Set existing key
- **WHEN** sorted_dict['a'] = 10 is executed on SortedDict({'a': 1, 'b': 2})
- **THEN** value for key 'a' is updated to 10, order preserved

#### Scenario: Update with dict
- **WHEN** sorted_dict.update({'c': 3, 'a': 10}) is called
- **THEN** keys are updated/added maintaining sorted order

#### Scenario: Update with keyword arguments
- **WHEN** sorted_dict.update(d=4, b=2) is called
- **THEN** keys are added/updated in sorted order

### Requirement: Deletion operations
The SortedDict class SHALL support removing items by key and clearing all entries.

#### Scenario: Delete by key
- **WHEN** del sorted_dict['b'] is executed on SortedDict({'a': 1, 'b': 2, 'c': 3})
- **THEN** key 'b' and associated value are removed

#### Scenario: Pop key
- **WHEN** sorted_dict.pop('b') is called
- **THEN** value 2 is returned and key is removed

#### Scenario: Pop with default
- **WHEN** sorted_dict.pop('z', 'default') is called on SortedDict({'a': 1})
- **THEN** 'default' is returned and no error is raised

#### Scenario: Popitem removes last
- **WHEN** sorted_dict.popitem() is called on SortedDict({'a': 1, 'b': 2})
- **THEN** ('b', 2) is returned and removed

#### Scenario: Clear all items
- **WHEN** sorted_dict.clear() is called
- **THEN** all key-value pairs are removed

### Requirement: Key iteration and access
The SortedDict class SHALL support iteration over keys, values, and items in sorted order.

#### Scenario: Iterate keys
- **WHEN** iterating SortedDict({'c': 3, 'a': 1, 'b': 2})
- **THEN** keys are yielded in sorted order: 'a', 'b', 'c'

#### Scenario: Keys method
- **WHEN** sorted_dict.keys() is called
- **THEN** SortedKeysView is returned supporting index access and slicing

#### Scenario: Values method
- **WHEN** sorted_dict.values() is called
- **THEN** SortedValuesView is returned in key-sorted order

#### Scenario: Items method
- **WHEN** sorted_dict.items() is called
- **THEN** SortedItemsView is returned with (key, value) pairs in key-sorted order

### Requirement: Containment and length
The SortedDict class SHALL support membership testing and length operations.

#### Scenario: Check key existence
- **WHEN** checking 'a' in SortedDict({'a': 1, 'b': 2})
- **THEN** True is returned

#### Scenario: Get length
- **WHEN** len(SortedDict({'a': 1, 'b': 2, 'c': 3})) is called
- **THEN** 3 is returned

### Requirement: Indexing by position
The SortedDict class SHALL support accessing keys, values, and items by numeric index.

#### Scenario: Get key by index
- **WHEN** accessing sorted_dict.keys()[1] on SortedDict({'a': 1, 'b': 2, 'c': 3})
- **THEN** key 'b' is returned (second key in sorted order)

#### Scenario: Get value by index
- **WHEN** accessing sorted_dict.values()[0] on SortedDict({'a': 1, 'b': 2})
- **THEN** value 1 is returned (first value in sorted key order)

### Requirement: Copy operation
The SortedDict class SHALL create independent shallow copies.

#### Scenario: Copy creates independent dict
- **WHEN** copy() is called on SortedDict({'a': 1, 'b': 2})
- **THEN** new independent SortedDict({'a': 1, 'b': 2}) is returned

### Requirement: Boolean evaluation
The SortedDict class SHALL support truthiness testing.

#### Scenario: Empty dict is falsy
- **WHEN** bool(SortedDict()) is evaluated
- **THEN** False is returned

#### Scenario: Non-empty dict is truthy
- **WHEN** bool(SortedDict({'a': 1})) is evaluated
- **THEN** True is returned
