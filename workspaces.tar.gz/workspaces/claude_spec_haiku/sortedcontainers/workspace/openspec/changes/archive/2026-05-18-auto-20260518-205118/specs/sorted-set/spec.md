## ADDED Requirements

### Requirement: SortedSet initialization and storage
The SortedSet class SHALL maintain unique elements in sorted order, supporting optional iterable initialization.

#### Scenario: Initialize empty
- **WHEN** SortedSet() is called
- **THEN** empty SortedSet is created

#### Scenario: Initialize with iterable
- **WHEN** SortedSet([3, 1, 2, 1, 3]) is initialized
- **THEN** unique elements are stored sorted: [1, 2, 3]

#### Scenario: Initialize with duplicates
- **WHEN** SortedSet([1, 2, 2, 3, 3, 3]) is initialized
- **THEN** duplicates are removed, [1, 2, 3] is stored

### Requirement: Element addition and removal
The SortedSet class SHALL support add, remove, discard, and clear operations maintaining sorted order.

#### Scenario: Add new element
- **WHEN** add(2) is called on SortedSet([1, 3])
- **THEN** element 2 is inserted at correct position, set becomes {1, 2, 3}

#### Scenario: Add duplicate element
- **WHEN** add(1) is called on SortedSet([1, 3])
- **THEN** no change occurs, duplicate is not added

#### Scenario: Remove element
- **WHEN** remove(2) is called on SortedSet([1, 2, 3])
- **THEN** element 2 is removed, set becomes {1, 3}

#### Scenario: Remove missing element
- **WHEN** remove(5) is called on SortedSet([1, 3])
- **THEN** KeyError is raised

#### Scenario: Discard element
- **WHEN** discard(2) is called on SortedSet([1, 2, 3])
- **THEN** element 2 is removed, set becomes {1, 3}

#### Scenario: Discard missing element
- **WHEN** discard(5) is called on SortedSet([1, 3])
- **THEN** no error is raised, set remains unchanged

#### Scenario: Pop arbitrary element
- **WHEN** pop() is called on SortedSet([1, 2, 3])
- **THEN** last element (3) is removed and returned

#### Scenario: Pop from empty set
- **WHEN** pop() is called on empty SortedSet()
- **THEN** KeyError is raised

#### Scenario: Clear all elements
- **WHEN** clear() is called on SortedSet([1, 2, 3])
- **THEN** all elements are removed, set becomes empty

### Requirement: Set union operations
The SortedSet class SHALL support union, update, and union_update operations combining sets.

#### Scenario: Union with set
- **WHEN** SortedSet([1, 2]) | SortedSet([2, 3]) is executed
- **THEN** SortedSet([1, 2, 3]) is returned

#### Scenario: Union with iterable
- **WHEN** SortedSet([1, 2]).union([2, 3, 4]) is called
- **THEN** SortedSet([1, 2, 3, 4]) is returned

#### Scenario: Update union in-place
- **WHEN** sorted_set.update([3, 4, 5]) is called on SortedSet([1, 2])
- **THEN** set becomes {1, 2, 3, 4, 5}

#### Scenario: Union_update with set
- **WHEN** sorted_set |= SortedSet([3, 4]) is executed on SortedSet([1, 2])
- **THEN** set becomes {1, 2, 3, 4}

### Requirement: Set intersection operations
The SortedSet class SHALL support intersection, intersection_update operations finding common elements.

#### Scenario: Intersection with set
- **WHEN** SortedSet([1, 2, 3]) & SortedSet([2, 3, 4]) is executed
- **THEN** SortedSet([2, 3]) is returned

#### Scenario: Intersection with iterable
- **WHEN** SortedSet([1, 2, 3]).intersection([2, 3, 4]) is called
- **THEN** SortedSet([2, 3]) is returned

#### Scenario: Intersection_update in-place
- **WHEN** sorted_set &= SortedSet([2, 3, 4]) is executed on SortedSet([1, 2, 3])
- **THEN** set becomes {2, 3}

### Requirement: Set difference operations
The SortedSet class SHALL support difference, difference_update operations removing common elements.

#### Scenario: Difference with set
- **WHEN** SortedSet([1, 2, 3]) - SortedSet([2, 3, 4]) is executed
- **THEN** SortedSet([1]) is returned

#### Scenario: Difference with iterable
- **WHEN** SortedSet([1, 2, 3]).difference([2, 3, 4]) is called
- **THEN** SortedSet([1]) is returned

#### Scenario: Difference_update in-place
- **WHEN** sorted_set -= SortedSet([2, 3, 4]) is executed on SortedSet([1, 2, 3])
- **THEN** set becomes {1}

### Requirement: Set symmetric difference operations
The SortedSet class SHALL support symmetric_difference and symmetric_difference_update operations.

#### Scenario: Symmetric difference
- **WHEN** SortedSet([1, 2, 3]) ^ SortedSet([2, 3, 4]) is executed
- **THEN** SortedSet([1, 4]) is returned

#### Scenario: Symmetric_difference_update in-place
- **WHEN** sorted_set ^= SortedSet([2, 3, 4]) is executed on SortedSet([1, 2, 3])
- **THEN** set becomes {1, 4}

### Requirement: Set comparison operations
The SortedSet class SHALL support subset, superset, and disjoint comparison operations.

#### Scenario: Subset comparison
- **WHEN** SortedSet([1, 2]) <= SortedSet([1, 2, 3]) is executed
- **THEN** True is returned

#### Scenario: Proper subset
- **WHEN** SortedSet([1, 2]) < SortedSet([1, 2, 3]) is executed
- **THEN** True is returned

#### Scenario: Superset comparison
- **WHEN** SortedSet([1, 2, 3]) >= SortedSet([1, 2]) is executed
- **THEN** True is returned

#### Scenario: Disjoint test
- **WHEN** SortedSet([1, 2]).isdisjoint(SortedSet([3, 4])) is called
- **THEN** True is returned

### Requirement: Containment and membership
The SortedSet class SHALL support membership testing and length operations.

#### Scenario: Check element existence
- **WHEN** checking 2 in SortedSet([1, 2, 3])
- **THEN** True is returned

#### Scenario: Check missing element
- **WHEN** checking 5 in SortedSet([1, 2, 3])
- **THEN** False is returned

#### Scenario: Get set length
- **WHEN** len(SortedSet([1, 2, 3])) is called
- **THEN** 3 is returned

### Requirement: Iteration and sequence access
The SortedSet class SHALL support iteration, indexing, and slicing like a sequence.

#### Scenario: Forward iteration
- **WHEN** iterating SortedSet([3, 1, 2])
- **THEN** elements are yielded in sorted order: 1, 2, 3

#### Scenario: Reverse iteration
- **WHEN** using reversed(SortedSet([3, 1, 2]))
- **THEN** elements are yielded in reverse order: 3, 2, 1

#### Scenario: Access by index
- **WHEN** accessing sorted_set[1] on SortedSet([1, 3, 5])
- **THEN** element 3 is returned

#### Scenario: Slicing access
- **WHEN** accessing sorted_set[1:3] on SortedSet([1, 3, 5, 7])
- **THEN** sublist [3, 5] is returned

#### Scenario: Negative indexing
- **WHEN** accessing sorted_set[-1] on SortedSet([1, 3, 5])
- **THEN** last element 5 is returned

### Requirement: Copy operation
The SortedSet class SHALL create independent shallow copies.

#### Scenario: Copy creates independent set
- **WHEN** copy() is called on SortedSet([1, 2, 3])
- **THEN** new independent SortedSet([1, 2, 3]) is returned

### Requirement: Boolean evaluation
The SortedSet class SHALL support truthiness testing.

#### Scenario: Empty set is falsy
- **WHEN** bool(SortedSet()) is evaluated
- **THEN** False is returned

#### Scenario: Non-empty set is truthy
- **WHEN** bool(SortedSet([1])) is evaluated
- **THEN** True is returned
