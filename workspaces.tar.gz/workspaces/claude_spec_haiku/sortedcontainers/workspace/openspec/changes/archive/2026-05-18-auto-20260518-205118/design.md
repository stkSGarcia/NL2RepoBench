## Context

The Python standard library lacks efficient sorted container types, leaving developers to use third-party libraries or implement their own sorting solutions. The sortedcontainers library fills this gap by providing pure-Python implementations of SortedList, SortedDict, and SortedSet with O(log n) binary search operations rivaling C-based implementations.

The project targets Python 3.10.11+ and relies on standard library modules (bisect, collections.abc) plus testing and documentation dependencies (pytest, sphinx, etc.). It will be published on PyPI for universal adoption.

Key stakeholders: Python developers requiring sorted collections in trading systems, data analysis, distributed computing, and general application development.

## Goals / Non-Goals

**Goals:**
- Implement three core sorted container types (SortedList, SortedDict, SortedSet) with O(log n) operations
- Support custom key functions via SortedKeyList for complex sorting scenarios
- Maintain Python standard library API compatibility (MutableSequence, MutableMapping, MutableSet)
- Provide view objects (SortedKeysView, SortedValuesView, SortedItemsView) for dictionary access
- Achieve 100,000+ element scalability with dynamic load factor optimization
- Deliver comprehensive testing (>95% coverage), documentation, and packaging
- Enable pip installation with clear API and straightforward usage

**Non-Goals:**
- Thread-safe implementations (reliance on GIL documented)
- C-extension optimization (pure Python only)
- Support for Python < 3.10
- Integration with specific frameworks or databases
- Real-time performance guarantees beyond documented O(log n) complexity

## Decisions

### 1. Segmented List Architecture

**Decision:** Implement SortedList using segmented internal storage (_lists) with index tracking (_maxes, _index, _offset) rather than single monolithic list.

**Rationale:** 
- Single list requires O(n) insertion in worst case
- Segmentation allows efficient binary search (O(log n)) across segments
- Dynamic load factor management optimizes memory/performance trade-off
- Segment-based approach scales to 100,000+ elements efficiently

**Alternatives Considered:**
- Tree-based approach (B-tree): More complex, similar performance, harder to implement in pure Python
- Heap-based approach: Doesn't maintain index-based access efficiently
- Sorted list with no segmentation: Can't achieve O(log n) for all operations

### 2. Key Function Abstraction via Subclass

**Decision:** Implement SortedKeyList as subclass of SortedList with key function support via __new__() factory pattern.

**Rationale:**
- Separates key function complexity from base SortedList
- Factory pattern (SortedList(..., key=fn) returns SortedKeyList instance) is intuitive
- Subclass approach avoids runtime key function checks in hot paths
- Maintains API parity while allowing inheritance of base functionality

**Alternatives Considered:**
- Single class with optional key parameter: Adds branch conditions to every comparison
- Composition over inheritance: Would duplicate all methods
- Decorator pattern: Overkill and less idiomatic for Python

### 3. View Objects as Dynamic Proxies

**Decision:** Implement SortedKeysView, SortedValuesView, SortedItemsView as dynamic proxy objects returning views rather than static snapshots.

**Rationale:**
- View objects must reflect real-time dictionary changes
- Proxy pattern allows indexing and slicing on sorted keys/values
- Avoids copying data on each view() call
- Matches dict.keys() / dict.values() semantics

**Alternatives Considered:**
- Return list snapshots: Inconsistent with dict.keys() and adds memory overhead
- Lazy generators: Can't support indexing/slicing operations
- Custom list subclass: Requires copying, loses dynamic behavior

### 4. Assertion-Based Internal Consistency Checks

**Decision:** Use _check() method with assertions to validate internal state (_lists, _maxes, _index consistency).

**Rationale:**
- Fast failure detection for internal bugs
- Can be disabled in production via Python -O flag
- Low overhead in development/testing
- Helps identify corruption from edge cases

**Alternatives Considered:**
- Silent recovery: Masks bugs, leads to subtle data corruption
- Runtime validation: Too expensive for every operation
- External validation: Can't catch issues during development

### 5. Load Factor Management

**Decision:** Implement DEFAULT_LOAD_FACTOR = 1000 with dynamic adjustment capability for optimization.

**Rationale:**
- 1000-element segments balance insertion cost vs. binary search depth
- Segment size is adjustable to optimize for workload (many small inserts vs. few large batches)
- Scales from small to 100,000+ element datasets
- Empirically validated in original sortedcontainers implementation

**Alternatives Considered:**
- Fixed segment size: Doesn't optimize across different workloads
- Auto-tuning: Complex, introduces unpredictability
- No segmentation: Falls back to O(n) insertion

### 6. Pure Python Implementation without C Extensions

**Decision:** Implement entirely in pure Python, relying on bisect module for binary search.

**Rationale:**
- No compiler/build toolchain required (key library advantage)
- Bisect module is optimized and well-tested
- Pure Python remains competitive with simple C implementations
- Simplifies deployment and compatibility

**Alternatives Considered:**
- Hybrid Python+C: Adds build complexity, doesn't match project goals
- Full C implementation: Sacrifices key advantage (no compilation needed)

### 7. Standard Library Protocol Compliance

**Decision:** Inherit from collections.abc (MutableSequence, MutableMapping, MutableSet) for protocol support.

**Rationale:**
- Ensures API compatibility with standard library expectations
- Enables polymorphism with regular list/dict/set APIs
- Provides clear interface contracts
- Type checkers recognize protocol compliance

**Alternatives Considered:**
- Custom abstract base classes: Duplicates standard library work
- No inheritance: Loses type checking and polymorphism benefits

## Risks / Trade-offs

**[Risk] Memory overhead of segmentation**
→ *Mitigation:* Segments reduce insertion cost (O(log n) bisection vs. O(n) shifting). Memory overhead is minimal (lists store references, not copies). For 100,000 elements with load_factor=1000, only ~100 segment pointers needed.

**[Risk] Segmentation complexity in maintenance**
→ *Mitigation:* Complexity is contained in SortedList core. View objects and SortedDict/Set layer remain simple. Comprehensive tests catch regressions. _check() validates invariants.

**[Risk] Pure Python performance on very large datasets**
→ *Mitigation:* Documented as unsuitable for datasets > 1M elements or extreme latency requirements. Typical use cases (trading, data analysis) are well-served. Users needing C-level performance can use Cython-compiled builds.

**[Risk] Key function overhead in SortedKeyList**
→ *Mitigation:* Key function called only during comparisons (bisection, insertion). Subclass design avoids overhead in base SortedList. Documented limitation for performance-critical code.

**[Risk] Not thread-safe**
→ *Mitigation:* GIL provides implicit protection for single-threaded code. Multi-threaded access documented as requiring external locking. No attempt to hide this limitation.

**[Risk] View objects don't snapshot state**
→ *Mitigation:* Matches dict.keys() behavior. Users needing snapshots can convert to list() or set(). Dynamic behavior is intentional and documented.

## Assumptions

1. **Python 3.10.11+**: Assumes modern Python versions; older versions unsupported.
2. **GIL-protected mutations**: Assumes single-threaded access or external synchronization for thread safety.
3. **Comparable objects**: Assumes elements in SortedList/SortedSet are comparable; non-comparable objects will raise TypeError as expected.
4. **Bisect module stability**: Assumes bisect module behavior is stable and correct.
5. **Standard library compliance sufficient**: Assumes inheriting from abc classes satisfies type system and polymorphism needs.
6. **No circular references in keys/values**: Assumes standard garbage collection handles SortedDict keys/values without special cleanup.
7. **Load factor discovery**: Assumes DEFAULT_LOAD_FACTOR=1000 is appropriate; documentation warns users can tune for workloads.

## Open Questions

1. **Cython compilation optional:** Should distribute wheels with Cython-compiled versions for performance, or keep pure Python only? → Decision: Pure Python for now, optional Cython builds for future.
2. **Specialized range query methods:** Should irange() and islice() be public API or internal helpers? → Decision: Public API per spec.
3. **Copy semantics for views:** Should copy() create independent view or snapshot? → Decision: Independent copy with same key/dict reference.
4. **Pickle support:** Should containers be picklable? → Decision: Yes, via standard Python pickle protocol inheritance.
5. **Documentation examples:** Should examples use real-world data (market ticks, etc.) or simple toy data? → Decision: Mix of both for clarity.

## Migration Plan

1. **Phase 1: Core Implementation** (Tasks 1-30)
   - Implement SortedList with all core operations
   - Implement SortedKeyList with key function support
   - Basic error handling and validation

2. **Phase 2: Extended Containers** (Tasks 31-50)
   - Implement SortedDict with dictionary operations
   - Implement SortedSet with set operations
   - Implement view objects (Keys, Values, Items)

3. **Phase 3: Optimization & Testing** (Tasks 51-70)
   - Implement load factor management
   - Performance optimization
   - Comprehensive test suite (unit, stress, memory, concurrent)

4. **Phase 4: Documentation & Packaging** (Tasks 71-90)
   - API documentation with docstrings
   - Sphinx documentation with examples
   - Setup.py, pyproject.toml, tox.ini configuration
   - MANIFEST.in, LICENSE, README

5. **Phase 5: Deployment & Verification** (Tasks 91-100)
   - Verify pip installation works
   - Test across Python versions via tox
   - Performance benchmarking
   - Final documentation review

**Rollback Strategy:** Not applicable (new library). For updates, version increments follow semantic versioning with migration guides for breaking changes.
