## ADDED Requirements

### Requirement: SortedKeyList with custom key functions
The SortedKeyList class SHALL support custom key functions for sorting complex objects and special rules with O(log n) binary search operations.

#### Scenario: Initialize with key function
- **WHEN** SortedKeyList([3, 1, 2], key=lambda x: -x) is created
- **THEN** elements are sorted by negated value: [3, 2, 1]

#### Scenario: Sort by object attribute
- **WHEN** SortedKeyList(persons, key=lambda p: p.age) is created
- **THEN** persons are sorted by age attribute

#### Scenario: Multi-level sorting
- **WHEN** SortedKeyList(data, key=lambda x: (x[0], -x[1])) is created
- **THEN** data is sorted by first element ascending, second element descending

### Requirement: Key function operations
The SortedKeyList class SHALL maintain binary search, insertion, and removal operations with key function applied.

#### Scenario: Add element with key function
- **WHEN** add(0) is called on SortedKeyList([3, 1, 2], key=lambda x: -x)
- **THEN** element 0 is inserted at correct position per key, list becomes [3, 2, 1, 0]

#### Scenario: Bisect with key function
- **WHEN** bisect_left(2) is called on SortedKeyList([3, 1, 2], key=lambda x: -x)
- **THEN** insertion point considers key function, correct bisection point is returned

#### Scenario: Search with key function
- **WHEN** index(2) is called on SortedKeyList([3, 1, 2], key=lambda x: -x)
- **THEN** index is found based on key-sorted position, value 2 is located

### Requirement: Complex sorting scenarios
The SortedKeyList class SHALL handle modulo operations, negative value sorting, and other special sorting rules.

#### Scenario: Modulo-based sorting
- **WHEN** SortedKeyList([7, 3, 5, 1], key=lambda x: x % 3) is created
- **THEN** elements are sorted by modulo 3 result: [3, 1, 7, 5]

#### Scenario: Case-insensitive string sorting
- **WHEN** SortedKeyList(['Apple', 'banana', 'Cherry'], key=str.lower) is created
- **THEN** strings are sorted case-insensitively: ['Apple', 'banana', 'Cherry']

### Requirement: Inheritance of SortedList functionality
The SortedKeyList class SHALL inherit all SortedList operations with key function applied throughout.

#### Scenario: All sequence operations work
- **WHEN** using getitem, slicing, iteration, and deletion on SortedKeyList
- **THEN** all operations respect the key function and maintain sorted order

#### Scenario: View operations with key function
- **WHEN** accessing irange or islice on SortedKeyList with key function
- **THEN** range operations consider key function for boundary calculations

### Requirement: Type flexibility
The SortedKeyList class SHALL support key=None to behave as SortedList without key function overhead.

#### Scenario: Disable key function
- **WHEN** SortedKeyList([3, 1, 2], key=None) is created
- **THEN** elements are sorted naturally, behaving like SortedList

### Requirement: Key function validation
The SortedKeyList class SHALL validate that key function is callable or None.

#### Scenario: Invalid key function
- **WHEN** SortedKeyList([1, 2, 3], key="not_callable") is initialized
- **THEN** TypeError is raised

### Requirement: Copy with key function
The SortedKeyList class SHALL preserve key function when copying.

#### Scenario: Copy maintains key function
- **WHEN** copy() is called on SortedKeyList([3, 1, 2], key=lambda x: -x)
- **THEN** new SortedKeyList with same key function is returned
