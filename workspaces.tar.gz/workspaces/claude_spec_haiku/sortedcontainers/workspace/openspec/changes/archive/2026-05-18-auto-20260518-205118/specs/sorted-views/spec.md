## ADDED Requirements

### Requirement: SortedKeysView implementation
The SortedKeysView class SHALL provide a sorted view of SortedDict keys supporting index access, slicing, and set operations.

#### Scenario: Keys iteration
- **WHEN** iterating SortedDict({'c': 3, 'a': 1, 'b': 2}).keys()
- **THEN** keys are yielded in sorted order: 'a', 'b', 'c'

#### Scenario: Keys indexing
- **WHEN** accessing SortedDict({'c': 3, 'a': 1, 'b': 2}).keys()[1]
- **THEN** key 'b' is returned (second key in sorted order)

#### Scenario: Keys slicing
- **WHEN** accessing SortedDict({'a': 1, 'b': 2, 'c': 3, 'd': 4}).keys()[1:3]
- **THEN** keys ['b', 'c'] are returned

#### Scenario: Keys containment
- **WHEN** checking 'b' in SortedDict({'a': 1, 'b': 2}).keys()
- **THEN** True is returned

#### Scenario: Keys length
- **WHEN** len(SortedDict({'a': 1, 'b': 2, 'c': 3}).keys()) is called
- **THEN** 3 is returned

#### Scenario: Keys reflect changes
- **WHEN** adding new key to dict after keys() call
- **THEN** SortedKeysView reflects the new key

### Requirement: SortedValuesView implementation
The SortedValuesView class SHALL provide a sorted view of SortedDict values in key-sorted order supporting index access and slicing.

#### Scenario: Values iteration
- **WHEN** iterating SortedDict({'c': 3, 'a': 1, 'b': 2}).values()
- **THEN** values are yielded in key-sorted order: 1, 2, 3

#### Scenario: Values indexing
- **WHEN** accessing SortedDict({'c': 3, 'a': 1, 'b': 2}).values()[0]
- **THEN** value 1 is returned (first value in key-sorted order)

#### Scenario: Values slicing
- **WHEN** accessing SortedDict({'a': 1, 'b': 2, 'c': 3, 'd': 4}).values()[1:3]
- **THEN** values [2, 3] are returned

#### Scenario: Values containment
- **WHEN** checking 2 in SortedDict({'a': 1, 'b': 2}).values()
- **THEN** True is returned

#### Scenario: Values length
- **WHEN** len(SortedDict({'a': 1, 'b': 2, 'c': 3}).values()) is called
- **THEN** 3 is returned

#### Scenario: Values reflect changes
- **WHEN** updating value for existing key
- **THEN** SortedValuesView reflects the new value

### Requirement: SortedItemsView implementation
The SortedItemsView class SHALL provide a sorted view of SortedDict (key, value) pairs in key-sorted order supporting index access, slicing, and set operations.

#### Scenario: Items iteration
- **WHEN** iterating SortedDict({'c': 3, 'a': 1, 'b': 2}).items()
- **THEN** items are yielded in key-sorted order: ('a', 1), ('b', 2), ('c', 3)

#### Scenario: Items indexing
- **WHEN** accessing SortedDict({'c': 3, 'a': 1, 'b': 2}).items()[1]
- **THEN** item ('b', 2) is returned

#### Scenario: Items slicing
- **WHEN** accessing SortedDict({'a': 1, 'b': 2, 'c': 3, 'd': 4}).items()[1:3]
- **THEN** items [('b', 2), ('c', 3)] are returned

#### Scenario: Items containment
- **WHEN** checking ('b', 2) in SortedDict({'a': 1, 'b': 2}).items()
- **THEN** True is returned

#### Scenario: Items length
- **WHEN** len(SortedDict({'a': 1, 'b': 2, 'c': 3}).items()) is called
- **THEN** 3 is returned

#### Scenario: Items reflect changes
- **WHEN** modifying SortedDict after items() call
- **THEN** SortedItemsView reflects the changes

### Requirement: View set operations
The view classes SHALL support set operations for compatibility with set protocol.

#### Scenario: Keys set operations
- **WHEN** performing & | - ^ operations on SortedKeysView objects
- **THEN** set operations return appropriate results

#### Scenario: Items set operations
- **WHEN** performing set operations on SortedItemsView objects
- **THEN** set operations work with (key, value) tuples

### Requirement: View copy operation
The view classes SHALL support copying to create regular sets or lists.

#### Scenario: Convert keys to set
- **WHEN** set(SortedDict({'a': 1, 'b': 2}).keys()) is called
- **THEN** regular Python set {'a', 'b'} is returned

#### Scenario: Convert items to list
- **WHEN** list(SortedDict({'a': 1, 'b': 2}).items()) is called
- **THEN** regular Python list [('a', 1), ('b', 2)] is returned

### Requirement: View equality and comparison
The view classes SHALL support equality and comparison operations.

#### Scenario: Keys equality
- **WHEN** comparing two SortedKeysView objects from identical dicts
- **THEN** equality is based on key content

#### Scenario: Views immutability
- **WHEN** attempting to modify view directly
- **THEN** view operations are read-only through view interface
