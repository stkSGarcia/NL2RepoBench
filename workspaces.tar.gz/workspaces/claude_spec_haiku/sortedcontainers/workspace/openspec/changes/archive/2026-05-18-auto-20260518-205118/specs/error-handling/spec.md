## ADDED Requirements

### Requirement: Parameter validation
The sorted containers SHALL validate input parameters and raise appropriate exceptions for invalid inputs.

#### Scenario: Non-iterable initialization
- **WHEN** SortedList(123) is initialized with non-iterable
- **THEN** TypeError is raised

#### Scenario: Invalid key function
- **WHEN** SortedKeyList([1, 2], key="not_callable") is initialized
- **THEN** TypeError is raised

#### Scenario: Non-comparable elements
- **WHEN** SortedList([1, "string"]) tries to sort mixed types
- **THEN** TypeError is raised during comparison

### Requirement: Index out of bounds handling
The sorted containers SHALL properly handle index out of bounds conditions.

#### Scenario: Positive index out of range
- **WHEN** accessing sorted_list[100] on SortedList([1, 2, 3])
- **THEN** IndexError is raised

#### Scenario: Negative index out of range
- **WHEN** accessing sorted_list[-100] on SortedList([1, 2, 3])
- **THEN** IndexError is raised

#### Scenario: Slice with out of range indices
- **WHEN** accessing sorted_list[10:20] on SortedList([1, 2, 3])
- **THEN** empty slice is returned (standard Python behavior)

### Requirement: Key error handling
The sorted containers SHALL properly handle key errors for dictionary and set operations.

#### Scenario: Get non-existent key
- **WHEN** accessing sorted_dict['nonexistent'] on SortedDict({'a': 1})
- **THEN** KeyError is raised

#### Scenario: Remove non-existent key
- **WHEN** remove('nonexistent') is called on SortedSet({1, 2, 3})
- **THEN** KeyError is raised

#### Scenario: Pop from empty set
- **WHEN** pop() is called on empty SortedSet()
- **THEN** KeyError is raised

### Requirement: Value error handling
The sorted containers SHALL raise ValueError for invalid operations on values.

#### Scenario: Index of missing value
- **WHEN** index(999) is called on SortedList([1, 2, 3])
- **THEN** ValueError is raised

#### Scenario: Remove non-existent value
- **WHEN** remove(999) is called on SortedList([1, 2, 3])
- **THEN** ValueError is raised

### Requirement: Empty container handling
The sorted containers SHALL handle operations on empty containers gracefully.

#### Scenario: Pop from empty list
- **WHEN** pop() is called on empty SortedList()
- **THEN** IndexError is raised

#### Scenario: Access empty list
- **WHEN** accessing empty_sorted_list[0]
- **THEN** IndexError is raised

#### Scenario: Iterate empty container
- **WHEN** iterating empty SortedList()
- **THEN** iteration completes without yielding values

#### Scenario: Length of empty container
- **WHEN** len(empty_sorted_list) is called
- **THEN** 0 is returned

### Requirement: Single element handling
The sorted containers SHALL properly handle containers with single element.

#### Scenario: Operations on single element
- **WHEN** accessing, removing, or iterating SortedList([1])
- **THEN** operations work correctly

#### Scenario: Remove single element
- **WHEN** remove(1) is called on SortedList([1])
- **THEN** element is removed, container becomes empty

### Requirement: Duplicate element handling
The sorted containers SHALL properly handle duplicate elements in SortedList and SortedKeyList.

#### Scenario: Multiple duplicates
- **WHEN** SortedList([1, 1, 1, 1]) is initialized
- **THEN** all duplicates are stored

#### Scenario: Count duplicates
- **WHEN** count(1) is called on SortedList([1, 1, 1, 2, 3])
- **THEN** 3 is returned

#### Scenario: Duplicates not allowed in set
- **WHEN** SortedSet([1, 1, 2, 2]) is initialized
- **THEN** only unique elements {1, 2} are stored

### Requirement: Non-comparable object handling
The sorted containers SHALL handle non-comparable objects with appropriate error messages.

#### Scenario: Non-comparable types
- **WHEN** SortedList([1, None, "string"]) tries to sort
- **THEN** TypeError is raised during comparison

#### Scenario: Custom objects without comparison
- **WHEN** SortedList([obj1, obj2]) where objects don't implement comparison
- **THEN** TypeError is raised appropriately

### Requirement: Type checking and conversion
The sorted containers SHALL validate types and raise appropriate TypeErrors.

#### Scenario: Invalid operator operands
- **WHEN** SortedList([1, 2]) + "string" is evaluated
- **THEN** TypeError is raised

#### Scenario: Invalid slice types
- **WHEN** accessing sorted_list["string":5]
- **THEN** appropriate error is raised

### Requirement: Assertion-based consistency checks
The sorted containers SHALL use assertions for internal consistency validation.

#### Scenario: Assertion in _check()
- **WHEN** _check() is called on valid container
- **THEN** all internal assertions pass

#### Scenario: Assertion failure detection
- **WHEN** _check() is called on corrupted container
- **THEN** AssertionError is raised indicating corruption

### Requirement: Graceful degradation
The sorted containers SHALL operate correctly even in edge cases and stress conditions.

#### Scenario: Large number of duplicates
- **WHEN** SortedList() is populated with many identical values
- **THEN** all operations work correctly despite high duplication

#### Scenario: Rapidly changing data
- **WHEN** SortedList undergoes rapid add/remove cycles
- **THEN** container maintains consistency and correct state
