## ADDED Requirements

### Requirement: SortedList initialization
The SortedList class SHALL initialize with optional iterable and maintain all elements in sorted order with O(n log n) initialization time.

#### Scenario: Initialize empty list
- **WHEN** SortedList() is called with no arguments
- **THEN** an empty SortedList is created

#### Scenario: Initialize with iterable
- **WHEN** SortedList([3, 1, 2]) is called
- **THEN** all elements are stored in sorted order [1, 2, 3]

### Requirement: Element insertion with O(log n) complexity
The SortedList class SHALL insert elements maintaining sorted order with O(log n) bisection time and O(n) insertion time.

#### Scenario: Add single element
- **WHEN** add(5) is called on SortedList([1, 3, 7])
- **THEN** element 5 is inserted at correct position, list becomes [1, 3, 5, 7]

#### Scenario: Add duplicate element
- **WHEN** add(3) is called on SortedList([1, 3, 7])
- **THEN** element is added, allowing duplicates, list becomes [1, 3, 3, 7]

#### Scenario: Batch insertion
- **WHEN** update([5, 6, 4]) is called on SortedList([1, 3, 7])
- **THEN** all elements are inserted maintaining sort order, list becomes [1, 3, 4, 5, 6, 7]

### Requirement: Element deletion and removal
The SortedList class SHALL support removing elements by index, value, and clearing all elements.

#### Scenario: Remove by index
- **WHEN** pop(1) is called on SortedList([1, 2, 3])
- **THEN** element at index 1 is removed and returned, list becomes [1, 3]

#### Scenario: Remove by value
- **WHEN** remove(2) is called on SortedList([1, 2, 3])
- **THEN** first occurrence of value 2 is removed, list becomes [1, 3]

#### Scenario: Discard non-existent value
- **WHEN** discard(5) is called on SortedList([1, 2, 3])
- **THEN** no error is raised, list remains [1, 2, 3]

#### Scenario: Clear all elements
- **WHEN** clear() is called on SortedList([1, 2, 3])
- **THEN** all elements are removed, list becomes empty

### Requirement: Indexing and slicing operations
The SortedList class SHALL support getitem, setitem, and delitem with standard Python indexing and slicing semantics.

#### Scenario: Get element by index
- **WHEN** accessing sorted_list[1] on SortedList([1, 3, 5])
- **THEN** element at index 1 (value 3) is returned

#### Scenario: Slice access
- **WHEN** accessing sorted_list[1:3] on SortedList([1, 3, 5, 7])
- **THEN** sublist [3, 5] is returned

#### Scenario: Negative indexing
- **WHEN** accessing sorted_list[-1] on SortedList([1, 3, 5])
- **THEN** last element (value 5) is returned

### Requirement: Binary search operations
The SortedList class SHALL provide bisect_left and bisect_right operations returning insertion points.

#### Scenario: Bisect left
- **WHEN** bisect_left(3) is called on SortedList([1, 3, 3, 5])
- **THEN** insertion point 1 is returned (leftmost position for value 3)

#### Scenario: Bisect right
- **WHEN** bisect_right(3) is called on SortedList([1, 3, 3, 5])
- **THEN** insertion point 3 is returned (rightmost position for value 3)

### Requirement: Containment and counting operations
The SortedList class SHALL efficiently test membership and count occurrences.

#### Scenario: Check element existence
- **WHEN** checking if 3 in SortedList([1, 3, 5])
- **THEN** True is returned for existing elements

#### Scenario: Count element occurrences
- **WHEN** count(3) is called on SortedList([1, 3, 3, 5])
- **THEN** 2 is returned

### Requirement: Iteration and reversal
The SortedList class SHALL support forward and reverse iteration over all elements.

#### Scenario: Forward iteration
- **WHEN** iterating SortedList([1, 3, 5])
- **THEN** elements are yielded in order: 1, 3, 5

#### Scenario: Reverse iteration
- **WHEN** using reversed(SortedList([1, 3, 5]))
- **THEN** elements are yielded in reverse order: 5, 3, 1

### Requirement: Range query operations
The SortedList class SHALL support irange and islice for efficient range queries.

#### Scenario: Inclusive range
- **WHEN** irange(2, 4) is called on SortedList([1, 2, 3, 4, 5])
- **THEN** iterator yields values within range [2, 4]

#### Scenario: Range with exclusive boundaries
- **WHEN** irange(2, 4, (False, False)) is called
- **THEN** iterator yields values in open interval (2, 4)

### Requirement: Sequence operations
The SortedList class SHALL support concatenation and repetition operations.

#### Scenario: Addition concatenation
- **WHEN** SortedList([1, 2]) + SortedList([3, 4])
- **THEN** new SortedList([1, 2, 3, 4]) is returned

#### Scenario: Multiplication repetition
- **WHEN** SortedList([1, 2]) * 2
- **THEN** new SortedList([1, 1, 2, 2]) is returned with duplicates sorted

### Requirement: Length and representation
The SortedList class SHALL support len() and repr() operations.

#### Scenario: Get list length
- **WHEN** len() is called on SortedList([1, 2, 3])
- **THEN** 3 is returned

#### Scenario: String representation
- **WHEN** repr() is called on SortedList([1, 2, 3])
- **THEN** "SortedList([1, 2, 3])" is returned

### Requirement: Index finding by value
The SortedList class SHALL find the index of a value using binary search.

#### Scenario: Find existing value
- **WHEN** index(3) is called on SortedList([1, 3, 5])
- **THEN** index 1 is returned

#### Scenario: Value not found
- **WHEN** index(4) is called on SortedList([1, 3, 5])
- **THEN** ValueError is raised

### Requirement: Copy operation
The SortedList class SHALL create a shallow copy.

#### Scenario: Copy creates independent list
- **WHEN** copy() is called on SortedList([1, 2, 3])
- **THEN** new independent SortedList([1, 2, 3]) is returned

### Requirement: Internal consistency and debugging
The SortedList class SHALL provide internal consistency checks and reset functions for debugging.

#### Scenario: Consistency check
- **WHEN** _check() is called on valid SortedList
- **THEN** assertion passes with no errors

#### Scenario: Reset internal state
- **WHEN** _reset() is called
- **THEN** internal indices are rebuilt to ensure consistency
