from collections.abc import MutableMapping, KeysView, ValuesView, ItemsView
from .sortedlist import SortedList


class SortedKeysView(KeysView):

    def __init__(self, sd):
        self._sd = sd
        self._keys = sd._keys

    def __getitem__(self, index):
        if isinstance(index, slice):
            return list(self._keys[index])
        return self._keys[index]

    def __iter__(self):
        return iter(self._keys)

    def __len__(self):
        return len(self._keys)

    def __contains__(self, key):
        return key in self._keys


class SortedValuesView(ValuesView):

    def __init__(self, sd):
        self._sd = sd
        self._keys = sd._keys
        self._values = sd._values

    def __getitem__(self, index):
        if isinstance(index, slice):
            keys = self._keys[index]
            return [self._values[k] for k in keys]
        key = self._keys[index]
        return self._values[key]

    def __iter__(self):
        for key in self._keys:
            yield self._values[key]

    def __len__(self):
        return len(self._keys)

    def __contains__(self, value):
        return value in self._values.values()


class SortedItemsView(ItemsView):

    def __init__(self, sd):
        self._sd = sd
        self._keys = sd._keys
        self._values = sd._values

    def __getitem__(self, index):
        if isinstance(index, slice):
            keys = self._keys[index]
            return [(k, self._values[k]) for k in keys]
        key = self._keys[index]
        return (key, self._values[key])

    def __iter__(self):
        for key in self._keys:
            yield (key, self._values[key])

    def __len__(self):
        return len(self._keys)

    def __contains__(self, item):
        key, value = item
        return key in self._values and self._values[key] == value


class SortedDict(MutableMapping):

    def __init__(self, *args, **kwargs):
        self._keys = SortedList()
        self._values = {}

        if args:
            if len(args) > 1:
                raise TypeError(f'SortedDict() takes at most 1 positional argument ({len(args)} given)')
            other = args[0]
            if isinstance(other, dict):
                for key in sorted(other.keys()):
                    self._keys.add(key)
                    self._values[key] = other[key]
            else:
                for key, value in other:
                    self[key] = value

        for key, value in kwargs.items():
            self[key] = value

    def __getitem__(self, key):
        return self._values[key]

    def __setitem__(self, key, value):
        if key not in self._values:
            self._keys.add(key)
        self._values[key] = value

    def __delitem__(self, key):
        try:
            self._keys.remove(key)
        except ValueError:
            raise KeyError(key)
        del self._values[key]

    def __len__(self):
        return len(self._keys)

    def __repr__(self):
        items = ', '.join(f'{k!r}: {v!r}' for k, v in self.items())
        return f'SortedDict({{{items}}})'

    def __iter__(self):
        return iter(self._keys)

    def __contains__(self, key):
        return key in self._values

    def __bool__(self):
        return bool(self._values)

    def get(self, key, default=None):
        return self._values.get(key, default)

    def setdefault(self, key, default=None):
        if key not in self._values:
            self[key] = default
        return self._values[key]

    def update(self, *args, **kwargs):
        if args:
            if len(args) > 1:
                raise TypeError(f'update() takes at most 1 positional argument ({len(args)} given)')
            other = args[0]
            if isinstance(other, dict):
                for key in other:
                    self[key] = other[key]
            else:
                for key, value in other:
                    self[key] = value
        for key, value in kwargs.items():
            self[key] = value

    def pop(self, key, *args):
        if len(args) > 1:
            raise TypeError(f'pop() takes at most 2 arguments ({len(args) + 1} given)')
        try:
            value = self._values[key]
            del self[key]
            return value
        except KeyError:
            if args:
                return args[0]
            raise

    def popitem(self):
        if not self._keys:
            raise KeyError('dictionary is empty')
        key = self._keys[-1]
        value = self._values[key]
        del self[key]
        return (key, value)

    def clear(self):
        self._keys.clear()
        self._values.clear()

    def copy(self):
        return SortedDict(self.items())

    def keys(self):
        return SortedKeysView(self)

    def values(self):
        return SortedValuesView(self)

    def items(self):
        return SortedItemsView(self)
