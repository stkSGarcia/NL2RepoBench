import bisect
from collections.abc import MutableSequence


class SortedList(MutableSequence):
    DEFAULT_LOAD_FACTOR = 1000

    def __init__(self, iterable=None, key=None):
        self._lists = [[]]
        self._maxes = [float('-inf')]
        self._index = [0]
        self._offset = [0]
        self._load = self.DEFAULT_LOAD_FACTOR
        if iterable:
            self.update(iterable)

    def _check(self):
        assert len(self._lists) == len(self._maxes) == len(self._index) == len(self._offset)
        for i, lst in enumerate(self._lists):
            assert lst, f"Empty list at index {i}"
            assert self._maxes[i] == lst[-1], f"Max mismatch at {i}"

    def _reset(self):
        self._maxes = [lst[-1] for lst in self._lists]
        self._index = [0]
        for lst in self._lists[:-1]:
            self._index.append(self._index[-1] + len(lst))
        self._offset = [0] * len(self._lists)

    def _pos(self, value):
        lo = 0
        hi = len(self._lists)
        while lo < hi:
            mid = (lo + hi) // 2
            if self._maxes[mid] == float('-inf') or value <= self._maxes[mid]:
                hi = mid
            else:
                lo = mid + 1
        return lo if lo < len(self._lists) else len(self._lists) - 1

    def add(self, value):
        pos = self._pos(value)
        lst = self._lists[pos]
        idx = bisect.bisect_right(lst, value)
        lst.insert(idx, value)
        self._maxes[pos] = lst[-1]

        if len(lst) > self._load:
            mid = len(lst) // 2
            new_lst = lst[mid:]
            lst[:] = lst[:mid]
            self._lists.insert(pos + 1, new_lst)
            self._maxes.insert(pos + 1, new_lst[-1])
            self._index.insert(pos + 1, 0)
            self._offset.insert(pos + 1, 0)
            self._reset()

    def __getitem__(self, index):
        if isinstance(index, slice):
            return [self[i] for i in range(*index.indices(len(self)))]

        if index < 0:
            index += len(self)
        if not (0 <= index < len(self)):
            raise IndexError("list index out of range")

        for i, lst in enumerate(self._lists):
            if index < len(lst):
                return lst[index]
            index -= len(lst)

    def __setitem__(self, index, value):
        if isinstance(index, slice):
            del self[index]
            for v in value:
                self.add(v)
            return

        if index < 0:
            index += len(self)
        if not (0 <= index < len(self)):
            raise IndexError("list index out of range")

        pos = 0
        for i, lst in enumerate(self._lists):
            if index < pos + len(lst):
                idx = index - pos
                del lst[idx]
                self._maxes[i] = lst[-1] if lst else float('-inf')
                self.add(value)
                return
            pos += len(lst)

    def __delitem__(self, index):
        if isinstance(index, slice):
            for i in reversed(range(*index.indices(len(self)))):
                del self[i]
            return

        if index < 0:
            index += len(self)
        if not (0 <= index < len(self)):
            raise IndexError("list index out of range")

        pos = 0
        for i, lst in enumerate(self._lists):
            if index < pos + len(lst):
                idx = index - pos
                del lst[idx]
                if lst:
                    self._maxes[i] = lst[-1]
                else:
                    self._lists.pop(i)
                    self._maxes.pop(i)
                    self._index.pop(i)
                    self._offset.pop(i)
                return
            pos += len(lst)

    def __len__(self):
        return sum(len(lst) for lst in self._lists)

    def __repr__(self):
        return f'SortedList({list(self)})'

    def __contains__(self, value):
        pos = self._pos(value)
        return value in self._lists[pos]

    def __iter__(self):
        for lst in self._lists:
            yield from lst

    def __reversed__(self):
        for lst in reversed(self._lists):
            yield from reversed(lst)

    def bisect_left(self, value):
        pos = self._pos(value)
        idx = bisect.bisect_left(self._lists[pos], value)
        for i in range(pos):
            idx += len(self._lists[i])
        return idx

    def bisect_right(self, value):
        pos = self._pos(value)
        idx = bisect.bisect_right(self._lists[pos], value)
        for i in range(pos):
            idx += len(self._lists[i])
        return idx

    def index(self, value, start=0, stop=None):
        if stop is None:
            stop = len(self)
        try:
            idx = self.bisect_left(value)
        except (ValueError, IndexError):
            raise ValueError(f'{value} not in list')
        if idx < start or idx >= stop or (idx < len(self) and self[idx] != value):
            raise ValueError(f'{value} not in list')
        return idx

    def count(self, value):
        left = self.bisect_left(value)
        right = self.bisect_right(value)
        return right - left

    def remove(self, value):
        idx = self.index(value)
        del self[idx]

    def discard(self, value):
        try:
            self.remove(value)
        except ValueError:
            pass

    def pop(self, index=-1):
        value = self[index]
        del self[index]
        return value

    def clear(self):
        self._lists = [[]]
        self._maxes = [float('-inf')]
        self._index = [0]
        self._offset = [0]

    def update(self, iterable):
        items = sorted(iterable)
        for item in items:
            self.add(item)

    def irange(self, minimum=None, maximum=None, inclusive=(True, True)):
        start = 0 if minimum is None else self.bisect_left(minimum)
        if minimum is not None and not inclusive[0] and start < len(self) and self[start] == minimum:
            start += 1
        if maximum is None:
            stop = len(self)
        else:
            stop = self.bisect_right(maximum)
            if not inclusive[1] and stop > 0 and self[stop - 1] == maximum:
                stop -= 1
        return iter(self[start:stop])

    def islice(self, start=None, stop=None, reverse=False):
        if start is None:
            start = 0
        if stop is None:
            stop = len(self)
        if start < 0:
            start = max(0, len(self) + start)
        if stop < 0:
            stop = max(0, len(self) + stop)
        if reverse:
            for i in range(min(stop, len(self)) - 1, max(start - 1, -1), -1):
                yield self[i]
        else:
            for i in range(start, min(stop, len(self))):
                yield self[i]

    def copy(self):
        return SortedList(self)

    def __add__(self, other):
        result = self.copy()
        result.update(other)
        return result

    def __iadd__(self, other):
        self.update(other)
        return self

    def __mul__(self, count):
        if count < 0:
            return SortedList()
        result = SortedList()
        for _ in range(count):
            result.update(self)
        return result

    def __imul__(self, count):
        if count < 1:
            self.clear()
        elif count > 1:
            self.update(list(self) * (count - 1))
        return self

    def insert(self, index, value):
        self.add(value)


class SortedKeyList(SortedList):

    def __new__(cls, iterable=None, key=None):
        if key is None:
            return object.__new__(SortedList)
        return object.__new__(cls)

    def __init__(self, iterable=None, key=None):
        if key is None:
            return
        self._key = key
        super().__init__(iterable=None)
        if iterable:
            self.update(iterable)

    def add(self, value):
        key_value = self._key(value)
        pos = self._pos_key(key_value)
        lst = self._lists[pos]
        idx = self._bisect_right(lst, key_value)
        lst.insert(idx, value)
        self._maxes[pos] = lst[-1]

        if len(lst) > self._load:
            mid = len(lst) // 2
            new_lst = lst[mid:]
            lst[:] = lst[:mid]
            self._lists.insert(pos + 1, new_lst)
            self._maxes.insert(pos + 1, new_lst[-1])
            self._index.insert(pos + 1, 0)
            self._offset.insert(pos + 1, 0)
            self._reset()

    def _pos_key(self, key_value):
        lo = 0
        hi = len(self._lists)
        while lo < hi:
            mid = (lo + hi) // 2
            max_val = self._maxes[mid]
            max_key = self._key(max_val) if max_val != float('-inf') else float('-inf')
            if key_value <= max_key:
                hi = mid
            else:
                lo = mid + 1
        return lo if lo < len(self._lists) else len(self._lists) - 1

    def _bisect_left(self, lst, key_value):
        lo, hi = 0, len(lst)
        while lo < hi:
            mid = (lo + hi) // 2
            if self._key(lst[mid]) < key_value:
                lo = mid + 1
            else:
                hi = mid
        return lo

    def _bisect_right(self, lst, key_value):
        lo, hi = 0, len(lst)
        while lo < hi:
            mid = (lo + hi) // 2
            if key_value < self._key(lst[mid]):
                hi = mid
            else:
                lo = mid + 1
        return lo

    def bisect_left(self, value):
        key_value = self._key(value)
        pos = self._pos_key(key_value)
        idx = self._bisect_left(self._lists[pos], key_value)
        for i in range(pos):
            idx += len(self._lists[i])
        return idx

    def bisect_right(self, value):
        key_value = self._key(value)
        pos = self._pos_key(key_value)
        idx = self._bisect_right(self._lists[pos], key_value)
        for i in range(pos):
            idx += len(self._lists[i])
        return idx

    def index(self, value, start=0, stop=None):
        if stop is None:
            stop = len(self)
        key_value = self._key(value)
        idx = self.bisect_left(value)
        if idx < start or idx >= stop or idx >= len(self) or self[idx] != value:
            raise ValueError(f'{value} not in list')
        return idx

    def count(self, value):
        key_value = self._key(value)
        left = self.bisect_left(value)
        right = self.bisect_right(value)
        return right - left

    def copy(self):
        return SortedKeyList(self, key=self._key)
