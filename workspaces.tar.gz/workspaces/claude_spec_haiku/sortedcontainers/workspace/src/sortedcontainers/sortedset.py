from collections.abc import MutableSet
from .sortedlist import SortedList


class SortedSet(MutableSet):

    def __init__(self, iterable=None):
        self._list = SortedList()
        if iterable:
            for item in iterable:
                self.add(item)

    def add(self, value):
        if value not in self._list:
            self._list.add(value)

    def discard(self, value):
        self._list.discard(value)

    def remove(self, value):
        if value not in self._list:
            raise KeyError(value)
        self._list.remove(value)

    def pop(self):
        if not self._list:
            raise KeyError('pop from an empty set')
        return self._list.pop()

    def clear(self):
        self._list.clear()

    def __contains__(self, value):
        return value in self._list

    def __iter__(self):
        return iter(self._list)

    def __reversed__(self):
        return reversed(self._list)

    def __len__(self):
        return len(self._list)

    def __repr__(self):
        return f'SortedSet({list(self._list)})'

    def __getitem__(self, index):
        if isinstance(index, slice):
            return SortedSet(self._list[index])
        return self._list[index]

    def copy(self):
        return SortedSet(self._list)

    def __bool__(self):
        return bool(self._list)

    def union(self, *others):
        result = self.copy()
        for other in others:
            for item in other:
                result.add(item)
        return result

    def __or__(self, other):
        return self.union(other)

    def __ior__(self, other):
        self.update(other)
        return self

    def update(self, *others):
        for other in others:
            for item in other:
                self.add(item)

    def intersection(self, *others):
        if not others:
            return self.copy()
        result = SortedSet()
        for item in self:
            if all(item in other for other in others):
                result.add(item)
        return result

    def __and__(self, other):
        return self.intersection(other)

    def __iand__(self, other):
        temp = self.intersection(other)
        self._list = temp._list
        return self

    def intersection_update(self, *others):
        if not others:
            return
        temp = self.intersection(*others)
        self._list = temp._list

    def difference(self, *others):
        result = self.copy()
        for other in others:
            for item in other:
                result.discard(item)
        return result

    def __sub__(self, other):
        return self.difference(other)

    def __isub__(self, other):
        for item in other:
            self.discard(item)
        return self

    def difference_update(self, *others):
        for other in others:
            for item in other:
                self.discard(item)

    def symmetric_difference(self, other):
        result = self.copy()
        for item in other:
            if item in result:
                result.discard(item)
            else:
                result.add(item)
        return result

    def __xor__(self, other):
        return self.symmetric_difference(other)

    def __ixor__(self, other):
        temp = self.symmetric_difference(other)
        self._list = temp._list
        return self

    def symmetric_difference_update(self, other):
        for item in other:
            if item in self:
                self.discard(item)
            else:
                self.add(item)

    def isdisjoint(self, other):
        return not any(item in other for item in self)

    def __le__(self, other):
        return all(item in other for item in self)

    def __lt__(self, other):
        return len(self) < len(other) and self <= other

    def __ge__(self, other):
        return all(item in self for item in other)

    def __gt__(self, other):
        return len(self) > len(other) and self >= other

    def __eq__(self, other):
        if not isinstance(other, (set, SortedSet)):
            return False
        return len(self) == len(other) and all(item in other for item in self)

    def __ne__(self, other):
        return not (self == other)
