__version__ = '1.0.0'
__title__ = 'sortedcontainers'
__description__ = 'Pure-Python sorted container types with O(log n) operations'
__author__ = 'Samuel Garcia'
__license__ = 'Apache 2.0'

from .sortedlist import SortedList, SortedKeyList
from .sorteddict import SortedDict
from .sortedset import SortedSet

__all__ = [
    'SortedList',
    'SortedKeyList',
    'SortedDict',
    'SortedSet',
]
