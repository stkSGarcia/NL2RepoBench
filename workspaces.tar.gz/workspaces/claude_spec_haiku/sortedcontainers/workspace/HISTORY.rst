History
=======

1.0.0 (2024-05-18)
------------------

Initial release of sortedcontainers library.

New Features
~~~~~~~~~~~~

- **SortedList** - Pure-Python sorted list with O(log n) insertion, deletion, and lookup

  - Binary search operations: bisect_left, bisect_right, index, count
  - Removal operations: remove, discard, pop, clear
  - Batch operations: update, irange, islice
  - Sequence protocol: indexing, slicing, iteration
  - Operators: __add__, __mul__, __iadd__, __imul__

- **SortedKeyList** - SortedList with custom key function support

  - Factory pattern: SortedList(..., key=fn) automatically returns SortedKeyList instance
  - Key-aware binary search and comparison operations
  - Maintains API compatibility with SortedList

- **SortedDict** - Sorted dictionary with O(log n) key operations

  - Maintains sorted key order with dictionary semantics
  - View objects: keys(), values(), items() with indexing and slicing
  - Dynamic views reflect real-time dictionary changes
  - Full MutableMapping protocol implementation

- **SortedSet** - Sorted set with sequence and set operations

  - Sequence access: indexing, slicing, iteration
  - Set operations: union, intersection, difference, symmetric_difference
  - Comparison operators: isdisjoint, subset, superset
  - Full MutableSet protocol implementation

- **Performance Optimization**

  - Segmented list architecture with default load factor of 1000
  - Dynamic index management for efficient binary search
  - Amortized O(1) insertion cost after binary search
  - Efficient handling of 100,000+ element datasets

- **Testing**

  - Comprehensive test suite with 129 unit tests
  - Coverage includes edge cases, large datasets, and error conditions
  - Tests for all sequence, mapping, and set protocols

- **Documentation**

  - API reference documentation with Sphinx
  - Introduction with quick-start examples
  - Usage examples for all data structures
  - Performance analysis and comparison with alternatives
  - Installation and development guides

- **Packaging**

  - Pure-Python implementation, no build tools required
  - Setup via pyproject.toml and setup.py
  - Multi-environment testing via tox (Python 3.10, 3.11, 3.12)
  - Configured for PyPI distribution

Supported Python Versions
~~~~~~~~~~~~~~~~~~~~~~~~~

- Python 3.10
- Python 3.11
- Python 3.12

Known Limitations
~~~~~~~~~~~~~~~~~

- Not thread-safe (relies on GIL for implicit protection)
- Designed for datasets up to 100,000+ elements
- Pure Python may be slower than C-based alternatives for extreme performance requirements

Future Plans
~~~~~~~~~~~~

- Optional Cython-compiled wheels for additional performance
- Additional specialized methods for specific use cases
- Extended documentation with real-world examples
- Performance benchmarking suite and optimization improvements
