from setuptools import setup, find_packages

setup(
    name='pypinyin',
    version='0.1.0',
    author='Samuel Garcia',
    author_email='stk.sgarcia@gmail.com',
    description='A Chinese character to pinyin conversion library',
    long_description=open('README.rst', encoding='utf-8').read() if __name__ == '__main__' else '',
    url='https://github.com/example/pypinyin',
    packages=find_packages(),
    include_package_data=True,
    install_requires=[
        'jieba>=0.42.1',
        'chardet>=5.2.0',
        'typing-extensions>=4.12.2',
    ],
    python_requires='>=3.10',
    classifiers=[
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'License :: OSI Approved :: MIT License',
    ],
)
