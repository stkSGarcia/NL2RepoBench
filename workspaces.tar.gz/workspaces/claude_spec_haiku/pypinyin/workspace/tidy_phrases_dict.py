"""Script to tidy and validate phrases dictionary."""

import json
import os
from typing import Dict, List

def get_pinyins_via_pinyin_dict(phrase: str, pinyin_dict: Dict[str, str]) -> List[List[str]]:
    """Get pinyins for a phrase using pinyin dictionary.

    Args:
        phrase: Phrase string
        pinyin_dict: Character pinyin dictionary

    Returns:
        List of pinyin lists for each character
    """
    result = []
    for char in phrase:
        code = str(ord(char))
        if code in pinyin_dict:
            pinyins = pinyin_dict[code].split(',')
            result.append(pinyins)
        else:
            result.append([char])
    return result

def double_check(phrases_dict: Dict[str, List[List[str]]],
                 pinyin_dict: Dict[str, str]) -> Dict[str, List[List[str]]]:
    """Verify and clean phrases dictionary against pinyin dictionary.

    Args:
        phrases_dict: Phrases dictionary to check
        pinyin_dict: Reference pinyin dictionary

    Returns:
        Cleaned phrases dictionary
    """
    cleaned = {}

    for phrase, pinyin_list in phrases_dict.items():
        # Verify each pinyin exists in pinyin dict
        valid = True
        for py_options in pinyin_list:
            if not py_options:
                valid = False
                break

        if valid:
            cleaned[phrase] = pinyin_list
        else:
            # Try to reconstruct from pinyin dict
            reconstructed = get_pinyins_via_pinyin_dict(phrase, pinyin_dict)
            if reconstructed:
                cleaned[phrase] = reconstructed

    return cleaned

def tidy_phrases_dict(input_file: str, pinyin_dict_file: str, output_file: str):
    """Tidy phrases dictionary.

    Args:
        input_file: Phrases dictionary JSON
        pinyin_dict_file: Pinyin dictionary JSON for reference
        output_file: Output tidied JSON
    """
    if not os.path.exists(input_file):
        print(f"Phrases dict not found: {input_file}")
        return

    if not os.path.exists(pinyin_dict_file):
        print(f"Pinyin dict not found: {pinyin_dict_file}")
        return

    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            phrases_dict = json.load(f)

        with open(pinyin_dict_file, 'r', encoding='utf-8') as f:
            pinyin_dict = json.load(f)

        cleaned = double_check(phrases_dict, pinyin_dict)

        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(cleaned, f, ensure_ascii=False, indent=2)

        print(f"Tidied {len(cleaned)} phrases to {output_file}")
        print(f"Removed {len(phrases_dict) - len(cleaned)} invalid entries")

    except Exception as e:
        print(f"Error tidying dictionary: {e}")

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 2:
        phrases_f = sys.argv[1]
        pinyin_f = sys.argv[2]
        output_f = sys.argv[3] if len(sys.argv) > 3 else 'phrases_dict_tidied.json'
        tidy_phrases_dict(phrases_f, pinyin_f, output_f)
    else:
        print("Usage: python tidy_phrases_dict.py <phrases_dict> <pinyin_dict> [output_file]")
