pypinyin - English Documentation
=================================

**pypinyin** is a Python library for converting Chinese characters to pinyin (romanization).

What is Pinyin?
---------------

Pinyin is the romanization system for Standard Chinese. It represents Chinese characters
using Latin alphabet letters with tone marks.

Features
--------

- **Multiple Styles**: Support for TONE, TONE2, TONE3, INITIALS, FINALS, and more
- **Polyphone Support**: Handle characters with multiple pronunciations
- **Tone Sandhi**: Automatic application of Chinese tone sandhi rules
- **Custom Dictionaries**: Load custom character and phrase dictionaries
- **Type Safety**: Full type hints with .pyi stub files
- **Flexible Error Handling**: Multiple strategies for handling unconvertible characters

Installation
------------

.. code-block:: bash

    pip install pypinyin

Basic Usage
-----------

.. code-block:: python

    from pypinyin import pinyin, lazy_pinyin, Style

    # Basic conversion returns nested lists
    result = pinyin('你好')
    # [['ni'], ['hao']]

    # Flatten results with lazy_pinyin
    result = lazy_pinyin('你好')
    # ['ni', 'hao']

    # Change output style
    result = lazy_pinyin('你好', style=Style.TONE)
    # ['nǐ', 'hǎo']

    # Create a slug
    from pypinyin import slug
    slug('北京')
    # 'bei-jing'

Advanced Features
-----------------

**Heteronyms (Polyphones):**

.. code-block:: python

    result = pinyin('中', heteronym=True)
    # [['zhong', 'zhòng']]

**Tone Sandhi:**

.. code-block:: python

    from pypinyin.contrib.tone_sandhi import ToneSandhiMixin
    result = ToneSandhiMixin.apply_tone_sandhi(['ni3', 'hao3'])
    # ['ni2', 'hao3']  # Third tone sandhi applied

**Custom Dictionary:**

.. code-block:: python

    from pypinyin import pinyin_dict
    custom_dict = {'20320': 'you1,ni3'}  # Custom entry for character 你
    pinyin_dict.load_single_dict(custom_dict)

API Reference
-------------

Main Functions:

- ``pinyin(text, style, heteronym, errors, strict)`` - Convert to nested lists
- ``lazy_pinyin(text, style, errors, strict)`` - Convert to flat list
- ``slug(text, style, heteronym, separator, errors)`` - Convert to slug

Classes:

- ``Converter`` - Base converter class
- ``DefaultConverter`` - Standard conversion
- ``UltimateConverter`` - All features enabled

Contributing
------------

Contributions are welcome! Please open an issue or submit a pull request.

License
-------

MIT License - see LICENSE.txt for details
