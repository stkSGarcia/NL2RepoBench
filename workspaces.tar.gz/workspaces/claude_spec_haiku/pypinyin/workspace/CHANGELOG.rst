Changelog
=========

All notable changes to this project will be documented in this file.

The format is based on `Keep a Changelog <https://keepachangelog.com/en/1.0.0/>`_
and this project adheres to `Semantic Versioning <https://semver.org/spec/v2.0.0.html>`_.

[0.1.0] - 2026-05-17
--------------------

Initial Release

Added
~~~~~

- Core pinyin conversion engine with dictionary-based lookup
- Support for 45+ pinyin output styles
- Multiple pinyin conversion modes (NORMAL, TONE, TONE2, TONE3, INITIALS, FINALS, etc.)
- Polyphone (heteronym) support for characters with multiple pronunciations
- Tone sandhi rules for natural speech conversion
- Custom dictionary loading support
- Phrase-level pinyin conversion with context awareness
- High-level API functions (pinyin, lazy_pinyin, slug)
- Converter pattern for pluggable behavior
- Style registry for extensible output formats
- Comprehensive error handling strategies
- Type hints and PEP 561 support (.pyi files)
- Support for CJK characters (basic blocks and extensions)
- Bopomofo (Zhuyin) notation conversion
- Wade-Giles romanization
- Cyrillic transliteration
- Braille notation
- Gwoyeu Romatzyh romanization
- CLI support via __main__.py
- PyInstaller hook for frozen applications
- Extensive documentation and examples
- Test suite with multiple test categories
- Configuration files for development (tox, pytest, coverage)

[Unreleased]
------------

- Machine learning-based pinyin prediction
- Real-time dictionary updates
- Web service/API component
- Audio pronunciation generation
