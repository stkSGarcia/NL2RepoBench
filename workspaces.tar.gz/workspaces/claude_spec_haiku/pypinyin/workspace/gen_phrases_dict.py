"""Script to generate phrases dictionary from source data."""

import json
import os
from typing import Dict, List

def remove_dup_items(lst: List) -> List:
    """Remove duplicate items while preserving order."""
    seen = set()
    result = []
    for item in lst:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result

def generate_phrases_dict(input_file: str, output_file: str):
    """Generate phrases dictionary JSON from source data.

    Args:
        input_file: Source phrases data file
        output_file: Output JSON dictionary file
    """
    if not os.path.exists(input_file):
        print(f"Input file not found: {input_file}")
        return

    phrases_dict: Dict[str, List[List[str]]] = {}

    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue

                # Expected format: phrase,pinyin1,pinyin2,...
                parts = line.split(',')
                if len(parts) >= 2:
                    phrase = parts[0]
                    # Each character gets a list of pinyin options
                    pinyins = parts[1:]
                    # For simplicity, split into character pinyins
                    if len(phrase) == len(pinyins):
                        phrases_dict[phrase] = [[py] for py in pinyins]

        # Write output
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(phrases_dict, f, ensure_ascii=False, indent=2)

        print(f"Generated {len(phrases_dict)} entries to {output_file}")

    except Exception as e:
        print(f"Error generating dictionary: {e}")

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        input_f = sys.argv[1]
        output_f = sys.argv[2] if len(sys.argv) > 2 else 'phrases_dict.json'
        generate_phrases_dict(input_f, output_f)
    else:
        print("Usage: python gen_phrases_dict.py <input_file> [output_file]")
