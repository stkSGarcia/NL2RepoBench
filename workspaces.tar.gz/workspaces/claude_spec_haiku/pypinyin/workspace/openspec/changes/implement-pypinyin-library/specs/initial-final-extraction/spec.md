## ADDED Requirements

### Requirement: Extract initial consonants from pinyin
The system SHALL identify and return the initial consonant(s) from a pinyin syllable.

#### Scenario: Extract simple initial
- **WHEN** to_initials() is called with "ni"
- **THEN** system returns "n"

#### Scenario: Extract two-character initial
- **WHEN** to_initials() is called with "zhong"
- **THEN** system returns "zh" (two-character initial)

#### Scenario: No initial (zero initial)
- **WHEN** to_initials() is called with "ai"
- **THEN** system returns "" (empty, as 'a' is a vowel)

#### Scenario: Strict vs relaxed mode for y/w
- **WHEN** to_initials() is called with "ya" and strict=True
- **THEN** system returns "" (y not initial in strict mode)

- **WHEN** to_initials() is called with "ya" and strict=False
- **THEN** system returns "y" (y treated as initial in relaxed mode)

### Requirement: Extract final vowels from pinyin
The system SHALL identify and return the final vowel portion from a pinyin syllable.

#### Scenario: Extract simple final
- **WHEN** to_finals() is called with "ni"
- **THEN** system returns "i"

#### Scenario: Extract complex final
- **WHEN** to_finals() is called with "zhong"
- **THEN** system returns "ong"

#### Scenario: Entire syllable as final for zero initial
- **WHEN** to_finals() is called with "ai"
- **THEN** system returns "ai"

#### Scenario: Final with u-v conversion
- **WHEN** to_finals() is called with "nv" and v_to_u=True
- **THEN** system returns "ü" (v converted to ü)

### Requirement: Extract finals with tone marks
The system SHALL extract final vowels while preserving tone marks.

#### Scenario: Extract finals with TONE style
- **WHEN** to_finals_tone() is called with "nǐ"
- **THEN** system returns "ǐ" (final with tone mark)

#### Scenario: Extract finals with TONE2 style
- **WHEN** to_finals_tone2() is called with "ni3"
- **THEN** system returns "i3" (final with tone number)

#### Scenario: Extract finals with TONE3 style
- **WHEN** to_finals_tone3() is called with "ni3"
- **THEN** system returns "i3" (final with tone at end)

### Requirement: Strict and relaxed initial/final processing
The system SHALL support both strict (Hanyu Pinyin) and relaxed modes for initial/final separation.

#### Scenario: Strict mode enforcement
- **WHEN** strict=True is used
- **THEN** system follows official Hanyu Pinyin standard strictly

#### Scenario: Relaxed mode flexibility
- **WHEN** strict=False is used
- **THEN** system allows alternative treatments (e.g., y/w as initials)

### Requirement: Standard initial and final lists
The system SHALL maintain authoritative lists of valid initials and finals.

#### Scenario: Standard initials list
- **WHEN** system initializes
- **THEN** it loads standard initials list (b,p,m,f,d,t,n,l,g,k,h,j,q,x,zh,ch,sh,r,z,c,s)

#### Scenario: Standard finals list
- **WHEN** system initializes
- **THEN** it loads standard finals list (i,u,ü,a,ia,ua,o,uo,e,ie,üe,ai,uai,ei,uei,ao,iao,ou,iou,an,ian,uan,üan,en,in,uen,ün,ang,iang,uang,eng,ing,ueng,ong,iong,er,ê)
