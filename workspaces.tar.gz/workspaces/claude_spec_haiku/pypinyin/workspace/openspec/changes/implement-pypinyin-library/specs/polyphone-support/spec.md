## ADDED Requirements

### Requirement: Return all pronunciations for heteronym characters
The system SHALL return all possible pronunciations for a character when heteronym=True.

#### Scenario: Multiple pronunciations returned
- **WHEN** pinyin() is called with "中" and heteronym=True
- **THEN** result is [['zhōng', 'zhòng']] with all pronunciations

#### Scenario: Character with single pronunciation
- **WHEN** heteronym=True for character with only one pronunciation
- **THEN** result is [['nǐ']] with single pronunciation in list

### Requirement: Return only first pronunciation by default
The system SHALL return only the first pronunciation when heteronym=False (default).

#### Scenario: Single pronunciation by default
- **WHEN** pinyin() is called with "中"
- **THEN** result is [['zhōng']] (first pronunciation only)

#### Scenario: Heteronym disabled
- **WHEN** heteronym=False explicitly
- **THEN** only first pronunciation is returned

### Requirement: Multiple pronunciations in dictionary
The system SHALL store and return multiple pronunciations per character.

#### Scenario: Dictionary contains comma-separated pronunciations
- **WHEN** character has multiple entries in pinyin_dict
- **THEN** all pronunciations can be returned with heteronym=True

#### Scenario: Pronunciation order matters
- **WHEN** character has multiple pronunciations
- **THEN** first pronunciation is most common (used when heteronym=False)

### Requirement: Heteronym support in phrase context
The system SHALL respect heteronym parameter in phrase conversion.

#### Scenario: Heteronym in phrase lookup
- **WHEN** phrase_pinyin() is called with heteronym=True
- **THEN** all character pronunciations are returned for the phrase

#### Scenario: Single pronunciation in phrase
- **WHEN** phrase_pinyin() is called with heteronym=False
- **THEN** only first pronunciation per character is returned

### Requirement: Lazy pinyin with heteronym
The system SHALL flatten heteronym results in lazy_pinyin output.

#### Scenario: lazy_pinyin with heteronym enabled
- **WHEN** lazy_pinyin() is called with "中" and heteronym=True
- **THEN** result is ['zhōng', 'zhòng'] (flattened list)

#### Scenario: lazy_pinyin removes duplicates
- **WHEN** lazy_pinyin() is called
- **THEN** duplicate pronunciations within a character are handled properly
