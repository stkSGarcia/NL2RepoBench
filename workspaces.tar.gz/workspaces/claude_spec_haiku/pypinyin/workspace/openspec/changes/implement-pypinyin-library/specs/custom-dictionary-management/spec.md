## ADDED Requirements

### Requirement: Load custom single-character pinyin dictionary
The system SHALL allow users to load custom pinyin definitions for individual characters.

#### Scenario: Load single character custom pinyin
- **WHEN** load_single_dict({ord('桔'): 'jú,jié'}) is called
- **THEN** character '桔' uses custom pinyin definitions

#### Scenario: Custom pinyin overrides default
- **WHEN** custom pinyin is loaded for a character
- **THEN** pinyin() returns the custom definition instead of default

#### Scenario: Multiple pronunciations in custom definition
- **WHEN** load_single_dict() is called with comma-separated values
- **THEN** all pronunciations are available (heteronym support)

### Requirement: Load custom phrase dictionary
The system SHALL allow users to load custom pinyin definitions for multi-character phrases.

#### Scenario: Load phrase custom pinyin
- **WHEN** load_phrases_dict({'同行': [['tóng'], ['xíng']]}) is called
- **THEN** phrase '同行' uses custom pinyin

#### Scenario: Custom phrase pinyin overrides default
- **WHEN** custom phrase pinyin is loaded
- **THEN** pinyin() returns custom definition for that phrase

### Requirement: Dictionary is mutable for custom definitions
The system SHALL maintain mutable dictionaries that can be extended with custom entries.

#### Scenario: Add entry to single-character dictionary
- **WHEN** PINYIN_DICT is updated with new entry
- **THEN** new character has pinyin definition

#### Scenario: Add entry to phrase dictionary
- **WHEN** PHRASES_DICT is updated with new entry
- **THEN** new phrase has pinyin definition

#### Scenario: Prevent accidental mutation with dictionary copy
- **WHEN** system initializes with PYPINYIN_NO_DICT_COPY not set
- **THEN** dictionaries are copied to prevent external mutations affecting other users

### Requirement: Environment variable to disable dictionary copy
The system SHALL support PYPINYIN_NO_DICT_COPY environment variable for memory efficiency.

#### Scenario: Disable copy for memory savings
- **WHEN** PYPINYIN_NO_DICT_COPY is set
- **THEN** dictionaries are not copied (saves memory)

#### Scenario: Default copies dictionaries
- **WHEN** PYPINYIN_NO_DICT_COPY is not set
- **THEN** dictionaries are deep copied

### Requirement: Load dictionaries from JSON files
The system SHALL load pinyin and phrase dictionaries from JSON files.

#### Scenario: Load pinyin dictionary
- **WHEN** _load_pinyin_dict() is called
- **THEN** system loads pinyin_dict.json into PINYIN_DICT

#### Scenario: Load phrases dictionary
- **WHEN** _load_phrases_dict() is called
- **THEN** system loads phrases_dict.json into PHRASES_DICT

#### Scenario: Dictionary format conversion
- **WHEN** JSON dictionary is loaded
- **THEN** string keys are converted to integer character codes (for pinyin_dict)
