## ADDED Requirements

### Requirement: Apply third-tone sandhi rules
The system SHALL apply tone sandhi rules that modify tones based on pronunciation context.

#### Scenario: Third-tone sandhi in "你好"
- **WHEN** pinyin() is called with "你好" and tone_sandhi=True
- **THEN** system returns [['ní'], ['hǎo']] (first third tone becomes second tone)

#### Scenario: Third-tone sandhi rules only apply in sequence
- **WHEN** tone_sandhi applies
- **THEN** consecutive third tones have first one changed to second tone

#### Scenario: Tone sandhi disabled by default
- **WHEN** pinyin() is called without tone_sandhi parameter
- **THEN** tone sandhi is not applied

### Requirement: Support ToneSandhiMixin for tone sandhi processing
The system SHALL provide a mixin class that adds tone sandhi capabilities to custom converters.

#### Scenario: ToneSandhiMixin adds sandhi processing
- **WHEN** converter class includes ToneSandhiMixin
- **THEN** tone sandhi rules are applied during conversion

#### Scenario: Mixin can be composed with other features
- **WHEN** custom converter inherits from ToneSandhiMixin and other mixins
- **THEN** multiple features work together

### Requirement: Handle neutral tone in tone sandhi
The system SHALL correctly handle neutral tone interactions in sandhi rules.

#### Scenario: Neutral tone after third tone
- **WHEN** third tone is followed by neutral tone
- **THEN** third tone remains unchanged (no sandhi applies)

### Requirement: Provide tone sandhi as configurable feature
The system SHALL allow tone_sandhi parameter in main conversion functions.

#### Scenario: Enable tone sandhi globally
- **WHEN** tone_sandhi=True in pinyin() call
- **THEN** all applicable tone sandhi rules are applied

#### Scenario: Disable tone sandhi explicitly
- **WHEN** tone_sandhi=False
- **THEN** no tone sandhi is applied regardless of defaults
