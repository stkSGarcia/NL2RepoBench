## ADDED Requirements

### Requirement: Convert v to ü in pinyin
The system SHALL convert 'v' to 'ü' in pinyin when v_to_u=True.

#### Scenario: V to Ü conversion enabled
- **WHEN** pinyin() is called with "女" and v_to_u=True
- **THEN** system returns [['nǚ']] (with ü not v)

#### Scenario: V to Ü conversion disabled
- **WHEN** pinyin() is called with "女" and v_to_u=False or not set
- **THEN** system returns [['nv']] or [['nǚ']] depending on style

#### Scenario: Conversion in different styles
- **WHEN** v_to_u=True with TONE2 style
- **THEN** 'v' is replaced with 'ü' in tone2 representation

### Requirement: Support _v_to_u utility function
The system SHALL provide _v_to_u() function for explicit v-ü conversion.

#### Scenario: Convert v to ü with replace=True
- **WHEN** _v_to_u('nv', replace=True) is called
- **THEN** result is 'nü'

#### Scenario: No conversion with replace=False
- **WHEN** _v_to_u('nv', replace=False) is called
- **THEN** result is 'nv' unchanged

### Requirement: Fix v/ü consistency in tone conversions
The system SHALL ensure consistent use of v vs ü during tone conversions.

#### Scenario: Maintain v_to_u preference in conversions
- **WHEN** tone conversions happen with v_to_u parameter
- **THEN** result respects v_to_u setting

#### Scenario: _fix_v_u utility function
- **WHEN** _fix_v_u() is called with origin_py and new_py
- **THEN** ü/v handling is consistent between original and new forms

### Requirement: V to Ü in finals extraction
The system SHALL apply v_to_u conversion during finals extraction.

#### Scenario: Extract finals with v_to_u conversion
- **WHEN** to_finals() is called with "nv" and v_to_u=True
- **THEN** finals are returned with 'ü' not 'v'

#### Scenario: Extract finals_tone2 with v_to_u
- **WHEN** to_finals_tone2() is called with v_to_u=True
- **THEN** result uses 'ü' notation

### Requirement: V to Ü in tone conversion functions
The system SHALL provide v_to_u parameter in tone conversion functions.

#### Scenario: tone2_to_normal with v_to_u
- **WHEN** tone2_to_normal('nv3', v_to_u=True) is called
- **THEN** result is 'nü'

#### Scenario: tone2_to_tone3 with v_to_u
- **WHEN** tone2_to_tone3() is called with v_to_u=True
- **THEN** result uses 'ü'

#### Scenario: tone3_to_normal with v_to_u
- **WHEN** tone3_to_normal() is called with v_to_u=True
- **THEN** 'v' is converted to 'ü' in output
