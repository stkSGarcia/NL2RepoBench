## ADDED Requirements

### Requirement: Convert between phonetic symbols and tone numbers
The system SHALL convert multi-character phonetic symbols to their equivalent tone number representations.

#### Scenario: Multi-character phonetic symbol conversion
- **WHEN** prepare() processes input with multi-character phonetic symbols
- **THEN** symbols are replaced with single-character equivalents

#### Scenario: Identify phonetic symbols
- **WHEN** text contains phonetic symbols
- **THEN** system recognizes them for conversion

### Requirement: Support phonetic symbol dictionary
The system SHALL maintain a dictionary mapping phonetic symbols to tone numbers.

#### Scenario: Phonetic symbol lookup
- **WHEN** PHONETIC_SYMBOL_DICT is accessed
- **THEN** it contains mappings of phonetic characters to tones

#### Scenario: Multi-character symbol dictionary
- **WHEN** PHONETIC_SYMBOL_DICT_KEY_LENGTH_NOT_ONE is accessed
- **THEN** it contains symbols with length > 1

### Requirement: Regular expression for phonetic symbol matching
The system SHALL provide regex pattern for identifying phonetic symbols.

#### Scenario: Detect phonetic symbols with regex
- **WHEN** RE_PHONETIC_SYMBOL pattern is used
- **WHEN** text contains phonetic symbols
- **THEN** pattern matches single-character symbols

### Requirement: Prepare input for tone conversion
The system SHALL prepare input text by replacing phonetic symbols before tone conversion.

#### Scenario: Prepare input with multi-char symbols
- **WHEN** prepare() is called with multi-character symbols
- **THEN** symbols are normalized for processing

#### Scenario: No replacement needed
- **WHEN** prepare() is called with already-normalized input
- **THEN** input is returned unchanged

### Requirement: Regex substitution utility
The system SHALL provide re_sub() function for phonetic symbol replacement.

#### Scenario: Apply action to regex matches
- **WHEN** re_sub() is called with action function
- **THEN** action is applied to matched text
