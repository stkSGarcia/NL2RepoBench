## ADDED Requirements

### Requirement: Convert single Chinese character to pinyin
The system SHALL look up single Chinese characters in the pinyin dictionary and return their pronunciation.

#### Scenario: Single character conversion
- **WHEN** single_pinyin() is called with character "中"
- **THEN** system returns pinyin list [['zhōng']] (or [['zhòng']] depending on context)

#### Scenario: Character not in dictionary
- **WHEN** single_pinyin() is called with a character having no pinyin entry
- **THEN** system handles according to errors parameter (default/ignore/replace/exception)

### Requirement: Convert multi-character phrases to pinyin
The system SHALL look up phrases in the phrases dictionary for context-aware pronunciation, with fallback to character-by-character conversion.

#### Scenario: Phrase-level lookup succeeds
- **WHEN** phrase_pinyin() is called with "中心" as a phrase
- **THEN** system returns phrase-specific pinyin if available, not character-by-character lookup

#### Scenario: Unknown phrase falls back to character lookup
- **WHEN** phrase_pinyin() is called with a phrase not in phrases_dict
- **THEN** system converts each character individually using pinyin_dict

#### Scenario: Complex text with mixed characters
- **WHEN** pinyin() is called with "你好abc世界"
- **THEN** system converts Chinese characters and handles non-Chinese content per errors parameter

### Requirement: Support heteronym (polyphone) lookups
The system SHALL return all possible pronunciations for a character when heteronym=True.

#### Scenario: Heteronym enabled
- **WHEN** pinyin() is called with "中" and heteronym=True
- **THEN** system returns [['zhōng', 'zhòng']] with all pronunciations

#### Scenario: Heteronym disabled
- **WHEN** pinyin() is called with "中" and heteronym=False
- **THEN** system returns [['zhōng']] with only first pronunciation

### Requirement: Provide lazy_pinyin convenience function
The system SHALL provide lazy_pinyin() that returns a flat list of pinyin strings instead of nested lists.

#### Scenario: lazy_pinyin flattens output
- **WHEN** lazy_pinyin() is called with "你好"
- **THEN** system returns ['nǐ', 'hǎo'] instead of [['nǐ'], ['hǎo']]

#### Scenario: lazy_pinyin with heteronym
- **WHEN** lazy_pinyin() is called with "中" and heteronym=True
- **THEN** system returns ['zhōng', 'zhòng'] as a flat list
