## ADDED Requirements

### Requirement: Default error handling (keep original characters)
The system SHALL keep original characters when they have no pinyin.

#### Scenario: Non-Chinese character default behavior
- **WHEN** pinyin() is called with "你好123" and errors='default'
- **THEN** result is [['nǐ'], ['hǎo'], ['123']]

#### Scenario: Unknown character default behavior
- **WHEN** unknown character has no pinyin and errors='default'
- **THEN** original character is returned

### Requirement: Ignore error handling (skip non-pinyin characters)
The system SHALL skip characters that have no pinyin when errors='ignore'.

#### Scenario: Skip non-Chinese characters
- **WHEN** pinyin() is called with "你好123" and errors='ignore'
- **THEN** result is [['nǐ'], ['hǎo']] (123 skipped)

#### Scenario: Skip unknown characters
- **WHEN** unknown character is encountered and errors='ignore'
- **THEN** character is not included in output

### Requirement: Replace error handling (convert to unicode format)
The system SHALL replace non-pinyin characters with their unicode representation when errors='replace'.

#### Scenario: Replace with unicode escape
- **WHEN** pinyin() is called with character and errors='replace'
- **THEN** character without pinyin is replaced with unicode string (e.g., '0x01a2' without \u prefix)

### Requirement: Exception error handling
The system SHALL raise PinyinNotFoundException when errors='exception'.

#### Scenario: Raise exception for non-pinyin character
- **WHEN** pinyin() is called with non-pinyin character and errors='exception'
- **THEN** PinyinNotFoundException is raised

### Requirement: Custom error handler function
The system SHALL allow users to provide a custom callable for error handling.

#### Scenario: Custom error handler is called
- **WHEN** pinyin() is called with errors=<custom_function>
- **THEN** custom function is called for each non-pinyin character with character as argument

#### Scenario: Custom handler return value
- **WHEN** custom error handler returns a value
- **THEN** that value is included in the result

### Requirement: Handle non-pinyin in phrase context
The system SHALL apply error handling strategy to non-pinyin characters within phrases.

#### Scenario: Error handling in mixed phrases
- **WHEN** phrase_pinyin() is called with mixed characters
- **THEN** errors parameter applies to all characters without pinyin

### Requirement: Provide handle_nopinyin utility function
The system SHALL provide handle_nopinyin() for error handling logic.

#### Scenario: handle_nopinyin applies strategy
- **WHEN** handle_nopinyin() is called with chars and errors parameter
- **THEN** appropriate error handling strategy is applied
