## Context

pypinyin is a Chinese character to pinyin conversion library used in NLP, text-to-speech, and Chinese text processing applications. The implementation must support multiple pinyin styles, handle polyphones, apply tone sandhi rules, and provide both high-level convenience functions and low-level conversion APIs. The library needs to work with large character datasets (CJK basic + extensions A-G) and support custom dictionary loading for domain-specific pinyin definitions.

## Goals / Non-Goals

**Goals:**
- Implement a complete, feature-rich pypinyin library with 45+ public API functions
- Support all major pinyin styles: TONE, TONE2, TONE3, INITIALS, FINALS, BOPOMOFO, WADE-GILES, CYRILLIC, BRAILLE
- Provide multiple API levels: high-level convenience functions (pinyin(), lazy_pinyin()), mid-level phrase/single-character APIs, low-level style conversion functions
- Enable custom dictionary management (single-character and phrase-level)
- Support polyphone handling and tone sandhi rules
- Create installable package (setup.py) with proper dependency declarations
- Ensure type safety with .pyi stub files for all modules

**Non-Goals:**
- Machine learning-based pinyin prediction (use static dictionaries only)
- Real-time dictionary updates or online data sources
- Support for Python versions below 3.10
- GUI or web interface components
- Audio/pronunciation generation

## Decisions

### 1. Modular Architecture with Separated Concerns
**Decision:** Organize code into distinct modules: core (conversion engine), style (output formatting), contrib (advanced features), tools (utilities).

**Rationale:** Chinese pinyin conversion is complex with many orthogonal concerns (tone handling, style conversion, character parsing, error handling). Separating these into modules enables independent testing, reuse, and future extensibility.

**Alternatives Considered:**
- Monolithic implementation: Simpler initially but harder to maintain and test
- Plugin architecture: More flexible but adds complexity for this relatively stable domain

### 2. Dictionary-Based Approach with Fallback Chain
**Decision:** Use pre-computed pinyin_dict.json (single characters) and phrases_dict.json (multi-character words) as lookup tables. Cache and deep copy dictionaries to prevent accidental mutation.

**Rationale:** Pinyin pronunciation is largely deterministic and stable. Dictionary-based lookup is O(1) for characters and O(1) for phrases, avoiding the need for ML or heuristics. Caching provides performance while preventing external code from corrupting shared data.

**Alternatives Considered:**
- Computed on-the-fly: Too slow and error-prone
- Shallow copy: Risk of state corruption from user code
- Read-only access: Too restrictive for custom dictionary loading use cases

### 3. Converter Pattern for Pluggable Behavior
**Decision:** Create Converter base class with DefaultConverter and UltimateConverter implementations. Users can extend Converter for custom behavior.

**Rationale:** Different use cases need different converter strategies (basic conversion vs. tone sandhi vs. segmentation-aware). The converter pattern allows pluggable behavior without modifying core code. Stores pinyin() and lazy_pinyin() instances globally for convenience while allowing custom converters.

**Alternatives Considered:**
- Global singleton with configuration: Less flexible, harder to test
- Functional approach with parameter passing: Repetitive and verbose

### 4. Style Registry for Extensible Output Formats
**Decision:** Implement a style registry (@register decorator) where style conversion functions register their implementation. New styles can be added without modifying core code.

**Rationale:** Supporting 10+ output styles plus user-defined styles requires flexibility. Registry pattern decouples style implementations from the conversion engine.

**Alternatives Considered:**
- Switch/if-else chains: Not extensible
- Direct function dispatch: Couples style definitions to core code

### 5. Tone Representation Conversions
**Decision:** Implement tone conversion functions between representations: TONE (marks like ǐ), TONE2 (numbers after vowel like i3), TONE3 (numbers at end like ni3). Neutral tones can be marked as 5.

**Rationale:** Different applications use different tone representations. Users need to convert between them. Implementing every pairwise conversion (6 functions) is simpler than a unified intermediate representation.

**Alternatives Considered:**
- Unified internal representation: Adds conversion overhead
- Subset of conversions: Users end up chaining multiple conversions

### 6. Character vs. Phrase Lookup Priority
**Decision:** Check phrases_dict first for multi-character sequences, then fall back to single-character pinyin_dict. This enables context-aware pronunciation (e.g., "中心" → zhōngxīn vs. zhòngxīn).

**Rationale:** Many Chinese words have different pronunciations when spoken as a phrase vs. individual characters. Phrase-first lookup provides better accuracy while maintaining fallback for unknown phrases.

### 7. Error Handling Strategy Parameters
**Decision:** Provide errors parameter in top-level functions supporting 'default' (keep original), 'ignore' (skip), 'replace' (convert to unicode), 'exception' (raise), and callable custom handlers.

**Rationale:** Different applications need different error handling (logging apps ignore punctuation, display apps keep original, strict parsing raises). Making this configurable per-call avoids forced choices.

### 8. Unicode Support with UCS4 Detection
**Decision:** Detect Python's UCS4 support and adjust CJK character ranges accordingly. Include ranges for Extensions A-G for UCS4 builds.

**Rationale:** Some environments have UCS4 support (full Unicode) while others don't. Adapting character detection ensures broad compatibility.

## Risks / Trade-offs

**[Risk: Dictionary Size]** → The full pinyin and phrases dictionaries can be large (megabytes). **Mitigation:** Lazy load dictionaries and provide PYPINYIN_NO_DICT_COPY environment variable for memory-constrained environments.

**[Risk: Dictionary Staleness]** → Dictionary-based approach misses newly-coined words or domain-specific characters. **Mitigation:** Support load_single_dict() and load_phrases_dict() for runtime updates.

**[Risk: Polyphone Ambiguity]** → Some characters have 10+ pronunciations. Returning all via heteronym=True can be slow. **Mitigation:** Default to heteronym=False (first pronunciation only), let users opt-in to completeness.

**[Risk: Tone Sandhi Complexity]** → Implementing all tone sandhi rules (third-tone, neutral tone, etc.) is error-prone. **Mitigation:** Start with common rules and provide tone_sandhi parameter to enable/disable.

**[Risk: API Surface Size]** → 45+ functions create documentation and maintenance burden. **Mitigation:** Group functions by purpose (core, style conversions, tone conversions, utilities) and auto-generate docs from docstrings.

**[Trade-off: Strict vs. Relaxed Mode]** → Strict mode follows Hanyu Pinyin rules strictly (y/w not initials), relaxed mode allows them. Different users prefer different modes. **Resolution:** Default to strict=True, allow per-function override.

## Assumptions

1. **Dictionary Format**: pinyin_dict.json uses character code → pinyin string format (e.g., "20320": "ni3,ni2"); phrases_dict.json uses phrase text → list of pinyin lists
2. **Python Environment**: Python 3.10+ is available; jieba, chardet, typing-extensions are installable
3. **Data Stability**: Pinyin rules and standard dictionaries are stable (no frequent updates expected)
4. **Performance Requirements**: Sub-millisecond per-character conversion is acceptable; no real-time audio processing needed
5. **Backward Compatibility**: Initial release doesn't need to maintain compatibility with older versions
