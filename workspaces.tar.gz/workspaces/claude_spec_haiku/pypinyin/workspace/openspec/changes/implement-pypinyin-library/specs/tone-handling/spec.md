## ADDED Requirements

### Requirement: Convert between TONE and TONE2 styles
The system SHALL convert tone marks to tone numbers and vice versa.

#### Scenario: TONE to TONE2 conversion
- **WHEN** tone2_to_tone() is called with "ni3"
- **THEN** system returns "nǐ" (tone mark)

#### Scenario: TONE2 to TONE conversion
- **WHEN** tone_to_tone2() is called with "nǐ"
- **THEN** system returns "ni3" (tone number)

### Requirement: Convert TONE2 to NORMAL style
The system SHALL remove tone numbers from TONE2 style pinyin.

#### Scenario: Remove tone numbers
- **WHEN** tone2_to_normal() is called with "ni3hao3"
- **THEN** system returns "nihao"

### Requirement: Convert between TONE and TONE3 styles
The system SHALL convert between tone marks and tone numbers at end of syllable.

#### Scenario: TONE to TONE3 conversion
- **WHEN** tone_to_tone3() is called with "nǐ"
- **THEN** system returns "ni3"

#### Scenario: TONE3 to TONE conversion
- **WHEN** tone3_to_tone() is called with "ni3"
- **THEN** system returns "nǐ"

### Requirement: Convert between TONE2 and TONE3 styles
The system SHALL convert between different tone number placements.

#### Scenario: TONE2 to TONE3 conversion
- **WHEN** tone2_to_tone3() is called with "ni3"
- **THEN** system returns "ni3"

#### Scenario: TONE3 to TONE2 conversion
- **WHEN** tone3_to_tone2() is called with "ni3"
- **THEN** system returns "ni3"

### Requirement: Extract tone number from pinyin
The system SHALL identify and return the tone number from a pinyin string.

#### Scenario: Extract tone from TONE2 style
- **WHEN** _get_number_from_pinyin() is called with "ni3"
- **THEN** system returns 3

#### Scenario: Extract tone from TONE3 style
- **WHEN** _get_number_from_pinyin() is called with "ni3"
- **THEN** system returns 3

#### Scenario: No tone returns None
- **WHEN** _get_number_from_pinyin() is called with "ni"
- **THEN** system returns None

### Requirement: Handle neutral tones
The system SHALL support marking neutral tones with number 5 or no number.

#### Scenario: Neutral tone without marker
- **WHEN** neutral tone is not marked
- **THEN** system treats as unmarked tone

#### Scenario: Neutral tone with marker 5
- **WHEN** neutral_tone_with_five=True
- **THEN** neutral tones are marked with "5"

### Requirement: Improve TONE3 representation
The system SHALL enhance TONE3 output by adding neutral tone marker when needed.

#### Scenario: Add neutral tone marker to TONE3
- **WHEN** _improve_tone3() is called with neutral_tone_with_five=True
- **THEN** system adds "5" to mark neutral tones

### Requirement: Regular expression utilities for tone detection
The system SHALL provide regex patterns for detecting and matching tones.

#### Scenario: Match TONE2 pattern
- **WHEN** RE_TONE2 pattern matches "ni3"
- **THEN** pattern identifies tone number "3"

#### Scenario: Match TONE3 pattern
- **WHEN** RE_TONE3 pattern matches "ni3"
- **THEN** pattern identifies tone number "3"
