## ADDED Requirements

### Requirement: Support NORMAL style (no tones)
The system SHALL convert pinyin to NORMAL style with all tone marks and numbers removed.

#### Scenario: NORMAL conversion removes tone marks
- **WHEN** pinyin() is called with "你好" and style=Style.NORMAL
- **THEN** system returns [['ni'], ['hao']] (without tone marks)

#### Scenario: NORMAL conversion removes tone numbers
- **WHEN** converting "ni3" to NORMAL style
- **THEN** result is "ni"

### Requirement: Support TONE style (tone marks on vowels)
The system SHALL convert pinyin to TONE style with tone marks placed on the appropriate vowel.

#### Scenario: TONE style with standard characters
- **WHEN** pinyin() is called with "你好" and style=Style.TONE
- **THEN** system returns [['nǐ'], ['hǎo']] with tone marks

#### Scenario: TONE style follows tone placement rules
- **WHEN** converting "ni3" to TONE style
- **THEN** result is "nǐ" (tone on "i" which is the main vowel)

### Requirement: Support TONE2 style (tone numbers after vowels)
The system SHALL convert pinyin to TONE2 style with tone numbers placed after the tone-bearing vowel.

#### Scenario: TONE2 conversion places number correctly
- **WHEN** pinyin() is called with "你好" and style=Style.TONE2
- **THEN** system returns [['ni3'], ['hao3']] (number after vowel)

### Requirement: Support TONE3 style (tone number at end)
The system SHALL convert pinyin to TONE3 style with tone number placed at the end of the syllable.

#### Scenario: TONE3 places number at end
- **WHEN** pinyin() is called with "你好" and style=Style.TONE3
- **THEN** system returns [['ni3'], ['hao3']] (number at end)

### Requirement: Support INITIALS and FIRST_LETTER styles
The system SHALL extract initial consonants from pinyin.

#### Scenario: INITIALS returns all initials
- **WHEN** pinyin() is called with "你好" and style=Style.INITIALS
- **THEN** system returns [['n'], ['h']]

#### Scenario: FIRST_LETTER returns first character only
- **WHEN** pinyin() is called with "你好" and style=Style.FIRST_LETTER
- **THEN** system returns [['n'], ['h']]

### Requirement: Support FINALS styles (FINALS, FINALS_TONE, FINALS_TONE2, FINALS_TONE3)
The system SHALL extract final vowel portions of pinyin in various tone representations.

#### Scenario: FINALS returns vowels without tone
- **WHEN** pinyin() is called with "你好" and style=Style.FINALS
- **THEN** system returns [['i'], ['ao']]

#### Scenario: FINALS_TONE returns finals with tone marks
- **WHEN** pinyin() is called with "你好" and style=Style.FINALS_TONE
- **THEN** system returns [['ǐ'], ['ǎo']]

### Requirement: Support BOPOMOFO style (Zhuyin phonetic annotation)
The system SHALL convert pinyin to Zhuyin (Bopomofo) characters.

#### Scenario: BOPOMOFO converts to Zhuyin symbols
- **WHEN** pinyin() is called with "你好" and style=Style.BOPOMOFO
- **THEN** system returns Zhuyin character representations

### Requirement: Support WADE_GILES style (romanization system)
The system SHALL convert pinyin to Wade-Giles romanization.

#### Scenario: WADE_GILES converts to alternative romanization
- **WHEN** converting "zhong" to WADE_GILES style
- **THEN** result matches Wade-Giles romanization rules

### Requirement: Support CYRILLIC style (Russian alphabet)
The system SHALL convert pinyin to Cyrillic alphabet representation with tone numbers.

#### Scenario: CYRILLIC converts to Russian characters
- **WHEN** pinyin() is called with style=Style.CYRILLIC
- **THEN** system returns Cyrillic character representations

### Requirement: Support BRAILLE_MAINLAND style
The system SHALL convert pinyin to Mainland China braille representation.

#### Scenario: BRAILLE_MAINLAND uses correct braille patterns
- **WHEN** pinyin() is called with style=Style.BRAILLE_MAINLAND
- **THEN** system returns braille character patterns

### Requirement: Register custom styles
The system SHALL allow users to register custom style conversion functions.

#### Scenario: Custom style registration
- **WHEN** user registers a custom style with @register decorator
- **THEN** custom style can be used like built-in styles
