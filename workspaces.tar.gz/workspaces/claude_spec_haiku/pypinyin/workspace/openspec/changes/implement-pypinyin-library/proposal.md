## Why

The pypinyin library is essential for Chinese language processing applications. It provides intelligent pinyin conversion for Chinese characters, enabling phonetic annotation, sorting, retrieval, and text-to-speech applications. This implementation creates a complete, production-ready library with comprehensive style support and advanced features like polyphone handling and tone sandhi rules.

## What Changes

- Create a complete pypinyin package with core conversion engine supporting 45+ API functions
- Implement multiple pinyin output styles (TONE, TONE2, TONE3, INITIALS, FINALS, BOPOMOFO, WADE-GILES, CYRILLIC, etc.)
- Build modular architecture with separate concerns: parsing, conversion, style handling, tone management
- Provide comprehensive dictionary support (single-character and phrase-based)
- Support advanced features: polyphone handling, tone sandhi rules, custom dictionaries, flexible error handling
- Create installer package (setup.py) with proper dependency management

## Capabilities

### New Capabilities
- `chinese-character-parsing`: Parse Chinese text extracting characters while handling punctuation and special characters
- `pinyin-conversion`: Convert Chinese characters to pinyin using character and phrase dictionaries with polyphone support
- `style-conversion`: Convert pinyin between different output formats (TONE, TONE2, TONE3, INITIALS, FINALS, BOPOMOFO, WADE-GILES, CYRILLIC, BRAILLE)
- `tone-handling`: Comprehensive tone management including tone2-to-tone conversion, tone number extraction, and neutral tone handling
- `initial-final-extraction`: Extract and process pinyin initials and finals with strict/relaxed modes
- `tone-sandhi-processing`: Apply Chinese tone sandhi rules (e.g., third-tone sandhi in "你好")
- `custom-dictionary-management`: Support for loading and applying custom single-character and phrase-based pinyin dictionaries
- `error-handling-strategies`: Multiple error handling modes (default, ignore, replace, exception, custom callback)
- `polyphone-support`: Handle heteronyms and multiple pronunciations for the same character
- `unicode-support`: Support for CJK basic characters, extensions (A-G), compatibility characters, and modern variants
- `phonetic-symbol-conversion`: Convert between phonetic symbols and tone numbers/marks
- `v-to-u-conversion`: Handle ü/u equivalence in pinyin notation

## Impact

- **New Package**: Creates the complete pypinyin package as an installable Python library
- **API**: Exposes primary functions (pinyin, lazy_pinyin, slug) and converter classes for different use cases
- **Dependencies**: Requires jieba (0.42.1+), chardet (5.2.0+), typing-extensions (4.12.2+)
- **Data Files**: Includes pinyin_dict.json and phrases_dict.json for character and phrase lookups
- **Module Structure**: Implements core, style, contrib, and tools submodules with 45+ functions across type-annotated modules (.pyi files)
- **Compatibility**: Python 3.10+ with optional UCS4 support for extended Unicode ranges
