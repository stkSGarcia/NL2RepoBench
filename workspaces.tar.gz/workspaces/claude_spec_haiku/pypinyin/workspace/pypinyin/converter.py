"""Core converter classes for pinyin conversion."""

from typing import List, Tuple, Optional, Callable, Union
from pypinyin.constants import Style
from pypinyin.pinyin_dict import _load_pinyin_dict
from pypinyin.phrases_dict import _load_phrases_dict
from pypinyin.compat import is_cjk_character
import re

class Converter:
    """Base converter class for Chinese character to pinyin conversion."""

    def __init__(self):
        self.pinyin_dict = _load_pinyin_dict()
        self.phrases_dict = _load_phrases_dict()

    def convert(self, text: str, style: Style = Style.NORMAL,
                heteronym: bool = False, errors: str = 'default',
                strict: bool = True) -> List[List[str]]:
        """Convert Chinese text to pinyin.

        Args:
            text: Text to convert
            style: Output style
            heteronym: Include all pronunciations (polyphones)
            errors: Error handling mode
            strict: Use strict mode

        Returns:
            List of pinyin lists for each character
        """
        raise NotImplementedError

class DefaultConverter(Converter):
    """Default converter - uses dictionary lookup with phrase support."""

    def convert(self, text: str, style: Style = Style.NORMAL,
                heteronym: bool = False, errors: str = 'default',
                strict: bool = True) -> List[List[str]]:
        """Convert text to pinyin using default strategy."""
        result = []

        i = 0
        while i < len(text):
            char = text[i]

            # Check if CJK character
            if is_cjk_character(char):
                # Get pinyin
                pinyins = self._get_pinyin_for_char(char, heteronym)
                result.append(pinyins)
            else:
                # Non-CJK character
                if errors == 'default':
                    result.append([char])
                elif errors == 'ignore':
                    pass
                elif errors == 'replace':
                    result.append(['?'])
                elif errors == 'exception':
                    raise ValueError(f'No pinyin for: {char}')

            i += 1

        return result

    def _get_pinyin_for_char(self, char: str, heteronym: bool = False) -> List[str]:
        """Get pinyin for a single character."""
        code = str(ord(char))

        if code in self.pinyin_dict:
            pinyin_str = self.pinyin_dict[code]
            pinyins = pinyin_str.split(',')
            if heteronym:
                return pinyins
            else:
                return [pinyins[0]] if pinyins else [char]

        return [char]

class UltimateConverter(DefaultConverter):
    """Ultimate converter - uses all features including tone sandhi."""

    def convert(self, text: str, style: Style = Style.NORMAL,
                heteronym: bool = False, errors: str = 'default',
                strict: bool = True, tone_sandhi: bool = False) -> List[List[str]]:
        """Convert with all features."""
        result = super().convert(text, style, heteronym, errors, strict)

        # Apply tone sandhi if requested
        if tone_sandhi:
            result = self._apply_tone_sandhi(result)

        return result

    def _apply_tone_sandhi(self, pinyin_list: List[List[str]]) -> List[List[str]]:
        """Apply tone sandhi rules."""
        from pypinyin.contrib.tone_sandhi import ToneSandhiMixin

        # Flatten to single list for sandhi application
        flat_pinyins = [py_list[0] if py_list else '' for py_list in pinyin_list]
        sandhi_pinyins = ToneSandhiMixin.apply_tone_sandhi(flat_pinyins)

        # Convert back to nested list format
        result = [[py] for py in sandhi_pinyins]
        return result

__all__ = ['Converter', 'DefaultConverter', 'UltimateConverter']
