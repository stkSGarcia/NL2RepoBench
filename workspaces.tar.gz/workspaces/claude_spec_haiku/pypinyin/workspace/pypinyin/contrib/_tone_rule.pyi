from typing import Dict, Callable, Optional

TONE_SANDHI_RULES: Dict[tuple, int]
SPECIAL_TONE_RULES: Dict[str, Callable[[str, int], Optional[int]]]

def get_sandhi_tone(pinyin_prev: str, tone_prev: int, tone_next: int) -> Optional[int]: ...

__all__: list[str]
