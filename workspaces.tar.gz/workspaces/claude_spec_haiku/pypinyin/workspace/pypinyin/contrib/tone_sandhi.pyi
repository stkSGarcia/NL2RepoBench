from typing import List, Optional

class ToneSandhiMixin:
    @staticmethod
    def apply_tone_sandhi(pinyin_list: List[str]) -> List[str]: ...
    @staticmethod
    def get_tone_number(pinyin: str) -> Optional[int]: ...
    @staticmethod
    def change_tone(pinyin: str, new_tone: int) -> str: ...

__all__: list[str]
