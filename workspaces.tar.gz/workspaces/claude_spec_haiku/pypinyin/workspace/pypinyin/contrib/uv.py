"""Mixin for handling ü (u-umlaut) vs v conversion."""

class V2UMixin:
    """Mixin to convert ü to v in pinyin output."""

    @staticmethod
    def convert_umlaut_to_v(pinyin: str) -> str:
        """Convert ü to v for display purposes.

        Example: 'nü3' -> 'nv3', 'lü4' -> 'lv4'
        """
        return pinyin.replace('ü', 'v')

    @staticmethod
    def convert_v_to_umlaut(pinyin: str) -> str:
        """Convert v to ü (proper pinyin).

        Example: 'nv3' -> 'nü3', 'lv4' -> 'lü4'
        """
        return pinyin.replace('v', 'ü')

    @staticmethod
    def normalize_umlaut(pinyin: str) -> str:
        """Normalize ü/v representation to standard ü.

        Example: 'nv3' -> 'nü3', 'nü3' -> 'nü3'
        """
        return V2UMixin.convert_v_to_umlaut(pinyin)

__all__ = ['V2UMixin']
