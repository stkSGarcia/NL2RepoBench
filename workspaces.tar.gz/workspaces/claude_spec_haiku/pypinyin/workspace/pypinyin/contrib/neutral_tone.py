"""Neutral tone handling for pinyin."""

import re

class NeutralToneWith5Mixin:
    """Mixin to represent neutral tone with '5' tone number."""

    @staticmethod
    def mark_neutral_tone(pinyin: str) -> str:
        """Mark neutral tone with '5' at the end.

        Example: 'de' -> 'de5', 'ma' -> 'ma5'
        """
        # If no tone number present, add 5 for neutral tone
        if not re.search(r'[1-5]$', pinyin):
            return pinyin + '5'
        return pinyin

    @staticmethod
    def remove_neutral_tone_marker(pinyin: str) -> str:
        """Remove neutral tone '5' marker.

        Example: 'de5' -> 'de', 'ma5' -> 'ma'
        """
        return re.sub(r'5$', '', pinyin)

    @staticmethod
    def is_neutral_tone(pinyin: str) -> bool:
        """Check if pinyin has neutral tone (marked as 5 or no tone).

        Example: 'de5' -> True, 'ma' -> True, 'de1' -> False
        """
        if pinyin.endswith('5'):
            return True
        # If no tone number, treat as neutral
        if not re.search(r'[1-5]$', pinyin):
            return True
        return False

__all__ = ['NeutralToneWith5Mixin']
