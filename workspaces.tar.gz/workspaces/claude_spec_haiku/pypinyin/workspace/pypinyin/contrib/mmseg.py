"""Optional mmseg-based segmentation for pypinyin."""

from typing import List, Optional

try:
    import mmseg
    HAS_MMSEG = True
except ImportError:
    HAS_MMSEG = False

def seg(text: str) -> List[str]:
    """Segment text using mmseg if available, otherwise simple segmentation.

    Args:
        text: Text to segment

    Returns:
        List of segmented words
    """
    if HAS_MMSEG:
        return _seg_with_mmseg(text)
    else:
        return _simple_seg(text)

def _seg_with_mmseg(text: str) -> List[str]:
    """Use mmseg for segmentation."""
    if not HAS_MMSEG:
        return _simple_seg(text)

    try:
        return list(mmseg.seg(text))
    except Exception:
        return _simple_seg(text)

def _simple_seg(text: str) -> List[str]:
    """Simple character-level segmentation."""
    return list(text)

def is_mmseg_available() -> bool:
    """Check if mmseg is available."""
    return HAS_MMSEG

__all__ = ['seg', 'is_mmseg_available']
