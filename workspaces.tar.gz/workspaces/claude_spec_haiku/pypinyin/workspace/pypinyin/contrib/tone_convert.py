"""Tone conversion utilities for contrib module."""

from pypinyin.style._tone_convert import to_tone3, to_tone, to_tone2
import re

def tone_to_tone3(pinyin: str) -> str:
    """Convert from TONE (tone mark) to TONE3 (tone number at end)."""
    return to_tone3(pinyin)

def tone2_to_normal(pinyin: str) -> str:
    """Convert from TONE2 (tone after vowel) to NORMAL (no tone)."""
    result = re.sub(r'[1-5]', '', pinyin)
    tone_marks = {
        'ā': 'a', 'á': 'a', 'ǎ': 'a', 'à': 'a',
        'ē': 'e', 'é': 'e', 'ě': 'e', 'è': 'e',
        'ī': 'i', 'í': 'i', 'ǐ': 'i', 'ì': 'i',
        'ō': 'o', 'ó': 'o', 'ǒ': 'o', 'ò': 'o',
        'ū': 'u', 'ú': 'u', 'ǔ': 'u', 'ù': 'u',
        'ǖ': 'ü', 'ǘ': 'ü', 'ǚ': 'ü', 'ǜ': 'ü',
    }
    for mark, base in tone_marks.items():
        result = result.replace(mark, base)
    return result

def tone2_to_tone(pinyin: str) -> str:
    """Convert from TONE2 to TONE (tone mark)."""
    # First normalize to TONE3
    tone3 = to_tone3(pinyin)
    # Then convert to TONE
    return to_tone(tone3)

def tone2_to_tone3(pinyin: str) -> str:
    """Convert from TONE2 to TONE3."""
    return to_tone3(pinyin)

def tone3_to_normal(pinyin: str) -> str:
    """Convert from TONE3 to NORMAL."""
    return tone2_to_normal(pinyin)

def tone3_to_tone(pinyin: str) -> str:
    """Convert from TONE3 to TONE."""
    return to_tone(pinyin)

def tone3_to_tone2(pinyin: str) -> str:
    """Convert from TONE3 to TONE2."""
    return to_tone2(pinyin)

__all__ = [
    'tone_to_tone3',
    'tone2_to_normal',
    'tone2_to_tone',
    'tone2_to_tone3',
    'tone3_to_normal',
    'tone3_to_tone',
    'tone3_to_tone2',
]
