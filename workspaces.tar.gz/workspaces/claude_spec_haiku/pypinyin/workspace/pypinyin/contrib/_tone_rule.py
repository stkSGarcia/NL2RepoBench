"""Tone sandhi rule definitions."""

from typing import Dict, List, Callable, Optional

# Tone sandhi rules
# Format: (preceding_tone, following_tone) -> resulting_tone_for_preceding

TONE_SANDHI_RULES: Dict[tuple, int] = {
    # Third tone sandhi: 3 + 3 -> 2 + 3
    (3, 3): 2,
    # First tone rules
    (1, 1): 1,
    (1, 2): 1,
    (1, 3): 1,
    (1, 4): 1,
}

# Special case rules
SPECIAL_TONE_RULES: Dict[str, Callable[[str, int], Optional[int]]] = {}

def get_sandhi_tone(pinyin_prev: str, tone_prev: int, tone_next: int) -> Optional[int]:
    """Get the tone change for tone sandhi.

    Args:
        pinyin_prev: Previous syllable pinyin
        tone_prev: Previous syllable tone
        tone_next: Following syllable tone

    Returns:
        New tone for previous syllable, or None if no change
    """
    # Check if special rule applies
    if pinyin_prev in SPECIAL_TONE_RULES:
        result = SPECIAL_TONE_RULES[pinyin_prev](pinyin_prev, tone_next)
        if result is not None:
            return result

    # Check standard rules
    rule_key = (tone_prev, tone_next)
    if rule_key in TONE_SANDHI_RULES:
        return TONE_SANDHI_RULES[rule_key]

    return None

__all__ = ['TONE_SANDHI_RULES', 'SPECIAL_TONE_RULES', 'get_sandhi_tone']
