"""Tone sandhi (变调) rules for Chinese pinyin."""

from typing import List, Optional
import re

class ToneSandhiMixin:
    """Mixin for tone sandhi rule application."""

    @staticmethod
    def apply_tone_sandhi(pinyin_list: List[str]) -> List[str]:
        """Apply Chinese tone sandhi rules to pinyin sequence.

        Example: ['ni3', 'hao3'] -> ['ni2', 'hao3'] (third tone sandhi)
        """
        if len(pinyin_list) < 2:
            return pinyin_list

        result = list(pinyin_list)

        # Rule 1: Third tone + any tone -> second tone for first syllable
        for i in range(len(result) - 1):
            tone_curr = ToneSandhiMixin.get_tone_number(result[i])
            tone_next = ToneSandhiMixin.get_tone_number(result[i + 1])

            # Third tone + third tone -> second tone
            if tone_curr == 3 and tone_next == 3:
                result[i] = ToneSandhiMixin.change_tone(result[i], 2)

            # "一" (yi1) tone changes
            if result[i].startswith('yi') or result[i] == 'yi':
                if tone_next in (1, 2, 3, 4) and tone_next != -1:
                    # Before 4th tone -> 2nd tone
                    if tone_next == 4:
                        result[i] = ToneSandhiMixin.change_tone(result[i], 2)
                    # Before 1st, 2nd, 3rd -> 4th tone
                    else:
                        result[i] = ToneSandhiMixin.change_tone(result[i], 4)

            # "不" (bu4) tone changes
            if result[i].startswith('bu') or result[i] == 'bu':
                if tone_next in (1, 2, 3):
                    # Before 4th tone -> 2nd tone
                    result[i] = ToneSandhiMixin.change_tone(result[i], 2)

        return result

    @staticmethod
    def get_tone_number(pinyin: str) -> Optional[int]:
        """Extract tone number from pinyin."""
        match = re.search(r'[1-5]$', pinyin)
        if match:
            return int(match.group())
        return None

    @staticmethod
    def change_tone(pinyin: str, new_tone: int) -> str:
        """Change tone of pinyin."""
        if new_tone < 1 or new_tone > 5:
            return pinyin

        # Remove existing tone
        result = re.sub(r'[1-5]$', '', pinyin)

        # Add new tone
        if new_tone != 5:
            result += str(new_tone)

        return result

__all__ = ['ToneSandhiMixin']
