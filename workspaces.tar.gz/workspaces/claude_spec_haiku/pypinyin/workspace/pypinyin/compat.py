"""Compatibility utilities for pypinyin."""

import sys
from typing import Any

def is_ucs4() -> bool:
    """Check if Python is built with UCS4 support."""
    return sys.maxunicode > 0xFFFF

def ord_unicode(char: str) -> int:
    """Get Unicode code point of a character."""
    return ord(char)

def is_cjk_character(char: str) -> bool:
    """Check if character is a CJK character."""
    code = ord_unicode(char)
    # CJK basic block
    if 0x4E00 <= code <= 0x9FFF:
        return True
    # CJK extension A
    if 0x3400 <= code <= 0x4DBF:
        return True
    # CJK extension B (UCS4 only)
    if is_ucs4():
        if 0x20000 <= code <= 0x2A6DF:
            return True
        # CJK extension C-G
        if 0x2A700 <= code <= 0x2B73F:
            return True
        if 0x2B740 <= code <= 0x2B81F:
            return True
        if 0x2B820 <= code <= 0x2CEAF:
            return True
        if 0x2CEB0 <= code <= 0x2EBEF:
            return True
    return False

def is_punctuation(char: str) -> bool:
    """Check if character is punctuation."""
    if char.isalnum() or is_cjk_character(char):
        return False
    return True
