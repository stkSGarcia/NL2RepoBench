from typing import List, Optional, Callable
from pypinyin.constants import Style

class Converter:
    def convert(self, text: str, style: Style = Style.NORMAL,
                heteronym: bool = False, errors: str = 'default',
                strict: bool = True) -> List[List[str]]: ...

class DefaultConverter(Converter):
    def convert(self, text: str, style: Style = Style.NORMAL,
                heteronym: bool = False, errors: str = 'default',
                strict: bool = True) -> List[List[str]]: ...

class UltimateConverter(DefaultConverter):
    def convert(self, text: str, style: Style = Style.NORMAL,
                heteronym: bool = False, errors: str = 'default',
                strict: bool = True, tone_sandhi: bool = False) -> List[List[str]]: ...

__all__: list[str]
