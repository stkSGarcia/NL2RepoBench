"""Phrases dictionary loader for multi-character words."""

import json
import os
from copy import deepcopy
from typing import Dict, List, Optional

_PHRASES_DICT_CACHE: Optional[Dict[str, List[List[str]]]] = None

def _load_phrases_dict() -> Dict[str, List[List[str]]]:
    """Load phrases dictionary from JSON file.

    Returns a dictionary mapping phrases to lists of pinyin lists.
    Uses cache to avoid repeated file I/O.
    """
    global _PHRASES_DICT_CACHE

    if _PHRASES_DICT_CACHE is not None:
        return _PHRASES_DICT_CACHE

    dict_path = os.path.join(os.path.dirname(__file__), 'data', 'phrases_dict.json')

    with open(dict_path, 'r', encoding='utf-8') as f:
        _PHRASES_DICT_CACHE = json.load(f)

    return _PHRASES_DICT_CACHE

def get_phrases_dict() -> Dict[str, List[List[str]]]:
    """Get a deep copy of the phrases dictionary to prevent external mutation."""
    return deepcopy(_load_phrases_dict())

def load_phrases_dict(custom_dict: Dict[str, List[List[str]]]) -> None:
    """Load a custom phrases dictionary.

    Args:
        custom_dict: Dictionary mapping phrases to lists of pinyin lists
    """
    global _PHRASES_DICT_CACHE
    base_dict = _load_phrases_dict()
    base_dict.update(custom_dict)
