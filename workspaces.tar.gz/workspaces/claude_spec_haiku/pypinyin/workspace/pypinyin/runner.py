"""Runner utilities for pypinyin test execution."""

from typing import List, Dict, Any, Callable, Optional
import subprocess
import sys

def run_test(test_cmd: List[str]) -> Dict[str, Any]:
    """Run a test command and return results.

    Args:
        test_cmd: Test command as list

    Returns:
        Dict with returncode, stdout, stderr
    """
    try:
        result = subprocess.run(
            test_cmd,
            capture_output=True,
            text=True,
            timeout=30
        )
        return {
            'returncode': result.returncode,
            'stdout': result.stdout,
            'stderr': result.stderr,
            'success': result.returncode == 0
        }
    except subprocess.TimeoutExpired:
        return {
            'returncode': -1,
            'stdout': '',
            'stderr': 'Test timeout',
            'success': False
        }
    except Exception as e:
        return {
            'returncode': -1,
            'stdout': '',
            'stderr': str(e),
            'success': False
        }

def run_tests(test_commands: List[List[str]]) -> List[Dict[str, Any]]:
    """Run multiple test commands.

    Args:
        test_commands: List of test commands

    Returns:
        List of test results
    """
    results = []
    for test_cmd in test_commands:
        results.append(run_test(test_cmd))
    return results

__all__ = ['run_test', 'run_tests']
