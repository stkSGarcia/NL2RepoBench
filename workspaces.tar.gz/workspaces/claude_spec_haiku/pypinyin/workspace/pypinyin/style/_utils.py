"""Utility functions for style processing."""

import re
from typing import Optional
from pypinyin.style._constants import INITIALS, FINALS, TONE_VOWELS

def extract_initial(pinyin: str) -> str:
    """Extract initial consonant from pinyin.

    Example: 'ni3' -> 'n', 'ai3' -> ''
    """
    pinyin_clean = re.sub(r'[1-5]', '', pinyin)
    for initial in INITIALS:
        if pinyin_clean.lower().startswith(initial):
            return initial
    return ''

def extract_final(pinyin: str, strict: bool = True) -> str:
    """Extract final from pinyin.

    Example: 'ni3' -> 'i', 'zhang1' -> 'ang'
    Args:
        pinyin: Input pinyin
        strict: If True, follow strict Hanyu Pinyin rules
    """
    pinyin_clean = re.sub(r'[1-5]', '', pinyin).lower()
    initial = extract_initial(pinyin_clean)

    if initial:
        final = pinyin_clean[len(initial):]
    else:
        final = pinyin_clean

    return final

def get_tone_number(pinyin: str) -> Optional[int]:
    """Extract tone number from pinyin.

    Example: 'ni3' -> 3, 'nǐ' -> 3, 'ni' -> None
    """
    match = re.search(r'[1-5]', pinyin)
    if match:
        return int(match.group())
    return None

def remove_tone(pinyin: str) -> str:
    """Remove tone marks and numbers from pinyin.

    Example: 'ni3' -> 'ni', 'nǐ' -> 'ni'
    """
    # Remove tone numbers
    result = re.sub(r'[1-5]', '', pinyin)
    # Remove tone marks
    result = re.sub(r'[āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ]', lambda m: chr(ord(m.group()) - 0x0300), result)
    # Basic removal approach: replace tone marks with base vowel
    tone_marks = {
        'ā': 'a', 'á': 'a', 'ǎ': 'a', 'à': 'a',
        'ē': 'e', 'é': 'e', 'ě': 'e', 'è': 'e',
        'ī': 'i', 'í': 'i', 'ǐ': 'i', 'ì': 'i',
        'ō': 'o', 'ó': 'o', 'ǒ': 'o', 'ò': 'o',
        'ū': 'u', 'ú': 'u', 'ǔ': 'u', 'ù': 'u',
        'ǖ': 'ü', 'ǘ': 'ü', 'ǚ': 'ü', 'ǜ': 'ü',
    }
    for mark, base in tone_marks.items():
        result = result.replace(mark, base)
    return result
