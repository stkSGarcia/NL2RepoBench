"""Final vowel style converters."""

from pypinyin.style import register
from pypinyin.style._tone_convert import to_finals, to_tone3
import re

@register('FINALS')
def convert_finals(pinyin: str) -> str:
    """Convert to FINALS style - extract finals without tone."""
    final = to_finals(pinyin, strict=True)
    # Remove tone marks and numbers
    final = re.sub(r'[1-5]', '', final)
    tone_marks = {
        'ā': 'a', 'á': 'a', 'ǎ': 'a', 'à': 'a',
        'ē': 'e', 'é': 'e', 'ě': 'e', 'è': 'e',
        'ī': 'i', 'í': 'i', 'ǐ': 'i', 'ì': 'i',
        'ō': 'o', 'ó': 'o', 'ǒ': 'o', 'ò': 'o',
        'ū': 'u', 'ú': 'u', 'ǔ': 'u', 'ù': 'u',
        'ǖ': 'ü', 'ǘ': 'ü', 'ǚ': 'ü', 'ǜ': 'ü',
    }
    for mark, base in tone_marks.items():
        final = final.replace(mark, base)
    return final

@register('FINALS_TONE')
def convert_finals_tone(pinyin: str) -> str:
    """Convert to FINALS_TONE - finals with tone marks."""
    from pypinyin.style._tone_convert import to_tone
    # Get final and convert to tone mark format
    final = to_finals(pinyin, strict=True)
    return to_tone(final)

@register('FINALS_TONE2')
def convert_finals_tone2(pinyin: str) -> str:
    """Convert to FINALS_TONE2 - finals with tone number after vowel."""
    from pypinyin.style._tone_convert import to_tone2
    final = to_finals(pinyin, strict=True)
    return to_tone2(final)

@register('FINALS_TONE3')
def convert_finals_tone3(pinyin: str) -> str:
    """Convert to FINALS_TONE3 - finals with tone number at end."""
    final = to_finals(pinyin, strict=True)
    return to_tone3(final)

__all__ = ['convert_finals', 'convert_finals_tone', 'convert_finals_tone2', 'convert_finals_tone3']
