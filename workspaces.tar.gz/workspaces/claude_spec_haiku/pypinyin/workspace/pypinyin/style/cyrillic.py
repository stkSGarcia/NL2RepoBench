"""Cyrillic transliteration converter."""

from pypinyin.style import register
from pypinyin.style._tone_convert import to_tone3
import re

# Simplified Cyrillic mapping for Chinese pinyin
CYRILLIC_MAP = {
    'a': 'а', 'b': 'б', 'c': 'ц', 'd': 'д', 'e': 'е',
    'f': 'ф', 'g': 'г', 'h': 'х', 'i': 'и', 'j': 'ч',
    'k': 'к', 'l': 'л', 'm': 'м', 'n': 'н', 'o': 'о',
    'p': 'п', 'q': 'ч', 'r': 'р', 's': 'с', 't': 'т',
    'u': 'у', 'v': 'в', 'w': 'в', 'x': 'х', 'y': 'й',
    'z': 'з', 'ü': 'ю',
}

@register('CYRILLIC')
def convert_cyrillic(pinyin: str) -> str:
    """Convert pinyin to Cyrillic transliteration."""
    tone3 = to_tone3(pinyin)
    pinyin_clean = re.sub(r'[1-5]$', '', tone3).lower()

    result = []
    for char in pinyin_clean:
        result.append(CYRILLIC_MAP.get(char, char))

    return ''.join(result)

__all__ = ['convert_cyrillic']
