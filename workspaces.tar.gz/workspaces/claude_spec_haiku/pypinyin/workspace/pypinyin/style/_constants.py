"""Constants for style conversion including initials, finals, and regex patterns."""

# List of valid initials in Hanyu Pinyin
INITIALS = [
    'b', 'p', 'm', 'f', 'd', 't', 'n', 'l',
    'g', 'k', 'h', 'j', 'q', 'x', 'zh', 'ch', 'sh', 'r', 'z', 'c', 's', 'y', 'w'
]

# List of valid finals in Hanyu Pinyin (without tones)
FINALS = [
    'a', 'o', 'e', 'ai', 'ei', 'ao', 'ou', 'an', 'en', 'ang', 'eng', 'ong',
    'ia', 'ie', 'iao', 'iu', 'ian', 'in', 'iang', 'ing', 'iong',
    'ua', 'uo', 'uai', 'ui', 'uan', 'un', 'uang', 'ong',
    'ü', 'üe', 'üan', 'ün',
    'ê', 'er', 'ê', 'ng'
]

# Regex patterns for style conversion
# Pattern to identify tone numbers at end of syllable
TONE_NUMBER_PATTERN = r'[1-5]$'

# Pattern to identify tone marks in pinyin
TONE_MARK_PATTERN = r'[āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ]'

# Vowels that can have tone marks
TONE_VOWELS = 'aeiouüê'

# Map of relaxed initials (including y, w) to standard
RELAXED_INITIALS = INITIALS + ['y', 'w']
