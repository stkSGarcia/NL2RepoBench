"""Bopomofo (Zhuyin) style converters."""

from pypinyin.style import register
from pypinyin.style._tone_convert import to_tone3
import re

# Simplified Bopomofo mapping for common initials and finals
BOPOMOFO_MAP = {
    'b': 'ㄅ', 'p': 'ㄆ', 'm': 'ㄇ', 'f': 'ㄈ',
    'd': 'ㄉ', 't': 'ㄊ', 'n': 'ㄋ', 'l': 'ㄌ',
    'g': 'ㄍ', 'k': 'ㄎ', 'h': 'ㄏ',
    'j': 'ㄐ', 'q': 'ㄑ', 'x': 'ㄒ',
    'zh': 'ㄓ', 'ch': 'ㄔ', 'sh': 'ㄕ', 'r': 'ㄖ',
    'z': 'ㄗ', 'c': 'ㄘ', 's': 'ㄙ',
    'a': 'ㄚ', 'e': 'ㄜ', 'o': 'ㄛ',
    'i': 'ㄧ', 'u': 'ㄨ', 'ü': 'ㄩ',
    'ai': 'ㄞ', 'ei': 'ㄟ', 'ao': 'ㄠ', 'ou': 'ㄡ',
    'an': 'ㄢ', 'en': 'ㄣ', 'ang': 'ㄤ', 'eng': 'ㄥ', 'ong': 'ㄨㄥ',
}

BOPOMOFO_TONES = {
    '1': 'ˉ',
    '2': 'ˊ',
    '3': 'ˇ',
    '4': 'ˋ',
    '5': '',  # neutral tone
}

@register('BOPOMOFO')
def convert_bopomofo(pinyin: str) -> str:
    """Convert to BOPOMOFO style."""
    # Convert to tone3 first
    tone3 = to_tone3(pinyin)

    # Extract tone number
    tone_match = re.search(r'([1-5])$', tone3)
    tone_num = tone_match.group(1) if tone_match else '5'

    # Remove tone number
    pinyin_clean = re.sub(r'[1-5]$', '', tone3).lower()

    # Convert to Bopomofo
    result = ''
    i = 0
    while i < len(pinyin_clean):
        # Try longer matches first
        matched = False
        for length in [3, 2, 1]:
            substr = pinyin_clean[i:i+length]
            if substr in BOPOMOFO_MAP:
                result += BOPOMOFO_MAP[substr]
                i += length
                matched = True
                break
        if not matched:
            i += 1

    # Add tone mark
    if tone_num in BOPOMOFO_TONES:
        result += BOPOMOFO_TONES[tone_num]

    return result

@register('BOPOMOFO_FIRST')
def convert_bopomofo_first(pinyin: str) -> str:
    """Convert to BOPOMOFO_FIRST - first Bopomofo character only."""
    bopomofo = convert_bopomofo(pinyin)
    return bopomofo[0] if bopomofo else ''

__all__ = ['convert_bopomofo', 'convert_bopomofo_first']
