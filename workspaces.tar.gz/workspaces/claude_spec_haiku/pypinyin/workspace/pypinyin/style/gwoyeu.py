"""Gwoyeu Romatzyh (国語羅馬字) romanization converter."""

from pypinyin.style import register
from pypinyin.style._tone_convert import to_tone3
import re

# Simplified Gwoyeu mapping
GWOYEU_MAP = {
    'b': 'b', 'p': 'p', 'm': 'm', 'f': 'f',
    'd': 'd', 't': 't', 'n': 'n', 'l': 'l',
    'g': 'g', 'k': 'k', 'h': 'h',
    'j': 'j', 'q': 'ch', 'x': 'sh',
    'zh': 'j', 'ch': 'ch', 'sh': 'sh', 'r': 'r',
    'z': 'tz', 'c': 'ts', 's': 's',
}

@register('GWOYEU')
def convert_gwoyeu(pinyin: str) -> str:
    """Convert pinyin to Gwoyeu Romatzyh."""
    tone3 = to_tone3(pinyin)
    pinyin_clean = re.sub(r'[1-5]$', '', tone3).lower()

    # Apply Gwoyeu transformations
    result = pinyin_clean
    for pinyin_form, gwoyeu_form in GWOYEU_MAP.items():
        if result.startswith(pinyin_form):
            result = gwoyeu_form + result[len(pinyin_form):]
            break

    return result

__all__ = ['convert_gwoyeu']
