"""Style conversion registry and decorator."""

from typing import Callable, Dict, Optional

# Registry of style conversion functions
_STYLE_REGISTRY: Dict[str, Callable[[str], str]] = {}

def register(style_name: str) -> Callable:
    """Decorator to register a style conversion function.

    Example:
        @register('CUSTOM_STYLE')
        def convert_custom(pinyin: str) -> str:
            return pinyin.upper()
    """
    def decorator(func: Callable[[str], str]) -> Callable[[str], str]:
        _STYLE_REGISTRY[style_name] = func
        return func
    return decorator

def get_converter(style_name: str) -> Optional[Callable[[str], str]]:
    """Get the conversion function for a style."""
    return _STYLE_REGISTRY.get(style_name)

def list_styles() -> list[str]:
    """List all registered styles."""
    return list(_STYLE_REGISTRY.keys())

__all__ = ['register', 'get_converter', 'list_styles']
