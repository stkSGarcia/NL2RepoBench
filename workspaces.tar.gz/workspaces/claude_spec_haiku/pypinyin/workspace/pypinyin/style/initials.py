"""Initial consonant style converters."""

from pypinyin.style import register
from pypinyin.style._tone_convert import to_initials

@register('INITIALS')
def convert_initials(pinyin: str) -> str:
    """Convert to INITIALS style - extract initial consonant."""
    return to_initials(pinyin, strict=True)

@register('FIRST_LETTER')
def convert_first_letter(pinyin: str) -> str:
    """Convert to FIRST_LETTER style - get first letter only."""
    initial = to_initials(pinyin, strict=True)
    if initial:
        return initial[0]
    # If no initial, get first letter of pinyin
    import re
    clean = re.sub(r'[1-5āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ]', '', pinyin)
    return clean[0] if clean else ''

__all__ = ['convert_initials', 'convert_first_letter']
