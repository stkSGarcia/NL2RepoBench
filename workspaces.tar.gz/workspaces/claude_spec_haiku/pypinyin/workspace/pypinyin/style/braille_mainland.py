"""Braille notation converter for Mainland Chinese."""

from pypinyin.style import register
from pypinyin.style._tone_convert import to_tone3
import re

# Simplified Braille mapping for pinyin
BRAILLE_MAP = {
    'a': '⠁', 'b': '⠂', 'c': '⠄', 'd': '⠈', 'e': '⠐',
    'f': '⠠', 'g': '⠡', 'h': '⠢', 'i': '⠣', 'j': '⠤',
    'k': '⠥', 'l': '⠦', 'm': '⠧', 'n': '⠨', 'o': '⠩',
    'p': '⠪', 'q': '⠫', 'r': '⠬', 's': '⠭', 't': '⠮',
    'u': '⠯', 'v': '⠰', 'w': '⠱', 'x': '⠲', 'y': '⠳',
    'z': '⠴', 'ü': '⠵',
}

# Braille tone markers
BRAILLE_TONES = {
    '1': '⠈',  # tone 1
    '2': '⠌',  # tone 2
    '3': '⠐',  # tone 3
    '4': '⠠',  # tone 4
    '5': '',   # neutral tone
}

@register('BRAILLE_MAINLAND')
def convert_braille_mainland(pinyin: str) -> str:
    """Convert pinyin to Mainland Chinese Braille notation."""
    tone3 = to_tone3(pinyin)

    # Extract tone
    tone_match = re.search(r'([1-5])$', tone3)
    tone_num = tone_match.group(1) if tone_match else '5'

    # Remove tone number
    pinyin_clean = re.sub(r'[1-5]$', '', tone3).lower()

    # Convert to Braille
    result = []
    for char in pinyin_clean:
        result.append(BRAILLE_MAP.get(char, char))

    # Add tone marker
    braille_tone = BRAILLE_TONES.get(tone_num, '')
    if braille_tone:
        result.append(braille_tone)

    return ''.join(result)

__all__ = ['convert_braille_mainland']
