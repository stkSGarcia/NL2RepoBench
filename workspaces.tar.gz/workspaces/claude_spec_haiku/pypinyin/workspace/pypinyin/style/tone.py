"""Tone style converters (NORMAL, TONE, TONE2, TONE3)."""

from pypinyin.style import register
from pypinyin.style._tone_convert import to_tone3, to_tone, to_tone2
import re

@register('NORMAL')
def convert_normal(pinyin: str) -> str:
    """Convert to NORMAL style - remove all tone marks/numbers."""
    result = re.sub(r'[1-5]', '', pinyin)
    tone_marks = {
        'ā': 'a', 'á': 'a', 'ǎ': 'a', 'à': 'a',
        'ē': 'e', 'é': 'e', 'ě': 'e', 'è': 'e',
        'ī': 'i', 'í': 'i', 'ǐ': 'i', 'ì': 'i',
        'ō': 'o', 'ó': 'o', 'ǒ': 'o', 'ò': 'o',
        'ū': 'u', 'ú': 'u', 'ǔ': 'u', 'ù': 'u',
        'ǖ': 'ü', 'ǘ': 'ü', 'ǚ': 'ü', 'ǜ': 'ü',
    }
    for mark, base in tone_marks.items():
        result = result.replace(mark, base)
    return result

@register('TONE')
def convert_tone(pinyin: str) -> str:
    """Convert to TONE style - tone mark on vowel."""
    return to_tone(pinyin)

@register('TONE2')
def convert_tone2(pinyin: str) -> str:
    """Convert to TONE2 style - tone number after vowel."""
    return to_tone2(pinyin)

@register('TONE3')
def convert_tone3(pinyin: str) -> str:
    """Convert to TONE3 style - tone number at end."""
    return to_tone3(pinyin)

__all__ = ['convert_normal', 'convert_tone', 'convert_tone2', 'convert_tone3']
