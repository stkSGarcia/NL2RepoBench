"""Wade-Giles romanization converter."""

from pypinyin.style import register
from pypinyin.style._tone_convert import to_tone3
import re

# Simplified Wade-Giles mapping
WADEGILES_MAP = {
    # Initials
    'b': 'p', 'p': 'ph', 'm': 'm', 'f': 'f',
    'd': 't', 't': 'th', 'n': 'n', 'l': 'l',
    'g': 'k', 'k': 'kh', 'h': 'h',
    'j': 'ch', 'q': 'ch\'', 'x': 'hs',
    'zh': 'ch', 'ch': 'ch\'', 'sh': 'sh', 'r': 'j',
    'z': 'ts', 'c': 'ts\'', 's': 's',
    # Finals (simplified)
    'ai': 'ai', 'ei': 'ei', 'ao': 'ao', 'ou': 'ou',
    'an': 'an', 'en': 'en', 'ang': 'ang', 'eng': 'eng', 'ong': 'ung',
}

@register('WADE_GILES')
def convert_wade_giles(pinyin: str) -> str:
    """Convert pinyin to Wade-Giles romanization."""
    tone3 = to_tone3(pinyin)
    pinyin_clean = re.sub(r'[1-5]$', '', tone3).lower()

    # Simple conversion - map initials and finals
    result = pinyin_clean
    for pinyin_form, wade_form in WADEGILES_MAP.items():
        if result.startswith(pinyin_form):
            result = wade_form + result[len(pinyin_form):]
            break

    return result

__all__ = ['convert_wade_giles']
