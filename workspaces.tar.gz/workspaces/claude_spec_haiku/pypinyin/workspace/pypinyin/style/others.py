"""Additional style converters."""

from pypinyin.style import register
from pypinyin.style._tone_convert import to_tone3, to_finals, to_initials
import re

@register('TONE_NUMBER')
def convert_tone_number(pinyin: str) -> str:
    """Get tone number only."""
    match = re.search(r'[1-5]$', pinyin)
    if match:
        return match.group(1)
    return ''

@register('INITIALS_ONLY')
def convert_initials_only(pinyin: str) -> str:
    """Get initials only."""
    return to_initials(pinyin, strict=True)

@register('RELAXED_INITIALS')
def convert_relaxed_initials(pinyin: str) -> str:
    """Get initials in relaxed mode (includes y, w)."""
    pinyin_clean = re.sub(r'[1-5āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ]', '', pinyin).lower()

    # Relaxed initials include y and w
    relaxed_initials = [
        'zh', 'ch', 'sh', 'b', 'p', 'm', 'f', 'd', 't', 'n', 'l',
        'g', 'k', 'h', 'j', 'q', 'x', 'r', 'z', 'c', 's', 'y', 'w'
    ]

    for initial in sorted(relaxed_initials, key=len, reverse=True):
        if pinyin_clean.startswith(initial):
            return initial

    return ''

__all__ = ['convert_tone_number', 'convert_initials_only', 'convert_relaxed_initials']
