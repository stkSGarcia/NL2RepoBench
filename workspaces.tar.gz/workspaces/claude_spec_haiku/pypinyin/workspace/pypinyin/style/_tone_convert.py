"""Tone conversion utilities - convert between tone representations."""

import re
from typing import Optional

def to_tone3(pinyin: str) -> str:
    """Convert pinyin to TONE3 style (tone number at end).

    Example: 'nǐ' -> 'ni3', 'ni3' -> 'ni3'
    """
    # If already has tone number, return as-is
    if re.search(r'[1-5]$', pinyin):
        return pinyin

    # Convert tone mark to number
    tone_marks = {
        'ā': '1', 'á': '2', 'ǎ': '3', 'à': '4',
        'ē': '1', 'é': '2', 'ě': '3', 'è': '4',
        'ī': '1', 'í': '2', 'ǐ': '3', 'ì': '4',
        'ō': '1', 'ó': '2', 'ǒ': '3', 'ò': '4',
        'ū': '1', 'ú': '2', 'ǔ': '3', 'ù': '4',
        'ǖ': '1', 'ǘ': '2', 'ǚ': '3', 'ǜ': '4',
    }

    result = []
    tone_number = None

    for char in pinyin:
        if char in tone_marks:
            if tone_number is None:
                tone_number = tone_marks[char]
            # Replace tone mark with base vowel
            base_vowel = char.replace('̄', '').replace('́', '').replace('̌', '').replace('̀', '')
            result.append(base_vowel if base_vowel in 'aeiouü' else char[0])
        else:
            result.append(char)

    pinyin_clean = ''.join(result)

    if tone_number:
        return pinyin_clean + tone_number
    return pinyin_clean

def to_tone(pinyin: str) -> str:
    """Convert pinyin to TONE style (tone mark on vowel).

    Example: 'ni3' -> 'nǐ'
    """
    # Simple tone mark mapping based on last digit
    tone_marks = {
        ('a', '1'): 'ā', ('a', '2'): 'á', ('a', '3'): 'ǎ', ('a', '4'): 'à',
        ('e', '1'): 'ē', ('e', '2'): 'é', ('e', '3'): 'ě', ('e', '4'): 'è',
        ('i', '1'): 'ī', ('i', '2'): 'í', ('i', '3'): 'ǐ', ('i', '4'): 'ì',
        ('o', '1'): 'ō', ('o', '2'): 'ó', ('o', '3'): 'ǒ', ('o', '4'): 'ò',
        ('u', '1'): 'ū', ('u', '2'): 'ú', ('u', '3'): 'ǔ', ('u', '4'): 'ù',
        ('ü', '1'): 'ǖ', ('ü', '2'): 'ǘ', ('ü', '3'): 'ǚ', ('ü', '4'): 'ǜ',
    }

    match = re.search(r'([1-5])$', pinyin)
    if not match:
        return pinyin

    tone_num = match.group(1)
    pinyin_clean = pinyin[:-1]

    # Find the vowel to mark (priority: a > e > o > i > u > ü)
    vowel_priority = ['a', 'e', 'o', 'i', 'u', 'ü']
    for vowel in vowel_priority:
        if vowel in pinyin_clean:
            marked = tone_marks.get((vowel, tone_num), vowel)
            return pinyin_clean.replace(vowel, marked, 1)

    return pinyin

def to_tone2(pinyin: str) -> str:
    """Convert pinyin to TONE2 style (tone number after vowel).

    Example: 'nǐ' -> 'ni3'
    """
    # First convert to TONE3
    tone3 = to_tone3(pinyin)

    # Then move tone number after first vowel
    match = re.search(r'([aeiouü]+)', tone3)
    if not match:
        return tone3

    tone_match = re.search(r'([1-5])$', tone3)
    if not tone_match:
        return tone3

    tone_num = tone_match.group(1)
    pinyin_clean = tone3[:-1]

    vowel_match = re.search(r'[aeiouü]+', pinyin_clean)
    if not vowel_match:
        return tone3

    pos = vowel_match.end()
    return pinyin_clean[:pos] + tone_num + pinyin_clean[pos:]

def to_initials(pinyin: str, strict: bool = True) -> str:
    """Extract initial consonant from pinyin.

    Example: 'zhang1' -> 'zh', 'ai' -> ''
    """
    from pypinyin.style._constants import INITIALS

    pinyin_clean = re.sub(r'[1-5āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ]', '', pinyin).lower()

    for initial in sorted(INITIALS, key=len, reverse=True):
        if pinyin_clean.startswith(initial):
            return initial

    return ''

def to_finals(pinyin: str, strict: bool = True) -> str:
    """Extract final from pinyin, with optional tone.

    Example: 'zhang1' -> 'ang', 'ai3' -> 'ai3'
    """
    pinyin_clean = re.sub(r'[āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ]', '', pinyin).lower()

    from pypinyin.style._constants import INITIALS
    for initial in sorted(INITIALS, key=len, reverse=True):
        if pinyin_clean.startswith(initial):
            return pinyin_clean[len(initial):]

    return pinyin_clean

def _v_to_u(pinyin: str) -> str:
    """Convert ü to u (v-to-u conversion)."""
    return pinyin.replace('ü', 'u').replace('ǖ', 'u').replace('ǘ', 'u').replace('ǚ', 'u').replace('ǜ', 'u')

def _get_number_from_pinyin(pinyin: str) -> Optional[int]:
    """Extract tone number from pinyin."""
    match = re.search(r'[1-5]', pinyin)
    return int(match.group()) if match else None

def _replace(pinyin: str, old: str, new: str) -> str:
    """Replace substring in pinyin, preserving tone."""
    tone = _get_number_from_pinyin(pinyin)
    result = pinyin.replace(old, new)
    if tone and not re.search(r'[1-5]', result):
        result = result + str(tone)
    return result

def _improve_tone3(pinyin: str) -> str:
    """Improve TONE3 representation."""
    # Ensure tone number is present
    if not re.search(r'[1-5]$', pinyin):
        tone = _get_number_from_pinyin(pinyin)
        if tone:
            pinyin = re.sub(r'[1-5]', '', pinyin) + str(tone)
    return pinyin

def _fix_v_u(pinyin: str) -> str:
    """Fix v/u representation in pinyin."""
    # Replace v with ü
    return pinyin.replace('v', 'ü')

def convert_zero_consonant(pinyin: str) -> str:
    """Convert zero consonant pinyin (y/w -> nothing)."""
    # Handle y -> i/ü conversions
    if pinyin.lower().startswith('y'):
        if 'u' in pinyin:
            return pinyin[1:]
        return pinyin[1:]
    # Handle w -> u conversions
    if pinyin.lower().startswith('w'):
        return pinyin[1:]
    return pinyin

def convert_uv(pinyin: str) -> str:
    """Convert ü/u equivalence."""
    return pinyin.replace('ü', 'u').replace('v', 'u')

def convert_iou(pinyin: str) -> str:
    """Handle iou -> iu abbreviation."""
    return pinyin.replace('iou', 'iu')

def convert_uei(pinyin: str) -> str:
    """Handle uei -> ui abbreviation."""
    return pinyin.replace('uei', 'ui')

def convert_uen(pinyin: str) -> str:
    """Handle uen -> un abbreviation."""
    return pinyin.replace('uen', 'un')

def convert_finals(pinyin: str, style: str = 'default') -> str:
    """Convert finals based on style."""
    return to_finals(pinyin, strict=True)
