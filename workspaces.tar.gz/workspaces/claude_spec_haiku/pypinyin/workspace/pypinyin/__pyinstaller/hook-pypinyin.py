"""PyInstaller hook for pypinyin."""

from PyInstaller.utils.hooks import get_module_file_attribute
import os

# Get the path to the pypinyin package
try:
    import pypinyin
    pypinyin_path = os.path.dirname(pypinyin.__file__)

    # Include data files
    datas = [
        (os.path.join(pypinyin_path, 'data'), 'pypinyin/data'),
    ]

    # Hidden imports
    hiddenimports = [
        'pypinyin.constants',
        'pypinyin.exceptions',
        'pypinyin.compat',
        'pypinyin.pinyin_dict',
        'pypinyin.phrases_dict',
        'pypinyin.phonetic_symbol',
        'pypinyin.style',
        'pypinyin.converter',
        'pypinyin.core',
    ]
except ImportError:
    datas = []
    hiddenimports = []
