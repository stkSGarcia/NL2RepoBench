"""PyInstaller support for pypinyin."""

__all__ = []
