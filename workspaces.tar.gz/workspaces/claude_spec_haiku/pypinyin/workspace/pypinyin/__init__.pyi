from pypinyin.core import pinyin as pinyin, lazy_pinyin as lazy_pinyin, slug as slug
from pypinyin.constants import Style as Style, AutoConverter as AutoConverter

__version__: str
__author__: str
__email__: str

__all__: list[str]
