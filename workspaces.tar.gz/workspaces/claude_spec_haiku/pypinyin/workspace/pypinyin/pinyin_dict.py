"""Pinyin dictionary loader for single characters."""

import json
import os
from copy import deepcopy
from typing import Dict, Optional

_PINYIN_DICT_CACHE: Optional[Dict[str, str]] = None

def _load_pinyin_dict() -> Dict[str, str]:
    """Load pinyin dictionary from JSON file.

    Returns a dictionary mapping character code points to pinyin strings.
    Uses cache to avoid repeated file I/O.
    """
    global _PINYIN_DICT_CACHE

    if _PINYIN_DICT_CACHE is not None:
        return _PINYIN_DICT_CACHE

    dict_path = os.path.join(os.path.dirname(__file__), 'data', 'pinyin_dict.json')

    with open(dict_path, 'r', encoding='utf-8') as f:
        _PINYIN_DICT_CACHE = json.load(f)

    return _PINYIN_DICT_CACHE

def get_pinyin_dict() -> Dict[str, str]:
    """Get a deep copy of the pinyin dictionary to prevent external mutation."""
    return deepcopy(_load_pinyin_dict())

def load_single_dict(custom_dict: Dict[str, str], style: Optional[str] = None) -> None:
    """Load a custom single-character pinyin dictionary.

    Args:
        custom_dict: Dictionary mapping character code points to pinyin strings
        style: Optional style to apply conversions
    """
    global _PINYIN_DICT_CACHE
    base_dict = _load_pinyin_dict()
    base_dict.update(custom_dict)
