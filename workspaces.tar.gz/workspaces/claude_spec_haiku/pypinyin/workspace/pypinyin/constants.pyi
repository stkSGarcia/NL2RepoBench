from enum import Enum

class Style(Enum):
    NORMAL: int
    TONE: int
    TONE2: int
    TONE3: int
    INITIALS: int
    FIRST_LETTER: int
    FINALS: int
    FINALS_TONE: int
    FINALS_TONE2: int
    FINALS_TONE3: int
    BOPOMOFO: int
    BOPOMOFO_FIRST: int
    WADE_GILES: int
    CYRILLIC: int
    GWOYEU: int
    BRAILLE_MAINLAND: int

class AutoConverter(str, Enum):
    DEFAULT: str
    ULTIMATE: str

DEFAULT_STYLE: Style
ERROR_DEFAULT: str
ERROR_IGNORE: str
ERROR_REPLACE: str
ERROR_EXCEPTION: str
VALID_ERROR_MODES: tuple[str, ...]
