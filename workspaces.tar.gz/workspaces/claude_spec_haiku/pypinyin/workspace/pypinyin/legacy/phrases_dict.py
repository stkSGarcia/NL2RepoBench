"""Legacy phrases dict module for backward compatibility."""

from pypinyin.phrases_dict import _load_phrases_dict, get_phrases_dict, load_phrases_dict

__all__ = ['_load_phrases_dict', 'get_phrases_dict', 'load_phrases_dict']
