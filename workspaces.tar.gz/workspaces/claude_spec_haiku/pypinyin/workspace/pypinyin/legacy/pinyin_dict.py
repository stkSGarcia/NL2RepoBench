"""Legacy pinyin dict module for backward compatibility."""

from pypinyin.pinyin_dict import _load_pinyin_dict, get_pinyin_dict, load_single_dict

__all__ = ['_load_pinyin_dict', 'get_pinyin_dict', 'load_single_dict']
