"""
pypinyin: A Chinese character to pinyin conversion library.
"""

__version__ = '0.1.0'
__author__ = 'Samuel Garcia'
__email__ = 'stk.sgarcia@gmail.com'

from pypinyin.core import pinyin, lazy_pinyin, slug, Pinyin
from pypinyin.constants import Style, AutoConverter
from pypinyin.converter import Converter, DefaultConverter, UltimateConverter

__all__ = [
    'pinyin',
    'lazy_pinyin',
    'slug',
    'Pinyin',
    'Style',
    'AutoConverter',
    'Converter',
    'DefaultConverter',
    'UltimateConverter',
]
