class PinyinException(Exception):
    pass

class PinyinNotFoundException(PinyinException):
    pass

class InvalidStyleException(PinyinException):
    pass

class DictionaryLoadException(PinyinException):
    pass
