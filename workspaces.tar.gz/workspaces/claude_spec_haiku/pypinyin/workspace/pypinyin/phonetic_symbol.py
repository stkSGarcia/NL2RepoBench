"""Phonetic symbol to tone number/mark conversions."""

from typing import Dict

# Tone marks to tone numbers mapping
TONE_MARKS_TO_NUMBERS = {
    'ā': 'a1',
    'á': 'a2',
    'ǎ': 'a3',
    'à': 'a4',
    'ē': 'e1',
    'é': 'e2',
    'ě': 'e3',
    'è': 'e4',
    'ī': 'i1',
    'í': 'i2',
    'ǐ': 'i3',
    'ì': 'i4',
    'ō': 'o1',
    'ó': 'o2',
    'ǒ': 'o3',
    'ò': 'o4',
    'ū': 'u1',
    'ú': 'u2',
    'ǔ': 'u3',
    'ù': 'u4',
    'ǖ': 'ü1',
    'ǘ': 'ü2',
    'ǚ': 'ü3',
    'ǜ': 'ü4',
}

# Tone numbers to marks mapping
TONE_NUMBERS_TO_MARKS = {
    'a1': 'ā',
    'a2': 'á',
    'a3': 'ǎ',
    'a4': 'à',
    'e1': 'ē',
    'e2': 'é',
    'e3': 'ě',
    'e4': 'è',
    'i1': 'ī',
    'i2': 'í',
    'i3': 'ǐ',
    'i4': 'ì',
    'o1': 'ō',
    'o2': 'ó',
    'o3': 'ǒ',
    'o4': 'ò',
    'u1': 'ū',
    'u2': 'ú',
    'u3': 'ǔ',
    'u4': 'ù',
    'ü1': 'ǖ',
    'ü2': 'ǘ',
    'ü3': 'ǚ',
    'ü4': 'ǜ',
}

def convert_mark_to_number(pinyin_with_mark: str) -> str:
    """Convert pinyin with tone mark to pinyin with tone number.

    Example: 'nǐ' -> 'ni3'
    """
    result = []
    for char in pinyin_with_mark:
        if char in TONE_MARKS_TO_NUMBERS:
            result.append(TONE_MARKS_TO_NUMBERS[char])
        else:
            result.append(char)
    return ''.join(result)

def convert_number_to_mark(pinyin_with_number: str) -> str:
    """Convert pinyin with tone number to pinyin with tone mark.

    Example: 'ni3' -> 'nǐ'
    """
    import re
    result = []
    i = 0
    while i < len(pinyin_with_number):
        char = pinyin_with_number[i]
        if i + 1 < len(pinyin_with_number):
            potential_tone = char + pinyin_with_number[i + 1]
            if potential_tone in TONE_NUMBERS_TO_MARKS:
                result.append(TONE_NUMBERS_TO_MARKS[potential_tone])
                i += 2
                continue
        result.append(char)
        i += 1
    return ''.join(result)
