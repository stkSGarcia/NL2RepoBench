"""Standard pinyin conversions following Hanyu Pinyin rules."""

from pypinyin.style._tone_convert import (
    convert_zero_consonant,
    convert_uv,
    convert_iou,
    convert_uei,
    convert_uen,
)

def apply_standard_conversions(pinyin: str, **kwargs) -> str:
    """Apply standard Hanyu Pinyin conversions."""
    result = pinyin

    # Apply zero consonant conversion if needed
    if kwargs.get('zero_consonant', False):
        result = convert_zero_consonant(result)

    # Apply u/ü conversion if needed
    if kwargs.get('v_to_u', False):
        result = convert_uv(result)

    # Apply iou -> iu conversion
    result = convert_iou(result)

    # Apply uei -> ui conversion
    result = convert_uei(result)

    # Apply uen -> un conversion
    result = convert_uen(result)

    return result

__all__ = [
    'apply_standard_conversions',
    'convert_zero_consonant',
    'convert_uv',
    'convert_iou',
    'convert_uei',
    'convert_uen',
]
