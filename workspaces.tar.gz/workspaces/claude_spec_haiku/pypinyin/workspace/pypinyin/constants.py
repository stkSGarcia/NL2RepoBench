"""Constants for pypinyin including styles and other enumerations."""

from enum import Enum, auto

class Style(Enum):
    """Pinyin output styles."""
    NORMAL = auto()
    TONE = auto()
    TONE2 = auto()
    TONE3 = auto()
    INITIALS = auto()
    FIRST_LETTER = auto()
    FINALS = auto()
    FINALS_TONE = auto()
    FINALS_TONE2 = auto()
    FINALS_TONE3 = auto()
    BOPOMOFO = auto()
    BOPOMOFO_FIRST = auto()
    WADE_GILES = auto()
    CYRILLIC = auto()
    GWOYEU = auto()
    BRAILLE_MAINLAND = auto()

class AutoConverter(str, Enum):
    """Auto converter selection mode."""
    DEFAULT = 'default'
    ULTIMATE = 'ultimate'

# Default style
DEFAULT_STYLE = Style.NORMAL

# Common error handling modes
ERROR_DEFAULT = 'default'
ERROR_IGNORE = 'ignore'
ERROR_REPLACE = 'replace'
ERROR_EXCEPTION = 'exception'

# Valid error handling modes
VALID_ERROR_MODES = (ERROR_DEFAULT, ERROR_IGNORE, ERROR_REPLACE, ERROR_EXCEPTION)
