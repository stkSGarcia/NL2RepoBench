def prepare(pinyin: str, style: str = 'NORMAL', errors: str = 'default',
            strict: bool = True, v_to_u: bool = False,
            neutral_tone_with_five: bool = False) -> str: ...

def convert_pinyin(pinyin: str, from_style: str = 'TONE3',
                   to_style: str = 'NORMAL') -> str: ...

__all__: list[str]
