from typing import Dict

TONE_MARKS_TO_NUMBERS: Dict[str, str]
TONE_NUMBERS_TO_MARKS: Dict[str, str]

def convert_mark_to_number(pinyin_with_mark: str) -> str: ...
def convert_number_to_mark(pinyin_with_number: str) -> str: ...
