"""Core pinyin conversion functions."""

from typing import List, Tuple, Optional, Callable, Union
from pypinyin.constants import Style
from pypinyin.converter import DefaultConverter, UltimateConverter
import re

# Global converter instances
_default_pinyin_converter = DefaultConverter()
_ultimate_pinyin_converter = UltimateConverter()

class Pinyin:
    """High-level pinyin conversion class."""

    def __init__(self, converter=None):
        self.converter = converter or _default_pinyin_converter

    def pinyin(self, text: str, style: Style = Style.NORMAL,
               heteronym: bool = False, errors: str = 'default',
               strict: bool = True) -> List[List[str]]:
        """Convert Chinese text to pinyin."""
        return self.converter.convert(text, style, heteronym, errors, strict)

    def lazy_pinyin(self, text: str, style: Style = Style.NORMAL,
                    errors: str = 'default', strict: bool = True) -> List[str]:
        """Convert Chinese text to flat pinyin list (no heteronyms)."""
        result = self.pinyin(text, style, heteronym=False, errors=errors, strict=strict)
        return [py_list[0] if py_list else '' for py_list in result]

def pinyin(text: str, style: Style = Style.NORMAL,
           heteronym: bool = False, errors: str = 'default',
           strict: bool = True) -> List[List[str]]:
    """Convert Chinese text to pinyin.

    Args:
        text: Chinese text
        style: Output style (NORMAL, TONE, TONE2, TONE3, INITIALS, FINALS, etc.)
        heteronym: Include all pronunciations for polyphones
        errors: Error handling (default, ignore, replace, exception)
        strict: Use strict mode for initials

    Returns:
        List of pinyin lists (one list per character)

    Examples:
        >>> pinyin('中国')
        [['zhong'], ['guo']]
        >>> pinyin('中国', heteronym=True)
        [['zhong', 'zhòng'], ['guó']]
    """
    return _default_pinyin_converter.convert(text, style, heteronym, errors, strict)

def lazy_pinyin(text: str, style: Style = Style.NORMAL,
                errors: str = 'default', strict: bool = True) -> List[str]:
    """Convert Chinese text to flat pinyin list.

    Similar to pinyin() but returns a flat list of single pronunciations
    instead of a list of lists.

    Args:
        text: Chinese text
        style: Output style
        errors: Error handling
        strict: Use strict mode

    Returns:
        Flat list of pinyin

    Examples:
        >>> lazy_pinyin('中国')
        ['zhong', 'guo']
    """
    result = pinyin(text, style, heteronym=False, errors=errors, strict=strict)
    return [py_list[0] if py_list else '' for py_list in result]

def slug(text: str, style: Style = Style.NORMAL, heteronym: bool = False,
         separator: str = '-', errors: str = 'default') -> str:
    """Convert Chinese text to slug (all lowercase, separated by separator).

    Args:
        text: Chinese text
        style: Output style
        heteronym: Include heteronyms
        separator: Separator between pinyin
        errors: Error handling

    Returns:
        Slug string

    Examples:
        >>> slug('北京')
        'bei-jing'
    """
    result = lazy_pinyin(text, style, errors, strict=True)
    # Filter empty strings
    result = [py for py in result if py]
    return separator.join(result).lower()

__all__ = [
    'Pinyin',
    'pinyin',
    'lazy_pinyin',
    'slug',
]
