"""Mmseg-based segmentation for Chinese text."""

from typing import List, Optional

try:
    import mmseg
    HAS_MMSEG = True
except ImportError:
    HAS_MMSEG = False

def mmseg_seg(text: str) -> List[str]:
    """Segment text using mmseg if available.

    Falls back to simple character segmentation if mmseg is not installed.

    Args:
        text: Text to segment

    Returns:
        List of segmented words
    """
    if not HAS_MMSEG:
        return list(text)

    try:
        return list(mmseg.seg(text))
    except Exception:
        return list(text)

__all__ = ['mmseg_seg']
