"""Segmentation modules for Chinese text."""

from pypinyin.seg.simpleseg import simple_seg

__all__ = ['simple_seg']
