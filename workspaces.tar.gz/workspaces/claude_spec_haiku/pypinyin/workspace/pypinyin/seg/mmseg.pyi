from typing import List

def mmseg_seg(text: str) -> List[str]: ...

__all__: list[str]
