"""Simple character-level segmentation."""

from typing import List
from pypinyin.compat import is_cjk_character

def simple_seg(text: str) -> List[str]:
    """Simple segmentation - breaks text into tokens at CJK characters.

    Args:
        text: Text to segment

    Returns:
        List of tokens
    """
    result = []
    current_token = []

    for char in text:
        if is_cjk_character(char):
            if current_token:
                result.append(''.join(current_token))
                current_token = []
            result.append(char)
        else:
            current_token.append(char)

    if current_token:
        result.append(''.join(current_token))

    return result

__all__ = ['simple_seg']
