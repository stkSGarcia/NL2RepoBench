from typing import List

def simple_seg(text: str) -> List[str]: ...

__all__: list[str]
