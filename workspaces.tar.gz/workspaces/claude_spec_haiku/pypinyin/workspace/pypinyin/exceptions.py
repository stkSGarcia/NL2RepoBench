"""Exceptions for pypinyin."""

class PinyinException(Exception):
    """Base exception for pypinyin."""
    pass

class PinyinNotFoundException(PinyinException):
    """Raised when pinyin for a character is not found."""
    pass

class InvalidStyleException(PinyinException):
    """Raised when an invalid style is provided."""
    pass

class DictionaryLoadException(PinyinException):
    """Raised when dictionary loading fails."""
    pass
