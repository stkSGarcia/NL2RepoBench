"""Utility functions for pypinyin."""

from typing import List, Set, Tuple, Optional

def remove_dup_items(lst: List) -> List:
    """Remove duplicate items from list while preserving order.

    Args:
        lst: List with possible duplicates

    Returns:
        List with duplicates removed
    """
    seen: Set = set()
    result = []
    for item in lst:
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result

def remove_dup_and_empty(lst: List[str]) -> List[str]:
    """Remove duplicates and empty strings from list.

    Args:
        lst: List with possible duplicates and empty strings

    Returns:
        List with duplicates and empty strings removed
    """
    seen: Set[str] = set()
    result = []
    for item in lst:
        if item and item not in seen:
            seen.add(item)
            result.append(item)
    return result

def replace_tone2_style(pinyin: str, style_name: str) -> str:
    """Replace TONE2 style pinyin with another style.

    Args:
        pinyin: Input pinyin in TONE2 style
        style_name: Target style name

    Returns:
        Converted pinyin
    """
    from pypinyin.style import get_converter
    converter = get_converter(style_name)
    if converter:
        return converter(pinyin)
    return pinyin

def filter_pinyin(pinyin_list: List[List[str]], exclude: Optional[List[str]] = None) -> List[List[str]]:
    """Filter pinyin list based on exclusion criteria.

    Args:
        pinyin_list: List of pinyin lists
        exclude: List of strings to exclude

    Returns:
        Filtered pinyin list
    """
    if not exclude:
        return pinyin_list

    result = []
    for py_group in pinyin_list:
        filtered = [py for py in py_group if py not in exclude]
        result.append(filtered if filtered else py_group)

    return result

__all__ = [
    'remove_dup_items',
    'remove_dup_and_empty',
    'replace_tone2_style',
    'filter_pinyin',
]
