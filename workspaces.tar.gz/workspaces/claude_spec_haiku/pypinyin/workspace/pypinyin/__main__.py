"""CLI entry point for pypinyin."""

import sys
from pypinyin import pinyin, lazy_pinyin, Style

def main():
    if len(sys.argv) < 2:
        print('Usage: python -m pypinyin <text> [style]')
        print('Example: python -m pypinyin "你好" NORMAL')
        sys.exit(1)

    text = sys.argv[1]
    style = sys.argv[2] if len(sys.argv) > 2 else 'NORMAL'

    try:
        style_enum = getattr(Style, style)
    except AttributeError:
        print(f'Unknown style: {style}')
        sys.exit(1)

    result = lazy_pinyin(text, style=style_enum)
    print(' '.join(result))

if __name__ == '__main__':
    main()
