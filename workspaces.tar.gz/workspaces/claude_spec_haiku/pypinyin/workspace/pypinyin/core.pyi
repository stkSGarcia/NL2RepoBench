from typing import List, Optional
from pypinyin.constants import Style

class Pinyin:
    def pinyin(self, text: str, style: Style = Style.NORMAL,
               heteronym: bool = False, errors: str = 'default',
               strict: bool = True) -> List[List[str]]: ...
    def lazy_pinyin(self, text: str, style: Style = Style.NORMAL,
                    errors: str = 'default', strict: bool = True) -> List[str]: ...

def pinyin(text: str, style: Style = Style.NORMAL,
           heteronym: bool = False, errors: str = 'default',
           strict: bool = True) -> List[List[str]]: ...

def lazy_pinyin(text: str, style: Style = Style.NORMAL,
                errors: str = 'default', strict: bool = True) -> List[str]: ...

def slug(text: str, style: Style = Style.NORMAL, heteronym: bool = False,
         separator: str = '-', errors: str = 'default') -> str: ...

__all__: list[str]
