"""Script to generate pinyin dictionary from source data."""

import json
import os

def generate_pinyin_dict(input_file: str, output_file: str):
    """Generate pinyin dictionary JSON from source data.

    Args:
        input_file: Source pinyin data file
        output_file: Output JSON dictionary file
    """
    if not os.path.exists(input_file):
        print(f"Input file not found: {input_file}")
        return

    pinyin_dict = {}

    try:
        with open(input_file, 'r', encoding='utf-8') as f:
            for line in f:
                line = line.strip()
                if not line or line.startswith('#'):
                    continue

                # Expected format: character,pinyin1,pinyin2,...
                parts = line.split(',')
                if len(parts) >= 2:
                    char = parts[0]
                    pinyins = parts[1:]
                    # Store by Unicode code point
                    code = str(ord(char))
                    pinyin_dict[code] = ','.join(pinyins)

        # Write output
        with open(output_file, 'w', encoding='utf-8') as f:
            json.dump(pinyin_dict, f, ensure_ascii=False, indent=2)

        print(f"Generated {len(pinyin_dict)} entries to {output_file}")

    except Exception as e:
        print(f"Error generating dictionary: {e}")

if __name__ == '__main__':
    import sys
    if len(sys.argv) > 1:
        input_f = sys.argv[1]
        output_f = sys.argv[2] if len(sys.argv) > 2 else 'pinyin_dict.json'
        generate_pinyin_dict(input_f, output_f)
    else:
        print("Usage: python gen_pinyin_dict.py <input_file> [output_file]")
