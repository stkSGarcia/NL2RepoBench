pypinyin
========

A Chinese character to pinyin conversion library for Python.

Features
--------

- Convert Chinese characters to pinyin with multiple styles
- Support for polyphone (heteronym) characters
- Tone sandhi rules for natural speech
- Custom dictionary support
- Multiple output formats (TONE, TONE2, TONE3, INITIALS, FINALS, BOPOMOFO, etc.)
- Type hints and PEP 561 support

Installation
------------

.. code-block:: bash

    pip install pypinyin

Quick Start
-----------

.. code-block:: python

    from pypinyin import pinyin, lazy_pinyin, Style

    # Basic conversion
    pinyin('中国')
    # [['zhong'], ['guo']]

    # Get flat list
    lazy_pinyin('中国')
    # ['zhong', 'guo']

    # Different styles
    lazy_pinyin('中国', style=Style.TONE)
    # ['zhōng', 'guó']

    # Heteronyms
    pinyin('中', heteronym=True)
    # [['zhong', 'zhòng']]

Styles
------

- ``NORMAL``: Normal pinyin without tone marks
- ``TONE``: Pinyin with tone marks (ā, á, ǎ, à)
- ``TONE2``: Tone number after vowel (a1, a2, a3, a4)
- ``TONE3``: Tone number at end (ma1, ma2, ma3, ma4)
- ``INITIALS``: Initial consonants only (m, n, h, etc.)
- ``FINALS``: Final vowels only (a, o, e, ai, etc.)
- ``BOPOMOFO``: Bopomofo (Zhuyin) notation
- ``WADE_GILES``: Wade-Giles romanization
- ``CYRILLIC``: Cyrillic transliteration

Documentation
--------------

Full documentation available at https://pypinyin.readthedocs.io

License
-------

MIT License
