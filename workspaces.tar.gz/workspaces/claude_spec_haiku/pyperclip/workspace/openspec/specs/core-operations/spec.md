# core-operations Specification

## Purpose
TBD - created by archiving change auto-20260516-225411. Update Purpose after archive.
## Requirements
### Requirement: copy() function for text copying
The system SHALL provide a copy() function that copies text content to the system clipboard.

#### Scenario: Copy string text
- **WHEN** copy() is called with a string argument
- **THEN** the string SHALL be written to the system clipboard

#### Scenario: Copy integer value
- **WHEN** copy() is called with an integer argument
- **THEN** the integer SHALL be converted to string and written to the system clipboard

#### Scenario: Copy float value
- **WHEN** copy() is called with a float argument
- **THEN** the float SHALL be converted to string and written to the system clipboard

#### Scenario: Copy boolean True value
- **WHEN** copy() is called with True
- **THEN** the string "True" SHALL be written to the system clipboard

#### Scenario: Copy boolean False value
- **WHEN** copy() is called with False
- **THEN** the string "False" SHALL be written to the system clipboard

#### Scenario: Copy string with line breaks
- **WHEN** copy() is called with a string containing \r\n or \n characters
- **THEN** the text with line breaks SHALL be preserved in the clipboard

#### Scenario: Copy empty string
- **WHEN** copy() is called with an empty string ""
- **THEN** the clipboard SHALL be cleared or set to empty

#### Scenario: Copy string with Unicode characters
- **WHEN** copy() is called with Unicode text (e.g., "你好")
- **THEN** the Unicode text SHALL be preserved in UTF-8 encoding in the clipboard

#### Scenario: Copy string with emoji characters
- **WHEN** copy() is called with emoji text (e.g., "🙆")
- **THEN** the emoji SHALL be preserved in UTF-8 encoding in the clipboard

#### Scenario: Copy unsupported None type raises exception
- **WHEN** copy() is called with None
- **THEN** a PyperclipException SHALL be raised

#### Scenario: Copy unsupported list type raises exception
- **WHEN** copy() is called with a list
- **THEN** a PyperclipException SHALL be raised

#### Scenario: Copy unsupported dictionary type raises exception
- **WHEN** copy() is called with a dict
- **THEN** a PyperclipException SHALL be raised

### Requirement: paste() function for text retrieval
The system SHALL provide a paste() function that reads text content from the system clipboard.

#### Scenario: Paste simple text
- **WHEN** paste() is called
- **THEN** a string containing the current clipboard text SHALL be returned

#### Scenario: Paste empty clipboard
- **WHEN** paste() is called when clipboard is empty
- **THEN** an empty string "" SHALL be returned

#### Scenario: Paste text with line breaks
- **WHEN** paste() is called and clipboard contains \r\n or \n
- **THEN** the returned string SHALL preserve the line breaks exactly

#### Scenario: Paste Unicode text
- **WHEN** paste() is called and clipboard contains Unicode characters
- **THEN** the Unicode text SHALL be returned correctly in UTF-8 encoding

#### Scenario: Paste emoji text
- **WHEN** paste() is called and clipboard contains emoji
- **THEN** the emoji SHALL be returned correctly in UTF-8 encoding

#### Scenario: Paste whitespace text
- **WHEN** paste() is called and clipboard contains spaces, tabs, or other whitespace
- **THEN** the whitespace characters SHALL be returned exactly as stored

### Requirement: Type conversion and validation
The system SHALL validate input types to copy() and convert supported types to strings.

#### Scenario: Integer type validation
- **WHEN** copy() receives an integer
- **THEN** the integer SHALL be converted to string using str() function

#### Scenario: Float type validation
- **WHEN** copy() receives a float
- **THEN** the float SHALL be converted to string using str() function

#### Scenario: Boolean type validation
- **WHEN** copy() receives a boolean
- **THEN** the boolean SHALL be converted to string using str() function (True → "True", False → "False")

#### Scenario: None type rejection
- **WHEN** copy() receives None
- **THEN** a PyperclipException SHALL be raised with a helpful error message

#### Scenario: Unsupported collection types rejection
- **WHEN** copy() receives a list, tuple, set, or dict
- **THEN** a PyperclipException SHALL be raised

#### Scenario: Unsupported custom object rejection
- **WHEN** copy() receives a custom class instance
- **THEN** a PyperclipException SHALL be raised

### Requirement: UTF-8 encoding support
The system SHALL handle UTF-8 encoding consistently across all clipboard operations.

#### Scenario: UTF-8 encoding in copy operation
- **WHEN** copy() is called with text containing non-ASCII characters
- **THEN** the text SHALL be encoded as UTF-8 before writing to clipboard

#### Scenario: UTF-8 decoding in paste operation
- **WHEN** paste() is called
- **THEN** clipboard content SHALL be decoded from UTF-8 to Python string

#### Scenario: Mixed ASCII and Unicode handling
- **WHEN** copy() is called with text mixing ASCII and Unicode characters
- **THEN** both ASCII and Unicode portions SHALL be handled correctly

### Requirement: Unicode and emoji support
The system SHALL fully support Unicode characters including emojis in copy and paste operations.

#### Scenario: Unicode combining characters
- **WHEN** copy() or paste() is called with combining Unicode characters
- **THEN** the characters SHALL be handled without decomposition or normalization issues

#### Scenario: Emoji variation selectors
- **WHEN** copy() or paste() is called with emoji that have variation selectors
- **THEN** the variation selectors SHALL be preserved

#### Scenario: Multi-codepoint emoji sequences
- **WHEN** copy() or paste() is called with emoji sequences (e.g., family emoji with multiple codepoints)
- **THEN** the entire sequence SHALL be preserved intact

### Requirement: Whitespace handling
The system SHALL preserve all whitespace characters in copy and paste operations.

#### Scenario: Space character preservation
- **WHEN** copy() is called with text containing spaces
- **THEN** all spaces SHALL be preserved in the clipboard

#### Scenario: Tab character preservation
- **WHEN** copy() is called with text containing tabs (\t)
- **THEN** all tabs SHALL be preserved in the clipboard

#### Scenario: Newline preservation (LF)
- **WHEN** copy() is called with text containing \n characters
- **THEN** all newlines SHALL be preserved in the clipboard

#### Scenario: Carriage return preservation (CR)
- **WHEN** copy() is called with text containing \r characters
- **THEN** all carriage returns SHALL be preserved in the clipboard

#### Scenario: CRLF sequence preservation
- **WHEN** copy() is called with text containing \r\n sequences
- **THEN** both \r and \n SHALL be preserved together

