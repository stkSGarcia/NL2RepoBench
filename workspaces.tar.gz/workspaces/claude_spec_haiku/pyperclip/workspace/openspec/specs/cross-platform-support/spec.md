# cross-platform-support Specification

## Purpose
TBD - created by archiving change auto-20260516-225411. Update Purpose after archive.
## Requirements
### Requirement: Automatic platform detection
The system SHALL automatically detect the operating system and select the most appropriate clipboard mechanism without user intervention.

#### Scenario: Windows system detection
- **WHEN** running on Windows (os.name == 'nt' or platform.system() == 'Windows')
- **THEN** the system SHALL use the Windows API clipboard mechanism via ctypes

#### Scenario: macOS system detection
- **WHEN** running on macOS (platform.system() == 'Darwin')
- **THEN** the system SHALL attempt to use PyObjC framework first, falling back to pbcopy/pbpaste commands

#### Scenario: Linux system detection
- **WHEN** running on Linux (platform.system() == 'Linux')
- **THEN** the system SHALL detect available clipboard tools (xclip, xsel, wl-clipboard, klipper) and select the first available one

#### Scenario: WSL environment detection
- **WHEN** running in Windows Subsystem for Linux (detected via /proc/version containing "Microsoft")
- **THEN** the system SHALL use WSL clipboard mechanism via clip.exe and powershell.exe

#### Scenario: Cygwin environment detection
- **WHEN** running in Cygwin (detected via platform.system() or os.name)
- **THEN** the system SHALL use /dev/clipboard device for clipboard operations

### Requirement: Display server detection for Linux
The system SHALL detect and adapt to different Linux display servers when applicable.

#### Scenario: Wayland display server detection
- **WHEN** running on Linux with Wayland display server (WAYLAND_DISPLAY environment variable is set)
- **THEN** the system SHALL prioritize wl-clipboard tool over X11 tools

#### Scenario: X11 display server detection
- **WHEN** running on Linux with X11 display server (DISPLAY environment variable is set)
- **THEN** the system SHALL use xclip or xsel tools

#### Scenario: No display server available
- **WHEN** running on Linux without DISPLAY or WAYLAND_DISPLAY environment variables
- **THEN** the system SHALL attempt Qt framework or fallback to "no clipboard" mode

### Requirement: Support Windows API clipboard
The system SHALL support clipboard operations on Windows using the Windows API via ctypes.

#### Scenario: Windows copy operation
- **WHEN** copy() is called on Windows
- **THEN** the system SHALL use ctypes to call OpenClipboard, SetClipboardData with CF_UNICODETEXT format, and CloseClipboard

#### Scenario: Windows paste operation
- **WHEN** paste() is called on Windows
- **THEN** the system SHALL use ctypes to call OpenClipboard, GetClipboardData with CF_UNICODETEXT format, and CloseClipboard, returning the clipboard text

### Requirement: Support macOS pbcopy/pbpaste
The system SHALL support clipboard operations on macOS using pbcopy and pbpaste command-line tools.

#### Scenario: macOS copy via pbcopy
- **WHEN** copy() is called on macOS and pbcopy is available
- **THEN** the system SHALL pipe text to pbcopy subprocess

#### Scenario: macOS paste via pbpaste
- **WHEN** paste() is called on macOS and pbpaste is available
- **THEN** the system SHALL call pbpaste subprocess and return its stdout output

### Requirement: Support macOS PyObjC framework
The system SHALL support clipboard operations on macOS using the PyObjC framework and NSPasteboard.

#### Scenario: macOS copy via PyObjC
- **WHEN** copy() is called on macOS with PyObjC installed
- **THEN** the system SHALL use AppKit.NSPasteboard to set clipboard content

#### Scenario: macOS paste via PyObjC
- **WHEN** paste() is called on macOS with PyObjC installed
- **THEN** the system SHALL use AppKit.NSPasteboard to retrieve clipboard content

### Requirement: Support Linux xclip tool
The system SHALL support clipboard operations on Linux using the xclip tool.

#### Scenario: Linux copy via xclip (CLIPBOARD selection)
- **WHEN** copy() is called with xclip available
- **THEN** the system SHALL pipe text to `xclip -selection clipboard` subprocess

#### Scenario: Linux paste via xclip (CLIPBOARD selection)
- **WHEN** paste() is called with xclip available
- **THEN** the system SHALL run `xclip -selection clipboard -o` subprocess and return its output

#### Scenario: Linux copy via xclip (PRIMARY selection)
- **WHEN** copy() is called with primary=True parameter and xclip available
- **THEN** the system SHALL pipe text to `xclip -selection primary` subprocess

#### Scenario: Linux paste via xclip (PRIMARY selection)
- **WHEN** paste() is called with primary=True parameter and xclip available
- **THEN** the system SHALL run `xclip -selection primary -o` subprocess and return its output

### Requirement: Support Linux xsel tool
The system SHALL support clipboard operations on Linux using the xsel tool.

#### Scenario: Linux copy via xsel (CLIPBOARD selection)
- **WHEN** copy() is called with xsel available
- **THEN** the system SHALL pipe text to `xsel --clipboard --input` subprocess

#### Scenario: Linux paste via xsel (CLIPBOARD selection)
- **WHEN** paste() is called with xsel available
- **THEN** the system SHALL run `xsel --clipboard --output` subprocess and return its output

#### Scenario: Linux copy via xsel (PRIMARY selection)
- **WHEN** copy() is called with primary=True parameter and xsel available
- **THEN** the system SHALL pipe text to `xsel --primary --input` subprocess

#### Scenario: Linux paste via xsel (PRIMARY selection)
- **WHEN** paste() is called with primary=True parameter and xsel available
- **THEN** the system SHALL run `xsel --primary --output` subprocess and return its output

### Requirement: Support Wayland wl-clipboard
The system SHALL support clipboard operations on Wayland using the wl-clipboard tools.

#### Scenario: Wayland copy via wl-copy
- **WHEN** copy() is called with wl-clipboard available
- **THEN** the system SHALL pipe text to `wl-copy` subprocess with appropriate MIME type

#### Scenario: Wayland paste via wl-paste
- **WHEN** paste() is called with wl-clipboard available
- **THEN** the system SHALL run `wl-paste` subprocess and return its output

#### Scenario: Wayland clear clipboard
- **WHEN** copy() is called with empty string and wl-clipboard available
- **THEN** the system SHALL clear the clipboard using `wl-copy` with empty content

### Requirement: Support KDE Klipper clipboard manager
The system SHALL support clipboard operations on KDE using the Klipper manager via qdbus.

#### Scenario: KDE copy via Klipper
- **WHEN** copy() is called with Klipper and qdbus available
- **THEN** the system SHALL use qdbus to call Klipper's setClipboardContents method

#### Scenario: KDE paste via Klipper
- **WHEN** paste() is called with Klipper and qdbus available
- **THEN** the system SHALL use qdbus to call Klipper's getClipboardContents method and return the result, stripping trailing newline

### Requirement: Support Qt framework clipboard
The system SHALL support clipboard operations using the Qt framework (PyQt5 or qtpy).

#### Scenario: Qt copy operation
- **WHEN** copy() is called with Qt framework available
- **THEN** the system SHALL use QApplication.clipboard().setText() to set clipboard content

#### Scenario: Qt paste operation
- **WHEN** paste() is called with Qt framework available
- **THEN** the system SHALL use QApplication.clipboard().text() to retrieve clipboard content

### Requirement: Support Cygwin /dev/clipboard
The system SHALL support clipboard operations in Cygwin environment using /dev/clipboard device.

#### Scenario: Cygwin copy via /dev/clipboard
- **WHEN** copy() is called in Cygwin environment
- **THEN** the system SHALL write text to /dev/clipboard device file

#### Scenario: Cygwin paste via /dev/clipboard
- **WHEN** paste() is called in Cygwin environment
- **THEN** the system SHALL read text from /dev/clipboard device file

### Requirement: Support WSL clipboard synchronization
The system SHALL support clipboard operations in Windows Subsystem for Linux using Windows clipboard tools.

#### Scenario: WSL copy via clip.exe
- **WHEN** copy() is called in WSL environment
- **WHEN** text SHALL be piped to `clip.exe` subprocess

#### Scenario: WSL paste via powershell
- **WHEN** paste() is called in WSL environment
- **THEN** the system SHALL run `powershell.exe` to retrieve clipboard content encoded as UTF-8 from base64

### Requirement: Lazy initialization
The system SHALL defer clipboard mechanism detection and initialization until first use.

#### Scenario: Module import without clipboard usage
- **WHEN** importing pyperclip module
- **THEN** the system SHALL NOT perform platform detection or tool discovery operations

#### Scenario: First clipboard operation triggers initialization
- **WHEN** copy() or paste() is called for the first time after import
- **THEN** the system SHALL perform platform detection and initialize appropriate backend

#### Scenario: Subsequent operations use cached backend
- **WHEN** copy() or paste() is called after first initialization
- **THEN** the system SHALL use the already-initialized backend without re-detection

