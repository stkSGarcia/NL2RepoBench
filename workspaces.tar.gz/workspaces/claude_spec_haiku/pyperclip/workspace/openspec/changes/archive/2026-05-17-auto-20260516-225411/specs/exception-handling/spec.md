## ADDED Requirements

### Requirement: PyperclipException base exception class
The system SHALL provide PyperclipException as the base exception class for all clipboard-related errors.

#### Scenario: PyperclipException is RuntimeError subclass
- **WHEN** PyperclipException is raised
- **THEN** it SHALL be catchable as RuntimeError

#### Scenario: PyperclipException with error message
- **WHEN** PyperclipException is raised with a message
- **THEN** the message SHALL be stored and accessible as the exception message

#### Scenario: Copy with unavailable clipboard raises PyperclipException
- **WHEN** copy() is called when no clipboard backend is available
- **THEN** a PyperclipException SHALL be raised with a helpful error message

#### Scenario: Paste with unavailable clipboard raises PyperclipException
- **WHEN** paste() is called when no clipboard backend is available
- **THEN** a PyperclipException SHALL be raised with a helpful error message

#### Scenario: Copy with unsupported data type raises PyperclipException
- **WHEN** copy() is called with an unsupported type (e.g., None, list, dict)
- **THEN** a PyperclipException SHALL be raised

### Requirement: PyperclipWindowsException for Windows-specific errors
The system SHALL provide PyperclipWindowsException as a Windows-specific exception class.

#### Scenario: PyperclipWindowsException is PyperclipException subclass
- **WHEN** a Windows clipboard operation fails
- **THEN** PyperclipWindowsException SHALL be raised and be catchable as PyperclipException

#### Scenario: Windows API error code included
- **WHEN** PyperclipWindowsException is raised due to Windows API failure
- **THEN** the exception message SHALL include the Windows error code or error details

#### Scenario: Windows copy failure raises PyperclipWindowsException
- **WHEN** OpenClipboard or SetClipboardData fails in copy() on Windows
- **THEN** PyperclipWindowsException SHALL be raised instead of generic PyperclipException

#### Scenario: Windows paste failure raises PyperclipWindowsException
- **WHEN** OpenClipboard or GetClipboardData fails in paste() on Windows
- **THEN** PyperclipWindowsException SHALL be raised instead of generic PyperclipException

### Requirement: PyperclipTimeoutException for timeout errors
The system SHALL provide PyperclipTimeoutException for clipboard operations that exceed time limits.

#### Scenario: PyperclipTimeoutException is PyperclipException subclass
- **WHEN** a clipboard operation times out
- **THEN** PyperclipTimeoutException SHALL be raised and be catchable as PyperclipException

#### Scenario: Timeout exception on long-running operation
- **WHEN** copy() or paste() takes too long to complete
- **THEN** PyperclipTimeoutException SHALL be raised with a timeout message

### Requirement: Exception handling in copy() function
The system SHALL handle and wrap exceptions from clipboard operations in copy().

#### Scenario: Subprocess error handling
- **WHEN** a subprocess-based clipboard tool (xclip, xsel, pbcopy) fails
- **THEN** the subprocess error SHALL be wrapped in PyperclipException

#### Scenario: Type conversion validation
- **WHEN** copy() receives an unsupported type
- **THEN** PyperclipException SHALL be raised before attempting clipboard operation

#### Scenario: Encoding error handling
- **WHEN** text encoding to UTF-8 fails in copy()
- **THEN** PyperclipException SHALL be raised with encoding error details

### Requirement: Exception handling in paste() function
The system SHALL handle and wrap exceptions from clipboard operations in paste().

#### Scenario: Subprocess paste error handling
- **WHEN** a subprocess-based clipboard tool fails during paste()
- **THEN** the subprocess error SHALL be wrapped in PyperclipException

#### Scenario: Decoding error handling
- **WHEN** clipboard content cannot be decoded from UTF-8
- **THEN** PyperclipException SHALL be raised with decoding error details

#### Scenario: Empty clipboard handling
- **WHEN** paste() is called when clipboard is empty
- **THEN** an empty string SHALL be returned without raising an exception

### Requirement: Graceful degradation when no clipboard available
The system SHALL provide graceful error messages when clipboard is unavailable.

#### Scenario: Helpful error message for Linux without tools
- **WHEN** copy() or paste() is called on Linux with no clipboard tools available
- **THEN** PyperclipException SHALL be raised with message suggesting to install xclip, xsel, or wl-clipboard

#### Scenario: Helpful error message for no display server
- **WHEN** copy() or paste() is called on headless system with no DISPLAY or WAYLAND_DISPLAY
- **THEN** PyperclipException SHALL be raised suggesting to install clipboard tools

#### Scenario: No clipboard backend mode
- **WHEN** copy() or paste() is called after set_clipboard("no")
- **THEN** PyperclipException SHALL be raised with message explaining no clipboard backend is active

### Requirement: Exception inheritance hierarchy
The system SHALL maintain proper exception inheritance for granular exception handling.

#### Scenario: Catch specific Windows exception
- **WHEN** trying to catch Windows-specific errors
- **THEN** catching PyperclipWindowsException SHALL work for Windows API failures

#### Scenario: Catch general exception
- **WHEN** trying to catch any clipboard error
- **THEN** catching PyperclipException SHALL catch Windows, Timeout, and generic clipboard errors

#### Scenario: Catch as RuntimeError
- **WHEN** trying to catch with RuntimeError
- **THEN** catching RuntimeError SHALL catch PyperclipException and its subclasses

### Requirement: CheckedCall for Windows API error checking
The system SHALL provide CheckedCall utility for Windows API error checking.

#### Scenario: CheckedCall validates Windows API return values
- **WHEN** CheckedCall wraps a ctypes call to Windows API
- **THEN** it SHALL check the return value and raise PyperclipWindowsException on failure

#### Scenario: CheckedCall allows successful calls to pass through
- **WHEN** CheckedCall wraps a successful Windows API call
- **THEN** the return value SHALL pass through without raising exception
