## ADDED Requirements

### Requirement: CLI copy functionality
The system SHALL support copying text to clipboard via command line using -c flag.

#### Scenario: Copy text with -c flag
- **WHEN** running `python -m pyperclip -c "Hello World"`
- **THEN** the text "Hello World" SHALL be copied to the system clipboard

#### Scenario: Copy text with spaces
- **WHEN** running `python -m pyperclip -c "Hello World with spaces"`
- **THEN** the entire text including spaces SHALL be copied to clipboard

#### Scenario: Copy text with special characters
- **WHEN** running `python -m pyperclip -c "Text with special chars: @#$%"`
- **THEN** the text with special characters SHALL be copied to clipboard

#### Scenario: Copy Unicode text
- **WHEN** running `python -m pyperclip -c "你好世界 🙆"`
- **THEN** the Unicode and emoji text SHALL be copied to clipboard

#### Scenario: Copy from stdin without -c flag
- **WHEN** running `echo "test text" | python -m pyperclip`
- **THEN** the text from stdin SHALL be read and copied to clipboard

#### Scenario: Copy multiline text from stdin
- **WHEN** piping multiple lines to stdin without -c flag
- **THEN** all lines including line breaks SHALL be copied to clipboard

### Requirement: CLI paste functionality
The system SHALL support pasting text from clipboard to stdout via -p flag.

#### Scenario: Paste to stdout with -p flag
- **WHEN** running `python -m pyperclip -p`
- **THEN** the current clipboard content SHALL be output to stdout

#### Scenario: Paste empty clipboard
- **WHEN** running `python -m pyperclip -p` with empty clipboard
- **THEN** nothing SHALL be output (empty output)

#### Scenario: Paste multiline text
- **WHEN** running `python -m pyperclip -p` with multiline clipboard content
- **THEN** all lines including line breaks SHALL be output to stdout

#### Scenario: Pipe paste output to another command
- **WHEN** running `python -m pyperclip -p | grep "pattern"`
- **THEN** the clipboard content SHALL be piped to grep for filtering

### Requirement: CLI argument parsing
The system SHALL properly parse command line arguments for copy and paste operations.

#### Scenario: Default behavior without flags
- **WHEN** running `python -m pyperclip` without any arguments
- **THEN** the program SHALL read from stdin and copy to clipboard

#### Scenario: -p flag triggers paste mode
- **WHEN** running `python -m pyperclip -p`
- **THEN** the program SHALL output clipboard to stdout instead of reading stdin

#### Scenario: -c flag with text argument
- **WHEN** running `python -m pyperclip -c "text"`
- **THEN** the provided text SHALL be copied to clipboard

#### Scenario: Error handling for invalid flags
- **WHEN** running `python -m pyperclip --invalid-flag`
- **THEN** an error message SHALL be displayed and program SHALL exit with error code

### Requirement: CLI help and usage information
The system SHALL provide help and usage information via CLI.

#### Scenario: Help text with -h flag
- **WHEN** running `python -m pyperclip -h`
- **THEN** usage information and help text SHALL be displayed

#### Scenario: Help text with --help flag
- **WHEN** running `python -m pyperclip --help`
- **THEN** usage information and help text SHALL be displayed

#### Scenario: Help shows available options
- **WHEN** help text is displayed
- **THEN** it SHALL explain -c (copy) and -p (paste) options

### Requirement: CLI exit codes
The system SHALL return appropriate exit codes for success and failure.

#### Scenario: Success exit code
- **WHEN** copy or paste operation succeeds
- **THEN** the program SHALL exit with code 0

#### Scenario: Failure exit code
- **WHEN** clipboard operation fails (e.g., no clipboard available)
- **THEN** the program SHALL exit with non-zero code (e.g., 1)

#### Scenario: Argument error exit code
- **WHEN** invalid arguments are provided
- **THEN** the program SHALL exit with code 2

### Requirement: CLI error handling and messages
The system SHALL display clear error messages on clipboard errors.

#### Scenario: Error when clipboard unavailable
- **WHEN** copy() or paste() fails due to unavailable clipboard
- **THEN** an error message SHALL be printed to stderr

#### Scenario: Error message includes helpful guidance
- **WHEN** clipboard operation fails
- **THEN** the error message SHALL suggest solutions (e.g., install required tools on Linux)

#### Scenario: Traceback suppression for end users
- **WHEN** a user-facing error occurs
- **THEN** only a user-friendly error message SHALL be shown (not full traceback)

### Requirement: CLI stdin/stdout integration
The system SHALL properly handle stdin and stdout for Unix pipeline compatibility.

#### Scenario: Read from stdin when no -c flag
- **WHEN** data is piped to stdin without -c flag
- **THEN** the program SHALL read all stdin data and copy to clipboard

#### Scenario: Handle stdin end-of-file
- **WHEN** stdin reaches EOF
- **THEN** the program SHALL copy all read data to clipboard

#### Scenario: Write to stdout on paste
- **WHEN** -p flag is used
- **THEN** the program SHALL write clipboard content directly to stdout

#### Scenario: Preserve newlines in output
- **WHEN** clipboard contains newlines and paste is output to stdout
- **THEN** newlines SHALL be preserved in the output
