## Context

Pyperclip needs to support clipboard operations across drastically different platforms (Windows, macOS, Linux variants, WSL, Cygwin, Qt) that use fundamentally different APIs for clipboard access. The implementation must gracefully handle environments where clipboard support is unavailable, provide lazy initialization to avoid overhead, and expose a simple unified interface while internally managing complexity.

## Goals / Non-Goals

**Goals:**
- Provide a unified `copy()` and `paste()` interface across all supported platforms
- Automatically detect and select the most appropriate clipboard mechanism for the current environment
- Support manual override of clipboard mechanism via `set_clipboard()`
- Handle type conversion (str, int, float, bool) in `copy()` with full Unicode/emoji support
- Provide comprehensive exception handling with platform-specific and timeout exceptions
- Support primary/clipboard selection distinction on Linux (xclip, xsel, wl-clipboard)
- Implement command-line interface for clipboard operations
- Support lazy loading (defer initialization until first use)
- Provide testable architecture with isolated backend implementations

**Non-Goals:**
- Support for clipboard history or clipboard managers beyond Klipper
- Clipboard content format support beyond plain text
- Real-time clipboard monitoring or change callbacks
- Performance optimization beyond basic implementations (not a priority for initial release)
- Support for Python 2 (target Python 3.10+)

## Decisions

### 1. Modular Backend Architecture
**Decision**: Implement each clipboard mechanism as an isolated `init_<backend>_clipboard()` function returning a `(copy_func, paste_func)` tuple.
**Rationale**: Allows independent testing, easy addition of new backends, and clean platform detection logic without conditional imports at module level.
**Alternatives**: 
- Monolithic class hierarchy → too rigid, harder to test individual backends
- Direct conditional logic → difficult to extend and test

### 2. Lazy Loading with Stub Functions
**Decision**: Initialize `copy` and `paste` as lazy stub functions (`lazy_load_stub_copy`, `lazy_load_stub_paste`) that call `determine_clipboard()` on first invocation.
**Rationale**: Avoids expensive operations (subprocess checks, PyObjC imports) when module is imported but clipboard not used. Defers platform detection to actual usage time.
**Alternatives**:
- Eager initialization on import → slower imports, unnecessary overhead in non-clipboard code
- Manual initialization requirement → poor developer experience, error-prone

### 3. Project Structure: src/pyperclip Layout
**Decision**: Place library code in `src/pyperclip/` with `__init__.py` and `__main__.py` entry points.
**Rationale**: Industry standard for Python packages, supports pip install via setup.py, allows proper package isolation and namespace management.
**Alternatives**:
- Flat structure → less professional, harder to package
- Package root at workspace level → complicates installation

### 4. Platform Detection Strategy
**Decision**: Implement `determine_clipboard()` as a discovery function that tries backends in priority order, returning the first working implementation. On Linux, check for X11/Wayland first, then fallback to available tools.
**Rationale**: Maximizes compatibility by trying the best available option; graceful degradation if preferred tools unavailable.
**Alternatives**:
- Ask user to specify platform → poor UX, error-prone
- Single backend per OS → less flexible for different desktop environments

### 5. Exception Hierarchy
**Decision**: Create `PyperclipException(RuntimeError)` as base, with `PyperclipWindowsException` and `PyperclipTimeoutException` as subclasses.
**Rationale**: Allows granular exception handling while maintaining compatibility with general error catching.
**Alternatives**:
- Single exception class → loses platform-specific error context
- No exception hierarchy → forces users to catch RuntimeError

### 6. Type Conversion in copy()
**Decision**: Automatically convert str, int, float, bool to string in `copy()`. Raise `PyperclipException` for None, lists, dicts, etc.
**Rationale**: Intuitive for common numeric/boolean use cases; explicit errors for unsupported types prevent silent failures.
**Alternatives**:
- Only accept str → limits usability, forces users to convert
- Accept any type via str() → silently accepts wrong types like lists

### 7. Windows Clipboard via ctypes
**Decision**: Use ctypes to load user32.dll and call Windows clipboard APIs (OpenClipboard, SetClipboardData, GetClipboardData, CloseClipboard).
**Rationale**: No external dependencies, native Windows support, allows context manager for safe resource cleanup.
**Alternatives**:
- Use win32 module → adds dependency
- pyperclip library fork → dependency on external package

### 8. macOS Support: pbcopy vs PyObjC
**Decision**: Try PyObjC first (AppKit.NSPasteboard), fallback to pbcopy/pbpaste subprocess if PyObjC unavailable.
**Rationale**: PyObjC is more direct and handles edge cases better, but pbcopy is always available on macOS as fallback.
**Alternatives**:
- PyObjC only → may not be installed
- pbcopy only → less reliable for some edge cases

### 9. CLI Implementation
**Decision**: Implement via `__main__.py` supporting `python -m pyperclip -c "text"` (copy) and `python -m pyperclip -p` (paste), with stdin fallback for copy when no text specified.
**Rationale**: Mirrors common Unix conventions, allows integration with pipes and scripts.
**Alternatives**:
- Separate CLI binary → complicates installation
- No CLI → reduces utility for shell users

### 10. Test Architecture
**Decision**: Create base test class `_TestClipboard` with common tests, then subclass for each platform/backend. Use `_executable_exists()` and platform detection to conditionally skip tests.
**Rationale**: Prevents test duplication, allows running only relevant tests per environment, supports easy addition of new backends.
**Alternatives**:
- Single test file with conditionals → messy and hard to read
- No platform-specific tests → misses platform-specific bugs

## Risks / Trade-offs

**[Risk] No clipboard available** → When no backend works, graceful degradation to "no clipboard" mode that raises exceptions. Users get clear error message explaining why clipboard unavailable.

**[Risk] Subprocess-based backends** → xclip, xsel, wl-clipboard, klipper depend on external tools and subprocess communication. Tools may not be installed or may behave differently across versions. Mitigation: Try multiple backends in priority order, with clear error messages if all fail.

**[Risk] Type conversion ambiguity** → Converting `bool(True)` to string `"True"` may not match user expectation in all cases. Mitigation: Document behavior clearly, only support common types (str, int, float, bool).

**[Risk] Windows resource cleanup** → If CloseClipboard not called, clipboard remains locked. Mitigation: Use context manager to ensure cleanup, add try/finally blocks.

**[Risk] Unicode handling differences** → Different backends and OS versions may handle Unicode differently. Mitigation: Extensive Unicode/emoji tests, use UTF-8 encoding consistently, document known limitations.

**[Risk] Wayland vs X11 detection** → Wayland detection complex, may fail on some systems. Mitigation: Check `WAYLAND_DISPLAY` and `DISPLAY` env vars, try tools in appropriate order.

**[Risk] WSL clipboard synchronization** → WSL clipboard sync with Windows clipboard may be slow or unreliable. Mitigation: Document as best-effort, test thoroughly in WSL environments.

## Assumptions

1. **Target Environment**: Python 3.10+ with standard library only for core functionality. Optional dependencies (PyObjC, PyQt5, etc.) are detected at runtime.

2. **CLI Usage Model**: CLI users will mostly use copy from stdin or paste to stdout, matching standard Unix tool patterns.

3. **Platform Detection Sufficiency**: Using `sys.platform`, `os.name`, `platform.system()`, and checking for `/proc/version` for WSL detection is sufficient for accurate platform identification.

4. **Subprocess Tool Availability**: For Linux backends, tools like xclip, xsel, wl-clipboard, and klipper are either installed or absent; no partial installations to work around.

5. **Backend Ordering Strategy**: xclip → xsel → wl-clipboard → klipper for Linux; pbcopy → PyObjC for macOS. This order reflects reliability and availability across typical distributions.

6. **Test Environment Constraints**: Tests will be skipped gracefully on platforms where specific backends are unavailable; full test coverage requires running on multiple OS platforms.

7. **No Clipboard State Assumption**: The library doesn't maintain clipboard state between operations; it reads/writes current clipboard each time.

8. **UTF-8 as Default**: All text operations use UTF-8 encoding unless platform requires otherwise (Windows uses UTF-16LE internally, handled transparently).

## Migration Plan

N/A - This is a new project implementation with no existing users or code to migrate.

## Open Questions

1. Should clipboard history be supported (affects design)? **Assumption**: No, keep to plain text only.

2. Should there be async/thread-safe versions? **Assumption**: No for initial implementation; add if needed later.

3. What specific Python versions to support beyond 3.10? **Assumption**: 3.10+ as specified in environment config.

4. Should clipboard content be validated (size limits, content type checks)? **Assumption**: No validation; accept any content that platform clipboard accepts.
