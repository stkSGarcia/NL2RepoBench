## ADDED Requirements

### Requirement: determine_clipboard() function for automatic detection
The system SHALL provide a determine_clipboard() function that automatically detects and selects the appropriate clipboard mechanism for the current environment.

#### Scenario: Automatic detection returns tuple
- **WHEN** determine_clipboard() is called
- **THEN** a tuple of (copy_function, paste_function) SHALL be returned

#### Scenario: Detection with available backend
- **WHEN** determine_clipboard() is called on a system with at least one available clipboard backend
- **THEN** the system SHALL return the first working backend's copy and paste functions

#### Scenario: Detection tries backends in priority order
- **WHEN** determine_clipboard() is called on Linux
- **THEN** the system SHALL try xclip, then xsel, then wl-clipboard, then klipper, in that order

#### Scenario: Detection returns no clipboard backend as fallback
- **WHEN** determine_clipboard() is called and no suitable backend is available
- **THEN** the system SHALL return the "no clipboard" backend's copy and paste functions

### Requirement: set_clipboard() function for manual backend selection
The system SHALL provide a set_clipboard() function that allows users to manually select a specific clipboard mechanism.

#### Scenario: Set clipboard to Windows
- **WHEN** set_clipboard("windows") is called
- **THEN** subsequent copy() and paste() calls SHALL use the Windows API backend

#### Scenario: Set clipboard to macOS pbcopy
- **WHEN** set_clipboard("pbcopy") is called
- **THEN** subsequent copy() and paste() calls SHALL use pbcopy/pbpaste commands

#### Scenario: Set clipboard to macOS PyObjC
- **WHEN** set_clipboard("pyobjc") is called
- **THEN** subsequent copy() and paste() calls SHALL use the PyObjC framework

#### Scenario: Set clipboard to xclip
- **WHEN** set_clipboard("xclip") is called
- **THEN** subsequent copy() and paste() calls SHALL use the xclip tool

#### Scenario: Set clipboard to xsel
- **WHEN** set_clipboard("xsel") is called
- **THEN** subsequent copy() and paste() calls SHALL use the xsel tool

#### Scenario: Set clipboard to wl-clipboard
- **WHEN** set_clipboard("wl-clipboard") is called
- **THEN** subsequent copy() and paste() calls SHALL use the wl-clipboard (wl-copy/wl-paste) tools

#### Scenario: Set clipboard to Klipper
- **WHEN** set_clipboard("klipper") is called
- **THEN** subsequent copy() and paste() calls SHALL use the Klipper clipboard manager

#### Scenario: Set clipboard to Qt
- **WHEN** set_clipboard("qt") is called
- **THEN** subsequent copy() and paste() calls SHALL use the Qt framework

#### Scenario: Set clipboard to dev/clipboard (Cygwin)
- **WHEN** set_clipboard("dev") is called
- **THEN** subsequent copy() and paste() calls SHALL use the /dev/clipboard device

#### Scenario: Set clipboard to WSL
- **WHEN** set_clipboard("wsl") is called
- **THEN** subsequent copy() and paste() calls SHALL use WSL clipboard mechanisms (clip.exe/powershell.exe)

#### Scenario: Set clipboard to no clipboard support
- **WHEN** set_clipboard("no") is called
- **THEN** subsequent copy() and paste() calls SHALL raise exceptions

#### Scenario: Invalid clipboard type raises error
- **WHEN** set_clipboard() is called with an unsupported type name
- **THEN** a ValueError SHALL be raised

### Requirement: is_available() function for backend availability check
The system SHALL provide an is_available() function that checks if the clipboard backend has been initialized.

#### Scenario: Not available immediately after import
- **WHEN** is_available() is called immediately after importing pyperclip
- **THEN** the function SHALL return False (lazy loading not yet triggered)

#### Scenario: Available after first operation
- **WHEN** copy() or paste() is called, then is_available() is called
- **THEN** the function SHALL return True (backend has been initialized)

#### Scenario: Available after explicit determine_clipboard() call
- **WHEN** determine_clipboard() is called, then is_available() is called
- **THEN** the function SHALL return True

#### Scenario: Not available if set to no clipboard
- **WHEN** set_clipboard("no") is called, then is_available() is called
- **THEN** the function SHALL return False (no clipboard is not a real backend)

### Requirement: Initialization functions for each clipboard backend
The system SHALL provide dedicated initialization functions for each clipboard mechanism.

#### Scenario: init_windows_clipboard() returns tuple
- **WHEN** init_windows_clipboard() is called
- **THEN** a tuple of (copy_function, paste_function) for Windows clipboard SHALL be returned

#### Scenario: init_osx_pbcopy_clipboard() returns tuple
- **WHEN** init_osx_pbcopy_clipboard() is called
- **THEN** a tuple of (copy_function, paste_function) for macOS pbcopy SHALL be returned

#### Scenario: init_osx_pyobjc_clipboard() returns tuple
- **WHEN** init_osx_pyobjc_clipboard() is called
- **THEN** a tuple of (copy_function, paste_function) for macOS PyObjC SHALL be returned

#### Scenario: init_xclip_clipboard() returns tuple
- **WHEN** init_xclip_clipboard() is called
- **THEN** a tuple of (copy_function, paste_function) for xclip SHALL be returned

#### Scenario: init_xsel_clipboard() returns tuple
- **WHEN** init_xsel_clipboard() is called
- **THEN** a tuple of (copy_function, paste_function) for xsel SHALL be returned

#### Scenario: init_wl_clipboard() returns tuple
- **WHEN** init_wl_clipboard() is called
- **THEN** a tuple of (copy_function, paste_function) for wl-clipboard SHALL be returned

#### Scenario: init_klipper_clipboard() returns tuple
- **WHEN** init_klipper_clipboard() is called
- **THEN** a tuple of (copy_function, paste_function) for Klipper SHALL be returned

#### Scenario: init_qt_clipboard() returns tuple
- **WHEN** init_qt_clipboard() is called
- **THEN** a tuple of (copy_function, paste_function) for Qt framework SHALL be returned

#### Scenario: init_dev_clipboard_clipboard() returns tuple
- **WHEN** init_dev_clipboard_clipboard() is called
- **THEN** a tuple of (copy_function, paste_function) for /dev/clipboard (Cygwin) SHALL be returned

#### Scenario: init_wsl_clipboard() returns tuple
- **WHEN** init_wsl_clipboard() is called
- **THEN** a tuple of (copy_function, paste_function) for WSL clipboard SHALL be returned

#### Scenario: init_no_clipboard() returns tuple that raises on use
- **WHEN** init_no_clipboard() is called
- **THEN** a tuple of (copy_function, paste_function) SHALL be returned where both functions raise RuntimeError when called

### Requirement: Lazy loading mechanism
The system SHALL defer clipboard initialization until first use.

#### Scenario: lazy_load_stub_copy() initializes on first call
- **WHEN** copy() (which is initially lazy_load_stub_copy()) is called
- **THEN** determine_clipboard() SHALL be called and copy SHALL be replaced with the real implementation

#### Scenario: lazy_load_stub_paste() initializes on first call
- **WHEN** paste() (which is initially lazy_load_stub_paste()) is called
- **THEN** determine_clipboard() SHALL be called and paste SHALL be replaced with the real implementation

#### Scenario: Initialization happens only once
- **WHEN** copy() is called, then copy() is called again
- **THEN** determine_clipboard() SHALL only be called once; second call uses cached backend

### Requirement: _executable_exists() utility for tool detection
The system SHALL provide _executable_exists() function to check if a system command exists.

#### Scenario: Check for existing executable
- **WHEN** _executable_exists("xclip") is called on a system with xclip installed
- **THEN** the function SHALL return True

#### Scenario: Check for non-existing executable
- **WHEN** _executable_exists("nonexistent_tool") is called
- **THEN** the function SHALL return False

#### Scenario: Tool detection supports PATH search
- **WHEN** _executable_exists() is called for a tool in system PATH
- **THEN** the function SHALL find and return True for the tool
