## 1. Project Setup and Configuration

- [x] 1.1 Create project directory structure (src/pyperclip/, tests/)
- [x] 1.2 Create setup.py with package metadata and dependencies
- [x] 1.3 Create pyproject.toml with build configuration
- [x] 1.4 Create Pipfile and Pipfile.lock for dependency management
- [x] 1.5 Create .gitignore with Python-specific patterns
- [x] 1.6 Create README.md with basic usage documentation
- [x] 1.7 Create AUTHORS.txt and LICENSE.txt files
- [x] 1.8 Create CHANGES.txt changelog file

## 2. Exception Classes

- [x] 2.1 Create PyperclipException class inheriting from RuntimeError
- [x] 2.2 Create PyperclipWindowsException class for Windows-specific errors
- [x] 2.3 Create PyperclipTimeoutException class for timeout errors
- [x] 2.4 Create CheckedCall utility class for Windows API error checking
- [x] 2.5 Implement exception error messages with helpful guidance

## 3. Utility Functions

- [x] 3.1 Implement _executable_exists() function for cross-platform executable detection
- [x] 3.2 Define ENCODING constant (default: 'utf-8')
- [x] 3.3 Define _IS_RUNNING_PYTHON_2 constant for version detection
- [x] 3.4 Implement lazy_load_stub_copy() function for deferred initialization
- [x] 3.5 Implement lazy_load_stub_paste() function for deferred initialization

## 4. Windows Clipboard Backend

- [x] 4.1 Implement init_windows_clipboard() function
- [x] 4.2 Implement copy_windows() using ctypes and Windows API
- [x] 4.3 Implement paste_windows() using ctypes and Windows API
- [x] 4.4 Add Windows clipboard resource management and cleanup
- [x] 4.5 Handle CF_UNICODETEXT format and UTF-16 encoding for Windows

## 5. macOS Clipboard Backends

- [x] 5.1 Implement init_osx_pbcopy_clipboard() function
- [x] 5.2 Implement copy_osx_pbcopy() using pbcopy subprocess
- [x] 5.3 Implement paste_osx_pbcopy() using pbpaste subprocess
- [x] 5.4 Implement init_osx_pyobjc_clipboard() function
- [x] 5.5 Implement copy_osx_pyobjc() using AppKit.NSPasteboard
- [x] 5.6 Implement paste_osx_pyobjc() using AppKit.NSPasteboard
- [x] 5.7 Add fallback logic from PyObjC to pbcopy

## 6. Linux X11 Clipboard Backends (xclip, xsel)

- [x] 6.1 Implement init_xclip_clipboard() function
- [x] 6.2 Implement copy_xclip() with primary/CLIPBOARD selection support
- [x] 6.3 Implement paste_xclip() with primary/CLIPBOARD selection support
- [x] 6.4 Implement init_xsel_clipboard() function
- [x] 6.5 Implement copy_xsel() with primary/CLIPBOARD selection support
- [x] 6.6 Implement paste_xsel() with primary/CLIPBOARD selection support
- [x] 6.7 Add executable existence checks for xclip and xsel

## 7. Linux Wayland Clipboard Backend

- [x] 7.1 Implement init_wl_clipboard() function
- [x] 7.2 Implement copy_wl() using wl-copy subprocess
- [x] 7.3 Implement paste_wl() using wl-paste subprocess
- [x] 7.4 Add primary/CLIPBOARD selection support for Wayland
- [x] 7.5 Implement clipboard clear behavior for wl-copy
- [x] 7.6 Add executable existence check for wl-copy

## 8. Linux KDE Klipper Clipboard Backend

- [x] 8.1 Implement init_klipper_clipboard() function
- [x] 8.2 Implement copy_klipper() using qdbus to Klipper
- [x] 8.3 Implement paste_klipper() using qdbus from Klipper
- [x] 8.4 Handle trailing newline stripping in Klipper paste
- [x] 8.5 Add executable existence checks for klipper and qdbus

## 9. Qt Framework Clipboard Backend

- [x] 9.1 Implement init_qt_clipboard() function
- [x] 9.2 Implement copy_qt() using QApplication.clipboard().setText()
- [x] 9.3 Implement paste_qt() using QApplication.clipboard().text()
- [x] 9.4 Add PyQt5 and qtpy detection with fallback
- [x] 9.5 Add display environment detection for Qt support

## 10. Cygwin Clipboard Backend

- [x] 10.1 Implement init_dev_clipboard_clipboard() function
- [x] 10.2 Implement copy_dev_clipboard() using /dev/clipboard device
- [x] 10.3 Implement paste_dev_clipboard() using /dev/clipboard device
- [x] 10.4 Add Cygwin environment detection

## 11. Windows Subsystem for Linux (WSL) Backend

- [x] 11.1 Implement init_wsl_clipboard() function
- [x] 11.2 Implement copy_wsl() using clip.exe for UTF-16LE encoding
- [x] 11.3 Implement paste_wsl() using powershell.exe with base64 decoding
- [x] 11.4 Add WSL environment detection via /proc/version
- [x] 11.5 Handle UTF-8 to UTF-16LE conversion for WSL copy

## 12. No Clipboard Backend (Fallback)

- [x] 12.1 Implement init_no_clipboard() function
- [x] 12.2 Implement copy_no_clipboard() raising PyperclipException
- [x] 12.3 Implement paste_no_clipboard() raising PyperclipException
- [x] 12.4 Create helpful error messages for missing clipboard support

## 13. Core API Functions - Type Handling

- [x] 13.1 Implement type conversion for strings in copy()
- [x] 13.2 Implement type conversion for integers in copy()
- [x] 13.3 Implement type conversion for floats in copy()
- [x] 13.4 Implement type conversion for booleans in copy()
- [x] 13.5 Implement exception raising for unsupported types (None, list, dict, etc.)
- [x] 13.6 Add UTF-8 encoding/decoding support for copy() and paste()

## 14. Core API Functions - Platform Detection and Initialization

- [x] 14.1 Implement determine_clipboard() function for automatic backend detection
- [x] 14.2 Implement Windows platform detection logic
- [x] 14.3 Implement macOS platform detection logic
- [x] 14.4 Implement Linux platform detection with X11/Wayland support
- [x] 14.5 Implement WSL environment detection
- [x] 14.6 Implement Cygwin environment detection
- [x] 14.7 Implement backend fallback priority ordering

## 15. Core API Functions - Manual Backend Selection

- [x] 15.1 Implement set_clipboard() function for manual backend selection
- [x] 15.2 Add validation for supported clipboard type names
- [x] 15.3 Implement dynamic module global reassignment for copy and paste
- [x] 15.4 Add error handling for invalid clipboard types

## 16. Core API Functions - Clipboard Availability

- [x] 16.1 Implement is_available() function to check backend initialization status
- [x] 16.2 Track copy and paste as actual functions vs lazy stubs
- [x] 16.3 Return True only when backends are initialized

## 17. Module Initialization and Lazy Loading

- [x] 17.1 Create src/pyperclip/__init__.py main module
- [x] 17.2 Initialize copy and paste as lazy load stubs
- [x] 17.3 Implement lazy loading trigger on first copy() or paste() call
- [x] 17.4 Export public API functions (copy, paste, set_clipboard, determine_clipboard, is_available)
- [x] 17.5 Export exception classes (PyperclipException, PyperclipWindowsException, PyperclipTimeoutException)
- [x] 17.6 Export initialization functions (init_*_clipboard)
- [x] 17.7 Export utility functions (_executable_exists)
- [x] 17.8 Define __all__ list for public API

## 18. Command-Line Interface

- [x] 18.1 Create src/pyperclip/__main__.py for CLI entry point
- [x] 18.2 Implement argparse argument parsing for -c (copy) flag
- [x] 18.3 Implement argparse argument parsing for -p (paste) flag
- [x] 18.4 Implement stdin reading for default copy mode
- [x] 18.5 Implement stdout writing for paste mode
- [x] 18.6 Add exit code handling (0 for success, 1 for clipboard error, 2 for arg error)
- [x] 18.7 Add help text and usage information
- [x] 18.8 Add error message handling and output to stderr

## 19. Test Framework Setup

- [x] 19.1 Create tests/test_pyperclip.py test module
- [x] 19.2 Import pytest and unittest frameworks
- [x] 19.3 Create _TestClipboard base test class
- [x] 19.4 Implement setup and teardown for test classes
- [x] 19.5 Add skip decorators for platform-specific tests

## 20. Basic Clipboard Operation Tests

- [x] 20.1 Implement test_copy_paste_simple() for basic roundtrip
- [x] 20.2 Implement test_copy_simple() for simple copy
- [x] 20.3 Implement test_copy_blank() for empty string handling
- [x] 20.4 Implement test_copy_paste_whitespace() for whitespace preservation

## 21. Unicode and Emoji Tests

- [x] 21.1 Implement test_copy_unicode() for Unicode character support
- [x] 21.2 Implement test_copy_paste_unicode() for Unicode roundtrip
- [x] 21.3 Implement test_copy_unicode_emoji() for emoji support
- [x] 21.4 Implement test_copy_paste_unicode_emoji() for emoji roundtrip
- [x] 21.5 Add skip logic for backends without Unicode support

## 22. Data Type Conversion Tests

- [x] 22.1 Implement test_non_str() for type conversion testing
- [x] 22.2 Add integer copy test (42, -1)
- [x] 22.3 Add float copy test (3.141592)
- [x] 22.4 Add boolean copy test (True, False)
- [x] 22.5 Add exception tests for None, list, and dict types

## 23. Platform-Specific Test Classes

- [x] 23.1 Create TestWindows class for Windows tests
- [x] 23.2 Create TestOSX class for macOS tests
- [x] 23.3 Create TestXClip class for xclip-specific tests
- [x] 23.4 Create TestXSel class for xsel-specific tests
- [x] 23.5 Create TestWlClipboard class for Wayland tests
- [x] 23.6 Create TestKlipper class for Klipper tests
- [x] 23.7 Create TestQt class for Qt framework tests
- [x] 23.8 Create TestWSL class for WSL tests
- [x] 23.9 Create TestCygwin class for Cygwin tests
- [x] 23.10 Create TestNoClipboard class for fallback backend tests

## 24. Conditional Test Skipping

- [x] 24.1 Add platform detection skips (Windows, macOS, Linux)
- [x] 24.2 Add executable existence skips (xclip, xsel, wl-copy, klipper)
- [x] 24.3 Add PyObjC availability skip
- [x] 24.4 Add PyQt5 availability skip
- [x] 24.5 Add display environment skip for Qt tests
- [x] 24.6 Add WSL detection skip logic

## 25. Exception Handling Tests

- [x] 25.1 Test PyperclipException raising for unsupported types
- [x] 25.2 Test PyperclipWindowsException on Windows API failures
- [x] 25.3 Test PyperclipTimeoutException for timeout scenarios
- [x] 25.4 Test exception inheritance hierarchy
- [x] 25.5 Test exception catching with proper handler hierarchy

## 26. Integration and Verification

- [x] 26.1 Run all unit tests and verify passing
- [x] 26.2 Test setup.py installation with pip install -e .
- [x] 26.3 Verify module imports work correctly
- [x] 26.4 Test CLI via `python -m pyperclip` commands
- [x] 26.5 Test cross-platform compatibility on available platforms
- [x] 26.6 Verify lazy loading behavior (no clipboard ops on import)
- [x] 26.7 Test set_clipboard() manual backend switching

## 27. Documentation and Final Setup

- [x] 27.1 Update README.md with installation instructions
- [x] 27.2 Add usage examples to README.md
- [x] 27.3 Add API reference documentation
- [x] 27.4 Document CLI usage and examples
- [x] 27.5 Document supported platforms and backends
- [x] 27.6 Add troubleshooting section to README
- [x] 27.7 Create tox.ini for test automation
- [x] 27.8 Verify all files are in correct locations per API Usage Guide
