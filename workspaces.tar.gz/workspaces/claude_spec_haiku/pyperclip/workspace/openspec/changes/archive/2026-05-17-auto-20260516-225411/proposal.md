## Why

Clipboard operations vary significantly across operating systems, requiring developers to write platform-specific code or rely on external dependencies. Pyperclip solves this by providing a unified, cross-platform clipboard interface that automatically detects and adapts to each system's native mechanisms (Windows API, macOS pbcopy/PyObjC, Linux xclip/xsel/wl-clipboard, WSL, Cygwin, and Qt framework), enabling seamless clipboard integration with minimal code.

## What Changes

This is a new Python project implementing a comprehensive cross-platform clipboard library with the following components:

- **Core clipboard functions**: `copy()` and `paste()` with automatic type conversion (strings, numbers, booleans) and Unicode/emoji support
- **Clipboard mechanism management**: `set_clipboard()`, `determine_clipboard()`, and `is_available()` for dynamic clipboard selection
- **Multi-backend support**: Windows API (ctypes), macOS (pbcopy/PyObjC), Linux (xclip, xsel, wl-clipboard, klipper), WSL, Cygwin, and Qt frameworks
- **Exception handling**: Custom exception classes (`PyperclipException`, `PyperclipWindowsException`, `PyperclipTimeoutException`)
- **Command-line interface**: Support for `python -m pyperclip -c [text]` and `python -m pyperclip -p` operations
- **Lazy loading mechanism**: Deferred initialization to avoid overhead on import
- **Primary/clipboard selection support**: For Linux systems supporting X11/Wayland display servers
- **Comprehensive test coverage**: Unit tests for all platforms, backends, and edge cases

## Capabilities

### New Capabilities
- `cross-platform-support`: Automatic detection and adaptation to Windows, macOS, Linux, WSL, Cygwin, and Qt platforms
- `core-operations`: Text copy and paste with type conversion and Unicode support
- `backend-management`: Dynamic selection and switching of clipboard mechanisms
- `exception-handling`: Custom exception classes and graceful degradation
- `command-line-interface`: CLI tool for clipboard operations via command line
- `test-system`: Comprehensive unit tests with platform-specific coverage

### Modified Capabilities
<!-- No existing capabilities to modify; this is a new project -->

## Impact

- **New Project Structure**: Creates `src/pyperclip/` package with `__init__.py`, `__main__.py`, and clipboard backend modules
- **Configuration Files**: Includes `setup.py`, `pyproject.toml`, `Pipfile`, `.gitignore`
- **Test Suite**: Adds `tests/test_pyperclip.py` with comprehensive test coverage
- **APIs**: Exposes core functions via `from pyperclip import copy, paste, set_clipboard, determine_clipboard, is_available`
- **Dependencies**: Requires no external dependencies for core functionality; optional support for PyObjC, PyQt5, and command-line tools
- **Platform Coverage**: Supports Python 3.10+ on Windows, macOS, Linux, WSL, and Cygwin environments
