# Pyperclip

A cross-platform clipboard library for Python supporting Windows, macOS, Linux, WSL, and Cygwin.

## Installation

```bash
pip install pyperclip
```

## Usage

### Basic Usage

```python
import pyperclip

# Copy text to clipboard
pyperclip.copy('Hello, world!')

# Paste text from clipboard
text = pyperclip.paste()
print(text)
```

### Supported Types

The `copy()` function automatically converts:
- `str`: Copied as-is
- `int`, `float`, `bool`: Converted to string representation
- Other types: Raise `PyperclipException`

### Type Conversion Examples

```python
pyperclip.copy(42)  # Copies "42"
pyperclip.copy(3.14)  # Copies "3.14"
pyperclip.copy(True)  # Copies "True"
```

### Unicode and Emoji Support

```python
pyperclip.copy('Hello 👋 世界')
text = pyperclip.paste()
```

### Command-Line Interface

```bash
# Copy from stdin
echo "Hello" | python -m pyperclip

# Paste to stdout
python -m pyperclip -p

# Copy directly
python -m pyperclip -c "Text to copy"
```

### Manual Backend Selection

```python
import pyperclip

# Switch to specific clipboard backend
pyperclip.set_clipboard('xclip')

# Check if clipboard is available
if pyperclip.is_available():
    pyperclip.copy('text')
```

## Supported Platforms and Backends

### Windows
- Windows API via ctypes

### macOS
- PyObjC (AppKit.NSPasteboard)
- pbcopy/pbpaste fallback

### Linux
- xclip
- xsel
- wl-clipboard (Wayland)
- klipper (KDE)
- Qt framework
- /dev/clipboard (Cygwin)

### Other
- WSL (Windows Subsystem for Linux)
- Cygwin

## Exception Handling

```python
import pyperclip
from pyperclip import PyperclipException, PyperclipWindowsException

try:
    pyperclip.copy([1, 2, 3])  # Unsupported type
except PyperclipException as e:
    print(f"Clipboard error: {e}")
```

## API Reference

### Functions

- `copy(text)`: Copy text to clipboard
- `paste()`: Get text from clipboard
- `set_clipboard(backend)`: Manually select clipboard backend
- `determine_clipboard()`: Automatically detect appropriate backend
- `is_available()`: Check if clipboard is available

### Exception Classes

- `PyperclipException`: Base exception
- `PyperclipWindowsException`: Windows API errors
- `PyperclipTimeoutException`: Timeout errors

## Troubleshooting

### "Pyperclip could not find a copy/paste mechanism for your system"

This error means no supported clipboard backend is available. Solutions:
- Install clipboard tools (xclip, xsel on Linux)
- Install PyObjC on macOS if pbcopy not working
- Check that Qt is installed if using Qt backend

### Unicode Issues

If Unicode characters aren't copying correctly:
- Ensure your system locale supports UTF-8
- On WSL, verify Windows clipboard is enabled
- Try switching backends with `set_clipboard()`

## License

BSD License
