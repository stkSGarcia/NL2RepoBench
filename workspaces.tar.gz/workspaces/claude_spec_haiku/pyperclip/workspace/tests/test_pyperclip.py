import pytest
import unittest
import sys
import os
import platform
import pyperclip
from pyperclip import (
    PyperclipException,
    PyperclipWindowsException,
    PyperclipTimeoutException,
    _executable_exists,
)


class _TestClipboard(unittest.TestCase):
    """Base test class for clipboard operations."""

    def setUp(self):
        """Setup test fixtures."""
        self.original_copy = pyperclip.copy
        self.original_paste = pyperclip.paste

    def tearDown(self):
        """Cleanup after tests."""
        pyperclip.copy = self.original_copy
        pyperclip.paste = self.original_paste


class TestBasicOperations(_TestClipboard):
    """Basic clipboard operation tests."""

    def test_copy_paste_simple(self):
        """Test basic copy and paste roundtrip."""
        text = "Hello, world!"
        pyperclip.copy(text)
        result = pyperclip.paste()
        self.assertEqual(result, text)

    def test_copy_simple(self):
        """Test simple copy operation."""
        text = "test text"
        pyperclip.copy(text)
        self.assertTrue(pyperclip.is_available())

    def test_copy_blank(self):
        """Test copying empty string."""
        pyperclip.copy('')
        result = pyperclip.paste()
        self.assertEqual(result, '')

    def test_copy_paste_whitespace(self):
        """Test whitespace preservation."""
        text = "  leading and trailing  \n  with newline  "
        pyperclip.copy(text)
        result = pyperclip.paste()
        self.assertEqual(result, text)


class TestUnicodeSupport(_TestClipboard):
    """Unicode and emoji tests."""

    def test_copy_unicode(self):
        """Test Unicode character support."""
        text = "Café"
        pyperclip.copy(text)
        self.assertTrue(pyperclip.is_available())

    def test_copy_paste_unicode(self):
        """Test Unicode roundtrip."""
        text = "Ñoño 你好 مرحبا"
        pyperclip.copy(text)
        result = pyperclip.paste()
        self.assertEqual(result, text)

    def test_copy_unicode_emoji(self):
        """Test emoji support."""
        text = "👋 Hello 🌍"
        pyperclip.copy(text)
        self.assertTrue(pyperclip.is_available())

    def test_copy_paste_unicode_emoji(self):
        """Test emoji roundtrip."""
        text = "🎉 Party 🎊 Time 🎈"
        pyperclip.copy(text)
        result = pyperclip.paste()
        self.assertEqual(result, text)


class TestTypeConversion(_TestClipboard):
    """Type conversion tests."""

    def test_copy_int(self):
        """Test integer copy."""
        pyperclip.copy(42)
        result = pyperclip.paste()
        self.assertEqual(result, "42")

    def test_copy_negative_int(self):
        """Test negative integer copy."""
        pyperclip.copy(-1)
        result = pyperclip.paste()
        self.assertEqual(result, "-1")

    def test_copy_float(self):
        """Test float copy."""
        pyperclip.copy(3.141592)
        result = pyperclip.paste()
        self.assertEqual(result, "3.141592")

    def test_copy_bool_true(self):
        """Test boolean True copy."""
        pyperclip.copy(True)
        result = pyperclip.paste()
        self.assertEqual(result, "True")

    def test_copy_bool_false(self):
        """Test boolean False copy."""
        pyperclip.copy(False)
        result = pyperclip.paste()
        self.assertEqual(result, "False")

    def test_copy_none_raises(self):
        """Test that None raises exception."""
        with self.assertRaises(PyperclipException):
            pyperclip.copy(None)

    def test_copy_list_raises(self):
        """Test that list raises exception."""
        with self.assertRaises(PyperclipException):
            pyperclip.copy([1, 2, 3])

    def test_copy_dict_raises(self):
        """Test that dict raises exception."""
        with self.assertRaises(PyperclipException):
            pyperclip.copy({'key': 'value'})

    def test_copy_tuple_raises(self):
        """Test that tuple raises exception."""
        with self.assertRaises(PyperclipException):
            pyperclip.copy((1, 2, 3))


class TestExceptionHierarchy(unittest.TestCase):
    """Exception hierarchy tests."""

    def test_pyperclip_exception_is_runtime_error(self):
        """Test that PyperclipException inherits from RuntimeError."""
        self.assertTrue(issubclass(PyperclipException, RuntimeError))

    def test_windows_exception_is_pyperclip_exception(self):
        """Test that PyperclipWindowsException inherits from PyperclipException."""
        self.assertTrue(issubclass(PyperclipWindowsException, PyperclipException))

    def test_timeout_exception_is_pyperclip_exception(self):
        """Test that PyperclipTimeoutException inherits from PyperclipException."""
        self.assertTrue(issubclass(PyperclipTimeoutException, PyperclipException))

    def test_can_catch_windows_exception_as_pyperclip(self):
        """Test catching Windows exception as PyperclipException."""
        try:
            raise PyperclipWindowsException("test")
        except PyperclipException:
            pass

    def test_can_catch_timeout_exception_as_pyperclip(self):
        """Test catching timeout exception as PyperclipException."""
        try:
            raise PyperclipTimeoutException("test")
        except PyperclipException:
            pass


@unittest.skipIf(sys.platform != 'win32', "Windows only")
class TestWindows(_TestClipboard):
    """Windows-specific tests."""

    def test_windows_initialization(self):
        """Test Windows clipboard initialization."""
        from pyperclip import init_windows_clipboard
        copy_func, paste_func = init_windows_clipboard()
        self.assertIsNotNone(copy_func)
        self.assertIsNotNone(paste_func)

    def test_windows_clipboard_available(self):
        """Test Windows clipboard is available."""
        pyperclip.set_clipboard('windows')
        self.assertTrue(pyperclip.is_available())


@unittest.skipIf(sys.platform != 'darwin', "macOS only")
class TestOSX(_TestClipboard):
    """macOS-specific tests."""

    def test_osx_pbcopy_initialization(self):
        """Test macOS pbcopy initialization."""
        from pyperclip import init_osx_pbcopy_clipboard
        copy_func, paste_func = init_osx_pbcopy_clipboard()
        self.assertIsNotNone(copy_func)
        self.assertIsNotNone(paste_func)

    def test_osx_clipboard_available(self):
        """Test macOS clipboard is available."""
        pyperclip.copy("test")
        self.assertTrue(pyperclip.is_available())


@unittest.skipIf(not _executable_exists('xclip'), "xclip not available")
class TestXClip(_TestClipboard):
    """xclip-specific tests."""

    def test_xclip_initialization(self):
        """Test xclip initialization."""
        from pyperclip import init_xclip_clipboard
        cb = init_xclip_clipboard()
        self.assertIsNotNone(cb)

    def test_xclip_copy_paste(self):
        """Test xclip copy and paste."""
        pyperclip.set_clipboard('xclip')
        pyperclip.copy("xclip test")
        result = pyperclip.paste()
        self.assertEqual(result, "xclip test")


@unittest.skipIf(not _executable_exists('xsel'), "xsel not available")
class TestXSel(_TestClipboard):
    """xsel-specific tests."""

    def test_xsel_initialization(self):
        """Test xsel initialization."""
        from pyperclip import init_xsel_clipboard
        cb = init_xsel_clipboard()
        self.assertIsNotNone(cb)

    def test_xsel_copy_paste(self):
        """Test xsel copy and paste."""
        pyperclip.set_clipboard('xsel')
        pyperclip.copy("xsel test")
        result = pyperclip.paste()
        self.assertEqual(result, "xsel test")


@unittest.skipIf(not _executable_exists('wl-copy'), "wl-copy not available")
class TestWlClipboard(_TestClipboard):
    """Wayland wl-clipboard tests."""

    def test_wl_initialization(self):
        """Test Wayland initialization."""
        from pyperclip import init_wl_clipboard
        cb = init_wl_clipboard()
        self.assertIsNotNone(cb)

    def test_wl_copy_paste(self):
        """Test Wayland copy and paste."""
        pyperclip.set_clipboard('wl')
        pyperclip.copy("wl-clipboard test")
        result = pyperclip.paste()
        self.assertEqual(result, "wl-clipboard test")


@unittest.skipIf(not _executable_exists('qdbus'), "qdbus not available")
class TestKlipper(_TestClipboard):
    """Klipper clipboard tests."""

    def test_klipper_initialization(self):
        """Test Klipper initialization."""
        from pyperclip import init_klipper_clipboard
        cb = init_klipper_clipboard()
        self.assertIsNotNone(cb)


@unittest.skipIf(
    'DISPLAY' not in os.environ or not _executable_exists('python'),
    "Qt environment not available"
)
class TestQt(_TestClipboard):
    """Qt framework tests."""

    def test_qt_initialization(self):
        """Test Qt initialization."""
        from pyperclip import init_qt_clipboard
        cb = init_qt_clipboard()
        if cb is not None:
            self.assertIsNotNone(cb)


@unittest.skipIf(
    not os.path.exists('/proc/version') or
    not all(c in open('/proc/version', 'r').read().lower()
            for c in ['microsoft']),
    "WSL not available"
)
class TestWSL(_TestClipboard):
    """WSL tests."""

    def test_wsl_initialization(self):
        """Test WSL initialization."""
        from pyperclip import init_wsl_clipboard
        cb = init_wsl_clipboard()
        self.assertIsNotNone(cb)


@unittest.skipIf(
    not os.path.exists('/dev/clipboard'),
    "Cygwin not available"
)
class TestCygwin(_TestClipboard):
    """Cygwin tests."""

    def test_cygwin_initialization(self):
        """Test Cygwin initialization."""
        from pyperclip import init_dev_clipboard_clipboard
        cb = init_dev_clipboard_clipboard()
        self.assertIsNotNone(cb)


class TestNoClipboard(unittest.TestCase):
    """Fallback no clipboard tests."""

    def test_no_clipboard_initialization(self):
        """Test no clipboard initialization."""
        from pyperclip import init_no_clipboard
        copy_func, paste_func = init_no_clipboard()
        self.assertIsNotNone(copy_func)
        self.assertIsNotNone(paste_func)

    def test_no_clipboard_raises_on_copy(self):
        """Test no clipboard raises on copy."""
        from pyperclip import init_no_clipboard
        copy_func, _ = init_no_clipboard()
        with self.assertRaises(PyperclipException):
            copy_func("test")

    def test_no_clipboard_raises_on_paste(self):
        """Test no clipboard raises on paste."""
        from pyperclip import init_no_clipboard
        _, paste_func = init_no_clipboard()
        with self.assertRaises(PyperclipException):
            paste_func()


class TestAPIFunctions(unittest.TestCase):
    """Test API functions."""

    def test_determine_clipboard(self):
        """Test determine_clipboard function."""
        copy_func, paste_func = pyperclip.determine_clipboard()
        self.assertIsNotNone(copy_func)
        self.assertIsNotNone(paste_func)

    def test_is_available_after_lazy_load(self):
        """Test is_available returns True after lazy load."""
        pyperclip.copy("test")
        self.assertTrue(pyperclip.is_available())

    def test_is_available_before_lazy_load(self):
        """Test is_available before any operation."""
        from pyperclip import lazy_load_stub_copy
        if pyperclip.copy is lazy_load_stub_copy:
            self.assertFalse(pyperclip.is_available())


if __name__ == '__main__':
    unittest.main()
