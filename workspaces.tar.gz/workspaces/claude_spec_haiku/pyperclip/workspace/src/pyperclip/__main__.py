import sys
import argparse
from . import (
    copy,
    paste,
    PyperclipException,
    __version__,
)


def main():
    """Main entry point for the CLI."""
    parser = argparse.ArgumentParser(
        prog='pyperclip',
        description='A cross-platform clipboard utility'
    )
    parser.add_argument(
        '-c', '--copy',
        metavar='TEXT',
        nargs='?',
        const='',
        help='Copy text to clipboard'
    )
    parser.add_argument(
        '-p', '--paste',
        action='store_true',
        help='Paste text from clipboard'
    )
    parser.add_argument(
        '--version',
        action='version',
        version=f'%(prog)s {__version__}'
    )

    args = parser.parse_args()

    try:
        if args.paste:
            text = paste()
            sys.stdout.write(text)
            sys.exit(0)
        elif args.copy is not None:
            if args.copy == '':
                text = sys.stdin.read()
            else:
                text = args.copy
            copy(text)
            sys.exit(0)
        else:
            text = sys.stdin.read()
            copy(text)
            sys.exit(0)
    except PyperclipException as e:
        sys.stderr.write(f'Error: {e}\n')
        sys.exit(1)
    except Exception as e:
        sys.stderr.write(f'Error: {e}\n')
        sys.exit(1)


if __name__ == '__main__':
    main()
