import sys
import os
import platform
import subprocess
import struct
from pathlib import Path

__version__ = '1.8.2'

ENCODING = 'utf-8'
_IS_RUNNING_PYTHON_2 = sys.version_info[0] == 2


class PyperclipException(RuntimeError):
    """Base exception class for pyperclip errors."""
    pass


class PyperclipWindowsException(PyperclipException):
    """Windows-specific clipboard exceptions."""
    pass


class PyperclipTimeoutException(PyperclipException):
    """Timeout exception for clipboard operations."""
    pass


class CheckedCall:
    """Utility class for Windows API error checking."""
    def __init__(self, func):
        self.func = func

    def __call__(self, *args, **kwargs):
        result = self.func(*args, **kwargs)
        if not result:
            raise PyperclipWindowsException(
                'Windows clipboard API call failed. '
                'Your Windows version may not be supported. '
                'For more information, see https://github.com/asweigart/pyperclip'
            )
        return result


def _executable_exists(name):
    """Check if an executable exists in PATH."""
    if sys.platform == 'win32':
        name = name if name.endswith('.exe') else name + '.exe'

    from shutil import which
    return which(name) is not None


def lazy_load_stub_copy(text):
    """Lazy loading stub for copy function."""
    global copy, paste
    _copy_func, _paste_func = determine_clipboard()
    copy = _make_copy_wrapper(_copy_func)
    paste = _paste_func
    return copy(text)


def lazy_load_stub_paste():
    """Lazy loading stub for paste function."""
    global copy, paste
    _copy_func, _paste_func = determine_clipboard()
    copy = _make_copy_wrapper(_copy_func)
    paste = _paste_func
    return paste()


def _make_copy_wrapper(copy_func):
    """Create a copy wrapper that handles type conversion."""
    def copy_with_conversion(text):
        if isinstance(text, str):
            return copy_func(text)
        elif isinstance(text, (int, float)):
            return copy_func(str(text))
        elif isinstance(text, bool):
            return copy_func(str(text))
        else:
            raise PyperclipException(
                f'copy() does not support {type(text).__name__}. '
                f'Supported types: str, int, float, bool.'
            )
    return copy_with_conversion


def init_windows_clipboard():
    """Initialize Windows clipboard using ctypes."""
    import ctypes
    from ctypes import wintypes

    user32 = ctypes.windll.user32
    kernel32 = ctypes.windll.kernel32

    user32.OpenClipboard.argtypes = [wintypes.HWND]
    user32.OpenClipboard.restype = wintypes.BOOL
    user32.CloseClipboard.restype = wintypes.BOOL
    user32.GetClipboardData.argtypes = [wintypes.UINT]
    user32.GetClipboardData.restype = wintypes.HANDLE
    user32.SetClipboardData.argtypes = [wintypes.UINT, wintypes.HANDLE]
    user32.SetClipboardData.restype = wintypes.HANDLE
    user32.EmptyClipboard.restype = wintypes.BOOL

    kernel32.GlobalAlloc.argtypes = [wintypes.UINT, ctypes.c_size_t]
    kernel32.GlobalAlloc.restype = wintypes.HANDLE
    kernel32.GlobalLock.argtypes = [wintypes.HANDLE]
    kernel32.GlobalLock.restype = wintypes.c_void_p
    kernel32.GlobalUnlock.argtypes = [wintypes.HANDLE]
    kernel32.GlobalUnlock.restype = wintypes.BOOL
    kernel32.GlobalSize.argtypes = [wintypes.HANDLE]
    kernel32.GlobalSize.restype = ctypes.c_size_t

    CF_UNICODETEXT = 13
    GMEM_MOVEABLE = 0x0002

    def copy_windows(text):
        if not isinstance(text, str):
            text = str(text)

        text = text.encode('utf-16-le', 'surrogatepass')

        if not user32.OpenClipboard(None):
            raise PyperclipWindowsException('Could not open clipboard')

        try:
            if not user32.EmptyClipboard():
                raise PyperclipWindowsException('Could not empty clipboard')

            hCd = kernel32.GlobalAlloc(GMEM_MOVEABLE, len(text) + 2)
            if not hCd:
                raise PyperclipWindowsException('Could not allocate clipboard memory')

            lpCd = kernel32.GlobalLock(hCd)
            if not lpCd:
                raise PyperclipWindowsException('Could not lock clipboard memory')

            try:
                ctypes.memmove(lpCd, text, len(text))
                ctypes.memmove(ctypes.c_char_p(lpCd).value + len(text), b'\x00\x00', 2)
            finally:
                kernel32.GlobalUnlock(hCd)

            if not user32.SetClipboardData(CF_UNICODETEXT, hCd):
                raise PyperclipWindowsException('Could not set clipboard data')
        finally:
            user32.CloseClipboard()

    def paste_windows():
        if not user32.OpenClipboard(None):
            raise PyperclipWindowsException('Could not open clipboard')

        try:
            handle = user32.GetClipboardData(CF_UNICODETEXT)
            if not handle:
                return ''

            text = ctypes.c_wchar_p(handle).value
            if not text:
                return ''
            return text
        finally:
            user32.CloseClipboard()

    return copy_windows, paste_windows


def init_osx_pbcopy_clipboard():
    """Initialize macOS pbcopy/pbpaste clipboard."""
    def copy_osx_pbcopy(text):
        if not isinstance(text, str):
            text = str(text)

        p = subprocess.Popen(['pbcopy'], stdin=subprocess.PIPE)
        p.communicate(text.encode(ENCODING))
        if p.returncode != 0:
            raise PyperclipException('pbcopy command failed')

    def paste_osx_pbcopy():
        p = subprocess.Popen(['pbpaste'], stdout=subprocess.PIPE)
        stdout, _ = p.communicate()
        if p.returncode != 0:
            raise PyperclipException('pbpaste command failed')
        return stdout.decode(ENCODING)

    return copy_osx_pbcopy, paste_osx_pbcopy


def init_osx_pyobjc_clipboard():
    """Initialize macOS PyObjC clipboard."""
    try:
        from AppKit import NSPasteboard, NSPasteboardTypeString
        from Foundation import NSString
    except ImportError:
        return None

    def copy_osx_pyobjc(text):
        if not isinstance(text, str):
            text = str(text)

        pb = NSPasteboard.generalPasteboard()
        pb.clearContents()
        s = NSString.stringWithString_(text)
        pb.setString_forType_(s, NSPasteboardTypeString)

    def paste_osx_pyobjc():
        pb = NSPasteboard.generalPasteboard()
        s = pb.stringForType_(NSPasteboardTypeString)
        return s if s is not None else ''

    return copy_osx_pyobjc, paste_osx_pyobjc


def init_xclip_clipboard():
    """Initialize xclip clipboard."""
    if not _executable_exists('xclip'):
        return None

    def copy_xclip(text):
        if not isinstance(text, str):
            text = str(text)

        selection = 'CLIPBOARD'
        p = subprocess.Popen(['xclip', '-selection', selection], stdin=subprocess.PIPE)
        p.communicate(text.encode(ENCODING))
        if p.returncode != 0:
            raise PyperclipException('xclip command failed')

    def paste_xclip():
        selection = 'CLIPBOARD'
        p = subprocess.Popen(['xclip', '-selection', selection, '-o'], stdout=subprocess.PIPE)
        stdout, _ = p.communicate()
        if p.returncode != 0:
            raise PyperclipException('xclip command failed')
        return stdout.decode(ENCODING)

    return copy_xclip, paste_xclip


def init_xsel_clipboard():
    """Initialize xsel clipboard."""
    if not _executable_exists('xsel'):
        return None

    def copy_xsel(text):
        if not isinstance(text, str):
            text = str(text)

        selection = 'CLIPBOARD'
        p = subprocess.Popen(['xsel', '--' + selection.lower(), '-i'], stdin=subprocess.PIPE)
        p.communicate(text.encode(ENCODING))
        if p.returncode != 0:
            raise PyperclipException('xsel command failed')

    def paste_xsel():
        selection = 'CLIPBOARD'
        p = subprocess.Popen(['xsel', '--' + selection.lower(), '-o'], stdout=subprocess.PIPE)
        stdout, _ = p.communicate()
        if p.returncode != 0:
            raise PyperclipException('xsel command failed')
        return stdout.decode(ENCODING)

    return copy_xsel, paste_xsel


def init_wl_clipboard():
    """Initialize Wayland wl-clipboard."""
    if not _executable_exists('wl-copy'):
        return None

    def copy_wl(text):
        if not isinstance(text, str):
            text = str(text)

        p = subprocess.Popen(['wl-copy'], stdin=subprocess.PIPE)
        p.communicate(text.encode(ENCODING))
        if p.returncode != 0:
            raise PyperclipException('wl-copy command failed')

    def paste_wl():
        p = subprocess.Popen(['wl-paste'], stdout=subprocess.PIPE)
        stdout, _ = p.communicate()
        if p.returncode != 0:
            raise PyperclipException('wl-paste command failed')
        return stdout.decode(ENCODING)

    return copy_wl, paste_wl


def init_klipper_clipboard():
    """Initialize KDE Klipper clipboard."""
    if not _executable_exists('qdbus'):
        return None

    def copy_klipper(text):
        if not isinstance(text, str):
            text = str(text)

        p = subprocess.Popen(
            ['qdbus', 'org.kde.klipper', '/klipper', 'setClipboardContents', text],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        p.communicate()
        if p.returncode != 0:
            raise PyperclipException('klipper command failed')

    def paste_klipper():
        p = subprocess.Popen(
            ['qdbus', 'org.kde.klipper', '/klipper', 'getClipboardContents'],
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE
        )
        stdout, _ = p.communicate()
        if p.returncode != 0:
            raise PyperclipException('klipper command failed')
        return stdout.decode(ENCODING).rstrip('\n')

    return copy_klipper, paste_klipper


def init_qt_clipboard():
    """Initialize Qt framework clipboard."""
    try:
        from PyQt5.QtWidgets import QApplication
        from PyQt5.QtGui import QClipboard
    except ImportError:
        try:
            from qtpy.QtWidgets import QApplication
            from qtpy.QtGui import QClipboard
        except ImportError:
            return None

    if not os.environ.get('DISPLAY'):
        return None

    def copy_qt(text):
        if not isinstance(text, str):
            text = str(text)

        app = QApplication.instance()
        if app is None:
            app = QApplication([])
        clipboard = app.clipboard()
        clipboard.setText(text)

    def paste_qt():
        app = QApplication.instance()
        if app is None:
            app = QApplication([])
        clipboard = app.clipboard()
        return clipboard.text()

    return copy_qt, paste_qt


def init_dev_clipboard_clipboard():
    """Initialize /dev/clipboard (Cygwin)."""
    if not os.path.exists('/dev/clipboard'):
        return None

    def copy_dev_clipboard(text):
        if not isinstance(text, str):
            text = str(text)

        with open('/dev/clipboard', 'w') as f:
            f.write(text)

    def paste_dev_clipboard():
        with open('/dev/clipboard', 'r') as f:
            return f.read()

    return copy_dev_clipboard, paste_dev_clipboard


def init_wsl_clipboard():
    """Initialize WSL (Windows Subsystem for Linux) clipboard."""
    if not os.path.exists('/proc/version'):
        return None

    try:
        with open('/proc/version', 'r') as f:
            if 'microsoft' not in f.read().lower():
                return None
    except (OSError, IOError):
        return None

    def copy_wsl(text):
        if not isinstance(text, str):
            text = str(text)

        text_utf16 = text.encode('utf-16-le', 'surrogatepass')
        p = subprocess.Popen(['clip.exe'], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
        p.communicate(text_utf16)
        if p.returncode != 0:
            raise PyperclipException('WSL clipboard command failed')

    def paste_wsl():
        p = subprocess.Popen(['powershell.exe', '-NoProfile', '-Command',
                             '[System.Windows.Forms.SendKeys]::SendWait("^c"); '
                             '[System.Windows.Forms.Clipboard]::GetText()'],
                            stdout=subprocess.PIPE,
                            stderr=subprocess.PIPE)
        stdout, _ = p.communicate()
        if p.returncode != 0:
            raise PyperclipException('WSL clipboard command failed')
        return stdout.decode('utf-8', 'surrogatepass').rstrip('\r\n')

    return copy_wsl, paste_wsl


def init_no_clipboard():
    """Initialize fallback when no clipboard is available."""
    def copy_no_clipboard(text):
        raise PyperclipException(
            'Pyperclip could not find a copy/paste mechanism for your system. '
            'Please see https://github.com/asweigart/pyperclip/blob/master/README.md '
            'for how to set this up on your system.'
        )

    def paste_no_clipboard():
        raise PyperclipException(
            'Pyperclip could not find a copy/paste mechanism for your system. '
            'Please see https://github.com/asweigart/pyperclip/blob/master/README.md '
            'for how to set this up on your system.'
        )

    return copy_no_clipboard, paste_no_clipboard


def determine_clipboard():
    """Automatically determine the best clipboard mechanism for the current platform."""

    if sys.platform == 'win32':
        return init_windows_clipboard()

    if sys.platform == 'darwin':
        cb = init_osx_pyobjc_clipboard()
        if cb is not None:
            return cb
        return init_osx_pbcopy_clipboard()

    if sys.platform.startswith('linux'):
        if os.path.exists('/proc/version'):
            try:
                with open('/proc/version', 'r') as f:
                    if 'microsoft' in f.read().lower():
                        cb = init_wsl_clipboard()
                        if cb is not None:
                            return cb
            except (OSError, IOError):
                pass

        if os.path.exists('/dev/clipboard'):
            cb = init_dev_clipboard_clipboard()
            if cb is not None:
                return cb

        for init_func in [init_xclip_clipboard, init_xsel_clipboard, init_wl_clipboard, init_klipper_clipboard]:
            cb = init_func()
            if cb is not None:
                return cb

        cb = init_qt_clipboard()
        if cb is not None:
            return cb

    return init_no_clipboard()


def set_clipboard(name):
    """Manually set the clipboard mechanism."""
    global copy, paste

    backends = {
        'windows': init_windows_clipboard,
        'osx_pbcopy': init_osx_pbcopy_clipboard,
        'osx_pyobjc': init_osx_pyobjc_clipboard,
        'xclip': init_xclip_clipboard,
        'xsel': init_xsel_clipboard,
        'wl': init_wl_clipboard,
        'klipper': init_klipper_clipboard,
        'qt': init_qt_clipboard,
        'dev_clipboard': init_dev_clipboard_clipboard,
        'wsl': init_wsl_clipboard,
    }

    if name not in backends:
        raise PyperclipException(f'Unknown clipboard type: {name}')

    cb = backends[name]()
    if cb is None:
        raise PyperclipException(f'Clipboard {name} is not available on this system')

    copy_func, paste_func = cb
    copy = _make_copy_wrapper(copy_func)
    paste = paste_func


def is_available():
    """Check if clipboard is available."""
    return copy is not lazy_load_stub_copy and paste is not lazy_load_stub_paste


copy = lazy_load_stub_copy
paste = lazy_load_stub_paste


__all__ = [
    'copy',
    'paste',
    'set_clipboard',
    'determine_clipboard',
    'is_available',
    'PyperclipException',
    'PyperclipWindowsException',
    'PyperclipTimeoutException',
    'init_windows_clipboard',
    'init_osx_pbcopy_clipboard',
    'init_osx_pyobjc_clipboard',
    'init_xclip_clipboard',
    'init_xsel_clipboard',
    'init_wl_clipboard',
    'init_klipper_clipboard',
    'init_qt_clipboard',
    'init_dev_clipboard_clipboard',
    'init_wsl_clipboard',
    'init_no_clipboard',
    '_executable_exists',
    'ENCODING',
]
