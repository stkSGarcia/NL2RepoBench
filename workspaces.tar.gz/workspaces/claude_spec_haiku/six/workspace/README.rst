====
Six
====

Six is a Python 2 and 3 compatibility library. It provides simple utilities for
writing code that is compatible with both Python 2 and Python 3.

Features
========

- Type constants for unified type checking across Python versions
- ``six.moves`` for standard library imports that changed names between versions
- Iterator and dictionary compatibility functions
- Byte and string conversion utilities
- Function and method introspection helpers
- Syntax compatibility wrappers (exec, print, exceptions)
- Metaclass and decorator utilities
- IO compatibility (StringIO, BytesIO)
- unittest assertion helpers

Installation
============

Install from PyPI::

    pip install six

Or install from source::

    python setup.py install

Usage
=====

Version Detection
-----------------

Use six's version constants to check the Python version::

    import six

    if six.PY2:
        print("Running on Python 2")
    elif six.PY3:
        print("Running on Python 3")

Type Compatibility
-------------------

Use six's type constants instead of version-specific types::

    import six

    if isinstance(obj, six.string_types):
        print("obj is a string")

    if isinstance(number, six.integer_types):
        print("number is an integer")

Standard Library Moves
----------------------

Access renamed standard library modules using ``six.moves``::

    from six.moves import queue
    from six.moves import configparser
    from six.moves.urllib.parse import urlparse

Iterator Functions
-------------------

Use six's iterator functions for version-agnostic iteration::

    import six

    for key in six.iterkeys(my_dict):
        print(key)

    for value in six.itervalues(my_dict):
        print(value)

    for item in six.iteritems(my_dict):
        print(item)

String and Byte Conversion
---------------------------

Convert between strings and bytes safely::

    import six

    # Create byte literals
    data = six.b("hello")

    # Create text/unicode literals
    text = six.u("hello")

    # Ensure binary
    binary = six.ensure_binary("text")

    # Ensure text
    text = six.ensure_text(b"bytes")

Metaclass Definition
---------------------

Define classes with metaclasses that work in both Python versions::

    import six

    class Meta(type):
        pass

    @six.add_metaclass(Meta)
    class MyClass(object):
        pass

Compatibility Functions
------------------------

Use six's wrapper functions for syntax differences::

    import six

    # Execute code
    six.exec_("code = 'string'")

    # Print function
    six.print_("hello", file=sys.stderr)

    # Raise exception with traceback
    six.reraise(exc_type, exc_value, exc_tb)

Testing Utilities
------------------

Use six's unittest helpers for consistent assertions::

    import six
    import unittest

    class TestSomething(unittest.TestCase):
        def test_something(self):
            self.assertCountEqual([1, 2], [2, 1])

Documentation
=============

Full documentation is available at https://six.readthedocs.io/

License
=======

Six is licensed under the MIT License. See LICENSE file for details.
