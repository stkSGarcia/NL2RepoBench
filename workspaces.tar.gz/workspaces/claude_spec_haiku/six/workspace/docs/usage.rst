Usage Guide
===========

This guide covers the most common usage patterns for Six.

Version Detection
-----------------

Six provides constants to detect the Python version at runtime::

    import six

    if six.PY2:
        # Python 2 specific code
        pass
    elif six.PY3:
        # Python 3 specific code
        pass

    if six.PY34:
        # Python 3.4 or later
        pass

Type Compatibility
-------------------

Instead of checking for multiple types, use Six's type constants::

    import six

    # Check if something is a string
    if isinstance(text, six.string_types):
        # Works on both Python 2 (str, unicode) and Python 3 (str)
        pass

    # Check if something is an integer
    if isinstance(number, six.integer_types):
        # Works on both Python 2 (int, long) and Python 3 (int)
        pass

    # Get the text type
    text = six.text_type("hello")

    # Get the binary type
    data = six.binary_type(b"hello")

Standard Library Compatibility
-------------------------------

Six.moves provides a unified interface to standard library modules that were
renamed or reorganized between Python 2 and 3::

    from six.moves import queue
    from six.moves import configparser
    from six.moves.urllib.parse import urlparse
    from six.moves.urllib.request import urlopen
    from six.moves import socketserver

Iterator and Dictionary Functions
----------------------------------

Python 3 changed how dictionary iteration works. Six provides compatible
functions::

    import six

    my_dict = {'a': 1, 'b': 2}

    # Iterate over keys
    for key in six.iterkeys(my_dict):
        print(key)

    # Iterate over values
    for value in six.itervalues(my_dict):
        print(value)

    # Iterate over items
    for key, value in six.iteritems(my_dict):
        print(key, value)

    # Get views
    keys_view = six.viewkeys(my_dict)
    values_view = six.viewvalues(my_dict)
    items_view = six.viewitems(my_dict)

Byte and String Handling
-------------------------

Six provides utilities for safe byte and string conversion::

    import six

    # Create byte literals
    data = six.b("hello")

    # Create unicode/text literals
    text = six.u("hello")

    # Convert with encoding
    binary = six.ensure_binary("text", encoding='utf-8')
    text = six.ensure_text(b"bytes", encoding='utf-8')

    # Character code conversion
    char = six.unichr(65)  # Returns 'A'
    code = ord(char)       # Returns 65

    # Byte conversion
    byte = six.int2byte(65)  # Returns b'A'
    num = six.byte2int(b'A')  # Returns 65

Function Introspection
-----------------------

Access function and method attributes in a version-agnostic way::

    import six

    def my_function(a, b=10):
        """Function docstring"""
        pass

    code = six.get_function_code(my_function)
    defaults = six.get_function_defaults(my_function)
    globals_dict = six.get_function_globals(my_function)
    closure = six.get_function_closure(my_function)

Syntax Compatibility
--------------------

Six provides wrapper functions for Python syntax differences::

    import six
    import sys

    # Execute code dynamically
    code_str = "x = 42; y = x + 8"
    six.exec_(code_str)

    # Print with Python 3 function syntax
    six.print_("Hello", "world", sep=", ", file=sys.stderr)

    # Re-raise exceptions with traceback
    try:
        something()
    except Exception:
        exc_info = sys.exc_info()
        six.reraise(exc_info[0], exc_info[1], exc_info[2])

    # Raise with cause (Python 3)
    try:
        do_something()
    except OldError as e:
        six.raise_from(NewError("new error"), e)

Metaclass Definition
--------------------

Define classes with metaclasses that work in both Python 2 and 3::

    import six

    class Meta(type):
        def __new__(cls, name, bases, dct):
            return super(Meta, cls).__new__(cls, name, bases, dct)

    # Using with_metaclass
    class MyClass(six.with_metaclass(Meta, object)):
        pass

    # Using add_metaclass decorator (cleaner)
    @six.add_metaclass(Meta)
    class MyClass(object):
        pass

Unicode Compatibility
---------------------

Six provides the python_2_unicode_compatible decorator for __str__ methods::

    import six

    @six.python_2_unicode_compatible
    class MyClass(object):
        def __str__(self):
            return u"My object"

    obj = MyClass()
    print(str(obj))  # Works on both Python 2 and 3

IO Compatibility
----------------

Access StringIO and BytesIO through a unified interface::

    import six

    # Text IO
    text_stream = six.StringIO()
    text_stream.write(u"hello")
    result = text_stream.getvalue()

    # Binary IO
    binary_stream = six.BytesIO()
    binary_stream.write(b"hello")
    result = binary_stream.getvalue()

unittest Compatibility
----------------------

Six provides compatible unittest assertion methods::

    import six
    import unittest

    class TestSomething(unittest.TestCase):
        def test_count_equal(self):
            # Check that lists have same elements (regardless of order)
            six.assertCountEqual(self, [1, 2, 3], [3, 1, 2])

        def test_regex_match(self):
            six.assertRegex(self, "hello world", r"wo\w+")
            six.assertNotRegex(self, "hello world", "xyz")

        def test_raises_regex(self):
            with six.assertRaisesRegex(self, ValueError, "invalid"):
                raise ValueError("invalid value")

Wrapping Functions
-------------------

Use the wraps decorator to preserve function metadata::

    import six

    def original(x):
        """Original function"""
        return x * 2

    @six.wraps(original)
    def wrapper(x):
        return original(x)

    print(wrapper.__name__)   # Prints 'original'
    print(wrapper.__doc__)    # Prints 'Original function'

Best Practices
--------------

1. Use Six's type constants instead of hardcoding types
2. Use six.moves for standard library imports that differ between versions
3. Use iterkeys/itervalues/iteritems instead of directly calling dict methods
4. Use ensure_* functions for any string/byte conversions
5. Use add_metaclass decorator for cleaner metaclass syntax
6. Use Six's wrapper functions instead of version-specific syntax
