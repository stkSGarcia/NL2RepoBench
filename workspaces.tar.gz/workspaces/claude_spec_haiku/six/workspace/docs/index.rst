====
Six
====

Six is a Python 2 and 3 compatibility library.

Contents
========

.. toctree::
   :maxdepth: 2

   usage
   api

Introduction
============

Six provides a simple collection of utilities for writing code that is compatible
with both Python 2 and Python 3. It is used in several popular open source projects
including Pylint and Setuptools.

Installation
============

Six is available on PyPI. Install it with::

    pip install six

Features
========

- **Version Detection**: PY2, PY3, PY34 constants for version checks
- **Type Constants**: string_types, integer_types, text_type, binary_type, etc.
- **six.moves**: Standard library imports that changed names
- **Iterator Functions**: iterkeys, itervalues, iteritems, viewkeys, viewvalues, viewitems
- **Byte/String Conversion**: b(), u(), ensure_binary(), ensure_text(), etc.
- **Function Introspection**: get_function_code(), get_method_self(), etc.
- **Syntax Compatibility**: exec_(), print_(), reraise(), raise_from()
- **Metaclass Utilities**: with_metaclass(), add_metaclass()
- **IO Compatibility**: StringIO, BytesIO
- **unittest Helpers**: assertCountEqual, assertRaisesRegex, etc.

Quick Start
===========

Check Python Version
--------------------

::

    import six

    if six.PY3:
        print("Running on Python 3")

Use Type Constants
------------------

::

    import six

    if isinstance(obj, six.string_types):
        print("obj is a string")

Access Renamed Modules
----------------------

::

    from six.moves import configparser
    from six.moves.urllib.parse import urlparse

Convert Strings and Bytes
--------------------------

::

    import six

    binary_data = six.b("hello")
    text_data = six.u("hello")
    safe_text = six.ensure_text(b"bytes")

Define Metaclasses
-------------------

::

    import six

    @six.add_metaclass(Meta)
    class MyClass(object):
        pass

Index and Search
================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
