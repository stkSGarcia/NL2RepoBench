"""Sphinx configuration for Six documentation"""

project = 'Six'
copyright = '2010-2020, Benjamin Peterson'
author = 'Benjamin Peterson'
release = '1.16.0'

extensions = [
    'sphinx.ext.autodoc',
    'sphinx.ext.doctest',
    'sphinx.ext.intersphinx',
    'sphinx.ext.viewcode',
]

templates_path = ['_templates']
exclude_patterns = ['_build']

html_theme = 'default'
html_static_path = []

autodoc_mock_imports = []

intersphinx_mapping = {
    'python': ('https://docs.python.org/3', None),
}
