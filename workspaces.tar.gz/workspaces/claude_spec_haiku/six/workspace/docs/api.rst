API Reference
=============

Version Constants
-----------------

.. py:data:: PY2

    True if running on Python 2.x, False otherwise.

.. py:data:: PY3

    True if running on Python 3.x, False otherwise.

.. py:data:: PY34

    True if running on Python 3.4 or later, False otherwise.

Type Constants
--------------

.. py:data:: string_types

    A tuple of string types: (basestring,) on Python 2, (str,) on Python 3.

.. py:data:: integer_types

    A tuple of integer types: (int, long) on Python 2, (int,) on Python 3.

.. py:data:: class_types

    A tuple of class types: (type, types.ClassType) on Python 2, (type,) on Python 3.

.. py:data:: text_type

    The text string type: unicode on Python 2, str on Python 3.

.. py:data:: binary_type

    The binary string type: str on Python 2, bytes on Python 3.

.. py:data:: MAXSIZE

    The maximum value a container can hold, from sys.maxsize.

six.moves
---------

.. py:data:: moves

    A module containing renamed standard library modules.

Common six.moves attributes:

- queue (Queue in Python 2, queue in Python 3)
- configparser (ConfigParser in Python 2, configparser in Python 3)
- urllib_parse (urlparse in Python 2, urllib.parse in Python 3)
- urllib_error (urllib2 in Python 2, urllib.error in Python 3)
- urllib_request (urllib2 in Python 2, urllib.request in Python 3)
- socketserver (SocketServer in Python 2, socketserver in Python 3)
- http_client (httplib in Python 2, http.client in Python 3)
- http_server (SimpleHTTPServer in Python 2, http.server in Python 3)
- http_cookiejar (cookielib in Python 2, http.cookiejar in Python 3)
- xmlrpc_client (xmlrpclib in Python 2, xmlrpc.client in Python 3)
- xmlrpc_server (SimpleXMLRPCServer in Python 2, xmlrpc.server in Python 3)

Iterator Functions
-------------------

.. py:function:: next(iterator)

    Call the next method on an iterator. Returns the next item.

.. py:class:: Iterator

    Base class for compatible iterators. Subclasses should define __next__.

.. py:function:: iterkeys(dictionary)

    Return an iterator over dictionary keys.

.. py:function:: itervalues(dictionary)

    Return an iterator over dictionary values.

.. py:function:: iteritems(dictionary)

    Return an iterator over (key, value) pairs.

.. py:function:: viewkeys(dictionary)

    Return a view object of dictionary keys.

.. py:function:: viewvalues(dictionary)

    Return a view object of dictionary values.

.. py:function:: viewitems(dictionary)

    Return a view object of (key, value) pairs.

Byte and String Functions
--------------------------

.. py:function:: b(string_literal)

    Create a byte string literal, encoding using 'latin-1' if necessary.

.. py:function:: u(string_literal)

    Create a unicode/text literal, decoding if necessary.

.. py:data:: unichr

    The character type: unichr on Python 2, chr on Python 3.

.. py:function:: int2byte(integer)

    Convert an integer to a single byte.

.. py:function:: byte2int(byte)

    Convert a single byte to an integer.

.. py:function:: ensure_binary(string, encoding='utf-8', errors='strict')

    Ensure a string is binary encoded (bytes).

.. py:function:: ensure_str(string, encoding='utf-8', errors='strict')

    Ensure a string is the native str type.

.. py:function:: ensure_text(string, encoding='utf-8', errors='strict')

    Ensure a string is text/unicode.

Function Introspection
----------------------

.. py:function:: get_function_code(function)

    Get the code object of a function.

.. py:function:: get_function_defaults(function)

    Get the default arguments of a function.

.. py:function:: get_function_globals(function)

    Get the globals dictionary of a function.

.. py:function:: get_function_closure(function)

    Get the closure of a function.

.. py:function:: get_unbound_function(method)

    Get an unbound function from a method.

.. py:function:: get_method_function(method)

    Get the function object from a bound method.

.. py:function:: get_method_self(method)

    Get the instance (self) from a bound method.

Syntax Compatibility
--------------------

.. py:function:: exec_(code, globals=None, locals=None)

    Execute code with Python 3 compatible syntax.

.. py:function:: print_(*args, file=None, sep=' ', end='\\n')

    Print function with Python 3 compatible syntax.

.. py:function:: raise_from(exception, cause)

    Raise an exception with a cause (exception chaining).

.. py:function:: reraise(type, value, traceback=None)

    Re-raise an exception with traceback information.

Metaclass and Decorator Utilities
----------------------------------

.. py:function:: with_metaclass(meta, *bases)

    Create a base class with a metaclass that works in both Python 2 and 3.

.. py:function:: add_metaclass(metaclass)

    Class decorator to add a metaclass to a class definition.

.. py:function:: python_2_unicode_compatible

    Class decorator for __str__ and __unicode__ compatibility.

IO Compatibility
----------------

.. py:class:: StringIO

    Text IO stream. StringIO.StringIO on Python 2, io.StringIO on Python 3.

.. py:class:: BytesIO

    Binary IO stream. io.BytesIO on both Python 2 and 3.

unittest Compatibility
----------------------

.. py:function:: assertCountEqual(test_case, first, second, msg=None)

    Assert that two sequences have the same elements (regardless of order).

.. py:function:: assertRaisesRegex(test_case, exception, regex, *args, **kwargs)

    Assert that an exception is raised and matches a regex pattern.

.. py:function:: assertRegex(test_case, text, regex, msg=None)

    Assert that text matches a regex pattern.

.. py:function:: assertNotRegex(test_case, text, regex, msg=None)

    Assert that text does not match a regex pattern.

Decorator Utilities
--------------------

.. py:function:: wraps(wrapped, assigned=WRAPPER_ASSIGNMENTS, updated=WRAPPER_UPDATES)

    Decorator to copy metadata from a wrapped function to a wrapper function.
