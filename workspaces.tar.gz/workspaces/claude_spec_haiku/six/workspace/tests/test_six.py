"""Tests for six module"""

import sys
import unittest
import six


class TestVersionDetection(unittest.TestCase):
    """Test version detection constants"""

    def test_py_version_constants(self):
        """Test PY2 and PY3 constants"""
        self.assertTrue(six.PY2 or six.PY3)
        self.assertFalse(six.PY2 and six.PY3)

    def test_py34_constant(self):
        """Test PY34 constant"""
        if sys.version_info[:2] >= (3, 4):
            self.assertTrue(six.PY34)
        else:
            self.assertFalse(six.PY34)


class TestTypeCompatibilityConstants(unittest.TestCase):
    """Test type compatibility constants"""

    def test_string_types(self):
        """Test string_types constant"""
        self.assertIsInstance("", six.string_types)
        self.assertIsInstance(u"", six.string_types)

    def test_integer_types(self):
        """Test integer_types constant"""
        self.assertIsInstance(1, six.integer_types)
        self.assertIsInstance(1 << 64, six.integer_types)

    def test_text_type(self):
        """Test text_type constant"""
        self.assertEqual(six.text_type, str if six.PY3 else unicode)

    def test_binary_type(self):
        """Test binary_type constant"""
        self.assertEqual(six.binary_type, bytes if six.PY3 else str)

    def test_maxsize(self):
        """Test MAXSIZE constant"""
        self.assertEqual(six.MAXSIZE, sys.maxsize)


class TestMovesImports(unittest.TestCase):
    """Test six.moves imports"""

    def test_moves_import(self):
        """Test importing six.moves"""
        self.assertTrue(hasattr(six, 'moves'))

    def test_configparser_import(self):
        """Test configparser import"""
        configparser = six.moves.configparser
        self.assertTrue(hasattr(configparser, 'ConfigParser'))

    def test_queue_import(self):
        """Test queue import"""
        queue = six.moves.queue
        self.assertTrue(hasattr(queue, 'Queue'))

    def test_urllib_import(self):
        """Test urllib imports"""
        urllib = six.moves.urllib
        self.assertTrue(hasattr(urllib, 'parse'))
        self.assertTrue(hasattr(urllib, 'error'))
        self.assertTrue(hasattr(urllib, 'request'))


class TestIteratorCompatibility(unittest.TestCase):
    """Test iterator compatibility functions"""

    def test_next_function(self):
        """Test next() function"""
        iterator = iter([1, 2, 3])
        self.assertEqual(six.next(iterator), 1)
        self.assertEqual(six.next(iterator), 2)

    def test_iterator_base_class(self):
        """Test Iterator base class"""
        class MyIterator(six.Iterator):
            def __init__(self):
                self.count = 0

            def __next__(self):
                if self.count < 3:
                    self.count += 1
                    return self.count
                raise StopIteration

        iterator = MyIterator()
        self.assertEqual(six.next(iterator), 1)
        self.assertEqual(six.next(iterator), 2)
        self.assertEqual(six.next(iterator), 3)

    def test_iterkeys(self):
        """Test iterkeys()"""
        d = {'a': 1, 'b': 2}
        keys = list(six.iterkeys(d))
        self.assertEqual(sorted(keys), ['a', 'b'])

    def test_itervalues(self):
        """Test itervalues()"""
        d = {'a': 1, 'b': 2}
        values = list(six.itervalues(d))
        self.assertEqual(sorted(values), [1, 2])

    def test_iteritems(self):
        """Test iteritems()"""
        d = {'a': 1, 'b': 2}
        items = list(six.iteritems(d))
        self.assertEqual(sorted(items), [('a', 1), ('b', 2)])

    def test_viewkeys(self):
        """Test viewkeys()"""
        d = {'a': 1, 'b': 2}
        keys = six.viewkeys(d)
        self.assertEqual(set(keys), {'a', 'b'})

    def test_viewvalues(self):
        """Test viewvalues()"""
        d = {'a': 1, 'b': 2}
        values = six.viewvalues(d)
        self.assertEqual(set(values), {1, 2})

    def test_viewitems(self):
        """Test viewitems()"""
        d = {'a': 1, 'b': 2}
        items = six.viewitems(d)
        self.assertEqual(set(items), {('a', 1), ('b', 2)})


class TestByteStringConversion(unittest.TestCase):
    """Test byte and string conversion functions"""

    def test_b_function(self):
        """Test b() function"""
        result = six.b("hello")
        self.assertIsInstance(result, six.binary_type)
        self.assertEqual(result, b"hello")

    def test_u_function(self):
        """Test u() function"""
        result = six.u("hello")
        self.assertIsInstance(result, six.text_type)
        self.assertEqual(result, u"hello")

    def test_unichr(self):
        """Test unichr() function"""
        result = six.unichr(65)
        self.assertEqual(result, "A")

    def test_int2byte(self):
        """Test int2byte() function"""
        result = six.int2byte(65)
        self.assertIsInstance(result, six.binary_type)

    def test_byte2int(self):
        """Test byte2int() function"""
        result = six.byte2int(b"A")
        self.assertEqual(result, 65)

    def test_ensure_binary(self):
        """Test ensure_binary()"""
        self.assertEqual(six.ensure_binary("hello"), b"hello")
        self.assertEqual(six.ensure_binary(b"hello"), b"hello")

    def test_ensure_str(self):
        """Test ensure_str()"""
        result = six.ensure_str("hello")
        self.assertIsInstance(result, str)

    def test_ensure_text(self):
        """Test ensure_text()"""
        self.assertEqual(six.ensure_text(b"hello"), "hello")
        self.assertEqual(six.ensure_text("hello"), "hello")


class TestFunctionIntrospection(unittest.TestCase):
    """Test function and method introspection"""

    def test_get_function_code(self):
        """Test get_function_code()"""
        def func():
            pass
        code = six.get_function_code(func)
        self.assertTrue(hasattr(code, 'co_code'))

    def test_get_function_defaults(self):
        """Test get_function_defaults()"""
        def func(a, b=10):
            pass
        defaults = six.get_function_defaults(func)
        self.assertEqual(defaults, (10,))

    def test_get_function_globals(self):
        """Test get_function_globals()"""
        def func():
            pass
        g = six.get_function_globals(func)
        self.assertIsInstance(g, dict)

    def test_get_function_closure(self):
        """Test get_function_closure()"""
        def outer():
            x = 10
            def inner():
                return x
            return inner
        func = outer()
        closure = six.get_function_closure(func)
        self.assertTrue(closure is None or isinstance(closure, tuple))

    def test_get_unbound_function(self):
        """Test get_unbound_function()"""
        def func():
            pass
        result = six.get_unbound_function(func)
        self.assertEqual(result, func)


class TestSyntaxCompatibility(unittest.TestCase):
    """Test syntax compatibility functions"""

    def test_exec_(self):
        """Test exec_() function"""
        d = {}
        six.exec_("x = 42", d)
        self.assertEqual(d['x'], 42)

    def test_print_(self):
        """Test print_() function"""
        import io
        stream = io.StringIO() if six.PY3 else io.BytesIO()
        try:
            six.print_("hello", file=stream)
        except Exception:
            pass

    def test_reraise(self):
        """Test reraise() function"""
        try:
            try:
                raise ValueError("test")
            except ValueError:
                exc_info = sys.exc_info()
                six.reraise(exc_info[0], exc_info[1], exc_info[2])
        except ValueError as e:
            self.assertEqual(str(e), "test")


class TestMetaclassUtilities(unittest.TestCase):
    """Test metaclass and decorator utilities"""

    def test_with_metaclass(self):
        """Test with_metaclass()"""
        class Meta(type):
            pass

        class Base(six.with_metaclass(Meta, object)):
            pass

        self.assertEqual(type(Base), Meta)

    def test_add_metaclass(self):
        """Test add_metaclass() decorator"""
        class Meta(type):
            pass

        @six.add_metaclass(Meta)
        class MyClass(object):
            pass

        self.assertEqual(type(MyClass), Meta)

    def test_python_2_unicode_compatible(self):
        """Test python_2_unicode_compatible() decorator"""
        @six.python_2_unicode_compatible
        class MyClass(object):
            def __str__(self):
                return "test"

        obj = MyClass()
        result = str(obj)
        self.assertEqual(result, "test")


class TestIOCompatibility(unittest.TestCase):
    """Test IO compatibility"""

    def test_stringio(self):
        """Test StringIO"""
        stream = six.StringIO()
        stream.write(u"hello")
        self.assertEqual(stream.getvalue(), u"hello")

    def test_bytesio(self):
        """Test BytesIO"""
        stream = six.BytesIO()
        stream.write(b"hello")
        self.assertEqual(stream.getvalue(), b"hello")


class TestUnittestAssertions(unittest.TestCase):
    """Test unittest assertion helpers"""

    def test_assertCountEqual(self):
        """Test assertCountEqual()"""
        six.assertCountEqual(self, [1, 2, 3], [3, 2, 1])

    def test_assertRaisesRegex(self):
        """Test assertRaisesRegex()"""
        with six.assertRaisesRegex(self, ValueError, "test"):
            raise ValueError("test error")

    def test_assertRegex(self):
        """Test assertRegex()"""
        six.assertRegex(self, "hello world", "world")

    def test_assertNotRegex(self):
        """Test assertNotRegex()"""
        six.assertNotRegex(self, "hello world", "goodbye")


class TestWrapsDecorator(unittest.TestCase):
    """Test wraps decorator"""

    def test_wraps(self):
        """Test wraps() decorator"""
        def original(x):
            """Original function"""
            return x * 2

        @six.wraps(original)
        def wrapper(x):
            return original(x)

        self.assertEqual(wrapper.__name__, original.__name__)
        self.assertEqual(wrapper.__doc__, original.__doc__)


if __name__ == '__main__':
    unittest.main()
