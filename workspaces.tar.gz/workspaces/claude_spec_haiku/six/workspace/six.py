# Six is a Python 2 and 3 compatibility library.
"""
Six is a Python 2 and 3 compatibility library
"""

import sys
import functools

__version__ = "1.16.0"

# ============================================================================
# Utility functions
# ============================================================================

def _add_doc(obj, doc):
    """Add __doc__ to obj"""
    obj.__doc__ = doc
    return obj

def _import_module(name):
    """Import a module by name"""
    __import__(name)
    return sys.modules[name]

# ============================================================================
# Python version detection
# ============================================================================

PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3
PY34 = sys.version_info[:2] >= (3, 4)

# ============================================================================
# Type compatibility constants
# ============================================================================

if PY3:
    string_types = (str,)
    integer_types = (int,)
    class_types = (type,)
    text_type = str
    binary_type = bytes
else:
    string_types = (basestring,)
    integer_types = (int, long)
    class_types = (type, types.ClassType)
    text_type = unicode
    binary_type = str

import sys
MAXSIZE = sys.maxsize

# ============================================================================
# Lazy loading infrastructure
# ============================================================================

class _LazyDescr:
    """Base class for lazy attribute descriptors"""
    def __init__(self, name):
        self.name = name

    def __get__(self, obj, objtype=None):
        if obj is None:
            return self
        result = self._resolve()
        setattr(obj, self.name, result)
        return result

    def _resolve(self):
        raise NotImplementedError

class _LazyModule(object):
    """Base class for lazy module loading"""
    def __init__(self, name):
        self.__name__ = name

    def __dir__(self):
        attrs = ["__name__", "__doc__"]
        attrs += [attr for attr in self._moved_attributes]
        return attrs

    def __getattr__(self, attr):
        for moved_attr in self._moved_attributes:
            if moved_attr.name == attr:
                return moved_attr._resolve()
        raise AttributeError("module {0!r} has no attribute {1!r}".format(
            self.__name__, attr))

# ============================================================================
# Module and Attribute Movement Classes
# ============================================================================

class MovedModule:
    """Represent a module that moved between Python 2 and 3"""
    def __init__(self, name, old, new):
        self.name = name
        self.old = old
        self.new = new

    def _resolve(self):
        return _import_module(self.new if PY3 else self.old)

    def __getattr__(self, attr):
        # For accessing submodules like six.moves.urllib.parse
        return getattr(self._resolve(), attr)

class MovedAttribute:
    """Represent an attribute that moved between Python 2 and 3"""
    def __init__(self, name, old_mod, new_mod, old_attr=None, new_attr=None):
        self.name = name
        self.old_mod = old_mod
        self.new_mod = new_mod
        self.old_attr = old_attr or name
        self.new_attr = new_attr or name

    def _resolve(self):
        old = _import_module(self.old_mod)
        new = _import_module(self.new_mod)
        return getattr(new, self.new_attr) if PY3 else getattr(old, self.old_attr)

    def __getattr__(self, attr):
        return getattr(self._resolve(), attr)

# ============================================================================
# Meta Path Importer for six.moves
# ============================================================================

class _SixMetaPathImporter:
    """Custom meta path importer for six.moves"""
    def __init__(self):
        self._modules = {}

    def _add_module(self, mod, *names):
        for name in names:
            self._modules['six.moves.' + name] = mod

    def _get_module(self, name):
        return self._modules.get(name)

    def find_module(self, fullname, path=None):
        if fullname in self._modules:
            return self
        return None

    def find_spec(self, fullname, path, target=None):
        if fullname in self._modules:
            from importlib.machinery import ModuleSpec
            return ModuleSpec(fullname, self)
        return None

    def load_module(self, fullname):
        try:
            return sys.modules[fullname]
        except KeyError:
            pass

        mod = self._modules[fullname]
        if isinstance(mod, MovedModule):
            mod = mod._resolve()
        else:
            mod.__loader__ = self
        sys.modules[fullname] = mod
        return mod

    def is_package(self, fullname):
        return hasattr(self._get_module(fullname), '__path__')

    def get_code(self, fullname):
        return None

    def get_source(self, fullname):
        return None

_importer = _SixMetaPathImporter()
sys.meta_path.append(_importer)

# ============================================================================
# six.moves setup
# ============================================================================

class _MovedItems(object):
    pass

_moved_attributes = [
    MovedAttribute("configparser", "ConfigParser", "configparser"),
    MovedAttribute("copyreg", "copy_reg", "copyreg"),
    MovedAttribute("email_mime_multipart", "email.MIMEMultipart", "email.mime.multipart"),
    MovedAttribute("email_mime_text", "email.MIMEText", "email.mime.text"),
    MovedAttribute("email_mime_base", "email.MIMEBase", "email.mime.base"),
    MovedAttribute("http_cookiejar", "cookielib", "http.cookiejar"),
    MovedAttribute("http_cookies", "Cookie", "http.cookies"),
    MovedAttribute("html_entities", "htmlentitydefs", "html.entities"),
    MovedAttribute("html_parser", "HTMLParser", "html.parser"),
    MovedAttribute("http_client", "httplib", "http.client"),
    MovedAttribute("email_mime_multipart", "email.MIMEMultipart", "email.mime.multipart"),
    MovedAttribute("tkinter", "Tkinter", "tkinter"),
    MovedAttribute("tkinter_dialog", "Dialog", "tkinter.dialog"),
    MovedAttribute("tkinter_filedialog", "FileDialog", "tkinter.filedialog"),
    MovedAttribute("tkinter_scrolledtext", "ScrolledText", "tkinter.scrolledtext"),
    MovedAttribute("tkinter_simpledialog", "SimpleDialog", "tkinter.simpledialog"),
    MovedAttribute("tkinter_tksimpledialog", "tkSimpleDialog", "tkinter.simpledialog"),
    MovedAttribute("tkinter_tkconstants", "Tkconstants", "tkinter.constants"),
    MovedAttribute("tkinter_dnd", "tkDnd", "tkinter.dnd"),
    MovedAttribute("tkinter_colorchooser", "tkColorChooser", "tkinter.colorchooser"),
    MovedAttribute("tkinter_commondialog", "tkCommonDialog", "tkinter.commondialog"),
    MovedAttribute("tkinter_tkfiledialog", "tkFileDialog", "tkinter.tkfiledialog"),
    MovedAttribute("tkinter_font", "tkFont", "tkinter.font"),
    MovedAttribute("tkinter_messagebox", "tkMessageBox", "tkinter.messagebox"),
    MovedAttribute("tkinter_tksimpledialog", "tkSimpleDialog", "tkinter.simpledialog"),
    MovedAttribute("urllib_parse", "urlparse", "urllib.parse"),
    MovedAttribute("urllib_error", "urllib2", "urllib.error"),
    MovedAttribute("urllib", "urllib", "urllib.request"),
    MovedAttribute("urllib_robotparser", "robotparser", "urllib.robotparser"),
    MovedAttribute("xmlrpc_client", "xmlrpclib", "xmlrpc.client"),
    MovedAttribute("xmlrpc_server", "SimpleXMLRPCServer", "xmlrpc.server"),
    MovedAttribute("queue", "Queue", "queue"),
    MovedAttribute("socketserver", "SocketServer", "socketserver"),
    MovedAttribute("_thread", "thread", "_thread"),
    MovedAttribute("_dummy_thread", "dummy_thread", "_dummy_thread"),
    MovedAttribute("http_server", "SimpleHTTPServer", "http.server"),
    MovedAttribute("dbm_gnu", "gdbm", "dbm.gnu"),
    MovedAttribute("tkinter_tix", "Tix", "tkinter.tix"),
]

for attr in _moved_attributes:
    setattr(_MovedItems, attr.name, attr)
    _importer._add_module(attr, attr.name)

moves = _MovedItems()

# Register moves in sys.modules
sys.modules['six.moves'] = moves

# ============================================================================
# urllib compatibility submodules
# ============================================================================

class Module_six_moves_urllib_parse(object):
    """urllib.parse compatibility"""
    pass

_urllib_parse_moved_attributes = [
    MovedAttribute("ParseResult", "urlparse", "urllib.parse"),
    MovedAttribute("parse_qs", "urlparse", "urllib.parse"),
    MovedAttribute("parse_qsl", "urlparse", "urllib.parse"),
    MovedAttribute("urldefrag", "urlparse", "urllib.parse"),
    MovedAttribute("urljoin", "urlparse", "urllib.parse"),
    MovedAttribute("urlparse", "urlparse", "urllib.parse"),
    MovedAttribute("urlsplit", "urlparse", "urllib.parse"),
    MovedAttribute("urlunparse", "urlparse", "urllib.parse"),
    MovedAttribute("urlunsplit", "urlparse", "urllib.parse"),
    MovedAttribute("quote", "urllib", "urllib.parse"),
    MovedAttribute("quote_plus", "urllib", "urllib.parse"),
    MovedAttribute("unquote", "urllib", "urllib.parse"),
    MovedAttribute("unquote_plus", "urllib", "urllib.parse"),
    MovedAttribute("urlencode", "urllib", "urllib.parse"),
]

for attr in _urllib_parse_moved_attributes:
    setattr(Module_six_moves_urllib_parse, attr.name, attr)

urllib_parse = Module_six_moves_urllib_parse()
sys.modules['six.moves.urllib_parse'] = urllib_parse
sys.modules['six.moves.urllib.parse'] = urllib_parse

class Module_six_moves_urllib_error(object):
    """urllib.error compatibility"""
    pass

_urllib_error_moved_attributes = [
    MovedAttribute("URLError", "urllib2", "urllib.error"),
    MovedAttribute("HTTPError", "urllib2", "urllib.error"),
]

for attr in _urllib_error_moved_attributes:
    setattr(Module_six_moves_urllib_error, attr.name, attr)

urllib_error = Module_six_moves_urllib_error()
sys.modules['six.moves.urllib_error'] = urllib_error
sys.modules['six.moves.urllib.error'] = urllib_error

class Module_six_moves_urllib_request(object):
    """urllib.request compatibility"""
    pass

_urllib_request_moved_attributes = [
    MovedAttribute("urlopen", "urllib2", "urllib.request"),
    MovedAttribute("install_opener", "urllib2", "urllib.request"),
    MovedAttribute("build_opener", "urllib2", "urllib.request"),
    MovedAttribute("pathname2url", "urllib", "urllib.request"),
    MovedAttribute("url2pathname", "urllib", "urllib.request"),
    MovedAttribute("getproxies", "urllib", "urllib.request"),
    MovedAttribute("Request", "urllib2", "urllib.request"),
    MovedAttribute("OpenerDirector", "urllib2", "urllib.request"),
    MovedAttribute("HTTPDefaultErrorHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPRedirectHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPCookieProcessor", "urllib2", "urllib.request"),
    MovedAttribute("ProxyHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPPasswordMgr", "urllib2", "urllib.request"),
    MovedAttribute("HTTPPasswordMgrWithDefaultRealm", "urllib2", "urllib.request"),
    MovedAttribute("AbstractBasicAuthHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPBasicAuthHandler", "urllib2", "urllib.request"),
    MovedAttribute("ProxyBasicAuthHandler", "urllib2", "urllib.request"),
    MovedAttribute("AbstractDigestAuthHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPDigestAuthHandler", "urllib2", "urllib.request"),
    MovedAttribute("ProxyDigestAuthHandler", "urllib2", "urllib.request"),
    MovedAttribute("FileHandler", "urllib2", "urllib.request"),
    MovedAttribute("FTPHandler", "urllib2", "urllib.request"),
    MovedAttribute("CacheFTPHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPSHandler", "urllib2", "urllib.request"),
]

for attr in _urllib_request_moved_attributes:
    setattr(Module_six_moves_urllib_request, attr.name, attr)

urllib_request = Module_six_moves_urllib_request()
sys.modules['six.moves.urllib_request'] = urllib_request
sys.modules['six.moves.urllib.request'] = urllib_request

class Module_six_moves_urllib_response(object):
    """urllib.response compatibility"""
    pass

_urllib_response_moved_attributes = [
    MovedAttribute("addbase", "urllib", "urllib.response"),
    MovedAttribute("addclosehook", "urllib", "urllib.response"),
    MovedAttribute("addinfo", "urllib", "urllib.response"),
]

for attr in _urllib_response_moved_attributes:
    setattr(Module_six_moves_urllib_response, attr.name, attr)

urllib_response = Module_six_moves_urllib_response()
sys.modules['six.moves.urllib_response'] = urllib_response
sys.modules['six.moves.urllib.response'] = urllib_response

class Module_six_moves_urllib_robotparser(object):
    """urllib.robotparser compatibility"""
    pass

_urllib_robotparser_moved_attributes = [
    MovedAttribute("RobotFileParser", "robotparser", "urllib.robotparser"),
]

for attr in _urllib_robotparser_moved_attributes:
    setattr(Module_six_moves_urllib_robotparser, attr.name, attr)

urllib_robotparser = Module_six_moves_urllib_robotparser()
sys.modules['six.moves.urllib_robotparser'] = urllib_robotparser
sys.modules['six.moves.urllib.robotparser'] = urllib_robotparser

class Module_six_moves_urllib(object):
    """urllib compatibility package"""
    parse = urllib_parse
    error = urllib_error
    request = urllib_request
    response = urllib_response
    robotparser = urllib_robotparser

urllib = Module_six_moves_urllib()
sys.modules['six.moves.urllib'] = urllib

# Add urllib to moves
setattr(_MovedItems, 'urllib_parse', urllib_parse)
setattr(_MovedItems, 'urllib_error', urllib_error)
setattr(_MovedItems, 'urllib', urllib)

_importer._add_module(urllib_parse, 'urllib_parse', 'urllib.parse')
_importer._add_module(urllib_error, 'urllib_error', 'urllib.error')
_importer._add_module(urllib, 'urllib', 'urllib')

# ============================================================================
# Iterator and Dictionary Compatibility
# ============================================================================

def next(it):
    """Call the iterator's next method"""
    return it.__next__()

class Iterator:
    """Base class for compatible iterators"""
    def __next__(self):
        raise NotImplementedError

    def next(self):
        return self.__next__()

def iterkeys(d):
    """Return an iterator over dictionary keys"""
    try:
        return iter(d.keys())
    except AttributeError:
        return d.iterkeys()

def itervalues(d):
    """Return an iterator over dictionary values"""
    try:
        return iter(d.values())
    except AttributeError:
        return d.itervalues()

def iteritems(d):
    """Return an iterator over dictionary items"""
    try:
        return iter(d.items())
    except AttributeError:
        return d.iteritems()

def viewkeys(d):
    """Return a view of dictionary keys"""
    try:
        return d.keys()
    except AttributeError:
        return d.viewkeys()

def viewvalues(d):
    """Return a view of dictionary values"""
    try:
        return d.values()
    except AttributeError:
        return d.viewvalues()

def viewitems(d):
    """Return a view of dictionary items"""
    try:
        return d.items()
    except AttributeError:
        return d.viewitems()

# ============================================================================
# Byte and String Conversion
# ============================================================================

def b(s):
    """Create a byte string literal"""
    if isinstance(s, text_type):
        return s.encode("latin-1")
    return s

def u(s):
    """Create a text/unicode literal"""
    if isinstance(s, binary_type):
        return s.decode("unicode_escape")
    return s

if PY3:
    unichr = chr
else:
    unichr = unichr

def int2byte(i):
    """Convert integer to byte"""
    if PY3:
        return bytes((i,))
    else:
        return chr(i)

def byte2int(bs):
    """Convert byte to integer"""
    if isinstance(bs, int):
        return bs
    else:
        return ord(bs)

def ensure_binary(s, encoding='utf-8', errors='strict'):
    """Ensure string is binary"""
    if isinstance(s, binary_type):
        return s
    if isinstance(s, text_type):
        return s.encode(encoding, errors)
    raise TypeError("ensure_binary expected str or bytes")

def ensure_str(s, encoding='utf-8', errors='strict'):
    """Ensure string is native str"""
    if PY3:
        return ensure_text(s, encoding, errors)
    else:
        if isinstance(s, text_type):
            return s.encode(encoding, errors)
        return s

def ensure_text(s, encoding='utf-8', errors='strict'):
    """Ensure string is text/unicode"""
    if isinstance(s, binary_type):
        return s.decode(encoding, errors)
    if isinstance(s, text_type):
        return s
    raise TypeError("ensure_text expected str or bytes")

# ============================================================================
# Function and Method Introspection
# ============================================================================

def get_function_code(func):
    """Get function code object"""
    return func.__code__

def get_function_defaults(func):
    """Get function default arguments"""
    return func.__defaults__

def get_function_globals(func):
    """Get function globals"""
    return func.__globals__

def get_function_closure(func):
    """Get function closure"""
    return func.__closure__

def get_unbound_function(meth):
    """Get unbound function from method"""
    return meth

def get_method_function(meth):
    """Get function from bound method"""
    return meth.__func__

def get_method_self(meth):
    """Get instance from bound method"""
    return meth.__self__

# ============================================================================
# Syntax and Exception Compatibility
# ============================================================================

def exec_(_code_, _globs_=None, _locs_=None):
    """Execute code with Python 3 compatibility"""
    if _globs_ is None:
        frame = sys._getframe(1)
        _globs_ = frame.f_globals
        if _locs_ is None:
            _locs_ = frame.f_locals
        del frame
    elif _locs_ is None:
        _locs_ = _globs_
    exec(_code_, _globs_, _locs_)

def print_(*args, **kwargs):
    """Print with Python 3 compatibility"""
    fp = kwargs.pop("file", sys.stdout)
    if fp is None:
        return
    def write(data):
        if not isinstance(data, binary_type):
            data = str(data)
        fp.write(data)
    want_unicode = False
    sep = kwargs.pop("sep", None)
    if sep is not None:
        if isinstance(sep, binary_type):
            want_unicode = True
        elif not isinstance(sep, str):
            raise TypeError("sep must be None or a string")
    end = kwargs.pop("end", None)
    if end is not None:
        if isinstance(end, binary_type):
            want_unicode = True
        elif not isinstance(end, str):
            raise TypeError("end must be None or a string")
    if kwargs:
        raise TypeError("invalid keyword arguments to print_()")
    if not want_unicode:
        for arg in args:
            if isinstance(arg, binary_type):
                want_unicode = True
                break
    if want_unicode:
        newline = "\n"
        space = " "
    else:
        newline = b"\n"
        space = b" "
    if sep is None:
        sep = space
    if end is None:
        end = newline
    for i, arg in enumerate(args):
        if i:
            write(sep)
        write(arg)
    write(end)

def raise_from(value, from_value):
    """Raise exception with cause"""
    raise value from from_value

if PY3:
    exec("""def reraise(tp, value, tb=None):
    if value is None:
        value = tp()
    if value.__traceback__ is not tb:
        raise value.with_traceback(tb)
    raise value
""")
else:
    def exec_(_code_, _globs_=None, _locs_=None):
        if _globs_ is None:
            frame = sys._getframe(1)
            _globs_ = frame.f_globals
            if _locs_ is None:
                _locs_ = frame.f_locals
            del frame
        elif _locs_ is None:
            _locs_ = _globs_
        exec("""exec _code_ in _globs_, _locs_""")

    exec_("""def reraise(tp, value, tb=None):
    raise tp, value, tb
""")

# ============================================================================
# Metaclass and Decorator Utilities
# ============================================================================

def with_metaclass(meta, *bases):
    """Create a base class with a metaclass"""
    class metaclass(type):
        def __new__(cls, name, this_bases, d):
            return meta(name, bases, d)
    return type.__new__(metaclass, 'temporary_class', (), {})

def add_metaclass(metaclass):
    """Class decorator for adding a metaclass"""
    def wrapper(cls):
        orig_vars = cls.__dict__.copy()
        slots = orig_vars.get('__slots__')
        if slots is not None:
            if isinstance(slots, str):
                slots = [slots]
            for slots_var in slots:
                orig_vars.pop(slots_var)
        orig_vars.pop('__dict__', None)
        orig_vars.pop('__weakref__', None)
        return metaclass(cls.__name__, cls.__bases__, orig_vars)
    return wrapper

def python_2_unicode_compatible(cls):
    """Class decorator for Python 2/3 __str__/__unicode__ compatibility"""
    if PY2:
        if not hasattr(cls, '__unicode__'):
            raise ValueError("@python_2_unicode_compatible requires __str__ method")
        cls.__unicode__ = cls.__str__
        cls.__str__ = lambda self: self.__unicode__().encode('utf-8')
    return cls

# ============================================================================
# IO Compatibility
# ============================================================================

if PY3:
    from io import StringIO, BytesIO
else:
    from StringIO import StringIO as _StringIO
    StringIO = _StringIO
    from io import BytesIO

# ============================================================================
# unittest Assertion Compatibility
# ============================================================================

class _AssertWarnsContext(object):
    """Context manager for assertRaisesRegex-like behavior"""
    def __init__(self, test_case, expected, pattern):
        self.test_case = test_case
        self.expected = expected
        self.pattern = pattern

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_value, tb):
        if exc_type is None:
            raise AssertionError("{0} not raised".format(self.expected))
        if not issubclass(exc_type, self.expected):
            return False
        return True

def assertCountEqual(test_case, first, second, msg=None):
    """Assert that sequences have same elements"""
    if hasattr(test_case, 'assertCountEqual'):
        return test_case.assertCountEqual(first, second, msg=msg)
    else:
        return test_case.assertEqual(sorted(first), sorted(second), msg=msg)

def assertRaisesRegex(test_case, expected_exception, expected_regex, *args, **kwargs):
    """Assert exception is raised and matches regex"""
    if hasattr(test_case, 'assertRaisesRegex'):
        return test_case.assertRaisesRegex(expected_exception, expected_regex, *args, **kwargs)
    else:
        return test_case.assertRaisesRegexp(expected_exception, expected_regex, *args, **kwargs)

def assertRegex(test_case, text, expected_regex, msg=None):
    """Assert text matches regex"""
    if hasattr(test_case, 'assertRegex'):
        return test_case.assertRegex(text, expected_regex, msg=msg)
    else:
        return test_case.assertRegexpMatches(text, expected_regex, msg=msg)

def assertNotRegex(test_case, text, unexpected_regex, msg=None):
    """Assert text does not match regex"""
    if hasattr(test_case, 'assertNotRegex'):
        return test_case.assertNotRegex(text, unexpected_regex, msg=msg)
    else:
        return test_case.assertNotRegexpMatches(text, unexpected_regex, msg=msg)

# ============================================================================
# Decorator Compatibility
# ============================================================================

def wraps(wrapped, assigned=functools.WRAPPER_ASSIGNMENTS, updated=functools.WRAPPER_UPDATES):
    """Copy metadata from wrapped function to wrapper"""
    return functools.wraps(wrapped, assigned=assigned, updated=updated)

# ============================================================================
# Module Assembly and API Export
# ============================================================================

__all__ = [
    'PY2', 'PY3', 'PY34',
    'string_types', 'integer_types', 'class_types', 'text_type', 'binary_type', 'MAXSIZE',
    'moves', 'Iterator', 'next',
    'iterkeys', 'itervalues', 'iteritems', 'viewkeys', 'viewvalues', 'viewitems',
    'b', 'u', 'unichr', 'int2byte', 'byte2int', 'ensure_binary', 'ensure_str', 'ensure_text',
    'get_function_code', 'get_function_defaults', 'get_function_globals', 'get_function_closure',
    'get_unbound_function', 'get_method_function', 'get_method_self',
    'exec_', 'print_', 'raise_from', 'reraise',
    'with_metaclass', 'add_metaclass', 'python_2_unicode_compatible',
    'StringIO', 'BytesIO',
    'assertCountEqual', 'assertRaisesRegex', 'assertRegex', 'assertNotRegex',
    'wraps',
]
