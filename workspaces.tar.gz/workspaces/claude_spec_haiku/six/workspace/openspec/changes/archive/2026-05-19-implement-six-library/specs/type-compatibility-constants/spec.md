## ADDED Requirements

### Requirement: Provide unified type compatibility constants
The system SHALL expose type constants that abstract away the differences between Python 2 and 3 type hierarchies, allowing code to perform type checks without version-specific logic.

#### Scenario: String type checking
- **WHEN** code checks `isinstance(obj, six.string_types)`
- **THEN** it returns True for both str (Python 3) and str/unicode (Python 2)

#### Scenario: Integer type checking
- **WHEN** code checks `isinstance(num, six.integer_types)`
- **THEN** it returns True for int and long (Python 2) or just int (Python 3)

#### Scenario: Class type checking
- **WHEN** code checks `isinstance(cls, six.class_types)`
- **THEN** it returns True for both old-style and new-style classes (Python 2) or all classes (Python 3)

#### Scenario: Text type access
- **WHEN** code calls `six.text_type("hello")`
- **THEN** it returns unicode in Python 2 and str in Python 3

#### Scenario: Binary type access
- **WHEN** code calls `six.binary_type(b"hello")`
- **THEN** it returns str in Python 2 and bytes in Python 3

#### Scenario: Maximum container size constant
- **WHEN** code accesses `six.MAXSIZE`
- **THEN** it returns the maximum size for containers in the current Python version
