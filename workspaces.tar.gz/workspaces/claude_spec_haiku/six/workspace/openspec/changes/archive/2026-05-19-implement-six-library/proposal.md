## Why

Python 2 reached end-of-life in 2020, but many legacy codebases still need to support both Python 2.7 and Python 3.3+. Six is a lightweight compatibility library that eliminates the need for multiple code branches, allowing developers to write single-source code that runs seamlessly across both versions. This greatly simplifies maintenance and accelerates Python 3 migration strategies for large organizations with legacy systems.

## What Changes

- Introduce a comprehensive Python 2/3 compatibility library as a single installable package (via pip/setup.py)
- Unify type judgment through constants (string_types, integer_types, etc.) instead of version-specific isinstance checks
- Provide six.moves for standard library imports that changed names (queue, configparser, urllib, etc.)
- Implement cross-version iterator, dictionary, and string/byte conversion utilities
- Add syntax compatibility functions for exec, print, exception handling differences
- Provide metaclass and class decorator utilities that work across versions
- Include unittest assertion helpers for consistent test writing
- Enable decorators (wraps) and StringIO/BytesIO access through unified APIs

## Capabilities

### New Capabilities

- `version-detection`: Detect and expose Python version constants (PY2, PY3, PY34, etc.)
- `type-compatibility-constants`: Provide unified type constants (string_types, integer_types, text_type, binary_type, class_types, MAXSIZE)
- `standard-library-moves`: Implement six.moves for seamless standard library imports across Python versions
- `iterator-compatibility`: Provide next(), Iterator base class, and dictionary iteration methods (iterkeys, itervalues, iteritems, viewkeys, viewvalues, viewitems)
- `byte-string-conversion`: Implement byte/string conversion utilities (b, u, unichr, int2byte, byte2int, ensure_binary, ensure_str, ensure_text)
- `function-introspection`: Provide utilities for accessing function/method attributes across versions (get_function_code, get_function_defaults, get_method_self, etc.)
- `syntax-compatibility`: Implement exec_, print_, raise_from, reraise for syntax/exception handling differences
- `metaclass-decorators`: Provide with_metaclass, add_metaclass, python_2_unicode_compatible for class definition compatibility
- `unittest-assertions`: Provide cross-version unittest assertion helpers (assertCountEqual, assertRaisesRegex, assertRegex, assertNotRegex)
- `io-compatibility`: Provide StringIO and BytesIO unified access through six.StringIO and six.BytesIO
- `utility-functions`: Implement internal utilities (_add_doc, _import_module) for module management
- `meta-path-importer`: Implement _SixMetaPathImporter for lazy loading six.moves submodules
- `moved-module-proxy`: Implement MovedModule and MovedAttribute classes for lazy attribute resolution
- `decorator-compatibility`: Provide wraps decorator for cross-version function decoration
- `lazy-module-system`: Implement _LazyDescr and _LazyModule base classes for lazy loading infrastructure

### Modified Capabilities

<!-- No existing capabilities are being modified; this is a new implementation -->

## Impact

- **New files**: six.py (main module), setup.py, supporting documentation and config files
- **New APIs**: Developers can import from six and six.moves for all compatibility needs
- **No breaking changes**: This is a new library with no existing functionality to break
- **Dependencies**: Requires Python 2.7, 3.3+ (declared in setup.py). Optional dev dependencies: setuptools, flake8, isort, mypy, pytest, tox, black, sphinx
- **Installation**: Package will be installable via `pip install six` or `pip install -e .` in the workspace
