## Context

Six is a minimal compatibility library that bridges Python 2 and Python 3 API differences. It provides a single six.py module (~900 lines in real Six) that developers can import to gain access to unified APIs without maintaining separate code paths.

The project requires:
- Support for Python 2.7 and Python 3.3+ 
- Single-source code via unified APIs and six.moves
- Installation via setuptools/pip
- No mandatory external dependencies beyond standard library

Key stakeholders: Python developers with codebases supporting both Python 2 and 3.

## Goals / Non-Goals

**Goals:**
- Provide unified type constants (string_types, integer_types, text_type, binary_type, etc.)
- Enable standard library imports via six.moves that work across Python versions
- Support iterator and dictionary traversal methods that are version-agnostic
- Implement byte/string conversion utilities with encoding awareness
- Provide function/method introspection abstractions
- Support syntax differences (exec, print, exceptions) through wrapper functions
- Enable metaclass and class decorator definitions that work in both versions
- Provide StringIO/BytesIO access through unified APIs
- Make six installable and importable as: `import six` and `from six import moves`

**Non-Goals:**
- Supporting Python 3.0-3.2 (target 3.3+)
- Supporting Python 2.6 or earlier (target 2.7+)
- Wrapping all standard library differences (only common ones via six.moves)
- Runtime version switching or dynamic compatibility (version detection is load-time)
- Performance optimization beyond lazy loading
- Replacing testing frameworks or providing extensive testing utilities

## Decisions

### Decision 1: Single-file module (six.py)
**Choice**: Implement entire library in a single six.py file (~900 lines) rather than a package.

**Rationale**: 
- Easy distribution (single file, no directory structure overhead)
- Clear namespace (everything under `six.*`)
- Mimics the real Six library structure
- Reduces import complexity

**Alternatives Considered**:
- Package structure (six/): adds complexity, directory management, but cleaner modularization
- Multiple specialized modules: harder to manage dependencies between compatibility layers

### Decision 2: Lazy loading via _SixMetaPathImporter
**Choice**: Implement a custom meta path importer to handle six.moves imports lazily.

**Rationale**:
- six.moves contains ~60+ modules/attributes; many users only need a few
- Lazy loading avoids importing unnecessary modules at startup
- Defers error reporting to actual usage time, not import time
- Supports dynamic MovedModule and MovedAttribute registration

**Alternatives Considered**:
- Direct module mapping at import: simpler but loads all modules upfront
- __getattr__ on moves object: easier but doesn't work for submodules like `from six.moves.urllib import parse`

### Decision 3: Abstract versions at module load time
**Choice**: Define PY2, PY3, PY34 etc. constants once when six.py is imported.

**Rationale**:
- Version detection happens once, not repeatedly during execution
- Code is cleaner with constants than if/else version checks everywhere
- Constants are immutable after module load

**Alternatives Considered**:
- Runtime version checks: more flexible but slower, repeated overhead

### Decision 4: Type constants mirror native Python types
**Choice**: Map six.string_types to (str, unicode) in Py2 and (str,) in Py3.

**Rationale**:
- Exactly mirrors how isinstance(obj, six.string_types) would work
- Simple tuple unpacking in code
- Works seamlessly with isinstance() and type checking

**Alternatives Considered**:
- Custom type class: overcomplicated, doesn't integrate with isinstance
- Conditional function: runtime overhead, less efficient

### Decision 5: MovedModule/MovedAttribute as descriptors
**Choice**: Implement moved classes as _LazyDescr subclasses that resolve on attribute access.

**Rationale**:
- __get__ is called only when attribute is actually accessed
- Descriptor protocol integrates cleanly with Python's attribute resolution
- Enables seamless attribute binding via setattr()

**Alternatives Considered**:
- Regular classes with __call__: requires explicit invocation to resolve
- Module replace-in-place: loses reference to proxy, harder to debug

### Decision 6: Separate urllib modules (urllib, urllib_parse, urllib_error, etc.)
**Choice**: Break urllib handling into separate lazy modules for urllib_parse, urllib_error, urllib_request, etc.

**Rationale**:
- Python 2: urllib and urllib2 (separate modules)
- Python 3: all under urllib.* submodules
- Separating allows users to only import what they need
- Matches how real Six organizes these

**Alternatives Considered**:
- Single urllib module: monolithic, hard to navigate

### Decision 7: Utility functions (_add_doc, _import_module) are internal
**Choice**: Prefix utility functions with underscore to indicate they're internal infrastructure.

**Rationale**:
- Signals to users these are not public API
- Allows refactoring without breaking user code
- Keeps public API surface clean

**Alternatives Considered**:
- Public utilities: pollutes namespace, locks implementation

### Decision 8: setup.py with full dependency list
**Choice**: Include all dev/test dependencies in setup.py (flake8, mypy, pytest, tox, black, sphinx).

**Rationale**:
- Core library has no runtime dependencies (pure Python)
- Dev dependencies enable quality tools
- setup.py becomes complete specification of project needs
- Follows Python packaging best practices

**Alternatives Considered**:
- requirements.txt: doesn't enable pip install with extras
- No setup.py: not installable via pip

## Risks / Trade-offs

### Risk: Lazy loading adds complexity
**Mitigation**: Use well-documented _LazyDescr/_LazyModule base classes; provide clear examples in docstrings.

### Risk: some edge cases in function introspection may differ slightly
**Mitigation**: Document known issues in function attributes; add test cases for common scenarios.

### Risk: exec_/print_ may not handle all syntactic variations
**Mitigation**: Focus on 80% use cases; document limitations in docstrings.

### Risk: Metaclass with_metaclass pattern is obscure
**Mitigation**: Provide clear usage examples in docstrings and comments.

### Risk: six.moves grows without clear governance
**Mitigation**: Only add new moves for genuinely renamed standard library items, not custom modules.

### Trade-off: Single-file module vs package structure
- **Single file**: simpler distribution, but large file (~900 LOC) can be harder to navigate
- **Mitigation**: Use clear section comments and logical organization within six.py

## Assumptions

1. **Python version is fixed at import time**: Code assumes Python version doesn't change during execution (reasonable for normal programs).

2. **Six.moves imports only call _SixMetaPathImporter when needed**: Assumes users won't manually manipulate sys.modules or use dangerous importlib tricks that bypass the importer.

3. **Existing code doesn't use "six" as a module name**: No name collision detection; assumes users won't have their own six.py.

4. **String encoding defaults to UTF-8 when not specified**: ensure_text(), ensure_str(), ensure_binary() default to UTF-8 encoding.

5. **Function/method introspection works on regular Python functions**: Built-in functions and C-extensions may not have all attributes (e.g., __code__); code should handle AttributeError gracefully if inspecting C functions.

6. **unittest TestCase methods are compatible**: assertCountEqual, assertRaisesRegex, etc. map to methods that exist in both Py2.7+ and Py3.3+.

7. **sys.modules can be modified safely**: The importer adds/modifies sys.modules; assumes no other code will interfere with this.

## Migration Plan

1. **Create six.py** with all core functionality
2. **Create setup.py** with metadata and dependencies
3. **Test locally** with both Python 2.7 (if available) and Python 3.3+
4. **Document in setup.cfg and MANIFEST.in** for proper distribution
5. **Verify imports work**: `import six`, `from six import moves`, etc.
6. **No deployment concerns**: This is a new library, not replacing existing code

## Open Questions

1. **Should setup.py include all tox/black/sphinx configs, or minimal installation?** → Decision: include all for completeness per requirements.

2. **Should six.py include extensive inline documentation, or rely on docstrings?** → Decision: docstrings for functions, comment blocks for complex sections.

3. **How to handle Python 3.13+ changes to standard library?** → Decision: defer; target Python 3.3-3.12 for this version.

4. **Should add_move()/remove_move() be publicly documented or remain internal?** → Decision: make public but mark as advanced usage.
