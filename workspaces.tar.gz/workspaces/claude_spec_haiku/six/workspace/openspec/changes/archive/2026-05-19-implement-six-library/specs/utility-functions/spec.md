## ADDED Requirements

### Requirement: Provide internal utility functions for module management
The system SHALL provide utility functions for attaching documentation and dynamically importing modules, used internally by six for infrastructure purposes.

#### Scenario: Add documentation to function
- **WHEN** code calls `_add_doc(func, "Documentation string")`
- **THEN** the function's __doc__ attribute is set to the provided string

#### Scenario: Import module dynamically
- **WHEN** code calls `_import_module("os.path")`
- **THEN** it imports the module and returns the module object from sys.modules

#### Scenario: Import module with dots in name
- **WHEN** code calls `_import_module("urllib.parse")`
- **THEN** it correctly imports the submodule and returns it
