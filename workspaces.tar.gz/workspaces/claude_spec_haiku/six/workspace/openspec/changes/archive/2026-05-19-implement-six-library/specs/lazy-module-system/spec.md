## ADDED Requirements

### Requirement: Implement lazy loading infrastructure base classes
The system SHALL provide _LazyDescr and _LazyModule base classes that enable lazy resolution of attributes and modules, avoiding unnecessary imports until attributes are actually accessed.

#### Scenario: Create lazy descriptor
- **WHEN** code subclasses `_LazyDescr` with a _resolve method
- **THEN** the descriptor only imports/resolves its target when __get__ is called

#### Scenario: Access lazy attribute
- **WHEN** code accesses a lazy descriptor attribute
- **THEN** the attribute is resolved (imported) on first access and cached

#### Scenario: Create lazy module
- **WHEN** code subclasses `_LazyModule` and defines _moved_attributes
- **THEN** attributes are lazily resolved when accessed

#### Scenario: Set attributes on lazy module
- **WHEN** code calls `setattr()` on a lazy module class with moved attributes
- **THEN** the attributes are bound to the lazy module and resolved on access

#### Scenario: Get __path__ from lazy module
- **WHEN** code accesses `__path__` from a lazy module
- **THEN** it returns an empty list (indicating it's a package)
