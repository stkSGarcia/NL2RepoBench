## ADDED Requirements

### Requirement: Provide metaclass and class decorator compatibility utilities
The system SHALL provide utilities for defining metaclasses and applying class-level decorations in a syntax that works consistently across Python 2 and 3.

#### Scenario: Define class with metaclass using with_metaclass
- **WHEN** code defines `class MyClass(six.with_metaclass(MyMeta, BaseClass))`
- **THEN** the class uses MyMeta as metaclass and inherits from BaseClass in both Py2 and Py3

#### Scenario: Apply metaclass with decorator
- **WHEN** code applies `@six.add_metaclass(MyMeta)` to a class definition
- **THEN** the class uses MyMeta as metaclass without changing the base class syntax

#### Scenario: Make class unicode-compatible
- **WHEN** code applies `@six.python_2_unicode_compatible` to a class with `__str__` returning unicode
- **THEN** the class __str__ returns proper type in both Python 2 and 3
