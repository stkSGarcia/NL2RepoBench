## ADDED Requirements

### Requirement: Provide cross-version unittest assertion compatibility
The system SHALL provide unittest assertion helper functions that abstract away differences in assertion method names across Python versions.

#### Scenario: Assert equal counts without order
- **WHEN** code calls `six.assertCountEqual(testcase, [1, 2], [2, 1])`
- **THEN** assertion passes (assertCountEqual in Py3, assertItemsEqual in Py2)

#### Scenario: Assert exception matches regex
- **WHEN** code calls `six.assertRaisesRegex(testcase, ValueError, "pattern")`
- **THEN** assertion passes if ValueError is raised and message matches pattern (assertRaisesRegex in Py3, assertRaisesRegexp in Py2)

#### Scenario: Assert string matches regex
- **WHEN** code calls `six.assertRegex(testcase, "hello world", r"hello")`
- **THEN** assertion passes if string matches regex

#### Scenario: Assert string does not match regex
- **WHEN** code calls `six.assertNotRegex(testcase, "hello world", r"xyz")`
- **THEN** assertion passes if string does not match regex
