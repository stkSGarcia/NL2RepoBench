# meta-path-importer Specification

## Purpose
TBD - created by archiving change implement-six-library. Update Purpose after archive.
## Requirements
### Requirement: Implement meta path importer for six.moves
The system SHALL provide a _SixMetaPathImporter class that implements PEP 302/451 finder and loader interfaces, enabling lazy loading of six.moves submodules.

#### Scenario: Initialize importer
- **WHEN** code creates `_SixMetaPathImporter("six")`
- **THEN** an importer instance is created with empty known_modules dict

#### Scenario: Register module with importer
- **WHEN** code calls `importer._add_module(module, "fullname")`
- **THEN** the module is registered and can be found by that fullname

#### Scenario: Find known module
- **WHEN** code calls `importer.find_module("moves.queue")`
- **THEN** it returns self if the module is registered, otherwise None

#### Scenario: Get module from importer
- **WHEN** code calls `importer._get_module("moves.queue")`
- **THEN** it returns the registered module or raises KeyError

#### Scenario: Load module
- **WHEN** code calls `importer.load_module("moves.queue")`
- **THEN** the module is inserted into sys.modules and returned

#### Scenario: Check if module is package
- **WHEN** code calls `importer.is_package("moves.urllib")`
- **THEN** it returns True if the module has __path__, False otherwise

