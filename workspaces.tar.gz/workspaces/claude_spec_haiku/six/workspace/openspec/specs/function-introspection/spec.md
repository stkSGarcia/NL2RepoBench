# function-introspection Specification

## Purpose
TBD - created by archiving change implement-six-library. Update Purpose after archive.
## Requirements
### Requirement: Provide cross-version function and method introspection utilities
The system SHALL provide utilities for accessing function and method attributes (code objects, defaults, globals, closures, etc.) in a version-agnostic way.

#### Scenario: Get function code object
- **WHEN** code calls `six.get_function_code(my_func)`
- **THEN** it returns the code object (func_code in Py2, __code__ in Py3)

#### Scenario: Get function default arguments
- **WHEN** code calls `six.get_function_defaults(my_func)`
- **THEN** it returns a tuple of default argument values

#### Scenario: Get function globals
- **WHEN** code calls `six.get_function_globals(my_func)`
- **THEN** it returns the globals dictionary of the function

#### Scenario: Get function closure
- **WHEN** code calls `six.get_function_closure(my_func)`
- **THEN** it returns the closure tuple or None

#### Scenario: Get unbound function from method
- **WHEN** code calls `six.get_unbound_function(MyClass.method)`
- **THEN** it returns the underlying function object

#### Scenario: Get function from bound method
- **WHEN** code calls `six.get_method_function(bound_method)`
- **THEN** it returns the function (im_func in Py2, __func__ in Py3)

#### Scenario: Get instance from bound method
- **WHEN** code calls `six.get_method_self(bound_method)`
- **THEN** it returns the instance to which the method is bound

