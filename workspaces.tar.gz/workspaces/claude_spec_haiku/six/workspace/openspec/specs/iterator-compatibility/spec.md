# iterator-compatibility Specification

## Purpose
TBD - created by archiving change implement-six-library. Update Purpose after archive.
## Requirements
### Requirement: Provide cross-version iterator compatibility
The system SHALL provide a unified `next()` function and Iterator base class that work consistently across Python 2 and 3, along with dictionary iteration methods that handle version differences.

#### Scenario: Call next on iterator
- **WHEN** code calls `six.next(iterator)`
- **THEN** it returns the next item from the iterator (using .next() in Python 2, next() in Python 3)

#### Scenario: Subclass Iterator base class
- **WHEN** a custom class inherits from `six.Iterator` and defines `__next__`
- **THEN** it works as an iterator in both Python 2 and 3

#### Scenario: Iterate over dictionary keys
- **WHEN** code calls `six.iterkeys(dict)`
- **THEN** it returns an iterator over keys (iter in Py3, .iterkeys() in Py2)

#### Scenario: Iterate over dictionary values
- **WHEN** code calls `six.itervalues(dict)`
- **THEN** it returns an iterator over values

#### Scenario: Iterate over dictionary items
- **WHEN** code calls `six.iteritems(dict)`
- **THEN** it returns an iterator over (key, value) pairs

#### Scenario: View keys
- **WHEN** code calls `six.viewkeys(dict)`
- **THEN** it returns a view object of dictionary keys

#### Scenario: View values
- **WHEN** code calls `six.viewvalues(dict)`
- **THEN** it returns a view object of dictionary values

#### Scenario: View items
- **WHEN** code calls `six.viewitems(dict)`
- **THEN** it returns a view object of dictionary (key, value) pairs

