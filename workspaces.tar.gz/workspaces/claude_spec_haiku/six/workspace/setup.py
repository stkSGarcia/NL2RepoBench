#!/usr/bin/env python
"""Six setup file"""

from setuptools import setup

with open("README.rst", "r") as f:
    long_description = f.read()

setup(
    name="six",
    version="1.16.0",
    description="Python 2 and 3 compatibility library",
    long_description=long_description,
    long_description_content_type="text/x-rst",
    author="Benjamin Peterson",
    author_email="benjamin@python.org",
    url="https://github.com/benjaminp/six",
    license="MIT",
    py_modules=["six"],
    python_requires=">=2.7, !=3.0.*, !=3.1.*, !=3.2.*",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 2",
        "Programming Language :: Python :: 2.7",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.3",
        "Programming Language :: Python :: 3.4",
        "Programming Language :: Python :: 3.5",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Topic :: Software Development :: Libraries",
        "Topic :: Utilities",
    ],
    extras_require={
        "dev": [
            "setuptools",
            "flake8",
            "isort",
            "mypy",
            "pytest",
            "tox",
            "black",
            "sphinx",
        ]
    },
)
