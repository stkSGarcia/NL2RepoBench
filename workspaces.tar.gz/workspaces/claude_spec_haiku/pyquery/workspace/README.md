# PyQuery

PyQuery is a jQuery-like library for Python. It allows you to make queries and manipulations on XML/HTML documents using a familiar jQuery-like syntax.

## Installation

```bash
pip install pyquery
```

## Quick Start

```python
from pyquery import PyQuery as pq

# Parse HTML
d = pq('<html><body><h1>Hello</h1></body></html>')

# Query elements
print(d('h1').text())  # Output: Hello

# Manipulate the DOM
d('h1').addClass('highlight')
print(d)
```

## Features

- **CSS Selectors**: Support for CSS selectors with jQuery-style pseudo-classes
- **DOM Traversal**: Navigate the DOM with methods like `find()`, `children()`, `parent()`, etc.
- **DOM Manipulation**: Modify the DOM with methods like `append()`, `remove()`, `replace_with()`, etc.
- **Method Chaining**: Chain methods for fluent API design
- **Form Handling**: Serialize form data with `serialize()`
- **Network Requests**: Load HTML from URLs with `url_opener()`
- **Dual Naming**: Both snake_case and camelCase method names

## Documentation

Comprehensive documentation is available in the docstrings of the classes and methods.
