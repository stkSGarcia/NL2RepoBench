## Why

PyQuery is needed to provide Python developers with a jQuery-like API for parsing and manipulating XML/HTML documents. Current Python solutions (lxml, BeautifulSoup) lack the fluent, chainable interface that jQuery provides, making HTML/XML processing more verbose and less intuitive. This library will democratize web scraping and document processing by leveraging the familiar jQuery patterns that many developers already know.

## What Changes

- **New PyQuery Library**: Complete implementation of a jQuery-like Python library for HTML/XML querying and manipulation
- **CSS Selector Support**: Support for CSS selectors with jQuery-style pseudo-classes (`:first`, `:last`, `:even`, `:odd`, `:eq()`, `:checked`, `:selected`, `:disabled`, etc.)
- **DOM Manipulation**: Full set of DOM manipulation methods (append, prepend, wrap, remove, clone, empty, etc.)
- **Method Chaining**: Support for jQuery-style method chaining for fluent API design
- **Multi-Parser Support**: Support for multiple HTML/XML parsers (html, xml, html5, html_fragments, soup)
- **Form Handling**: Specialized form serialization (serialize, serialize_array, serialize_dict, serialize_pairs)
- **Network Request Support**: Direct URL loading with custom openers, session management, and timeout settings
- **Dual Naming Style**: Both snake_case and camelCase method naming for API compatibility
- **Comprehensive Test Suite**: 150+ test cases covering all core functionality

## Capabilities

### New Capabilities

- `css-selector-querying`: CSS selector parsing and element querying with support for jQuery pseudo-classes (:first, :last, :even, :odd, :eq, :lt, :gt, :contains, :checked, :selected, :disabled, :enabled, :file, :input, :button, :radio, :checkbox, :text, :password, :submit, :hidden, :reset, :image, :header, :parent, :empty, :has)
- `dom-traversal`: Element navigation methods (find, children, parent, siblings, next, prev, next_all, prev_all, next_until, parents, closest, contents, end)
- `dom-filtering`: Element filtering operations (filter, not_, is_, eq, each, map)
- `dom-manipulation`: DOM modification operations (append, prepend, after, before, wrap, wrap_all, replace_with, remove, empty, clone)
- `attribute-manipulation`: Getting, setting, and removing HTML attributes and CSS classes
- `form-handling`: Form data serialization and form element value manipulation (val, serialize, serialize_array, serialize_dict, serialize_pairs)
- `text-content-manipulation`: Getting and setting text content (text, html, outer_html) with intelligent whitespace and encoding handling
- `html-xml-parsing`: Multi-source document loading from strings, files, URLs, and lxml objects with support for multiple parsers
- `web-crawling`: HTTP/HTTPS URL loading with custom openers, session management, and timeout configuration
- `namespace-handling`: XML namespace support including namespace-aware queries and XHTML conversion
- `text-extraction`: Intelligent text extraction with support for inline/block tags, separators, and whitespace squashing
- `method-chaining`: Fluent API design with jQuery-style method chaining
- `dual-naming-style`: Both snake_case and camelCase method aliases for all public methods

### Modified Capabilities

<!-- No existing capabilities are being modified in this implementation -->

## Impact

- **New Package**: Creates the `pyquery` package with core modules (pyquery.py, cssselectpatch.py, openers.py, text.py)
- **Dependencies**: Requires lxml>=2.1, cssselect>=1.2.0, requests (optional for web crawling)
- **Setup.py**: Comprehensive package configuration with dependency declarations
- **API Entry Point**: pyquery/__init__.py exports PyQuery, fromstring, url_opener, no_default
- **Test Infrastructure**: Complete pytest test suite with 150+ test cases
- **Documentation**: Usage examples and API documentation
