## ADDED Requirements

### Requirement: val() method to get and set form element values
The system SHALL support val() method to get and set values for form elements like input, textarea, and select.

#### Scenario: Get input value
- **WHEN** user calls val() on an input element
- **THEN** system returns the current value attribute

#### Scenario: Set input value
- **WHEN** user calls val('newvalue') on input elements
- **THEN** system sets the value attribute

#### Scenario: Get select value
- **WHEN** user calls val() on a select element with selected option
- **THEN** system returns the value of the selected option

#### Scenario: Set select value
- **WHEN** user calls val('option2') on a select element
- **THEN** system selects the option with matching value

#### Scenario: Get multi-select values
- **WHEN** user calls val() on a multiple select with selected options
- **THEN** system returns a list of selected option values

#### Scenario: Set multi-select values
- **WHEN** user calls val(['opt1', 'opt2']) on a multiple select
- **THEN** system selects all options with matching values

### Requirement: serialize() method to encode form as URL string
The system SHALL support serialize() method to encode form data as a URL-encoded query string.

#### Scenario: Serialize form to query string
- **WHEN** user calls serialize() on a form element
- **THEN** system returns URL-encoded string like 'key1=value1&key2=value2'

#### Scenario: Filter out disabled elements
- **WHEN** serialize() on form with disabled fields
- **THEN** system excludes disabled elements and submit buttons

### Requirement: serialize_array() method to return array of objects
The system SHALL support serialize_array() method to return form data as array of {name, value} objects.

#### Scenario: Serialize to array format
- **WHEN** user calls serialize_array() on a form
- **THEN** system returns [{'name': 'key', 'value': 'val'}, ...]

#### Scenario: Handle multiple fields with same name
- **WHEN** serialize_array() with duplicate field names
- **THEN** system returns separate entries for each value

### Requirement: serialize_pairs() method to return array of tuples
The system SHALL support serialize_pairs() method to return form data as array of (name, value) tuples.

#### Scenario: Serialize to tuples
- **WHEN** user calls serialize_pairs() on a form
- **THEN** system returns [('key', 'val'), ...]

### Requirement: serialize_dict() method to return ordered dictionary
The system SHALL support serialize_dict() method to return form data as ordered dictionary.

#### Scenario: Serialize to dictionary
- **WHEN** user calls serialize_dict() on a form
- **THEN** system returns OrderedDict with field names as keys

#### Scenario: Handle duplicate field names
- **WHEN** serialize_dict() with multiple fields having same name
- **THEN** system returns a list of values for that key

### Requirement: Form control filtering for serialization
The system SHALL automatically exclude non-submittable form controls from serialization.

#### Scenario: Exclude disabled elements
- **WHEN** serializing a form with disabled inputs
- **THEN** system excludes inputs with disabled attribute

#### Scenario: Exclude elements in disabled fieldset
- **WHEN** serializing a form with fieldset disabled
- **THEN** system excludes inputs within disabled fieldset

#### Scenario: Exclude submit/reset/image buttons
- **WHEN** serializing a form with submit buttons
- **THEN** system excludes button elements and type=submit inputs

#### Scenario: Exclude file inputs
- **WHEN** serializing a form with file input
- **THEN** system excludes type=file inputs

#### Scenario: Include regular form controls
- **WHEN** serializing a form with text, checkbox, radio inputs
- **THEN** system includes these elements that meet criteria

### Requirement: Both snake_case and camelCase method naming
The system SHALL provide both snake_case and camelCase names for all form methods.

#### Scenario: Use camelCase form method
- **WHEN** user calls serializeArray() or serializePairs()
- **THEN** system executes the same operation as snake_case equivalents
