## ADDED Requirements

### Requirement: Support XML namespaces in selectors
The system SHALL support XML namespace-aware element selection.

#### Scenario: Select with namespace prefix
- **WHEN** user provides namespaces dict and uses prefix in selector
- **THEN** system queries elements in correct namespace

#### Scenario: Define namespace mapping
- **WHEN** user creates PyQuery with namespaces parameter
- **THEN** system applies namespace mapping to queries

### Requirement: xhtml_to_html() method to convert XHTML
The system SHALL provide xhtml_to_html() method to remove XHTML namespaces.

#### Scenario: Convert XHTML namespace
- **WHEN** document contains XHTML namespace
- **THEN** xhtml_to_html() removes namespace prefix

#### Scenario: Return for chaining
- **WHEN** user calls xhtml_to_html()
- **THEN** system returns PyQuery object for method chaining

### Requirement: remove_namespaces() method to strip all namespaces
The system SHALL provide remove_namespaces() method to remove all namespace declarations.

#### Scenario: Remove all namespaces
- **WHEN** user calls remove_namespaces()
- **THEN** system removes all namespace prefixes and declarations

#### Scenario: Enable namespace-free queries
- **WHEN** namespaces removed
- **THEN** system allows element queries without namespace awareness

### Requirement: Handle default namespaces
The system SHALL support default namespace declarations (xmlns=...).

#### Scenario: Query with default namespace
- **WHEN** document uses default namespace
- **THEN** system correctly identifies elements with default namespace

### Requirement: Both snake_case and camelCase naming for namespace methods
The system SHALL provide both naming styles for namespace methods.

#### Scenario: Use camelCase method
- **WHEN** user calls xhtmlToHtml()
- **THEN** system executes same operation as xhtml_to_html()
