## Context

PyQuery bridges the gap between jQuery's intuitive API and Python's XML/HTML parsing capabilities. The implementation builds on lxml for efficient parsing and cssselect for CSS-to-XPath translation. The library must support:

- **Multiple parsers**: html (fault-tolerant), xml (strict), html5, html_fragments, soup
- **jQuery-like fluent interface**: Method chaining with each method returning a PyQuery object
- **CSS selector translation**: Converting jQuery selectors to XPath for lxml queries
- **jQuery pseudo-classes**: Custom pseudo-classes not in CSS standard (:first, :last, :even, :odd, :eq, :gt, :lt, :contains, :has, form-related pseudo-classes)
- **Dual API naming**: Both snake_case and camelCase aliases for all public methods
- **Web crawling**: URL loading with requests library or urllib fallback
- **Form handling**: Intelligent form serialization with proper filtering of disabled/submit elements

## Goals / Non-Goals

**Goals:**
- Provide a complete jQuery-like API that Python developers can use intuitively
- Support both direct HTML/XML string parsing and network-based loading
- Handle complex DOM traversal and manipulation operations
- Serialize form data with proper filtering of non-submittable elements
- Maintain performance for large documents through lxml's C-based parsing
- Provide comprehensive test coverage (150+ test cases)
- Support both Python 3.x with proper Unicode handling

**Non-Goals:**
- DOM events and event handling (jQuery events)
- jQuery plugins or plugin architecture
- Animation and effects (jQuery effects library)
- AJAX methods beyond basic URL loading (jQuery.ajax)
- Browser execution or JavaScript evaluation
- Thread-safe operations across multiple threads
- Streaming parsing for infinite/very large documents

## Decisions

### 1. PyQuery Class Design - Inherit from list
**Decision**: PyQuery inherits from Python's list class to store DOM elements.
**Rationale**: Allows natural iteration, indexing, and slicing of selected elements. Makes the API familiar to Python developers. Simplifies implementation of operations like `eq()`, `slice()`.
**Alternatives Considered**: 
- Use composition with internal list → More verbose API, lost Pythonic iteration
- Use a generator/iterator → Can't slice or index, less intuitive

### 2. Selector Translation - cssselect with JQueryTranslator
**Decision**: Extend cssselect's HTMLTranslator/GenericTranslator to create JQueryTranslator that adds jQuery pseudo-class support.
**Rationale**: cssselect handles standard CSS selectors → XPath translation reliably. Custom translator allows jQuery pseudo-classes (:first, :last, etc.) to be converted to XPath predicates.
**Alternatives Considered**:
- Direct regex-based selector parsing → Complex, error-prone, hard to maintain
- cssselect only without custom translation → Can't support jQuery pseudo-classes

### 3. Multi-Parser Support
**Decision**: Support multiple parser types (html, xml, html5, soup, html_fragments) via parser parameter to PyQuery constructor.
**Rationale**: Different use cases need different parsers. HTML parser is forgiving (suitable for web scraping). XML parser is strict (suitable for structured data). html5/soup provide alternative parsing strategies.
**Alternatives Considered**:
- Force single parser (html only) → Limits use cases, especially for XML processing
- Auto-detect parser → Complex heuristics, can be wrong

### 4. Method Chaining - Return PyQuery from mutating methods
**Decision**: All DOM manipulation methods (append, remove, etc.) return a PyQuery object wrapping the result, enabling fluent chaining.
**Rationale**: Matches jQuery's design where most methods return jQuery objects. Allows code like `d('p').find('span').addClass('highlight').show()`.
**Alternatives Considered**:
- Return None from mutations → Can't chain, less intuitive
- Complex context tracking → Over-engineering

### 5. Dual Naming with Aliases
**Decision**: Implement snake_case methods natively, use decorator `@with_camel_case_alias` to auto-generate camelCase aliases.
**Rationale**: Python convention is snake_case. But jQuery developers expect camelCase. Decorator approach keeps implementation simple while providing both.
**Alternatives Considered**:
- Implement both manually → Code duplication, maintenance burden
- Implement camelCase only → Violates Python conventions

### 6. Form Control Filtering
**Decision**: Exclude disabled elements, submit/reset/image buttons, and file inputs from form serialization.
**Rationale**: Matches jQuery's serialize() behavior and HTML form submission standards. Disabled elements and submit buttons are not sent in form submissions.
**Alternatives Considered**:
- Include all form elements → Non-standard behavior, unexpected results
- Configurable filtering → Added complexity, most users want standard behavior

### 7. CSS Attribute Handling
**Decision**: Use FlexibleElement descriptor to allow both `attr('name')` and `attr.name()` syntax.
**Rationale**: Provides JavaScript-like flexibility in accessing attributes. Allows CSS manipulation as `css('color', 'red')` or `css.color('red')`.
**Alternatives Considered**:
- Fixed method signatures only → Less flexible, less like jQuery
- Direct property access → Can't support getting/setting values with parameters

### 8. Network Requests - Try requests, fallback to urllib
**Decision**: Prefer requests library if installed, fallback to urllib for minimal dependencies.
**Rationale**: requests is standard for web requests (better API, session management). Fallback to stdlib (urllib) if not installed, maintaining minimal dependencies.
**Alternatives Considered**:
- requests only → Adds dependency, fails without it
- urllib only → Limited session/timeout support

### 9. No Default Sentinel Value
**Decision**: Use a custom `NoDefault` class instance to distinguish "no argument" from "None".
**Rationale**: Methods like `val()` need to distinguish between no argument (get) vs None argument (set to None). Can't use None because None is a valid value.
**Alternatives Considered**:
- Use None as sentinel → Breaks `val(None)` use case
- Overload with arity checking → More fragile, less clear intent

### 10. Namespaces Support
**Decision**: Accept optional `namespaces` parameter in PyQuery constructor for XML namespace queries.
**Rationale**: XML documents often use namespaces. Parameter allows flexible namespace mapping without complex inference.
**Alternatives Considered**:
- Auto-detect namespaces → Complex, can be incorrect
- No namespace support → Limits XML use cases

## Risks / Trade-offs

### Risk: Performance with large documents
**Mitigation**: lxml is C-based and performant. For very large documents, users should consider streaming or chunking strategies. Tests will benchmark common operations.

### Risk: CSS/XPath translation edge cases
**Mitigation**: Comprehensive test suite with diverse selectors. cssselect library is well-tested. Custom translator methods for jQuery pseudo-classes follow clear patterns.

### Risk: Parser-specific behavior differences
**Mitigation**: Document parser selection guidelines. Test with different parsers to ensure consistent behavior where possible. Accept parser-specific quirks where unavoidable.

### Risk: Network requests without timeout
**Mitigation**: Set DEFAULT_TIMEOUT=60 in openers.py. Allow timeout override in url_opener. Warn in documentation about network hang risks.

### Risk: Method naming confusion (snake_case vs camelCase)
**Mitigation**: Decorator approach is transparent. Documentation shows both styles. IDE autocomplete will expose both options.

### Risk: Form serialization doesn't handle all edge cases
**Mitigation**: Follow jQuery/HTML standards for most common cases. Document limitations. Provide serialize_pairs() for custom filtering if needed.

## Migration Plan

This is a new library implementation. No migration needed.

1. **Phase 1**: Core PyQuery class, parsing, basic selectors
2. **Phase 2**: DOM traversal and filtering methods
3. **Phase 3**: DOM manipulation (append, remove, wrap, etc.)
4. **Phase 4**: Form handling and web crawling
5. **Phase 5**: Advanced features (namespaces, multiple parsers, text extraction)
6. **Phase 6**: Test suite completion and optimization

## Open Questions

**Assumptions Made:**
- **Python 3.13.4+**: Based on environment specification
- **lxml 6.0.0+**: For XML/HTML parsing capability
- **cssselect 1.3.0+**: For CSS-to-XPath translation
- **requests 2.32.5+**: Optional for enhanced network request handling
- **Test Environment**: pytest with coverage reporting
- **No thread safety requirement**: GIL-based Python, single-threaded use case

