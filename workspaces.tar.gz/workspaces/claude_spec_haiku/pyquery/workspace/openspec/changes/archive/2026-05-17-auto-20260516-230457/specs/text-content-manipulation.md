## ADDED Requirements

### Requirement: text() method to get and set text content
The system SHALL support text() method to get and set the text content of elements.

#### Scenario: Get text content
- **WHEN** user calls text() on an element
- **THEN** system returns all text content of the element and its descendants

#### Scenario: Get text from multiple elements
- **WHEN** user calls text() on multiple elements
- **THEN** system concatenates all text from all elements

#### Scenario: Set text content
- **WHEN** user calls text('new text') on elements
- **THEN** system replaces element content with text (escaping HTML)

#### Scenario: Handle whitespace squashing
- **WHEN** user calls text(squash_space=True)
- **THEN** system collapses multiple whitespace characters to single space

#### Scenario: Handle block-level tags with newlines
- **WHEN** user calls text() on HTML with block tags
- **THEN** system inserts newlines around block-level elements

### Requirement: html() method to get and set inner HTML
The system SHALL support html() method to get and set the inner HTML content of elements.

#### Scenario: Get inner HTML
- **WHEN** user calls html() on an element
- **THEN** system returns the HTML of child elements

#### Scenario: Set inner HTML
- **WHEN** user calls html('<p>content</p>') on elements
- **THEN** system replaces inner content with parsed HTML

#### Scenario: Use alternative tostring method
- **WHEN** user calls html(method='html')
- **THEN** system uses specified tostring method parameter

### Requirement: outer_html() method to get outer HTML
The system SHALL support outer_html() method to get the full HTML of an element including its own tags.

#### Scenario: Get outer HTML
- **WHEN** user calls outer_html() on an element
- **THEN** system returns the element itself with opening/closing tags

#### Scenario: Specify output method
- **WHEN** user calls outer_html(method='xml')
- **THEN** system uses specified method for serialization

### Requirement: Both snake_case and camelCase method naming
The system SHALL provide both snake_case (outer_html) and camelCase (outerHtml) for content methods.

#### Scenario: Use camelCase content method
- **WHEN** user calls outerHtml()
- **THEN** system executes same operation as outer_html()

### Requirement: Unicode and encoding support
The system SHALL properly handle Unicode characters and various text encodings.

#### Scenario: Handle Unicode text
- **WHEN** parsing HTML with Unicode characters
- **THEN** system preserves and returns Unicode correctly

#### Scenario: Auto-detect encoding
- **WHEN** loading document with encoding declaration
- **THEN** system automatically detects and handles the encoding

### Requirement: Text extraction with intelligent whitespace handling
The system SHALL intelligently handle whitespace, block elements, separators, and line breaks during text extraction.

#### Scenario: Handle inline elements
- **WHEN** extracting text from elements with inline tags (span, em, strong)
- **THEN** system concatenates text without adding breaks

#### Scenario: Handle block elements
- **WHEN** extracting text from elements with block tags (div, p, h1)
- **THEN** system adds newlines around block-level elements

#### Scenario: Handle separators
- **WHEN** extracting text from elements with br tags
- **THEN** system inserts newline for each br element

#### Scenario: Preserve HTML entities
- **WHEN** HTML contains character entities like &amp;
- **THEN** system correctly decodes them to actual characters
