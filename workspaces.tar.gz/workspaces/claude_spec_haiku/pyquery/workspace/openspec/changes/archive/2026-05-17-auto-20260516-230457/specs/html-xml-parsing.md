## ADDED Requirements

### Requirement: Support HTML string parsing
The system SHALL support parsing HTML content from strings.

#### Scenario: Parse HTML string
- **WHEN** user creates PyQuery from HTML string
- **THEN** system parses string and creates DOM elements

#### Scenario: Handle malformed HTML
- **WHEN** parsing malformed HTML (unclosed tags, mismatched)
- **THEN** system automatically corrects structure using HTML parser

### Requirement: Support XML string parsing
The system SHALL support parsing XML content with strict parsing.

#### Scenario: Parse XML string
- **WHEN** user creates PyQuery with parser='xml' from XML string
- **THEN** system parses as XML maintaining case sensitivity

#### Scenario: Strict XML validation
- **WHEN** parsing malformed XML
- **THEN** system raises XMLSyntaxError

### Requirement: Support multiple parser types
The system SHALL support different parser types via parser parameter.

#### Scenario: Use HTML parser
- **WHEN** parser='html' or default
- **THEN** system uses fault-tolerant HTML parser

#### Scenario: Use XML parser
- **WHEN** parser='xml'
- **THEN** system uses strict XML parser

#### Scenario: Use HTML5 parser
- **WHEN** parser='html5'
- **THEN** system uses HTML5 standard parsing

#### Scenario: Use html_fragments parser
- **WHEN** parser='html_fragments'
- **THEN** system parses HTML fragment without document root

#### Scenario: Use soup parser
- **WHEN** parser='soup'
- **THEN** system uses BeautifulSoup-compatible parsing

### Requirement: Load HTML/XML from file
The system SHALL support loading documents from local files.

#### Scenario: Load from file
- **WHEN** user creates PyQuery(filename='path/to/file.html')
- **THEN** system reads and parses the file

#### Scenario: Specify encoding
- **WHEN** user provides encoding parameter
- **THEN** system uses specified encoding to read file

### Requirement: Load HTML/XML from URL
The system SHALL support loading documents from HTTP/HTTPS URLs.

#### Scenario: Load from URL
- **WHEN** user creates PyQuery(url='http://example.com')
- **THEN** system fetches and parses the URL content

#### Scenario: Custom opener function
- **WHEN** user provides custom opener function
- **THEN** system uses custom opener to fetch URL

### Requirement: Load from lxml elements
The system SHALL support wrapping existing lxml elements.

#### Scenario: Wrap lxml element
- **WHEN** user creates PyQuery(etree_element)
- **THEN** system wraps the element for PyQuery API access

### Requirement: fromstring() function for string parsing
The system SHALL provide fromstring() function for parsing HTML/XML strings.

#### Scenario: Parse string with fromstring
- **WHEN** user calls fromstring(html_string, parser='html')
- **THEN** system parses and returns list of DOM elements

#### Scenario: Auto-detect parser
- **WHEN** user calls fromstring without parser parameter
- **THEN** system intelligently selects appropriate parser

### Requirement: Support custom parser functions
The system SHALL allow custom parser functions via custom_parser parameter.

#### Scenario: Use custom parser
- **WHEN** user provides custom_parser callable
- **THEN** system uses custom function to parse content

### Requirement: Automatic encoding handling
The system SHALL automatically detect and handle document encoding.

#### Scenario: Detect UTF-8 encoding
- **WHEN** document declares UTF-8 encoding
- **THEN** system correctly parses Unicode characters

#### Scenario: Handle encoding in meta tag
- **WHEN** HTML contains meta charset tag
- **THEN** system respects declared encoding
