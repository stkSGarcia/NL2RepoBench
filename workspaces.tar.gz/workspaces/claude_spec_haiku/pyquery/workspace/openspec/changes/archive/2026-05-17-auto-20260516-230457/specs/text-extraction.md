## ADDED Requirements

### Requirement: Intelligent text extraction from DOM
The system SHALL extract text from DOM elements with intelligent handling of different tag types.

#### Scenario: Extract from mixed inline/block content
- **WHEN** DOM contains mix of inline and block elements
- **THEN** system extracts text with proper formatting

#### Scenario: Handle inline tags correctly
- **WHEN** DOM contains inline tags (span, em, strong, a)
- **THEN** system concatenates text without adding breaks

#### Scenario: Handle block tags correctly
- **WHEN** DOM contains block tags (div, p, h1, section)
- **THEN** system adds newlines around block elements

### Requirement: Separator tag handling
The system SHALL handle separator tags like <br> specially during text extraction.

#### Scenario: Handle BR tags
- **WHEN** DOM contains <br> elements
- **THEN** system inserts newline for each br

#### Scenario: Handle multiple separators
- **WHEN** DOM contains multiple consecutive <br> tags
- **THEN** system preserves each newline (may have empty lines)

### Requirement: Whitespace squashing option
The system SHALL support squash_space parameter to control whitespace handling.

#### Scenario: Squash whitespace
- **WHEN** user calls text(squash_space=True)
- **THEN** system collapses multiple whitespace to single space

#### Scenario: Preserve whitespace
- **WHEN** user calls text(squash_space=False)
- **THEN** system preserves original whitespace

### Requirement: Comment node filtering
The system SHALL ignore HTML comments during text extraction.

#### Scenario: Ignore comments
- **WHEN** DOM contains HTML comments
- **THEN** system excludes comment text from result

### Requirement: HTML entity decoding
The system SHALL properly decode HTML character entities.

#### Scenario: Decode entities
- **WHEN** DOM contains &amp;, &lt;, &gt; entities
- **THEN** system converts to actual characters (&, <, >)

### Requirement: Extract from complex DOM structures
The system SHALL handle complex nested DOM structures correctly.

#### Scenario: Extract from deeply nested elements
- **WHEN** DOM has multiple levels of nesting
- **THEN** system correctly extracts all text content

#### Scenario: Handle text nodes and element nodes
- **WHEN** DOM contains both text nodes and element nodes
- **THEN** system includes all text appropriately
