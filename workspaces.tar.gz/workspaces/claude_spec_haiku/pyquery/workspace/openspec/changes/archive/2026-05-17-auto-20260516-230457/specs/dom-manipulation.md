## ADDED Requirements

### Requirement: append() method to add content as last child
The system SHALL support append() method to add HTML content as the last child of each element.

#### Scenario: Append HTML string
- **WHEN** user calls append('<span>new</span>') on an element
- **THEN** system adds the span as the last child

#### Scenario: Append PyQuery object
- **WHEN** user calls append(pq_obj) on an element
- **THEN** system adds the PyQuery object's elements as last children

### Requirement: prepend() method to add content as first child
The system SHALL support prepend() method to add HTML content as the first child of each element.

#### Scenario: Prepend HTML string
- **WHEN** user calls prepend('<span>new</span>') on an element
- **THEN** system adds the span as the first child

### Requirement: append_to() and prepend_to() methods for reverse insertion
The system SHALL support append_to() and prepend_to() methods to append/prepend selected elements to a target.

#### Scenario: Append selected to target
- **WHEN** user calls append_to('.container') on a selection
- **THEN** system moves the selection to be last children of .container elements

### Requirement: after() method to insert after element
The system SHALL support after() method to insert HTML content after each element (as next sibling).

#### Scenario: Insert after element
- **WHEN** user calls after('<span>after</span>') on an element
- **THEN** system inserts the span as the next sibling

### Requirement: before() method to insert before element
The system SHALL support before() method to insert HTML content before each element (as previous sibling).

#### Scenario: Insert before element
- **WHEN** user calls before('<span>before</span>') on an element
- **THEN** system inserts the span as the previous sibling

### Requirement: insert_after() and insert_before() methods for reverse insertion
The system SHALL support insert_after() and insert_before() methods to insert selected elements relative to a target.

#### Scenario: Insert after target
- **WHEN** user calls insert_after('.marker') on a selection
- **THEN** system inserts the selection as siblings after .marker elements

### Requirement: wrap() method to wrap each element individually
The system SHALL support wrap() method to wrap each element in HTML structure.

#### Scenario: Wrap individual elements
- **WHEN** user calls wrap('<div class="wrapper"></div>') on multiple elements
- **THEN** system creates a separate wrapper for each element

### Requirement: wrap_all() method to wrap all elements with single wrapper
The system SHALL support wrap_all() method to wrap all elements collectively in a single structure.

#### Scenario: Wrap all elements together
- **WHEN** user calls wrap_all('<div id="wrapper"></div>') on multiple elements
- **THEN** system creates one wrapper containing all elements

### Requirement: replace_with() method to replace elements with content
The system SHALL support replace_with() method to replace selected elements with new content.

#### Scenario: Replace with HTML string
- **WHEN** user calls replace_with('<div>replacement</div>') on an element
- **THEN** system replaces the element with the new content

#### Scenario: Replace with function
- **WHEN** user calls replace_with(lambda i, el: ...) on elements
- **THEN** system executes function for each element, replaces with result

### Requirement: replace_all() method for reverse replacement
The system SHALL support replace_all() method to replace all matching target elements with selected elements.

#### Scenario: Replace all targets
- **WHEN** user calls replace_all('.old') on new elements
- **THEN** system replaces all .old elements with the new elements

### Requirement: remove() method to delete elements
The system SHALL support remove() method to remove selected elements from the DOM.

#### Scenario: Remove elements
- **WHEN** user calls remove() on elements
- **THEN** system deletes the elements from the DOM tree

#### Scenario: Remove with selector filter
- **WHEN** user calls remove('.temp') on elements
- **THEN** system removes only elements matching the selector

### Requirement: empty() method to remove children
The system SHALL support empty() method to remove all child content from elements while keeping the elements themselves.

#### Scenario: Empty element content
- **WHEN** user calls empty() on an element
- **THEN** system removes all child nodes but keeps the element

### Requirement: clone() method for deep cloning
The system SHALL support clone() method to create a deep copy of selected elements.

#### Scenario: Clone elements
- **WHEN** user calls clone() on elements
- **THEN** system returns new PyQuery with cloned copies, independent of originals

### Requirement: Method chaining for manipulation operations
The system SHALL return PyQuery objects from manipulation methods to enable chaining.

#### Scenario: Chain manipulation operations
- **WHEN** user calls append(...).wrap(...).addClass(...)
- **THEN** system chains the operations and returns final PyQuery object
