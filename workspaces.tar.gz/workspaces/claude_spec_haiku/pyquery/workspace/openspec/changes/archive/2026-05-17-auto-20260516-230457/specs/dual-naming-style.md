## ADDED Requirements

### Requirement: Python snake_case naming convention
The system SHALL provide all methods in Python snake_case naming style.

#### Scenario: Call snake_case method
- **WHEN** user calls remove_class() or next_all()
- **THEN** system executes the operation

### Requirement: jQuery camelCase naming aliases
The system SHALL provide jQuery-style camelCase aliases for all public methods.

#### Scenario: Call camelCase alias
- **WHEN** user calls removeClass() or nextAll()
- **THEN** system executes the same operation

#### Scenario: Both styles have identical functionality
- **WHEN** user calls snake_case vs camelCase versions
- **THEN** system returns identical results

### Requirement: Traversal method aliases
The system SHALL provide camelCase aliases for all traversal methods.

#### Scenario: Traversal camelCase aliases
- **WHEN** user calls nextAll(), prevAll(), nextUntil()
- **THEN** system executes same as next_all(), prev_all(), next_until()

### Requirement: DOM manipulation method aliases
The system SHALL provide camelCase aliases for all DOM manipulation methods.

#### Scenario: Manipulation camelCase aliases
- **WHEN** user calls append(), appendChild(), replaceWith()
- **THEN** system executes same as append(), append_to(), replace_with()

### Requirement: Attribute/CSS method aliases
The system SHALL provide camelCase aliases for attribute and CSS methods.

#### Scenario: Attribute method aliases
- **WHEN** user calls removeAttr(), addClass(), removeClass()
- **THEN** system executes same as remove_attr(), add_class(), remove_class()

#### Scenario: CSS method aliases
- **WHEN** user calls toggleClass(), hasClass()
- **THEN** system executes same as toggle_class(), has_class()

### Requirement: Form method aliases
The system SHALL provide camelCase aliases for form-related methods.

#### Scenario: Form method aliases
- **WHEN** user calls serializeArray(), serializePairs(), serializeDict()
- **THEN** system executes same as serialize_array(), serialize_pairs(), serialize_dict()

### Requirement: Automatic alias generation via decorator
The system SHALL use decorator pattern to generate aliases automatically.

#### Scenario: Decorator creates alias
- **WHEN** method is decorated with @with_camel_case_alias
- **THEN** system automatically creates camelCase version

### Requirement: Consistency across API
The system SHALL ensure consistent naming across all methods.

#### Scenario: Consistent naming for related methods
- **WHEN** methods are related (like next/nextAll)
- **THEN** system provides both snake_case and camelCase for all
