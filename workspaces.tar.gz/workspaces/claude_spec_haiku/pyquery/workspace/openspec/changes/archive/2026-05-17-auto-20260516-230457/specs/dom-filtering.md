## ADDED Requirements

### Requirement: filter() method to filter elements by selector or function
The system SHALL support filter() method to reduce the selection to elements matching a CSS selector or function.

#### Scenario: Filter by CSS selector
- **WHEN** user calls filter('.active') on a selection
- **THEN** system returns only elements matching .active

#### Scenario: Filter by function
- **WHEN** user calls filter(lambda i: i == 0) on a selection
- **THEN** system executes the function for each element and returns those where function is truthy

#### Scenario: Filter with index and element in function
- **WHEN** user calls filter(lambda i, el: ...) on a selection
- **THEN** system passes both index and element to the function

### Requirement: not_() method to exclude matching elements
The system SHALL support not_() method to exclude elements matching a CSS selector.

#### Scenario: Exclude by selector
- **WHEN** user calls not_('.disabled') on a selection
- **THEN** system returns elements not matching .disabled

### Requirement: is_() method to test if elements match selector
The system SHALL support is_() method to test if any selected element matches a selector.

#### Scenario: Test selector match
- **WHEN** user calls is_('.highlight') on a selection
- **THEN** system returns True if any element matches, False otherwise

### Requirement: eq() method to select element by index
The system SHALL support eq() method to select a single element at a specific index.

#### Scenario: Select by positive index
- **WHEN** user calls eq(0) on a selection
- **THEN** system returns a new selection with only the element at index 0

#### Scenario: Select by negative index
- **WHEN** user calls eq(-1) on a selection
- **THEN** system returns a new selection with the last element

#### Scenario: Out of bounds index
- **WHEN** user calls eq(100) on a selection with fewer than 100 elements
- **THEN** system returns an empty selection

### Requirement: each() method to iterate with callback
The system SHALL support each() method to execute a callback function for each element, supporting the 'this' keyword.

#### Scenario: Execute callback on each element
- **WHEN** user calls each(lambda: ...) on a selection
- **THEN** system executes the function once per element, with 'this' bound to current element

#### Scenario: Callback with index
- **WHEN** user calls each(lambda i: ...) on a selection
- **THEN** system passes the index to the callback

#### Scenario: Callback with index and element
- **WHEN** user calls each(lambda i, el: ...) on a selection
- **THEN** system passes both index and element to the callback

### Requirement: map() method to transform elements
The system SHALL support map() method to transform each element using a callback function.

#### Scenario: Map elements to values
- **WHEN** user calls map(lambda i, el: pq(el).text()) on a selection
- **THEN** system returns a list of transformed values

#### Scenario: Map with this keyword
- **WHEN** user calls map(lambda i, el: pq(this).text()) on a selection
- **THEN** system binds 'this' to current element and returns list of values

### Requirement: items() method to iterate as PyQuery objects
The system SHALL support items() method to iterate over selected elements, yielding PyQuery objects.

#### Scenario: Iterate as PyQuery objects
- **WHEN** user iterates using items()
- **THEN** system yields each element wrapped as a PyQuery object

#### Scenario: Filter items during iteration
- **WHEN** user calls items('span') on a selection
- **THEN** system first selects descendants matching 'span', then iterates as PyQuery objects
