## ADDED Requirements

### Requirement: Support CSS selector querying with element, class, and ID selectors
The system SHALL support basic CSS selectors including element names, class selectors, and ID selectors to select elements from HTML/XML documents.

#### Scenario: Select by element name
- **WHEN** user queries with selector 'div'
- **THEN** system returns all div elements

#### Scenario: Select by class name
- **WHEN** user queries with selector '.classname'
- **THEN** system returns all elements with that class

#### Scenario: Select by ID
- **WHEN** user queries with selector '#idname'
- **THEN** system returns the element with that ID

### Requirement: Support combined CSS selectors (descendant, child, adjacent sibling)
The system SHALL support CSS combinator selectors to find elements based on their relationship to other elements.

#### Scenario: Descendant selector
- **WHEN** user queries with selector 'div p'
- **THEN** system returns all p elements that are descendants of div

#### Scenario: Child selector
- **WHEN** user queries with selector 'div > p'
- **THEN** system returns all p elements that are direct children of div

#### Scenario: Adjacent sibling selector
- **WHEN** user queries with selector 'p + span'
- **THEN** system returns all span elements immediately following p elements

### Requirement: Support attribute selectors
The system SHALL support CSS attribute selectors to select elements based on attribute values.

#### Scenario: Select by attribute existence
- **WHEN** user queries with selector '[href]'
- **THEN** system returns all elements with an href attribute

#### Scenario: Select by attribute value
- **WHEN** user queries with selector '[type="text"]'
- **THEN** system returns all elements with type attribute equal to 'text'

#### Scenario: Select by attribute substring match
- **WHEN** user queries with selector '[class*="highlight"]'
- **THEN** system returns all elements with 'highlight' in their class attribute

### Requirement: Support jQuery :first pseudo-class
The system SHALL support :first pseudo-class to select the first matching element.

#### Scenario: Select first element
- **WHEN** user queries with selector 'p:first'
- **THEN** system returns only the first p element

### Requirement: Support jQuery :last pseudo-class
The system SHALL support :last pseudo-class to select the last matching element.

#### Scenario: Select last element
- **WHEN** user queries with selector 'p:last'
- **THEN** system returns only the last p element

### Requirement: Support jQuery :even pseudo-class
The system SHALL support :even pseudo-class to select elements at even indices (0-indexed).

#### Scenario: Select even-indexed elements
- **WHEN** user queries with selector 'p:even'
- **THEN** system returns p elements at indices 0, 2, 4, etc.

### Requirement: Support jQuery :odd pseudo-class
The system SHALL support :odd pseudo-class to select elements at odd indices (0-indexed).

#### Scenario: Select odd-indexed elements
- **WHEN** user queries with selector 'p:odd'
- **THEN** system returns p elements at indices 1, 3, 5, etc.

### Requirement: Support jQuery :eq(n) pseudo-class
The system SHALL support :eq(n) pseudo-class function to select an element at a specific index.

#### Scenario: Select element by index
- **WHEN** user queries with selector 'p:eq(2)'
- **THEN** system returns the p element at index 2

### Requirement: Support jQuery :lt(n) and :gt(n) pseudo-classes
The system SHALL support :lt(n) and :gt(n) pseudo-class functions to select elements by index range.

#### Scenario: Select elements with index less than n
- **WHEN** user queries with selector 'p:lt(3)'
- **THEN** system returns p elements at indices 0, 1, 2

#### Scenario: Select elements with index greater than n
- **WHEN** user queries with selector 'p:gt(1)'
- **THEN** system returns p elements at indices 2, 3, 4, etc.

### Requirement: Support jQuery :contains(text) pseudo-class
The system SHALL support :contains(text) pseudo-class function to select elements containing specific text.

#### Scenario: Select elements by text content
- **WHEN** user queries with selector 'p:contains("hello")'
- **THEN** system returns all p elements containing 'hello'

### Requirement: Support jQuery :checked pseudo-class
The system SHALL support :checked pseudo-class to select checked form elements.

#### Scenario: Select checked checkboxes
- **WHEN** user queries with selector 'input:checked'
- **THEN** system returns all checked input elements

### Requirement: Support jQuery :selected pseudo-class
The system SHALL support :selected pseudo-class to select selected option elements.

#### Scenario: Select selected options
- **WHEN** user queries with selector 'option:selected'
- **THEN** system returns all selected option elements

### Requirement: Support jQuery :disabled and :enabled pseudo-classes
The system SHALL support :disabled and :enabled pseudo-classes to select form elements by enabled/disabled state, following WHATWG spec rules for fieldset disabling.

#### Scenario: Select disabled elements
- **WHEN** user queries with selector 'input:disabled'
- **THEN** system returns all disabled input elements including those in disabled fieldsets

#### Scenario: Select enabled elements
- **WHEN** user queries with selector 'input:enabled'
- **THEN** system returns all enabled input elements not in disabled fieldsets

### Requirement: Support jQuery input type pseudo-classes
The system SHALL support :file, :text, :password, :checkbox, :radio, :submit, :reset, :hidden, :image, :button pseudo-classes for selecting input elements by type.

#### Scenario: Select text inputs
- **WHEN** user queries with selector 'input:text'
- **THEN** system returns all input elements with type='text'

#### Scenario: Select file inputs
- **WHEN** user queries with selector 'input:file'
- **THEN** system returns all input elements with type='file'

### Requirement: Support jQuery :input, :button, :radio, :checkbox pseudo-classes
The system SHALL support :input (all form controls), :button, :radio, :checkbox pseudo-classes to select groups of form elements.

#### Scenario: Select all form controls
- **WHEN** user queries with selector ':input'
- **THEN** system returns all form control elements (input, textarea, select, button)

#### Scenario: Select button controls
- **WHEN** user queries with selector ':button'
- **THEN** system returns all button input elements and button elements

### Requirement: Support jQuery :header pseudo-class
The system SHALL support :header pseudo-class to select heading elements (h1-h6).

#### Scenario: Select heading elements
- **WHEN** user queries with selector ':header'
- **THEN** system returns all h1, h2, h3, h4, h5, h6 elements

### Requirement: Support jQuery :parent and :empty pseudo-classes
The system SHALL support :parent (elements with children) and :empty (elements without children) pseudo-classes.

#### Scenario: Select elements with children
- **WHEN** user queries with selector 'div:parent'
- **THEN** system returns all div elements that contain other elements

#### Scenario: Select empty elements
- **WHEN** user queries with selector 'div:empty'
- **THEN** system returns all div elements without child elements or text

### Requirement: Support jQuery :has(selector) pseudo-class
The system SHALL support :has(selector) pseudo-class function to select elements containing matching descendant elements.

#### Scenario: Select elements with descendant match
- **WHEN** user queries with selector 'div:has(".highlight")'
- **THEN** system returns all div elements containing elements with class 'highlight'

### Requirement: CSS to XPath translation with custom jQuery translator
The system SHALL translate CSS selectors to XPath expressions using a custom JQueryTranslator class that extends cssselect's translator.

#### Scenario: Selector translation
- **WHEN** user provides CSS selector
- **THEN** system converts it to XPath and executes against lxml document
