## ADDED Requirements

### Requirement: find() method for locating descendant elements
The system SHALL support the find() method to search for descendant elements matching a CSS selector.

#### Scenario: Find descendants by selector
- **WHEN** user calls find('span') on a parent element
- **THEN** system returns all span descendants of that element

### Requirement: children() method for direct children
The system SHALL support the children() method to get direct child elements, optionally filtered by selector.

#### Scenario: Get all direct children
- **WHEN** user calls children() on an element
- **THEN** system returns all direct child elements

#### Scenario: Filter children by selector
- **WHEN** user calls children('.highlight') on an element
- **THEN** system returns only direct children matching the selector

### Requirement: parent() method for parent element
The system SHALL support the parent() method to get the parent element of the first selected element.

#### Scenario: Get parent element
- **WHEN** user calls parent() on an element
- **THEN** system returns the parent element

#### Scenario: Filter parent by selector
- **WHEN** user calls parent('.container') on an element
- **THEN** system returns parent only if it matches the selector, else empty

### Requirement: siblings() method for sibling elements
The system SHALL support the siblings() method to get all sibling elements, optionally filtered by selector.

#### Scenario: Get all siblings
- **WHEN** user calls siblings() on an element
- **THEN** system returns all sibling elements (excluding the element itself)

#### Scenario: Filter siblings by selector
- **WHEN** user calls siblings('p') on an element
- **THEN** system returns only sibling p elements

### Requirement: next() and prev() methods for adjacent siblings
The system SHALL support next() and prev() methods to get the immediately next or previous sibling element.

#### Scenario: Get next sibling
- **WHEN** user calls next() on an element
- **THEN** system returns the immediately following sibling

#### Scenario: Get previous sibling
- **WHEN** user calls prev() on an element
- **THEN** system returns the immediately preceding sibling

### Requirement: next_all() and prev_all() methods for all subsequent/preceding siblings
The system SHALL support next_all() and prev_all() methods to get all following or preceding siblings.

#### Scenario: Get all next siblings
- **WHEN** user calls next_all() on an element
- **THEN** system returns all following sibling elements

#### Scenario: Get all previous siblings
- **WHEN** user calls prev_all() on an element
- **THEN** system returns all preceding sibling elements

### Requirement: next_until() method for siblings until condition
The system SHALL support next_until(selector, filter=None) to get siblings until a matching element is found.

#### Scenario: Get siblings until match
- **WHEN** user calls next_until('h2') on an element
- **THEN** system returns all siblings until an h2 element (not including the h2)

#### Scenario: Filter siblings until match
- **WHEN** user calls next_until('h2', ':not(.skip)') on an element
- **THEN** system returns siblings until h2, filtered to exclude .skip elements

### Requirement: parents() method for all ancestor elements
The system SHALL support parents() method to get all ancestor elements, optionally filtered by selector.

#### Scenario: Get all ancestors
- **WHEN** user calls parents() on an element
- **THEN** system returns all ancestor elements up to root

#### Scenario: Filter ancestors by selector
- **WHEN** user calls parents('.container') on an element
- **THEN** system returns only ancestor elements matching the selector

### Requirement: closest() method for nearest ancestor match
The system SHALL support closest() method to find the nearest ancestor matching a selector.

#### Scenario: Find nearest ancestor
- **WHEN** user calls closest('.modal') on an element
- **THEN** system returns the nearest ancestor matching .modal, or empty if none

### Requirement: contents() method for all child nodes including text
The system SHALL support contents() method to get all child nodes including text nodes.

#### Scenario: Get all child nodes
- **WHEN** user calls contents() on an element
- **THEN** system returns list containing both element nodes and text nodes

### Requirement: end() method to break out of traversal chain
The system SHALL support end() method to return to the parent collection before the last traversal operation.

#### Scenario: Return to parent collection
- **WHEN** user calls find('span').end() on an element
- **THEN** system returns to the original element collection

### Requirement: Both snake_case and camelCase method naming
The system SHALL provide both snake_case (next_all) and camelCase (nextAll) method names for traversal methods.

#### Scenario: Use camelCase traversal method
- **WHEN** user calls nextAll() instead of next_all()
- **THEN** system executes the same operation
