## ADDED Requirements

### Requirement: url_opener() function for HTTP/HTTPS requests
The system SHALL provide url_opener() function to fetch content from URLs.

#### Scenario: Fetch from HTTP URL
- **WHEN** user calls url_opener('http://example.com')
- **THEN** system fetches and returns page content

#### Scenario: Fetch from HTTPS URL
- **WHEN** user calls url_opener('https://example.com')
- **THEN** system fetches and returns page content

#### Scenario: Handle redirect
- **WHEN** server returns redirect response
- **THEN** system follows redirect automatically

### Requirement: Support requests library for network requests
The system SHALL use requests library if installed for network requests.

#### Scenario: Use requests library
- **WHEN** requests library is installed
- **THEN** system uses requests for HTTP operations

#### Scenario: Fallback to urllib
- **WHEN** requests library is not installed
- **THEN** system falls back to urllib for compatibility

### Requirement: Custom opener support
The system SHALL allow custom opener functions for network requests.

#### Scenario: Use custom opener
- **WHEN** user provides custom opener function
- **THEN** system uses custom function to fetch URLs

### Requirement: Session management
The system SHALL support requests.Session objects for session management.

#### Scenario: Use session object
- **WHEN** user provides session parameter with requests.Session
- **THEN** system uses session for request handling

#### Scenario: Maintain cookies
- **WHEN** using session object
- **THEN** system maintains cookies across requests

### Requirement: Timeout configuration
The system SHALL support timeout settings for network requests.

#### Scenario: Default timeout
- **WHEN** no timeout specified
- **THEN** system uses DEFAULT_TIMEOUT (60 seconds)

#### Scenario: Custom timeout
- **WHEN** user specifies timeout parameter
- **THEN** system uses custom timeout value

### Requirement: GET and POST request support
The system SHALL support both GET and POST HTTP methods.

#### Scenario: GET request
- **WHEN** user creates PyQuery with method='get' and data
- **THEN** system sends GET request with URL parameters

#### Scenario: POST request
- **WHEN** user creates PyQuery with method='post' and data
- **THEN** system sends POST request with form data

### Requirement: Request parameters and headers
The system SHALL support passing request parameters and custom headers.

#### Scenario: Send request parameters
- **WHEN** user provides data parameter
- **THEN** system includes data in request

#### Scenario: Custom headers
- **WHEN** user provides headers parameter
- **THEN** system includes custom headers in request

### Requirement: make_links_absolute() method for URL resolution
The system SHALL provide make_links_absolute() method to convert relative links to absolute URLs.

#### Scenario: Convert relative link
- **WHEN** document has relative href
- **THEN** system converts to absolute URL using base_url

#### Scenario: Preserve absolute links
- **WHEN** document has absolute URL
- **THEN** system preserves as-is

### Requirement: base_url property for loaded URLs
The system SHALL set base_url property when loading from URL.

#### Scenario: Access base URL
- **WHEN** document loaded from URL
- **THEN** system provides base_url property with the URL
