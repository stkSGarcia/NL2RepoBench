#!/usr/bin/env python
from setuptools import setup, find_packages

with open('README.md', 'r', encoding='utf-8') as f:
    long_description = f.read()

setup(
    name='pyquery',
    version='1.0.0',
    description='PyQuery: A jQuery-like library for Python',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='PyQuery Contributors',
    author_email='info@pyquery.org',
    url='https://github.com/gawel/pyquery',
    packages=find_packages(),
    python_requires='>=3.7',
    install_requires=[
        'lxml>=2.1',
        'cssselect>=1.2.0',
    ],
    extras_require={
        'requests': ['requests>=2.20'],
        'dev': ['pytest>=7.0', 'pytest-cov>=3.0'],
    },
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: BSD License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Programming Language :: Python :: 3.12',
        'Programming Language :: Python :: 3.13',
    ],
)
