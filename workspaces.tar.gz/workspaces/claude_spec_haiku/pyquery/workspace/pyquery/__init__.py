__version__ = '1.0.0'

from .pyquery import PyQuery
from .pyquery import fromstring
from .openers import url_opener
from .pyquery import no_default

__all__ = ['PyQuery', 'fromstring', 'url_opener', 'no_default']
