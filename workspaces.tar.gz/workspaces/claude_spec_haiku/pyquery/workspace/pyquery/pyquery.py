import re
import copy
import inspect
import warnings
from urllib.parse import urljoin, urlparse
from io import StringIO

from lxml import etree
from lxml.html import HtmlElement, tostring, fromstring as lxml_html_fromstring, \
    document_fromstring, fragments_fromstring, html_to_xhtml, Element as HtmlElementClass
from lxml.etree import ElementBase
from cssselect import GenericTranslator, SelectorError

from .openers import url_opener
from .text import extract_text


class NoDefault:
    """Sentinel value to distinguish "no argument" from None"""
    def __repr__(self):
        return '<no_default>'


no_default = NoDefault()


class FlexibleElement:
    """Descriptor for flexible attribute/style access (attr.name or attr('name'))"""
    def __init__(self, method_name):
        self.method_name = method_name

    def __get__(self, obj, objtype=None):
        if obj is None:
            return self

        class FlexibleAccessor:
            def __init__(self, pq_obj, method):
                self.pq_obj = pq_obj
                self.method = method

            def __call__(self, name, value=no_default):
                if value is no_default:
                    return self.method(name)
                return self.method(name, value)

            def __getattr__(self, name):
                return self.method(name)

        return FlexibleAccessor(obj, getattr(obj, f'_{self.method_name}'))


class XPathExpr:
    """Extended XPath expression class"""
    def __init__(self, path, regex=None, flags=None):
        self.path = path
        self.regex = regex
        self.flags = flags

    def __repr__(self):
        return f'XPathExpr({self.path!r})'


def getargspec(func):
    """Get function argument specifications (handles Python 3.x)"""
    try:
        sig = inspect.signature(func)
        args = [p.name for p in sig.parameters.values()
                if p.kind in (inspect.Parameter.POSITIONAL_OR_KEYWORD,
                             inspect.Parameter.POSITIONAL_ONLY)]
        return args
    except (ValueError, TypeError):
        return []


def callback(func, *args, **kwargs):
    """Call a function with appropriate number of arguments"""
    if func is None:
        return None

    argspec = getargspec(func)
    num_args = len(argspec)

    if num_args == 0:
        return func()
    elif num_args == 1:
        return func(args[0] if args else kwargs.get('index'))
    elif num_args == 2:
        return func(args[0] if args else kwargs.get('index'),
                   args[1] if len(args) > 1 else kwargs.get('element'))
    else:
        return func(*args, **kwargs)


def with_camel_case_alias(method_name):
    """Decorator to add camelCase alias to a snake_case method"""
    def decorator(func):
        # Store original function
        func._snake_case_name = method_name
        func._camel_case_name = snake_to_camel(method_name)
        return func
    return decorator


def snake_to_camel(snake_str):
    """Convert snake_case to camelCase"""
    components = snake_str.split('_')
    return components[0] + ''.join(x.title() for x in components[1:])


def build_camel_case_aliases(cls):
    """Build camelCase aliases for all decorated methods"""
    for attr_name in dir(cls):
        attr = getattr(cls, attr_name)
        if callable(attr) and hasattr(attr, '_camel_case_name'):
            camel_name = attr._camel_case_name
            # Create alias
            setattr(cls, camel_name, attr)
    return cls


def fromstring(text, parser='html', encoding=None, base_url=None, **kwargs):
    """Parse HTML/XML string and return a PyQuery object

    Args:
        text: HTML/XML string to parse
        parser: Parser to use ('html', 'xml', 'html5', 'html_fragments', 'soup')
        encoding: Document encoding
        base_url: Base URL for relative links

    Returns:
        PyQuery object
    """
    if isinstance(text, PyQuery):
        return text

    # Handle bytes
    if isinstance(text, bytes):
        if encoding is None and hasattr(text, 'decode'):
            # Try to detect encoding from content
            try:
                text = text.decode('utf-8')
            except UnicodeDecodeError:
                try:
                    text = text.decode('latin-1')
                except:
                    text = text.decode('utf-8', errors='ignore')
        else:
            text = text.decode(encoding or 'utf-8', errors='ignore')

    # Handle empty string
    if not text or not text.strip():
        doc = lxml_html_fromstring('<div></div>')
    # Parse based on parser type
    elif parser == 'html':
        try:
            doc = lxml_html_fromstring(text)
        except Exception:
            doc = lxml_html_fromstring('<div></div>')
    elif parser == 'xml':
        try:
            text_bytes = text.encode('utf-8') if isinstance(text, str) else text
            doc = etree.fromstring(text_bytes)
        except (etree.XMLSyntaxError, Exception) as e:
            # Fallback for malformed XML - try wrapping in a root
            try:
                wrapped = f'<root>{text}</root>'
                text_bytes = wrapped.encode('utf-8') if isinstance(wrapped, str) else wrapped
                doc = etree.fromstring(text_bytes)
            except:
                # Last fallback - use HTML parser
                try:
                    doc = lxml_html_fromstring(text)
                except:
                    doc = lxml_html_fromstring('<div></div>')
    elif parser == 'html5':
        try:
            from lxml import html
            doc = html.fromstring(text)
        except:
            doc = lxml_html_fromstring(text)
    elif parser == 'html_fragments':
        docs = fragments_fromstring(text)
        if not docs:
            doc = lxml_html_fromstring('<div></div>')
        else:
            # Wrap fragments in a container
            container = HtmlElementClass('div')
            for frag in docs:
                if isinstance(frag, str):
                    if container.text is None:
                        container.text = frag
                    else:
                        container.text += frag
                else:
                    container.append(frag)
            doc = container
    elif parser == 'soup':
        try:
            from bs4 import BeautifulSoup
            soup = BeautifulSoup(text, 'html.parser')
            doc = etree.HTML(str(soup))
        except ImportError:
            doc = lxml_html_fromstring(text)
    else:
        doc = lxml_html_fromstring(text)

    if isinstance(doc, str):
        # If doc is still a string (shouldn't happen), wrap in HTML
        doc = lxml_html_fromstring(str(doc))

    return PyQuery([doc], base_url=base_url, **kwargs)


class PyQuery(list):
    """jQuery-like library for Python"""

    def __init__(self, *args, **kwargs):
        """Initialize PyQuery object

        Can be called with:
        - A CSS/XPath selector string (requires 'default' kwarg for context)
        - An HTML/XML string
        - A file path
        - A URL
        - An lxml element or list of elements
        """
        self.parent = None
        if 'parent' in kwargs:
            self.parent = kwargs.pop('parent')

        self.parser = kwargs.pop('parser', 'html')
        self._base_url = kwargs.pop('base_url', None)
        self.namespaces = kwargs.pop('namespaces', {})
        self._translator = None

        # Determine what was passed
        if not args:
            # Empty PyQuery
            list.__init__(self)
            return

        arg = args[0]

        # If it's already a PyQuery, copy it
        if isinstance(arg, PyQuery):
            list.__init__(self, arg)
            self.parser = arg.parser
            self._base_url = self._base_url or arg._base_url
            self.namespaces = arg.namespaces.copy() if arg.namespaces else {}
            return

        # Convert bytes to string
        if isinstance(arg, bytes):
            try:
                arg = arg.decode('utf-8')
            except UnicodeDecodeError:
                try:
                    arg = arg.decode('latin-1')
                except:
                    arg = arg.decode('utf-8', errors='ignore')

        # If it's a selector string
        if isinstance(arg, str) and not arg.strip().startswith(('<', '<?xml')):
            # It's a selector, need a context
            if 'default' in kwargs:
                context = kwargs['default']
                if isinstance(context, PyQuery):
                    result = context(arg)
                    list.__init__(self, result)
                    self.parser = context.parser
                    self._base_url = self._base_url or context._base_url
                    return
            else:
                # Treat as HTML/XML string
                pass

        # Parse HTML/XML string or load from file/URL
        if isinstance(arg, str):
            # Check if it's a URL
            if arg.startswith(('http://', 'https://')):
                try:
                    response = url_opener(arg, **kwargs)
                    if hasattr(response, 'read'):
                        response_text = response.read()
                        if isinstance(response_text, bytes):
                            response_text = response_text.decode('utf-8', errors='ignore')
                    else:
                        response_text = response
                    doc = fromstring(response_text, parser=self.parser, base_url=arg, **kwargs)
                    list.__init__(self, doc)
                    self._base_url = arg
                    return
                except Exception:
                    # Fallback to parsing as HTML
                    pass

            # Parse as HTML/XML
            doc = fromstring(arg, parser=self.parser, **kwargs)
            list.__init__(self, doc)
            return

        # Handle lxml elements
        if isinstance(arg, (ElementBase, HtmlElement)):
            list.__init__(self, [arg])
            return

        # Handle list of elements
        if isinstance(arg, (list, tuple)):
            list.__init__(self, arg)
            return

        # Fallback
        list.__init__(self)

    def _copy(self, elements=None):
        """Create a new PyQuery instance with given elements"""
        if elements is None:
            elements = self
        result = PyQuery.__new__(PyQuery)
        list.__init__(result, elements)
        result.parent = self.parent
        result.parser = self.parser
        result._base_url = self._base_url
        result.namespaces = self.namespaces.copy() if self.namespaces else {}
        return result

    def __call__(self, selector):
        """Create a sub-query (find elements matching selector)"""
        return self.find(selector)

    def __add__(self, other):
        """Combine PyQuery objects"""
        if isinstance(other, PyQuery):
            result = PyQuery(list(self) + list(other))
            result.parser = self.parser
            result._base_url = self._base_url
            result.namespaces = self.namespaces.copy() if self.namespaces else {}
            return result
        return NotImplemented

    def extend(self, other):
        """Extend PyQuery with more elements"""
        if isinstance(other, PyQuery):
            list.extend(self, other)
        else:
            list.extend(self, other)
        return self

    def __repr__(self):
        return f'[{", ".join(repr(e) for e in self)}]'

    def __str__(self):
        return self.__html__()

    def __unicode__(self):
        return self.__html__()

    def __html__(self):
        """Return HTML representation"""
        parts = []
        for el in self:
            if isinstance(el, str):
                parts.append(el)
            else:
                parts.append(tostring(el, encoding='unicode'))
        return ''.join(parts)

    @property
    def root(self):
        """Get the root element of the first element"""
        if not self:
            return None
        el = self[0]
        # Walk up to find root
        while el.getparent() is not None:
            el = el.getparent()
        return el

    @property
    def encoding(self):
        """Get document encoding"""
        if not self:
            return None
        root = self.root
        if root is None:
            return None
        # Get encoding from tree
        tree = root.getroottree()
        return tree.docinfo.encoding

    def find(self, selector):
        """Find elements matching selector"""
        result = []
        for el in self:
            xpath = self._css_to_xpath(selector)
            result.extend(el.xpath(xpath, namespaces=self.namespaces))
        return self._copy(result)

    def _css_to_xpath(self, selector):
        """Convert CSS selector to XPath"""
        from .cssselectpatch import JQueryTranslator
        translator = JQueryTranslator()
        try:
            return translator.css_to_xpath(selector)
        except SelectorError:
            # Fallback to basic selector handling
            return f"//{selector}"

    def children(self, selector=None):
        """Get direct children, optionally filtered by selector"""
        result = []
        for el in self:
            for child in el:
                if isinstance(child.tag, str):
                    result.append(child)

        if selector:
            return self._copy([el for el in result if self._matches_selector(el, selector)])
        return self._copy(result)

    def parent(self, selector=None):
        """Get parent element, optionally filtered by selector"""
        result = []
        seen = set()
        for el in self:
            parent = el.getparent()
            if parent is not None and id(parent) not in seen:
                seen.add(id(parent))
                result.append(parent)

        if selector:
            return self._copy([el for el in result if self._matches_selector(el, selector)])
        return self._copy(result)

    def parents(self, selector=None):
        """Get all ancestor elements, optionally filtered by selector"""
        result = []
        seen = set()
        for el in self:
            parent = el.getparent()
            while parent is not None:
                if id(parent) not in seen:
                    seen.add(id(parent))
                    result.append(parent)
                parent = parent.getparent()

        if selector:
            return self._copy([el for el in result if self._matches_selector(el, selector)])
        return self._copy(result)

    def siblings(self, selector=None):
        """Get sibling elements"""
        result = []
        seen = set()
        for el in self:
            parent = el.getparent()
            if parent is not None:
                for sibling in parent:
                    if sibling is not el and id(sibling) not in seen and isinstance(sibling.tag, str):
                        seen.add(id(sibling))
                        result.append(sibling)

        if selector:
            return self._copy([el for el in result if self._matches_selector(el, selector)])
        return self._copy(result)

    def next(self, selector=None):
        """Get next sibling"""
        result = []
        for el in self:
            next_el = el.getnext()
            if next_el is not None:
                result.append(next_el)

        if selector:
            return self._copy([el for el in result if self._matches_selector(el, selector)])
        return self._copy(result)

    def prev(self, selector=None):
        """Get previous sibling"""
        result = []
        for el in self:
            prev_el = el.getprevious()
            if prev_el is not None:
                result.append(prev_el)

        if selector:
            return self._copy([el for el in result if self._matches_selector(el, selector)])
        return self._copy(result)

    def next_all(self, selector=None):
        """Get all next siblings"""
        result = []
        seen = set()
        for el in self:
            next_el = el.getnext()
            while next_el is not None:
                if id(next_el) not in seen:
                    seen.add(id(next_el))
                    result.append(next_el)
                next_el = next_el.getnext()

        if selector:
            return self._copy([el for el in result if self._matches_selector(el, selector)])
        return self._copy(result)

    def prev_all(self, selector=None):
        """Get all previous siblings"""
        result = []
        seen = set()
        for el in self:
            prev_el = el.getprevious()
            while prev_el is not None:
                if id(prev_el) not in seen:
                    seen.add(id(prev_el))
                    result.append(prev_el)
                prev_el = prev_el.getprevious()

        if selector:
            return self._copy([el for el in result if self._matches_selector(el, selector)])
        return self._copy(result)

    def next_until(self, selector, filter_selector=None):
        """Get siblings until selector is matched"""
        result = []
        seen = set()
        for el in self:
            next_el = el.getnext()
            while next_el is not None:
                if self._matches_selector(next_el, selector):
                    break
                if id(next_el) not in seen:
                    seen.add(id(next_el))
                    result.append(next_el)
                next_el = next_el.getnext()

        if filter_selector:
            return self._copy([el for el in result if self._matches_selector(el, filter_selector)])
        return self._copy(result)

    def closest(self, selector):
        """Get closest ancestor matching selector"""
        result = []
        seen = set()
        for el in self:
            current = el
            while current is not None:
                if self._matches_selector(current, selector):
                    if id(current) not in seen:
                        seen.add(id(current))
                        result.append(current)
                    break
                current = current.getparent()
        return self._copy(result)

    def contents(self):
        """Get all child nodes (including text nodes)"""
        result = []
        for el in self:
            if el.text:
                result.append(el.text)
            for child in el:
                result.append(child)
                if child.tail:
                    result.append(child.tail)
        return self._copy(result)

    def end(self):
        """Break out of method chain, return parent"""
        return self.parent if self.parent is not None else self._copy([])

    def filter(self, selector_or_func):
        """Filter elements by selector or function"""
        if callable(selector_or_func):
            result = []
            for i, el in enumerate(self):
                if callback(selector_or_func, i, el):
                    result.append(el)
            return self._copy(result)
        else:
            result = [el for el in self if self._matches_selector(el, selector_or_func)]
            return self._copy(result)

    def not_(self, selector_or_func):
        """Exclude elements matching selector or function"""
        if callable(selector_or_func):
            result = []
            for i, el in enumerate(self):
                if not callback(selector_or_func, i, el):
                    result.append(el)
            return self._copy(result)
        else:
            result = [el for el in self if not self._matches_selector(el, selector_or_func)]
            return self._copy(result)

    def is_(self, selector):
        """Test if element matches selector"""
        if not self:
            return False
        return self._matches_selector(self[0], selector)

    def eq(self, index):
        """Select element by index"""
        if 0 <= index < len(self):
            return self._copy([self[index]])
        elif -len(self) <= index < 0:
            return self._copy([self[index]])
        return self._copy([])

    def each(self, func):
        """Iterate with callback"""
        for i, el in enumerate(self):
            callback(func, i, el)
        return self

    def map(self, func):
        """Transform elements with callback"""
        result = []
        for i, el in enumerate(self):
            result.append(callback(func, i, el))
        return result

    def items(self):
        """Iterate elements as PyQuery objects"""
        for el in self:
            yield self._copy([el])

    def attr(self, name=None, value=no_default):
        """Get or set attribute"""
        if name is None:
            return None

        if isinstance(name, dict):
            # Set multiple attributes
            for k, v in name.items():
                for el in self:
                    if v is None:
                        if k in el.attrib:
                            del el.attrib[k]
                    else:
                        el.set(k, str(v))
            return self

        if value is no_default:
            # Get attribute
            if not self:
                return None
            return self[0].get(name)

        # Set attribute
        for el in self:
            if value is None:
                if name in el.attrib:
                    del el.attrib[name]
            else:
                el.set(name, str(value))
        return self

    def remove_attr(self, name):
        """Remove attribute"""
        for el in self:
            if name in el.attrib:
                del el.attrib[name]
        return self

    def has_class(self, name):
        """Check if element has class"""
        if not self:
            return False
        classes = self[0].get('class', '').split()
        return name in classes

    def add_class(self, name):
        """Add class to elements"""
        for el in self:
            classes = el.get('class', '').split()
            if name not in classes:
                classes.append(name)
            el.set('class', ' '.join(classes))
        return self

    def remove_class(self, name):
        """Remove class from elements"""
        for el in self:
            classes = el.get('class', '').split()
            if name in classes:
                classes.remove(name)
            if classes:
                el.set('class', ' '.join(classes))
            else:
                if 'class' in el.attrib:
                    del el.attrib['class']
        return self

    def toggle_class(self, name):
        """Toggle class on elements"""
        for el in self:
            if self._element_has_class(el, name):
                classes = el.get('class', '').split()
                classes.remove(name)
                if classes:
                    el.set('class', ' '.join(classes))
                else:
                    if 'class' in el.attrib:
                        del el.attrib['class']
            else:
                classes = el.get('class', '').split()
                classes.append(name)
                el.set('class', ' '.join(classes))
        return self

    def _element_has_class(self, el, name):
        """Check if element has class"""
        classes = el.get('class', '').split()
        return name in classes

    def css(self, name=None, value=no_default):
        """Get or set CSS style"""
        if name is None:
            return None

        if isinstance(name, dict):
            # Set multiple styles
            for k, v in name.items():
                for el in self:
                    self._set_style(el, k, v)
            return self

        if value is no_default:
            # Get style
            if not self:
                return None
            return self._get_style(self[0], name)

        # Set style
        for el in self:
            self._set_style(el, name, value)
        return self

    def _get_style(self, el, name):
        """Get style value from element"""
        style = el.get('style', '')
        for part in style.split(';'):
            if ':' in part:
                key, val = part.split(':', 1)
                if key.strip().lower() == name.lower():
                    return val.strip()
        return None

    def _set_style(self, el, name, value):
        """Set style value on element"""
        style = el.get('style', '')
        styles = {}
        for part in style.split(';'):
            if ':' in part:
                key, val = part.split(':', 1)
                styles[key.strip().lower()] = val.strip()

        styles[name.lower()] = value
        style_str = '; '.join(f'{k}: {v}' for k, v in styles.items())
        el.set('style', style_str)

    def height(self, value=no_default):
        """Get or set height"""
        if value is no_default:
            return self.css('height')
        return self.css('height', value)

    def width(self, value=no_default):
        """Get or set width"""
        if value is no_default:
            return self.css('width')
        return self.css('width', value)

    def hide(self):
        """Hide elements"""
        return self.css('display', 'none')

    def show(self):
        """Show elements"""
        return self.css('display', 'block')

    def html(self, value=no_default):
        """Get or set inner HTML"""
        if value is no_default:
            # Get
            if not self:
                return None
            el = self[0]
            parts = []
            if el.text:
                parts.append(el.text)
            for child in el:
                parts.append(tostring(child, encoding='unicode'))
            return ''.join(parts)
        else:
            # Set
            for el in self:
                el.text = None
                el[:] = []
                # Parse the HTML
                if value:
                    try:
                        root = fromstring(f'<div>{value}</div>', parser=self.parser)
                        for child in root[0]:
                            el.append(child)
                        if root[0].text:
                            el.text = root[0].text
                    except:
                        el.text = value
            return self

    def text(self, value=no_default, squash_space=False):
        """Get or set text content"""
        if value is no_default:
            # Get
            if not self:
                return None
            parts = []
            for el in self:
                parts.append(self._get_text(el, squash_space))
            return ''.join(parts)
        else:
            # Set
            for el in self:
                el.text = str(value)
                el[:] = []
            return self

    def _get_text(self, el, squash_space=False):
        """Get text content from element"""
        text_parts = []
        if el.text:
            text_parts.append(el.text)
        for child in el:
            text_parts.append(self._get_text(child, squash_space))
            if child.tail:
                text_parts.append(child.tail)

        text = ''.join(text_parts)
        if squash_space:
            text = re.sub(r'\s+', ' ', text).strip()
        return text

    def outer_html(self):
        """Get full element HTML"""
        if not self:
            return None
        return tostring(self[0], encoding='unicode')

    def val(self, value=no_default):
        """Get or set form element value"""
        if value is no_default:
            # Get
            if not self:
                return None
            return self._get_value(self[0])
        else:
            # Set
            for el in self:
                self._set_value(el, value)
            return self

    def _get_value(self, el):
        """Get value from form element"""
        tag = el.tag.lower() if hasattr(el.tag, 'lower') else str(el.tag).lower()

        if tag == 'input':
            input_type = el.get('type', 'text').lower()
            if input_type in ('checkbox', 'radio'):
                return el.get('value') if el.get('checked') else None
            return el.get('value', '')
        elif tag == 'textarea':
            return el.text or ''
        elif tag == 'select':
            for option in el.xpath('.//option[@selected]'):
                return option.get('value', option.text or '')
            for option in el.xpath('.//option'):
                return option.get('value', option.text or '')
            return ''
        else:
            return el.get('value', '')

    def _set_value(self, el, value):
        """Set value on form element"""
        tag = el.tag.lower() if hasattr(el.tag, 'lower') else str(el.tag).lower()

        if tag == 'input':
            el.set('value', str(value) if value is not None else '')
        elif tag == 'textarea':
            el.text = str(value) if value is not None else ''
        elif tag == 'select':
            for option in el.xpath('.//option'):
                if option.get('value', option.text or '') == str(value):
                    option.set('selected', 'selected')
                else:
                    if 'selected' in option.attrib:
                        del option.attrib['selected']
        else:
            el.set('value', str(value) if value is not None else '')

    def append(self, content):
        """Append content as last child"""
        return self._insert_content(content, 'append')

    def prepend(self, content):
        """Prepend content as first child"""
        return self._insert_content(content, 'prepend')

    def after(self, content):
        """Insert content as next sibling"""
        return self._insert_content(content, 'after')

    def before(self, content):
        """Insert content as previous sibling"""
        return self._insert_content(content, 'before')

    def _insert_content(self, content, position):
        """Insert content in specified position"""
        if isinstance(content, PyQuery):
            content_el = list(content)
        elif isinstance(content, str):
            content_el = [el for el in fromstring(f'<div>{content}</div>', parser=self.parser)]
            if content_el:
                content_el = list(content_el[0])
        else:
            content_el = [content]

        for el in self:
            for item in content_el:
                if position == 'append':
                    el.append(copy.deepcopy(item))
                elif position == 'prepend':
                    el.insert(0, copy.deepcopy(item))
                elif position == 'after':
                    parent = el.getparent()
                    if parent is not None:
                        idx = list(parent).index(el)
                        parent.insert(idx + 1, copy.deepcopy(item))
                elif position == 'before':
                    parent = el.getparent()
                    if parent is not None:
                        idx = list(parent).index(el)
                        parent.insert(idx, copy.deepcopy(item))
        return self

    def append_to(self, target):
        """Append to target element"""
        target_el = PyQuery(target) if not isinstance(target, PyQuery) else target
        for el in self:
            for t in target_el:
                t.append(copy.deepcopy(el))
        return self

    def prepend_to(self, target):
        """Prepend to target element"""
        target_el = PyQuery(target) if not isinstance(target, PyQuery) else target
        for el in self:
            for t in target_el:
                t.insert(0, copy.deepcopy(el))
        return self

    def insert_after(self, target):
        """Insert after target element"""
        target_el = PyQuery(target) if not isinstance(target, PyQuery) else target
        for el in self:
            for t in target_el:
                parent = t.getparent()
                if parent is not None:
                    idx = list(parent).index(t)
                    parent.insert(idx + 1, copy.deepcopy(el))
        return self

    def insert_before(self, target):
        """Insert before target element"""
        target_el = PyQuery(target) if not isinstance(target, PyQuery) else target
        for el in self:
            for t in target_el:
                parent = t.getparent()
                if parent is not None:
                    idx = list(parent).index(t)
                    parent.insert(idx, copy.deepcopy(el))
        return self

    def wrap(self, wrapper):
        """Wrap each element individually"""
        for el in self:
            wrapper_el = PyQuery(wrapper, parser=self.parser)[0]
            parent = el.getparent()
            if parent is not None:
                idx = list(parent).index(el)
                parent.remove(el)
                parent.insert(idx, wrapper_el)
                wrapper_el.append(el)
            else:
                wrapper_el.append(el)
        return self

    def wrap_all(self, wrapper):
        """Wrap all elements collectively"""
        if not self:
            return self

        wrapper_el = PyQuery(wrapper, parser=self.parser)[0]
        first_el = self[0]
        parent = first_el.getparent()

        if parent is not None:
            idx = list(parent).index(first_el)
            parent.insert(idx, wrapper_el)

        for el in self:
            parent = el.getparent()
            if parent is wrapper_el:
                continue
            if parent is not None:
                parent.remove(el)
            wrapper_el.append(el)

        return self

    def replace_with(self, replacement):
        """Replace elements"""
        for el in self:
            replacement_el = PyQuery(replacement, parser=self.parser)[0]
            parent = el.getparent()
            if parent is not None:
                idx = list(parent).index(el)
                parent.remove(el)
                parent.insert(idx, replacement_el)
        return self

    def replace_all(self, target):
        """Replace all matching target elements"""
        target_el = PyQuery(target) if not isinstance(target, PyQuery) else target
        for t in target_el:
            parent = t.getparent()
            if parent is not None:
                idx = list(parent).index(t)
                parent.remove(t)
                for el in self:
                    parent.insert(idx, copy.deepcopy(el))
                    idx += 1
        return self

    def remove(self):
        """Remove elements"""
        for el in self:
            parent = el.getparent()
            if parent is not None:
                parent.remove(el)
        return self

    def empty(self):
        """Remove all children"""
        for el in self:
            el.text = None
            el[:] = []
        return self

    def clone(self):
        """Deep clone elements"""
        result = []
        for el in self:
            result.append(copy.deepcopy(el))
        return self._copy(result)

    def serialize(self):
        """Serialize form data to URL-encoded string"""
        pairs = self.serialize_pairs()
        return '&'.join(f'{k}={v}' for k, v in pairs)

    def serialize_array(self):
        """Serialize form data to list of dicts"""
        result = []
        for name, value in self.serialize_pairs():
            result.append({'name': name, 'value': value})
        return result

    def serialize_pairs(self):
        """Serialize form data to list of tuples"""
        result = []
        for el in self:
            self._serialize_element(el, result)
        return result

    def serialize_dict(self):
        """Serialize form data to dictionary"""
        result = {}
        for name, value in self.serialize_pairs():
            if name in result:
                if not isinstance(result[name], list):
                    result[name] = [result[name]]
                result[name].append(value)
            else:
                result[name] = value
        return result

    def _serialize_element(self, el, result):
        """Serialize form element"""
        tag = el.tag.lower() if hasattr(el.tag, 'lower') else str(el.tag).lower()

        if tag == 'form':
            for input_el in el.xpath('.//*[self::input or self::textarea or self::select]'):
                self._serialize_element(input_el, result)
        elif tag == 'input':
            input_type = el.get('type', 'text').lower()
            if input_type in ('checkbox', 'radio'):
                if el.get('checked'):
                    name = el.get('name')
                    if name:
                        result.append((name, el.get('value', 'on')))
            elif input_type != 'file':
                name = el.get('name')
                if name and not el.get('disabled'):
                    result.append((name, el.get('value', '')))
        elif tag == 'textarea':
            name = el.get('name')
            if name and not el.get('disabled'):
                result.append((name, el.text or ''))
        elif tag == 'select':
            name = el.get('name')
            if name and not el.get('disabled'):
                for option in el.xpath('.//option[@selected]'):
                    result.append((name, option.get('value', option.text or '')))
                if not el.xpath('.//option[@selected]'):
                    for option in el.xpath('.//option'):
                        result.append((name, option.get('value', option.text or '')))
                        break
        elif tag == 'button':
            input_type = el.get('type', 'submit').lower()
            if input_type == 'submit':
                name = el.get('name')
                if name and not el.get('disabled'):
                    result.append((name, el.get('value', el.text or '')))

    def xhtml_to_html(self):
        """Remove XHTML namespace"""
        for el in self:
            self._remove_xhtml_namespace(el)
        return self

    def _remove_xhtml_namespace(self, el):
        """Remove XHTML namespace from element"""
        if el.tag.startswith('{'):
            ns, tag = el.tag[1:].split('}', 1)
            if ns == 'http://www.w3.org/1999/xhtml':
                el.tag = tag
        for child in el:
            self._remove_xhtml_namespace(child)

    def remove_namespaces(self):
        """Remove all namespaces"""
        for el in self:
            self._strip_namespaces(el)
        return self

    def _strip_namespaces(self, el):
        """Strip namespaces from element"""
        if el.tag.startswith('{'):
            el.tag = el.tag.split('}', 1)[1]
        for child in el:
            self._strip_namespaces(child)

    @property
    def base_url(self):
        """Get base URL"""
        return self._base_url

    @base_url.setter
    def base_url(self, value):
        """Set base URL"""
        self._base_url = value

    def make_links_absolute(self, base_url=None):
        """Make all links absolute"""
        url = base_url or self._base_url
        if not url:
            return self

        for el in self:
            self._make_links_absolute_in_element(el, url)
        return self

    def _make_links_absolute_in_element(self, el, base_url):
        """Make links absolute in element"""
        for attr_name in ('href', 'src'):
            if attr_name in el.attrib:
                href = el.get(attr_name)
                if href:
                    el.set(attr_name, urljoin(base_url, href))

        for child in el:
            self._make_links_absolute_in_element(child, base_url)

    def _matches_selector(self, el, selector):
        """Check if element matches selector"""
        try:
            xpath = self._css_to_xpath(selector)
            parent = el.getparent()
            if parent is None:
                # Check on root element
                return el.xpath(f'self::{selector}', namespaces=self.namespaces)
            # Check element within parent
            return parent.xpath(f'.//{selector}[generate-id() = "{id(el)}"]', namespaces=self.namespaces)
        except:
            return False


# Add camelCase aliases
for attr_name in dir(PyQuery):
    attr = getattr(PyQuery, attr_name)
    if not attr_name.startswith('_') and callable(attr):
        # Create camelCase versions
        camel_name = snake_to_camel(attr_name)
        if camel_name != attr_name and not hasattr(PyQuery, camel_name):
            setattr(PyQuery, camel_name, attr)
