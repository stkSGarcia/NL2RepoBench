import sys
from urllib.request import urlopen, Request
from urllib.parse import urlencode
from io import BytesIO

DEFAULT_TIMEOUT = 60


def url_opener(url, method='GET', headers=None, timeout=DEFAULT_TIMEOUT,
               data=None, auth=None, verify=None, session=None, **kwargs):
    """Open URL and return response

    Args:
        url: URL to open
        method: HTTP method (GET, POST, etc.)
        headers: HTTP headers dict
        timeout: Request timeout in seconds
        data: Request body (for POST)
        auth: Authentication tuple (user, password)
        verify: SSL verification (for requests library)
        session: Session object (for requests library)

    Returns:
        Response object or file-like object
    """
    return _requests(url, method=method, headers=headers, timeout=timeout,
                    data=data, auth=auth, verify=verify, session=session, **kwargs)


def _requests(url, method='GET', headers=None, timeout=DEFAULT_TIMEOUT,
              data=None, auth=None, verify=None, session=None, **kwargs):
    """Try using requests library, fallback to urllib"""
    try:
        import requests

        req_kwargs = {
            'timeout': timeout,
        }

        if headers:
            req_kwargs['headers'] = headers

        if auth:
            req_kwargs['auth'] = auth

        if verify is not None:
            req_kwargs['verify'] = verify

        if method.upper() == 'GET':
            resp = requests.get(url, **req_kwargs)
        elif method.upper() == 'POST':
            if data:
                req_kwargs['data'] = data
            resp = requests.post(url, **req_kwargs)
        else:
            resp = requests.request(method, url, **req_kwargs)

        return resp

    except ImportError:
        # Fallback to urllib
        return _urllib(url, method=method, headers=headers, timeout=timeout,
                      data=data, auth=auth, **kwargs)


def _urllib(url, method='GET', headers=None, timeout=DEFAULT_TIMEOUT,
            data=None, auth=None, **kwargs):
    """Use urllib for requests (fallback)"""
    req_headers = headers or {}

    if auth:
        import base64
        user, password = auth
        credentials = base64.b64encode(f'{user}:{password}'.encode()).decode()
        req_headers['Authorization'] = f'Basic {credentials}'

    if method.upper() == 'POST' and data:
        if isinstance(data, dict):
            data = urlencode(data).encode('utf-8')
        elif isinstance(data, str):
            data = data.encode('utf-8')
        req = Request(url, data=data, headers=req_headers)
    else:
        req = Request(url, headers=req_headers)

    try:
        response = urlopen(req, timeout=timeout)
        # Return response content wrapped in BytesIO for compatibility
        content = response.read()
        response_file = BytesIO(content)
        response_file.encoding = response.headers.get('content-encoding', 'utf-8')
        return response_file
    except Exception as e:
        raise IOError(f'Failed to open {url}: {e}')


def _query(url, method='GET', **kwargs):
    """Build query string from kwargs"""
    if not kwargs:
        return url

    if method.upper() == 'GET':
        separator = '&' if '?' in url else '?'
        query_string = urlencode(kwargs)
        return f'{url}{separator}{query_string}'
    else:
        return url
