import re
from html import unescape

INLINE_TAGS = {
    'a', 'abbr', 'acronym', 'b', 'bdo', 'big', 'br', 'button', 'cite', 'code',
    'dfn', 'em', 'i', 'img', 'input', 'kbd', 'label', 'map', 'object', 'q',
    'samp', 'script', 'select', 'small', 'span', 'strong', 'sub', 'sup',
    'textarea', 'tt', 'var'
}

SEPARATORS = {
    'p': '\n',
    'div': '\n',
    'br': '\n',
    'blockquote': '\n',
    'pre': '\n',
    'table': '\n',
    'tr': '\n',
    'td': ' ',
    'th': ' ',
}

WHITESPACE_RE = re.compile(r'\s+')


def extract_text(element, squash_space=False):
    """Extract text content from element

    Args:
        element: lxml element
        squash_space: Whether to squash whitespace

    Returns:
        Extracted text string
    """
    text_parts = []
    _extract_text_impl(element, text_parts, squash_space)
    return ''.join(text_parts)


def extract_text_array(elements, squash_space=False):
    """Extract text from multiple elements

    Args:
        elements: List of lxml elements
        squash_space: Whether to squash whitespace

    Returns:
        List of text strings
    """
    result = []
    for el in elements:
        result.append(extract_text(el, squash_space))
    return result


def _extract_text_impl(element, parts, squash_space):
    """Implementation of text extraction"""
    tag = element.tag.lower() if hasattr(element.tag, 'lower') else str(element.tag).lower()

    # Add separator before block elements
    if tag in SEPARATORS:
        sep = SEPARATORS[tag]
        if parts and parts[-1] != sep:
            parts.append(sep)

    # Add element text
    if element.text:
        text = element.text
        if squash_space:
            text = WHITESPACE_RE.sub(' ', text).strip()
        if text:
            parts.append(text)

    # Process children
    for child in element:
        _extract_text_impl(child, parts, squash_space)
        # Add tail text after child
        if child.tail:
            text = child.tail
            if squash_space:
                text = WHITESPACE_RE.sub(' ', text).strip()
            if text:
                parts.append(text)

    # Add separator after block elements
    if tag in SEPARATORS:
        sep = SEPARATORS[tag]
        if parts and parts[-1] != sep:
            parts.append(sep)


def squash_html_whitespace(text):
    """Squash HTML whitespace in text

    Args:
        text: Text to squash

    Returns:
        Text with squashed whitespace
    """
    # Replace multiple whitespace with single space
    text = WHITESPACE_RE.sub(' ', text)
    # Strip leading/trailing whitespace
    text = text.strip()
    return text


def _squash_artifical_nl(text):
    """Remove artificial newlines (those added as separators)"""
    # This is a helper function for more sophisticated text extraction
    lines = text.split('\n')
    result = []
    for line in lines:
        line = line.strip()
        if line:
            result.append(line)
    return '\n'.join(result)


def _strip_artifical_nl(text):
    """Strip artificial newlines"""
    # Strip leading/trailing newlines
    return text.strip('\n')


def _merge_original_parts(parts):
    """Merge original text parts"""
    # This is for merging parts while preserving original structure
    return ''.join(parts)
