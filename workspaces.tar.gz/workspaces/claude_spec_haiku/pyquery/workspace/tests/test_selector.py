import pytest
from pyquery import PyQuery as pq


class TestBasicSelectors:
    """Test basic CSS selectors"""

    def test_element_selector(self):
        """Test selecting by element name"""
        html = '<div><p>Paragraph</p><span>Span</span></div>'
        d = pq(html)
        assert d('p').text() == 'Paragraph'
        assert d('span').text() == 'Span'

    def test_class_selector(self):
        """Test selecting by class"""
        html = '<div><p class="intro">Intro</p><p>Regular</p></div>'
        d = pq(html)
        assert len(d('.intro')) == 1
        assert d('.intro').text() == 'Intro'

    def test_id_selector(self):
        """Test selecting by ID"""
        html = '<div><p id="main">Main</p></div>'
        d = pq(html)
        assert d('#main').text() == 'Main'

    def test_attribute_selector(self):
        """Test attribute selectors"""
        html = '<div><input type="text" /><input type="password" /></div>'
        d = pq(html)
        assert len(d('[type="text"]')) == 1
        assert len(d('[type="password"]')) == 1

    def test_descendant_selector(self):
        """Test descendant selector"""
        html = '<div><p><span>Nested</span></p></div>'
        d = pq(html)
        assert len(d('p span')) == 1
        assert d('p span').text() == 'Nested'

    def test_child_selector(self):
        """Test child selector"""
        html = '<div><p><span>Child</span></p></div>'
        d = pq(html)
        assert len(d('p > span')) == 1

    def test_multiple_selector(self):
        """Test selecting multiple elements"""
        html = '<div><p>1</p><div>2</div><span>3</span></div>'
        d = pq(html)
        result = d('p, div, span')
        assert len(result) >= 3

    def test_universal_selector(self):
        """Test universal selector"""
        html = '<div><p>Test</p></div>'
        d = pq(html)
        result = d('*')
        assert len(result) > 0


class TestPseudoClassSelectors:
    """Test jQuery pseudo-class selectors"""

    def test_first_pseudo_class(self):
        """Test :first pseudo-class"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        result = d('p:first')
        assert len(result) >= 1
        assert '1' in result.text() or result.text() == '1'

    def test_last_pseudo_class(self):
        """Test :last pseudo-class"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        result = d('p:last')
        assert len(result) >= 1

    def test_even_pseudo_class(self):
        """Test :even pseudo-class"""
        html = '<div><p>1</p><p>2</p><p>3</p><p>4</p></div>'
        d = pq(html)
        result = d('p:even')
        # :even matches elements at even indices (0, 2, 4, ...)
        assert len(result) > 0

    def test_odd_pseudo_class(self):
        """Test :odd pseudo-class"""
        html = '<div><p>1</p><p>2</p><p>3</p><p>4</p></div>'
        d = pq(html)
        result = d('p:odd')
        # :odd matches elements at odd indices (1, 3, 5, ...)
        assert len(result) > 0

    def test_eq_pseudo_class(self):
        """Test :eq(n) pseudo-class"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        result = d('p:eq(1)')
        assert len(result) >= 1
        assert '2' in result.text() or result.text() == '2'

    def test_lt_pseudo_class(self):
        """Test :lt(n) pseudo-class"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        result = d('p:lt(2)')
        assert len(result) >= 1

    def test_gt_pseudo_class(self):
        """Test :gt(n) pseudo-class"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        result = d('p:gt(0)')
        assert len(result) >= 1

    def test_contains_pseudo_class(self):
        """Test :contains() pseudo-class"""
        html = '<div><p>Hello World</p><p>Goodbye</p></div>'
        d = pq(html)
        result = d('p:contains("Hello")')
        assert len(result) >= 1

    def test_empty_pseudo_class(self):
        """Test :empty pseudo-class"""
        html = '<div><p></p><p>Content</p></div>'
        d = pq(html)
        result = d('p:empty')
        assert len(result) >= 1

    def test_header_pseudo_class(self):
        """Test :header pseudo-class"""
        html = '<div><h1>Title</h1><h2>Subtitle</h2><p>Paragraph</p></div>'
        d = pq(html)
        result = d(':header')
        assert len(result) >= 2

    def test_parent_pseudo_class(self):
        """Test :parent pseudo-class"""
        html = '<div><p></p><div>Content</div></div>'
        d = pq(html)
        result = d(':parent')
        assert len(result) >= 1


class TestFormPseudoClasses:
    """Test form-related pseudo-classes"""

    def test_input_pseudo_class(self):
        """Test :input pseudo-class"""
        html = '<form><input /><textarea></textarea><select></select></form>'
        d = pq(html)
        result = d(':input')
        assert len(result) >= 1

    def test_text_pseudo_class(self):
        """Test :text pseudo-class"""
        html = '<form><input type="text" /><input type="password" /></form>'
        d = pq(html)
        result = d(':text')
        assert len(result) >= 1

    def test_password_pseudo_class(self):
        """Test :password pseudo-class"""
        html = '<form><input type="password" /></form>'
        d = pq(html)
        result = d(':password')
        assert len(result) >= 1

    def test_checkbox_pseudo_class(self):
        """Test :checkbox pseudo-class"""
        html = '<form><input type="checkbox" /></form>'
        d = pq(html)
        result = d(':checkbox')
        assert len(result) >= 1

    def test_radio_pseudo_class(self):
        """Test :radio pseudo-class"""
        html = '<form><input type="radio" /></form>'
        d = pq(html)
        result = d(':radio')
        assert len(result) >= 1

    def test_submit_pseudo_class(self):
        """Test :submit pseudo-class"""
        html = '<form><input type="submit" /></form>'
        d = pq(html)
        result = d(':submit')
        assert len(result) >= 1

    def test_button_pseudo_class(self):
        """Test :button pseudo-class"""
        html = '<form><button>Click</button></form>'
        d = pq(html)
        result = d(':button')
        assert len(result) >= 1

    def test_reset_pseudo_class(self):
        """Test :reset pseudo-class"""
        html = '<form><input type="reset" /></form>'
        d = pq(html)
        result = d(':reset')
        assert len(result) >= 1

    def test_image_pseudo_class(self):
        """Test :image pseudo-class"""
        html = '<form><input type="image" /></form>'
        d = pq(html)
        result = d(':image')
        assert len(result) >= 1

    def test_file_pseudo_class(self):
        """Test :file pseudo-class"""
        html = '<form><input type="file" /></form>'
        d = pq(html)
        result = d(':file')
        assert len(result) >= 1

    def test_checked_pseudo_class(self):
        """Test :checked pseudo-class"""
        html = '<form><input type="checkbox" checked /></form>'
        d = pq(html)
        result = d(':checked')
        assert len(result) >= 1

    def test_selected_pseudo_class(self):
        """Test :selected pseudo-class"""
        html = '<form><select><option selected>Option</option></select></form>'
        d = pq(html)
        result = d(':selected')
        assert len(result) >= 1

    def test_disabled_pseudo_class(self):
        """Test :disabled pseudo-class"""
        html = '<form><input disabled /><input /></form>'
        d = pq(html)
        result = d(':disabled')
        assert len(result) >= 1

    def test_enabled_pseudo_class(self):
        """Test :enabled pseudo-class"""
        html = '<form><input /><input disabled /></form>'
        d = pq(html)
        result = d(':enabled')
        assert len(result) >= 1


class TestComplexSelectors:
    """Test complex selector combinations"""

    def test_combined_selectors(self):
        """Test combining multiple selectors"""
        html = '<div><p class="intro">Intro</p><p id="main">Main</p></div>'
        d = pq(html)
        assert d('.intro').text() == 'Intro'
        assert d('#main').text() == 'Main'

    def test_nested_selectors(self):
        """Test nested selectors"""
        html = '<div class="outer"><div class="inner"><p>Content</p></div></div>'
        d = pq(html)
        result = d('.outer .inner p')
        assert result.text() == 'Content'
