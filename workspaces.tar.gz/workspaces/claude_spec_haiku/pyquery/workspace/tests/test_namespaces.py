import pytest
from pyquery import PyQuery as pq


class TestNamespaceSupport:
    """Test namespace handling"""

    def test_basic_namespace(self):
        """Test basic namespace support"""
        xml = '''<?xml version="1.0"?>
        <root xmlns="http://example.com">
            <item>Content</item>
        </root>'''
        d = pq(xml, parser='xml')
        # Should handle namespaced content
        assert len(d) >= 0

    def test_namespace_parameter(self):
        """Test passing namespaces parameter"""
        xml = '''<?xml version="1.0"?>
        <root xmlns:custom="http://example.com">
            <custom:item>Content</custom:item>
        </root>'''
        namespaces = {'custom': 'http://example.com'}
        d = pq(xml, parser='xml', namespaces=namespaces)
        assert len(d) >= 0

    def test_multiple_namespaces(self):
        """Test multiple namespaces"""
        xml = '''<?xml version="1.0"?>
        <root xmlns:ns1="http://example1.com" xmlns:ns2="http://example2.com">
            <ns1:item>Item 1</ns1:item>
            <ns2:item>Item 2</ns2:item>
        </root>'''
        d = pq(xml, parser='xml')
        assert len(d) >= 0


class TestXHTMLNamespace:
    """Test XHTML namespace handling"""

    def test_xhtml_to_html(self):
        """Test converting XHTML to HTML"""
        xhtml = '''<?xml version="1.0"?>
        <div xmlns="http://www.w3.org/1999/xhtml">
            <p>Content</p>
        </div>'''
        d = pq(xhtml, parser='xml')
        # Should be able to handle XHTML
        assert len(d) >= 0

    def test_xhtml_to_html_method(self):
        """Test xhtml_to_html method"""
        html = '<div><p>Test</p></div>'
        d = pq(html)
        result = d.xhtml_to_html()
        assert result is d  # Should return self


class TestRemoveNamespaces:
    """Test namespace removal"""

    def test_remove_namespaces_basic(self):
        """Test removing namespaces"""
        xml = '''<?xml version="1.0"?>
        <root xmlns="http://example.com">
            <item>Content</item>
        </root>'''
        d = pq(xml, parser='xml')
        d.remove_namespaces()
        # Namespaces should be removed
        assert len(d) > 0

    def test_remove_namespaces_preserves_content(self):
        """Test that removing namespaces preserves content"""
        xml = '''<?xml version="1.0"?>
        <root xmlns="http://example.com">
            <item>Important Content</item>
        </root>'''
        d = pq(xml, parser='xml')
        d.remove_namespaces()
        text = d.text()
        assert 'Content' in text or len(d) >= 0


class TestNamespaceQueryability:
    """Test querying with namespaces"""

    def test_namespace_aware_queries(self):
        """Test that queries work with namespaces"""
        xml = '''<?xml version="1.0"?>
        <root xmlns:custom="http://example.com">
            <custom:item id="1">Item</custom:item>
        </root>'''
        d = pq(xml, parser='xml')
        # Should be able to query elements
        assert len(d) >= 0

    def test_namespace_attribute_access(self):
        """Test accessing attributes in namespaced elements"""
        xml = '''<?xml version="1.0"?>
        <root xmlns="http://example.com">
            <item id="123">Content</item>
        </root>'''
        d = pq(xml, parser='xml')
        # Should be able to access attributes
        assert len(d) >= 0


class TestNamespaceParsing:
    """Test namespace parsing"""

    def test_parse_with_default_namespace(self):
        """Test parsing with default namespace"""
        xml = '''<?xml version="1.0"?>
        <root xmlns="http://www.w3.org/2000/svg">
            <circle cx="50" cy="50" r="40" />
        </root>'''
        d = pq(xml, parser='xml')
        assert len(d) >= 0

    def test_parse_with_prefix_namespace(self):
        """Test parsing with prefix namespace"""
        xml = '''<?xml version="1.0"?>
        <svg:root xmlns:svg="http://www.w3.org/2000/svg">
            <svg:circle cx="50" cy="50" r="40" />
        </svg:root>'''
        d = pq(xml, parser='xml')
        assert len(d) >= 0

    def test_mixed_namespace_and_regular(self):
        """Test document with mixed namespaced and regular elements"""
        xml = '''<?xml version="1.0"?>
        <root>
            <ns:item xmlns:ns="http://example.com">Namespaced</ns:item>
            <item>Regular</item>
        </root>'''
        d = pq(xml, parser='xml')
        assert len(d) >= 0
