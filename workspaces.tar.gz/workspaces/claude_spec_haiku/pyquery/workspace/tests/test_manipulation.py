import pytest
from pyquery import PyQuery as pq


class TestAppend:
    """Test append method"""

    def test_append_string(self):
        """Test appending string"""
        d = pq('<div></div>')
        d.append('<p>New</p>')
        assert 'New' in d.text()

    def test_append_element(self):
        """Test appending element"""
        d = pq('<div></div>')
        new_el = pq('<span>Added</span>')
        d.append(new_el)
        assert 'Added' in d.text()

    def test_append_multiple(self):
        """Test appending to multiple elements"""
        d = pq('<div></div><div></div>')
        d.append('<p>Test</p>')
        assert len(d) == 2


class TestPrepend:
    """Test prepend method"""

    def test_prepend_string(self):
        """Test prepending string"""
        d = pq('<div><p>Old</p></div>')
        d.prepend('<span>New</span>')
        text = d.text()
        assert 'New' in text

    def test_prepend_element(self):
        """Test prepending element"""
        d = pq('<div></div>')
        new_el = pq('<span>First</span>')
        d.prepend(new_el)
        assert 'First' in d.text()


class TestAfter:
    """Test after method"""

    def test_after_string(self):
        """Test inserting after"""
        d = pq('<div><p>First</p></div>')
        d('p').after('<p>Second</p>')
        paragraphs = d('p')
        assert len(paragraphs) >= 2

    def test_after_element(self):
        """Test after with element"""
        d = pq('<div><p>Content</p></div>')
        d('p').after('<span>After</span>')
        assert len(d('span')) >= 1


class TestBefore:
    """Test before method"""

    def test_before_string(self):
        """Test inserting before"""
        d = pq('<div><p>Original</p></div>')
        d('p').before('<p>Before</p>')
        paragraphs = d('p')
        assert len(paragraphs) >= 2

    def test_before_element(self):
        """Test before with element"""
        d = pq('<div><p>Content</p></div>')
        d('p').before('<span>Before</span>')
        assert len(d('span')) >= 1


class TestWrap:
    """Test wrap method"""

    def test_wrap_basic(self):
        """Test wrapping element"""
        d = pq('<div><p>Content</p></div>')
        d('p').wrap('<div class="wrapper"></div>')
        wrapper = d('.wrapper')
        assert len(wrapper) >= 1


class TestWrapAll:
    """Test wrap_all method"""

    def test_wrap_all_basic(self):
        """Test wrapping all elements"""
        d = pq('<div><p>1</p><p>2</p></div>')
        d('p').wrap_all('<section></section>')
        assert len(d('section')) >= 1


class TestRemoveMethod:
    """Test remove method"""

    def test_remove_element(self):
        """Test removing element"""
        d = pq('<div><p>Keep</p><p>Remove</p></div>')
        d('p').eq(1).remove()
        assert len(d('p')) == 1

    def test_remove_all(self):
        """Test removing all matching elements"""
        d = pq('<div><p>1</p><p>2</p></div>')
        d('p').remove()
        assert len(d('p')) == 0


class TestEmpty:
    """Test empty method"""

    def test_empty_children(self):
        """Test emptying element"""
        d = pq('<div><p>Content</p><span>More</span></div>')
        d.empty()
        assert len(d.text()) == 0

    def test_empty_multiple(self):
        """Test emptying multiple elements"""
        d = pq('<div><p>1</p></div><div><p>2</p></div>')
        d.empty()
        assert len(d('p')) == 0


class TestClone:
    """Test clone method"""

    def test_clone_basic(self):
        """Test cloning element"""
        d = pq('<div><p>Original</p></div>')
        cloned = d('p').clone()
        assert len(cloned) == 1
        assert cloned.text() == 'Original'

    def test_clone_independence(self):
        """Test that clone is independent"""
        d = pq('<div><p>Test</p></div>')
        cloned = d('p').clone()
        cloned.text('Modified')
        assert d('p').text() == 'Test'


class TestReplaceWith:
    """Test replace_with method"""

    def test_replace_with_string(self):
        """Test replacing with string"""
        d = pq('<div><p>Old</p></div>')
        d('p').replace_with('<span>New</span>')
        assert len(d('span')) >= 1
        assert len(d('p')) == 0

    def test_replace_with_element(self):
        """Test replacing with element"""
        d = pq('<div><p>Original</p></div>')
        d('p').replace_with('<div>Replacement</div>')
        assert 'Replacement' in d.text()


class TestAppendTo:
    """Test append_to method"""

    def test_append_to_basic(self):
        """Test appending to target"""
        d = pq('<span>Content</span>')
        target = pq('<div></div>')
        d.append_to(target)
        assert len(target('span')) >= 1


class TestPrependTo:
    """Test prepend_to method"""

    def test_prepend_to_basic(self):
        """Test prepending to target"""
        d = pq('<span>Content</span>')
        target = pq('<div></div>')
        d.prepend_to(target)
        assert len(target('span')) >= 1


class TestInsertAfter:
    """Test insert_after method"""

    def test_insert_after_basic(self):
        """Test inserting after target"""
        d = pq('<span>New</span>')
        target = pq('<div><p>Original</p></div>')
        d.insert_after(target('p'))
        assert len(target('span')) >= 1


class TestInsertBefore:
    """Test insert_before method"""

    def test_insert_before_basic(self):
        """Test inserting before target"""
        d = pq('<span>New</span>')
        target = pq('<div><p>Original</p></div>')
        d.insert_before(target('p'))
        assert len(target('span')) >= 1


class TestHtml:
    """Test html method"""

    def test_html_get(self):
        """Test getting inner HTML"""
        d = pq('<div><p>Content</p></div>')
        html = d.html()
        assert '<p>' in html or 'Content' in html

    def test_html_set(self):
        """Test setting inner HTML"""
        d = pq('<div></div>')
        d.html('<p>New</p>')
        assert d('p').text() == 'New'

    def test_html_replace(self):
        """Test replacing inner HTML"""
        d = pq('<div><p>Old</p></div>')
        d.html('<p>New</p>')
        assert d('p').text() == 'New'


class TestText:
    """Test text method"""

    def test_text_get(self):
        """Test getting text content"""
        d = pq('<div><p>Hello</p><p>World</p></div>')
        text = d('p').text()
        assert 'Hello' in text

    def test_text_set(self):
        """Test setting text content"""
        d = pq('<div></div>')
        d.text('New Text')
        assert d.text() == 'New Text'

    def test_text_get_all(self):
        """Test getting text from multiple elements"""
        d = pq('<div><p>1</p><p>2</p></div>')
        text = d('p').text()
        assert '1' in text


class TestOuterHtml:
    """Test outer_html method"""

    def test_outer_html_basic(self):
        """Test getting outer HTML"""
        d = pq('<p class="test">Content</p>')
        html = d.outer_html()
        assert '<p' in html
        assert 'Content' in html
