import pytest
from pyquery import PyQuery as pq


class TestVal:
    """Test val method"""

    def test_val_text_input(self):
        """Test getting text input value"""
        d = pq('<input type="text" value="test" />')
        assert d.val() == 'test'

    def test_val_text_input_set(self):
        """Test setting text input value"""
        d = pq('<input type="text" />')
        d.val('new value')
        assert d.val() == 'new value'

    def test_val_checkbox_checked(self):
        """Test getting checked checkbox value"""
        d = pq('<input type="checkbox" value="yes" checked />')
        assert d.val() == 'yes'

    def test_val_checkbox_unchecked(self):
        """Test getting unchecked checkbox value"""
        d = pq('<input type="checkbox" value="yes" />')
        assert d.val() is None

    def test_val_radio_checked(self):
        """Test getting checked radio value"""
        d = pq('<input type="radio" value="option1" checked />')
        assert d.val() == 'option1'

    def test_val_textarea(self):
        """Test getting textarea value"""
        d = pq('<textarea>text content</textarea>')
        assert d.val() == 'text content'

    def test_val_textarea_set(self):
        """Test setting textarea value"""
        d = pq('<textarea></textarea>')
        d.val('new content')
        assert d.val() == 'new content'

    def test_val_select(self):
        """Test getting select value"""
        d = pq('<select><option>First</option><option selected>Second</option></select>')
        val = d.val()
        assert val is not None

    def test_val_select_default(self):
        """Test select default value"""
        d = pq('<select><option>First</option><option>Second</option></select>')
        val = d.val()
        assert val is not None

    def test_val_multiple_elements(self):
        """Test getting value from multiple form elements"""
        d = pq('<div><input type="text" value="1" /><input type="text" value="2" /></div>')
        assert d('input').eq(0).val() == '1'
        assert d('input').eq(1).val() == '2'


class TestSerialize:
    """Test serialize method"""

    def test_serialize_basic_form(self):
        """Test serializing basic form"""
        html = '''<form>
            <input type="text" name="user" value="john" />
            <input type="password" name="pass" value="secret" />
            <textarea name="comment">Hello</textarea>
        </form>'''
        d = pq(html)
        serialized = d('form').serialize()
        assert 'user=john' in serialized
        assert 'pass=secret' in serialized
        assert 'comment=Hello' in serialized

    def test_serialize_with_checkboxes(self):
        """Test serializing form with checkboxes"""
        html = '''<form>
            <input type="checkbox" name="agree" value="yes" checked />
            <input type="checkbox" name="terms" value="yes" />
        </form>'''
        d = pq(html)
        serialized = d('form').serialize()
        assert 'agree=yes' in serialized
        assert 'terms' not in serialized

    def test_serialize_with_disabled(self):
        """Test serializing excludes disabled fields"""
        html = '''<form>
            <input type="text" name="enabled" value="yes" />
            <input type="text" name="disabled" value="no" disabled />
        </form>'''
        d = pq(html)
        serialized = d('form').serialize()
        assert 'enabled=yes' in serialized
        assert 'disabled' not in serialized

    def test_serialize_empty_form(self):
        """Test serializing empty form"""
        d = pq('<form></form>')
        serialized = d('form').serialize()
        assert serialized == ''


class TestSerializeArray:
    """Test serialize_array method"""

    def test_serialize_array_basic(self):
        """Test serialize_array with basic form"""
        html = '''<form>
            <input type="text" name="name" value="John" />
            <input type="text" name="email" value="john@example.com" />
        </form>'''
        d = pq(html)
        array = d('form').serialize_array()
        assert len(array) > 0
        assert any(item['name'] == 'name' for item in array)

    def test_serialize_array_format(self):
        """Test serialize_array format"""
        html = '<form><input type="text" name="test" value="value" /></form>'
        d = pq(html)
        array = d('form').serialize_array()
        assert isinstance(array, list)
        if array:
            assert 'name' in array[0]
            assert 'value' in array[0]


class TestSerializePairs:
    """Test serialize_pairs method"""

    def test_serialize_pairs_basic(self):
        """Test serialize_pairs with basic form"""
        html = '''<form>
            <input type="text" name="first" value="1" />
            <input type="text" name="second" value="2" />
        </form>'''
        d = pq(html)
        pairs = d('form').serialize_pairs()
        assert len(pairs) > 0
        assert isinstance(pairs, list)

    def test_serialize_pairs_format(self):
        """Test serialize_pairs returns tuples"""
        html = '<form><input type="text" name="key" value="val" /></form>'
        d = pq(html)
        pairs = d('form').serialize_pairs()
        if pairs:
            assert isinstance(pairs[0], tuple)
            assert len(pairs[0]) == 2


class TestSerializeDict:
    """Test serialize_dict method"""

    def test_serialize_dict_basic(self):
        """Test serialize_dict with basic form"""
        html = '''<form>
            <input type="text" name="name" value="John" />
            <input type="text" name="email" value="john@example.com" />
        </form>'''
        d = pq(html)
        dict_data = d('form').serialize_dict()
        assert isinstance(dict_data, dict)

    def test_serialize_dict_values(self):
        """Test serialize_dict values"""
        html = '''<form>
            <input type="text" name="username" value="testuser" />
            <textarea name="bio">My bio</textarea>
        </form>'''
        d = pq(html)
        dict_data = d('form').serialize_dict()
        assert 'username' in dict_data
        assert dict_data['username'] == 'testuser'

    def test_serialize_dict_multiple_values(self):
        """Test serialize_dict with multiple values same name"""
        html = '''<form>
            <input type="checkbox" name="option" value="1" checked />
            <input type="checkbox" name="option" value="2" checked />
        </form>'''
        d = pq(html)
        dict_data = d('form').serialize_dict()
        # Multiple values might be list or last value
        assert 'option' in dict_data


class TestFormFiltering:
    """Test form element filtering"""

    def test_excludes_file_inputs(self):
        """Test that file inputs are excluded"""
        html = '''<form>
            <input type="text" name="name" value="John" />
            <input type="file" name="upload" />
        </form>'''
        d = pq(html)
        serialized = d('form').serialize()
        assert 'name=John' in serialized
        assert 'upload' not in serialized

    def test_excludes_submit_buttons(self):
        """Test that submit buttons are excluded by default"""
        html = '''<form>
            <input type="text" name="field" value="value" />
            <input type="submit" name="submit" value="Submit" />
        </form>'''
        d = pq(html)
        serialized = d('form').serialize()
        assert 'field=value' in serialized

    def test_multiple_select_values(self):
        """Test multiple select handling"""
        html = '''<form>
            <select name="options" multiple>
                <option selected>1</option>
                <option selected>2</option>
                <option>3</option>
            </select>
        </form>'''
        d = pq(html)
        pairs = d('form').serialize_pairs()
        # Should have entries for selected options
        assert len(pairs) >= 1


class TestFilterMethod:
    """Test filter method"""

    def test_filter_by_selector(self):
        """Test filtering by selector"""
        html = '<div><p class="active">1</p><p>2</p><p class="active">3</p></div>'
        d = pq(html)
        filtered = d('p').filter('.active')
        assert len(filtered) == 2

    def test_filter_by_function(self):
        """Test filtering by function"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        filtered = d('p').filter(lambda i, el: i % 2 == 0)
        assert len(filtered) >= 1


class TestNotMethod:
    """Test not_ method"""

    def test_not_by_selector(self):
        """Test not with selector"""
        html = '<div><p class="exclude">1</p><p>2</p><p class="exclude">3</p></div>'
        d = pq(html)
        result = d('p').not_('.exclude')
        assert len(result) == 1
        assert result.text() == '2'

    def test_not_by_function(self):
        """Test not with function"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        result = d('p').not_(lambda i, el: i % 2 == 0)
        assert len(result) >= 1


class TestIsMethod:
    """Test is_ method"""

    def test_is_true(self):
        """Test is_ returns true"""
        d = pq('<p class="test">Content</p>')
        assert d.is_('.test') is True

    def test_is_false(self):
        """Test is_ returns false"""
        d = pq('<p>Content</p>')
        assert d.is_('.test') is False


class TestEqMethod:
    """Test eq method"""

    def test_eq_basic(self):
        """Test eq selects by index"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        result = d('p').eq(1)
        assert result.text() == '2'

    def test_eq_negative_index(self):
        """Test eq with negative index"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        result = d('p').eq(-1)
        assert result.text() == '3'

    def test_eq_out_of_range(self):
        """Test eq with out of range index"""
        html = '<div><p>1</p><p>2</p></div>'
        d = pq(html)
        result = d('p').eq(10)
        assert len(result) == 0


class TestEachMethod:
    """Test each method"""

    def test_each_basic(self):
        """Test each with callback"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        count = [0]

        def callback(i):
            count[0] += 1

        d('p').each(callback)
        assert count[0] == 3


class TestMapMethod:
    """Test map method"""

    def test_map_basic(self):
        """Test map with callback"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        result = d('p').map(lambda i, el: i)
        assert len(result) == 3
        assert result[0] == 0
        assert result[1] == 1


class TestItemsMethod:
    """Test items method"""

    def test_items_iteration(self):
        """Test items returns PyQuery objects"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        count = 0
        for item in d('p').items():
            count += 1
            assert isinstance(item, pq)
        assert count == 3
