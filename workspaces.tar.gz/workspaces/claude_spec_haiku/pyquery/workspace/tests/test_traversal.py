import pytest
from pyquery import PyQuery as pq


class TestFind:
    """Test find method"""

    def test_find_element(self):
        """Test finding elements"""
        html = '<div><p>First</p><span>Second</span></div>'
        d = pq(html)
        result = d.find('p')
        assert len(result) == 1
        assert result.text() == 'First'

    def test_find_nested(self):
        """Test finding nested elements"""
        html = '<div><div><p>Nested</p></div></div>'
        d = pq(html)
        result = d.find('p')
        assert result.text() == 'Nested'

    def test_find_multiple(self):
        """Test finding multiple elements"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        result = d.find('p')
        assert len(result) == 3

    def test_find_with_class(self):
        """Test finding with class selector"""
        html = '<div><p class="intro">Intro</p><p>Regular</p></div>'
        d = pq(html)
        result = d.find('.intro')
        assert result.text() == 'Intro'

    def test_find_empty_result(self):
        """Test finding with no matches"""
        html = '<div><p>Test</p></div>'
        d = pq(html)
        result = d.find('span')
        assert len(result) == 0


class TestChildren:
    """Test children method"""

    def test_children_basic(self):
        """Test getting direct children"""
        html = '<div><p>1</p><p>2</p><span>3</span></div>'
        d = pq(html)
        children = d.children()
        assert len(children) == 3

    def test_children_with_selector(self):
        """Test children with selector"""
        html = '<div><p>1</p><p>2</p><span>3</span></div>'
        d = pq(html)
        children = d.children('p')
        assert len(children) == 2

    def test_children_ignores_nested(self):
        """Test that children ignores deeply nested elements"""
        html = '<div><p><span>Nested</span></p><span>Direct</span></div>'
        d = pq(html)
        children = d.children('span')
        assert len(children) == 1


class TestParent:
    """Test parent method"""

    def test_parent_basic(self):
        """Test getting parent"""
        html = '<div><p>Content</p></div>'
        d = pq(html)
        parent = d('p').parent()
        assert parent[0].tag.lower() == 'div'

    def test_parent_with_selector(self):
        """Test parent with selector"""
        html = '<div class="outer"><div class="inner"><p>Content</p></div></div>'
        d = pq(html)
        parent = d('p').parent('.inner')
        assert len(parent) == 1
        assert 'inner' in parent.attr('class')

    def test_parent_no_match(self):
        """Test parent with non-matching selector"""
        html = '<div><p>Content</p></div>'
        d = pq(html)
        parent = d('p').parent('span')
        assert len(parent) == 0


class TestParents:
    """Test parents method"""

    def test_parents_basic(self):
        """Test getting all parents"""
        html = '<div><div><div><p>Deep</p></div></div></div>'
        d = pq(html)
        parents = d('p').parents()
        assert len(parents) >= 2

    def test_parents_with_selector(self):
        """Test parents with selector"""
        html = '<div class="outer"><div class="middle"><p>Content</p></div></div>'
        d = pq(html)
        parents = d('p').parents('.middle')
        assert len(parents) >= 1


class TestSiblings:
    """Test siblings method"""

    def test_siblings_basic(self):
        """Test getting siblings"""
        html = '<div><p>1</p><p>2</p><span>3</span></div>'
        d = pq(html)
        siblings = d('p').eq(0).siblings()
        assert len(siblings) >= 2

    def test_siblings_with_selector(self):
        """Test siblings with selector"""
        html = '<div><p>1</p><p>2</p><span>3</span></div>'
        d = pq(html)
        siblings = d('p').eq(0).siblings('p')
        assert len(siblings) >= 1


class TestNext:
    """Test next method"""

    def test_next_basic(self):
        """Test getting next sibling"""
        html = '<div><p>1</p><p>2</p></div>'
        d = pq(html)
        next_elem = d('p').eq(0).next()
        assert len(next_elem) == 1
        assert next_elem.text() == '2'

    def test_next_with_selector(self):
        """Test next with selector"""
        html = '<div><p>1</p><span>Skip</span><p>2</p></div>'
        d = pq(html)
        next_elem = d('p').eq(0).next('p')
        assert len(next_elem) == 0

    def test_next_at_end(self):
        """Test next when at end"""
        html = '<div><p>1</p></div>'
        d = pq(html)
        next_elem = d('p').next()
        assert len(next_elem) == 0


class TestPrev:
    """Test prev method"""

    def test_prev_basic(self):
        """Test getting previous sibling"""
        html = '<div><p>1</p><p>2</p></div>'
        d = pq(html)
        prev_elem = d('p').eq(1).prev()
        assert len(prev_elem) == 1
        assert prev_elem.text() == '1'

    def test_prev_at_start(self):
        """Test prev when at start"""
        html = '<div><p>1</p></div>'
        d = pq(html)
        prev_elem = d('p').prev()
        assert len(prev_elem) == 0


class TestNextAll:
    """Test next_all method"""

    def test_next_all_basic(self):
        """Test getting all next siblings"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        next_all = d('p').eq(0).next_all()
        assert len(next_all) == 2

    def test_next_all_with_selector(self):
        """Test next_all with selector"""
        html = '<div><p>1</p><span>2</span><p>3</p></div>'
        d = pq(html)
        next_all = d('p').eq(0).next_all('p')
        assert len(next_all) >= 1


class TestPrevAll:
    """Test prev_all method"""

    def test_prev_all_basic(self):
        """Test getting all previous siblings"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        prev_all = d('p').eq(2).prev_all()
        assert len(prev_all) == 2


class TestNextUntil:
    """Test next_until method"""

    def test_next_until_basic(self):
        """Test next_until method"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        result = d('p').eq(0).next_until('p:last')
        assert len(result) >= 1


class TestClosest:
    """Test closest method"""

    def test_closest_parent(self):
        """Test finding closest parent"""
        html = '<div class="outer"><div class="inner"><p>Content</p></div></div>'
        d = pq(html)
        closest = d('p').closest('.inner')
        assert len(closest) == 1

    def test_closest_self(self):
        """Test closest can match self"""
        html = '<p class="test">Content</p>'
        d = pq(html)
        closest = d('p').closest('.test')
        assert len(closest) == 1

    def test_closest_no_match(self):
        """Test closest with no match"""
        html = '<div><p>Content</p></div>'
        d = pq(html)
        closest = d('p').closest('span')
        assert len(closest) == 0


class TestContents:
    """Test contents method"""

    def test_contents_basic(self):
        """Test getting all child nodes"""
        html = '<div><p>Text</p><span>More</span></div>'
        d = pq(html)
        contents = d.contents()
        assert len(contents) >= 2


class TestEnd:
    """Test end method"""

    def test_end_returns_parent(self):
        """Test end returns parent"""
        html = '<div><p>Test</p></div>'
        d = pq(html)
        result = d('p').end()
        # end() should return empty or parent
        assert result is not None
