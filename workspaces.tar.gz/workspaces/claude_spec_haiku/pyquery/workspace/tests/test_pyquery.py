import pytest
from pyquery import PyQuery as pq


class TestPyQueryInitialization:
    """Test PyQuery initialization"""

    def test_empty_init(self):
        """Test initializing empty PyQuery"""
        d = pq()
        assert len(d) == 0

    def test_init_with_html_string(self):
        """Test initializing with HTML string"""
        html = '<div><p>Hello</p></div>'
        d = pq(html)
        assert len(d) > 0
        assert d('p').text() == 'Hello'

    def test_init_with_complex_html(self):
        """Test initializing with complex HTML"""
        html = '<html><body><h1>Title</h1><p>Content</p></body></html>'
        d = pq(html)
        assert d('h1').text() == 'Title'
        assert d('p').text() == 'Content'

    def test_init_with_pyquery_object(self):
        """Test initializing from PyQuery object"""
        d1 = pq('<div><p>Test</p></div>')
        d2 = pq(d1)
        assert d2('p').text() == 'Test'

    def test_init_with_element(self):
        """Test initializing with lxml element"""
        d1 = pq('<div><span>Element</span></div>')
        elem = d1[0]
        d2 = pq(elem)
        assert len(d2) == 1

    def test_init_with_element_list(self):
        """Test initializing with list of elements"""
        d1 = pq('<div><p>1</p><p>2</p></div>')
        elements = d1('p')
        d2 = pq(list(elements))
        assert len(d2) == 2

    def test_init_parser_html(self):
        """Test HTML parser"""
        html = '<div><p>Test</p>'  # Missing closing tags
        d = pq(html, parser='html')
        assert d('p').text() == 'Test'

    def test_init_parser_xml(self):
        """Test XML parser"""
        xml = '<?xml version="1.0"?><root><item>Test</item></root>'
        d = pq(xml, parser='xml')
        assert d('item').text() == 'Test'

    def test_init_with_bytes(self):
        """Test initialization with bytes"""
        html = b'<div><p>Bytes</p></div>'
        d = pq(html)
        assert d('p').text() == 'Bytes'

    def test_copy_preserves_parser(self):
        """Test that copying preserves parser"""
        d1 = pq('<div>Test</div>', parser='xml')
        d2 = pq(d1)
        assert d2.parser == 'xml'

    def test_copy_preserves_base_url(self):
        """Test that copying preserves base_url"""
        d1 = pq('<div>Test</div>', base_url='http://example.com')
        d2 = pq(d1)
        assert d2._base_url == 'http://example.com'


class TestPyQueryStringRepresentation:
    """Test string representations"""

    def test_repr(self):
        """Test __repr__"""
        d = pq('<div><p>Test</p></div>')
        repr_str = repr(d)
        assert 'p' in repr_str.lower() or 'test' in repr_str.lower()

    def test_str(self):
        """Test __str__"""
        d = pq('<div><p>Test</p></div>')
        str_repr = str(d)
        assert '<' in str_repr
        assert '>' in str_repr

    def test_html(self):
        """Test __html__"""
        html_input = '<div><p>Test</p></div>'
        d = pq(html_input)
        html_output = d.__html__()
        assert '<p>' in html_output or '<p ' in html_output
        assert 'Test' in html_output or 'test' in html_output.lower()


class TestPyQueryProperties:
    """Test PyQuery properties"""

    def test_root_property(self):
        """Test root property"""
        d = pq('<div><p>Test</p></div>')
        root = d.root
        assert root is not None

    def test_encoding_property(self):
        """Test encoding property"""
        d = pq('<div>Test</div>')
        encoding = d.encoding
        # Encoding may be None or a string
        assert encoding is None or isinstance(encoding, str)

    def test_length(self):
        """Test len() on PyQuery"""
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        assert len(d('p')) == 3

    def test_iteration(self):
        """Test iteration over PyQuery"""
        d = pq('<div><p>1</p><p>2</p></div>')
        paragraphs = d('p')
        count = 0
        for p in paragraphs:
            count += 1
        assert count == 2

    def test_indexing(self):
        """Test indexing"""
        d = pq('<div><p>First</p><p>Second</p></div>')
        paragraphs = d('p')
        assert paragraphs[0].text == 'First'
        assert paragraphs[1].text == 'Second'

    def test_negative_indexing(self):
        """Test negative indexing"""
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        paragraphs = d('p')
        assert paragraphs[-1].text == '3'


class TestPyQueryCombination:
    """Test combining PyQuery objects"""

    def test_add_two_pyquery_objects(self):
        """Test adding two PyQuery objects"""
        d1 = pq('<p>First</p>')
        d2 = pq('<p>Second</p>')
        result = d1 + d2
        assert len(result) == 2

    def test_extend(self):
        """Test extend method"""
        d1 = pq('<div><p>1</p></div>')
        d2 = pq('<div><p>2</p></div>')
        d1.extend(d2)
        assert len(d1) >= 1


class TestPyQueryCall:
    """Test __call__ method (find shorthand)"""

    def test_call_is_find(self):
        """Test that calling PyQuery object acts like find"""
        d = pq('<div><p>Test</p><span>Other</span></div>')
        result = d('p')
        assert result.text() == 'Test'

    def test_call_multiple_selectors(self):
        """Test calling with multiple matches"""
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        result = d('p')
        assert len(result) == 3
