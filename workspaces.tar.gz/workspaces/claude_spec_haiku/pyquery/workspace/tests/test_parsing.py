import pytest
from pyquery import PyQuery as pq, fromstring


class TestFromstring:
    """Test fromstring function"""

    def test_fromstring_html(self):
        """Test parsing HTML string"""
        html = '<div><p>Test</p></div>'
        d = fromstring(html)
        assert isinstance(d, pq)
        assert d('p').text() == 'Test'

    def test_fromstring_with_parser(self):
        """Test fromstring with explicit parser"""
        html = '<div><p>Test</p></div>'
        d = fromstring(html, parser='html')
        assert d('p').text() == 'Test'

    def test_fromstring_xml(self):
        """Test parsing XML"""
        xml = '<?xml version="1.0"?><root><item>Text</item></root>'
        d = fromstring(xml, parser='xml')
        assert d('item').text() == 'Text'

    def test_fromstring_bytes(self):
        """Test parsing bytes"""
        html_bytes = b'<div><p>Bytes</p></div>'
        d = fromstring(html_bytes)
        assert d('p').text() == 'Bytes'

    def test_fromstring_with_encoding(self):
        """Test parsing with encoding"""
        html = '<div><p>Test</p></div>'
        d = fromstring(html, encoding='utf-8')
        assert d('p').text() == 'Test'

    def test_fromstring_with_base_url(self):
        """Test fromstring with base_url"""
        html = '<a href="page">Link</a>'
        d = fromstring(html, base_url='http://example.com')
        assert d._base_url == 'http://example.com'


class TestHTMLParsing:
    """Test HTML parsing"""

    def test_parse_incomplete_html(self):
        """Test parsing incomplete HTML"""
        html = '<div><p>Unclosed paragraph'
        d = pq(html, parser='html')
        assert len(d) > 0

    def test_parse_with_attributes(self):
        """Test parsing elements with attributes"""
        html = '<div id="main" class="container"><p>Content</p></div>'
        d = pq(html)
        assert d.attr('id') == 'main'
        assert 'container' in d.attr('class')

    def test_parse_with_special_chars(self):
        """Test parsing with special characters"""
        html = '<div><p>&amp; &lt; &gt;</p></div>'
        d = pq(html)
        assert len(d) > 0

    def test_parse_self_closing_tags(self):
        """Test parsing self-closing tags"""
        html = '<div><input type="text" /><br /></div>'
        d = pq(html)
        assert len(d('input')) >= 1


class TestXMLParsing:
    """Test XML parsing"""

    def test_parse_xml_basic(self):
        """Test basic XML parsing"""
        xml = '<?xml version="1.0"?><root><child>Text</child></root>'
        d = pq(xml, parser='xml')
        assert d('child').text() == 'Text'

    def test_parse_xml_with_namespaces(self):
        """Test XML with namespaces"""
        xml = '''<?xml version="1.0"?>
        <root xmlns="http://example.com">
            <item>Content</item>
        </root>'''
        d = pq(xml, parser='xml')
        # Should be able to parse namespaced XML
        assert len(d) >= 0

    def test_parse_xml_attributes(self):
        """Test XML with attributes"""
        xml = '<?xml version="1.0"?><root><item id="1">Content</item></root>'
        d = pq(xml, parser='xml')
        item = d('item')
        if len(item) > 0:
            assert item.attr('id') == '1'


class TestParserComparison:
    """Test different parsers"""

    def test_html_vs_xml_parser(self):
        """Test HTML vs XML parser behavior"""
        content = '<div><p>Test</p></div>'
        d_html = pq(content, parser='html')
        d_xml = pq(content, parser='xml')
        # Both should parse the content
        assert len(d_html) > 0
        assert len(d_xml) > 0

    def test_parser_selection(self):
        """Test automatic parser selection"""
        html = '<div><p>HTML</p></div>'
        xml = '<?xml version="1.0"?><root><p>XML</p></root>'

        d_html = pq(html)
        d_xml = pq(xml)

        assert len(d_html) > 0
        assert len(d_xml) > 0


class TestEncodingDetection:
    """Test encoding detection"""

    def test_utf8_detection(self):
        """Test UTF-8 encoding detection"""
        html = '<div><p>UTF-8: café</p></div>'
        d = pq(html)
        assert 'café' in d.text() or 'caf' in d.text()

    def test_latin1_bytes(self):
        """Test Latin-1 encoded bytes"""
        html_bytes = '<div><p>Test</p></div>'.encode('latin-1')
        d = pq(html_bytes)
        assert d('p').text() == 'Test'

    def test_mixed_encoding_handling(self):
        """Test handling of mixed or malformed encoding"""
        html = '<div><p>Test</p></div>'
        d = pq(html)
        assert d('p').text() == 'Test'


class TestComplexStructures:
    """Test parsing complex HTML structures"""

    def test_nested_tables(self):
        """Test parsing nested tables"""
        html = '''<table>
            <tr><td>
                <table>
                    <tr><td>Nested</td></tr>
                </table>
            </td></tr>
        </table>'''
        d = pq(html)
        assert len(d('table')) >= 2

    def test_deeply_nested_divs(self):
        """Test deeply nested elements"""
        html = '<div>' * 10 + 'Deep' + '</div>' * 10
        d = pq(html)
        assert 'Deep' in d.text()

    def test_mixed_content(self):
        """Test mixed text and element content"""
        html = '<div>Text <p>Paragraph</p> More text</div>'
        d = pq(html)
        text = d.text()
        assert 'Text' in text
        assert 'Paragraph' in text
        assert 'More' in text


class TestEdgeCases:
    """Test edge cases in parsing"""

    def test_empty_string(self):
        """Test parsing empty string"""
        d = pq('')
        assert len(d) >= 0

    def test_whitespace_only(self):
        """Test parsing whitespace only"""
        d = pq('   \n  \t  ')
        assert len(d) >= 0

    def test_single_text_node(self):
        """Test parsing single text"""
        d = pq('Just text')
        assert len(d) > 0 or len(d) == 0

    def test_invalid_html(self):
        """Test parsing invalid HTML"""
        html = '<div><p>Unclosed <span>Tags</div>'
        d = pq(html)
        assert len(d) > 0

    def test_doctype_declaration(self):
        """Test parsing with DOCTYPE"""
        html = '<!DOCTYPE html><html><body><p>Test</p></body></html>'
        d = pq(html)
        assert d('p').text() == 'Test'


class TestFromstringReturnType:
    """Test fromstring return type"""

    def test_returns_pyquery(self):
        """Test that fromstring returns PyQuery"""
        d = fromstring('<div>Test</div>')
        assert isinstance(d, pq)

    def test_returns_pyquery_of_element(self):
        """Test that fromstring wraps elements"""
        d = fromstring('<div>Test</div>')
        assert len(d) > 0
