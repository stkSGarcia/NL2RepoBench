import pytest
from pyquery import PyQuery as pq


class TestCamelCaseAliases:
    """Test camelCase alias support"""

    def test_add_class_alias(self):
        """Test addClass camelCase alias"""
        d = pq('<div></div>')
        # Test both naming styles work
        d.add_class('test')
        d.addClass('another')
        assert 'test' in d.attr('class')
        assert 'another' in d.attr('class')

    def test_remove_class_alias(self):
        """Test removeClass camelCase alias"""
        d = pq('<div class="test remove"></div>')
        d.remove_class('test')
        d.removeClass('remove')
        assert d.attr('class') is None

    def test_has_class_alias(self):
        """Test hasClass camelCase alias"""
        d = pq('<div class="highlight"></div>')
        assert d.has_class('highlight') is True
        assert d.hasClass('highlight') is True

    def test_toggle_class_alias(self):
        """Test toggleClass camelCase alias"""
        d = pq('<div></div>')
        d.toggle_class('active')
        d.toggleClass('inactive')
        assert 'active' in d.attr('class')
        assert 'inactive' in d.attr('class')

    def test_remove_attr_alias(self):
        """Test removeAttr camelCase alias"""
        d = pq('<div id="test" data-value="123"></div>')
        d.remove_attr('id')
        d.removeAttr('data-value')
        assert d.attr('id') is None
        assert d.attr('data-value') is None

    def test_outer_html_alias(self):
        """Test outerHtml camelCase alias"""
        d = pq('<p class="test">Content</p>')
        html1 = d.outer_html()
        html2 = d.outerHtml()
        assert html1 == html2

    def test_next_all_alias(self):
        """Test nextAll camelCase alias"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        result1 = d('p').eq(0).next_all()
        result2 = d('p').eq(0).nextAll()
        assert len(result1) == len(result2)

    def test_prev_all_alias(self):
        """Test prevAll camelCase alias"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)
        result1 = d('p').eq(2).prev_all()
        result2 = d('p').eq(2).prevAll()
        assert len(result1) == len(result2)

    def test_next_until_alias(self):
        """Test nextUntil camelCase alias"""
        html = '<div><p>1</p><span>2</span><p>3</p></div>'
        d = pq(html)
        result1 = d('p').eq(0).next_until('p:last')
        result2 = d('p').eq(0).nextUntil('p:last')
        # Both should return similar results
        assert True

    def test_append_to_alias(self):
        """Test appendTo camelCase alias"""
        d = pq('<span>Content</span>')
        target = pq('<div></div>')
        d.append_to(target)
        assert len(target('span')) >= 1

        d2 = pq('<span>Another</span>')
        target2 = pq('<div></div>')
        d2.appendTo(target2)
        assert len(target2('span')) >= 1

    def test_prepend_to_alias(self):
        """Test prependTo camelCase alias"""
        d = pq('<span>Content</span>')
        target = pq('<div></div>')
        d.prepend_to(target)
        assert len(target('span')) >= 1

        d2 = pq('<span>Another</span>')
        target2 = pq('<div></div>')
        d2.prependTo(target2)
        assert len(target2('span')) >= 1

    def test_insert_after_alias(self):
        """Test insertAfter camelCase alias"""
        d = pq('<span>New</span>')
        target = pq('<div><p>Original</p></div>')
        d.insert_after(target('p'))
        assert len(target('span')) >= 1

    def test_insert_before_alias(self):
        """Test insertBefore camelCase alias"""
        d = pq('<span>New</span>')
        target = pq('<div><p>Original</p></div>')
        d.insert_before(target('p'))
        assert len(target('span')) >= 1

    def test_replace_with_alias(self):
        """Test replaceWith camelCase alias"""
        html = '<div><p>Old</p></div>'
        d = pq(html)
        d('p').replace_with('<span>New</span>')
        d2 = pq(html)
        d2('p').replaceWith('<span>New</span>')
        # Both should have span
        assert True

    def test_wrap_all_alias(self):
        """Test wrapAll camelCase alias"""
        d = pq('<div><p>1</p><p>2</p></div>')
        d('p').wrap_all('<section></section>')
        d2 = pq('<div><p>1</p><p>2</p></div>')
        d2('p').wrapAll('<section></section>')
        assert True

    def test_serialize_array_alias(self):
        """Test serializeArray camelCase alias"""
        html = '<form><input name="test" value="value" /></form>'
        d = pq(html)
        arr1 = d('form').serialize_array()
        arr2 = d('form').serializeArray()
        assert len(arr1) == len(arr2)

    def test_serialize_pairs_alias(self):
        """Test serializePairs camelCase alias"""
        html = '<form><input name="test" value="value" /></form>'
        d = pq(html)
        pairs1 = d('form').serialize_pairs()
        pairs2 = d('form').serializePairs()
        assert len(pairs1) == len(pairs2)

    def test_serialize_dict_alias(self):
        """Test serializeDict camelCase alias"""
        html = '<form><input name="test" value="value" /></form>'
        d = pq(html)
        dict1 = d('form').serialize_dict()
        dict2 = d('form').serializeDict()
        assert dict1 == dict2

    def test_make_links_absolute_alias(self):
        """Test makeLinksAbsolute camelCase alias"""
        html = '<div><a href="/page">Link</a></div>'
        d = pq(html, base_url='http://example.com')
        d.make_links_absolute()
        d2 = pq(html, base_url='http://example.com')
        d2.makeLinksAbsolute()
        assert True

    def test_xhtml_to_html_alias(self):
        """Test xhtmlToHtml camelCase alias"""
        html = '<div><p>Test</p></div>'
        d = pq(html)
        d.xhtml_to_html()
        d2 = pq(html)
        d2.xhtmlToHtml()
        assert True


class TestAliasEquivalence:
    """Test that aliases produce equivalent results"""

    def test_snake_case_camel_case_equivalent(self):
        """Test snake_case and camelCase produce same results"""
        html = '<div class="test"><p>Content</p></div>'
        d1 = pq(html)
        d2 = pq(html)

        # Test add_class vs addClass
        d1.add_class('new')
        d2.addClass('new')
        assert d1.attr('class') == d2.attr('class')

    def test_all_dom_methods_have_aliases(self):
        """Test that public methods have aliases"""
        html = '<div><p>Test</p></div>'
        d = pq(html)

        # Check some key methods
        assert hasattr(d, 'add_class')
        assert hasattr(d, 'addClass')
        assert hasattr(d, 'remove_class')
        assert hasattr(d, 'removeClass')
        assert hasattr(d, 'has_class')
        assert hasattr(d, 'hasClass')

    def test_traversal_method_aliases(self):
        """Test traversal method aliases"""
        html = '<div><p>1</p><p>2</p><p>3</p></div>'
        d = pq(html)

        assert hasattr(d('p'), 'next_all')
        assert hasattr(d('p'), 'nextAll')
        assert hasattr(d('p'), 'prev_all')
        assert hasattr(d('p'), 'prevAll')

    def test_manipulation_method_aliases(self):
        """Test manipulation method aliases"""
        d = pq('<div></div>')

        assert hasattr(d, 'append_to')
        assert hasattr(d, 'appendTo')
        assert hasattr(d, 'prepend_to')
        assert hasattr(d, 'prependTo')
        assert hasattr(d, 'insert_after')
        assert hasattr(d, 'insertAfter')
        assert hasattr(d, 'insert_before')
        assert hasattr(d, 'insertBefore')


class TestAliasChaining:
    """Test method chaining with aliases"""

    def test_chain_snake_case(self):
        """Test chaining with snake_case methods"""
        html = '<div><p>Content</p></div>'
        d = pq(html)
        result = d.add_class('test').add_class('another')
        assert 'test' in result.attr('class')
        assert 'another' in result.attr('class')

    def test_chain_camel_case(self):
        """Test chaining with camelCase methods"""
        html = '<div><p>Content</p></div>'
        d = pq(html)
        result = d.addClass('test').addClass('another')
        assert 'test' in result.attr('class')
        assert 'another' in result.attr('class')

    def test_chain_mixed_naming(self):
        """Test chaining with mixed naming styles"""
        html = '<div class="base"><p>Content</p></div>'
        d = pq(html)
        result = d.add_class('test').addClass('another').remove_class('base')
        assert 'test' in result.attr('class')
        assert 'another' in result.attr('class')
