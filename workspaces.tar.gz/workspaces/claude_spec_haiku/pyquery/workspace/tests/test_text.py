import pytest
from pyquery import PyQuery as pq


class TestTextExtraction:
    """Test text extraction functionality"""

    def test_text_basic(self):
        """Test basic text extraction"""
        d = pq('<div>Simple text</div>')
        assert d.text() == 'Simple text'

    def test_text_nested_elements(self):
        """Test text from nested elements"""
        html = '<div><p>Paragraph</p><span>Span</span></div>'
        d = pq(html)
        text = d.text()
        assert 'Paragraph' in text
        assert 'Span' in text

    def test_text_empty_element(self):
        """Test text from empty element"""
        d = pq('<div></div>')
        assert d.text() == ''

    def test_text_with_whitespace(self):
        """Test text with whitespace"""
        html = '<div>  Spaced  text  </div>'
        d = pq(html)
        text = d.text()
        assert 'text' in text

    def test_text_squash_space(self):
        """Test text with squash_space option"""
        html = '<div>Multiple   spaces   here</div>'
        d = pq(html)
        text = d.text(squash_space=True)
        assert text == 'Multiple spaces here'

    def test_text_multiple_paragraphs(self):
        """Test text from multiple paragraphs"""
        html = '<div><p>First</p><p>Second</p><p>Third</p></div>'
        d = pq(html)
        text = d.text()
        assert 'First' in text
        assert 'Second' in text
        assert 'Third' in text

    def test_text_with_html_entities(self):
        """Test text with HTML entities"""
        d = pq('<div>&lt;tag&gt;</div>')
        text = d.text()
        assert text  # Should have some content

    def test_text_mixed_inline_block(self):
        """Test text from mixed inline and block elements"""
        html = '<div><p>Block <span>inline</span> text</p></div>'
        d = pq(html)
        text = d.text()
        assert 'Block' in text
        assert 'inline' in text
        assert 'text' in text

    def test_text_ignores_script_style(self):
        """Test that script/style content is handled"""
        html = '<div><p>Visible</p><script>invisible()</script></div>'
        d = pq(html)
        text = d.text()
        assert 'Visible' in text

    def test_text_set_replaces_content(self):
        """Test setting text replaces element content"""
        d = pq('<div><p>Old</p></div>')
        d.text('New text')
        assert d.text() == 'New text'
        assert len(d('p')) == 0

    def test_text_get_from_first_element(self):
        """Test text gets from first element when multiple selected"""
        html = '<div><p>First</p><p>Second</p></div>'
        d = pq(html)
        text = d('p').text()
        assert 'First' in text


class TestHtmlContent:
    """Test HTML content methods"""

    def test_html_get_inner(self):
        """Test getting inner HTML"""
        html = '<div><p>Content</p><span>Text</span></div>'
        d = pq(html)
        inner_html = d.html()
        assert '<p>' in inner_html or 'Content' in inner_html

    def test_html_get_simple(self):
        """Test getting simple HTML"""
        d = pq('<div><p>Simple</p></div>')
        html = d('div').html()
        assert 'Simple' in html

    def test_html_set_replaces(self):
        """Test setting HTML replaces content"""
        d = pq('<div><p>Old</p></div>')
        d.html('<span>New</span>')
        assert len(d('span')) == 1
        assert len(d('p')) == 0

    def test_html_set_appends_to_multiple(self):
        """Test setting HTML on multiple elements"""
        d = pq('<div></div><div></div>')
        d.html('<p>Content</p>')
        assert len(d('p')) >= 2

    def test_outer_html_includes_element(self):
        """Test outer_html includes the element itself"""
        d = pq('<p class="test">Content</p>')
        html = d.outer_html()
        assert '<p' in html
        assert 'test' in html
        assert 'Content' in html

    def test_outer_html_single_element(self):
        """Test outer_html on single element"""
        html = '<div id="unique">Unique content</div>'
        d = pq(html)
        outer = d.outer_html()
        assert 'unique' in outer
        assert 'Unique content' in outer


class TestTextExtractionAdvanced:
    """Test advanced text extraction"""

    def test_text_from_list(self):
        """Test text extraction from list"""
        html = '<ul><li>Item 1</li><li>Item 2</li><li>Item 3</li></ul>'
        d = pq(html)
        text = d('li').text()
        assert 'Item' in text

    def test_text_from_table(self):
        """Test text extraction from table"""
        html = '''<table>
            <tr><td>Cell 1</td><td>Cell 2</td></tr>
            <tr><td>Cell 3</td><td>Cell 4</td></tr>
        </table>'''
        d = pq(html)
        text = d('table').text()
        assert 'Cell' in text

    def test_text_preserves_structure(self):
        """Test text extraction preserves logical structure"""
        html = '<div><h1>Title</h1><p>Content here</p></div>'
        d = pq(html)
        text = d.text()
        assert 'Title' in text
        assert 'Content' in text

    def test_text_from_form_elements(self):
        """Test text extraction from form elements"""
        html = '''<form>
            <label>Name:</label>
            <input type="text" value="John" />
            <label>Email:</label>
            <input type="email" value="john@example.com" />
        </form>'''
        d = pq(html)
        text = d('form').text()
        assert 'Name' in text
        assert 'Email' in text


class TestValueExtraction:
    """Test value extraction from form elements"""

    def test_val_extraction(self):
        """Test val method extracts values"""
        html = '<div><input type="text" value="value1" /><input type="text" value="value2" /></div>'
        d = pq(html)
        assert d('input').eq(0).val() == 'value1'
        assert d('input').eq(1).val() == 'value2'

    def test_val_from_textarea(self):
        """Test val from textarea"""
        d = pq('<textarea>Content in textarea</textarea>')
        assert d.val() == 'Content in textarea'

    def test_val_from_select(self):
        """Test val from select element"""
        html = '''<select>
            <option>Option 1</option>
            <option selected>Option 2</option>
            <option>Option 3</option>
        </select>'''
        d = pq(html)
        val = d.val()
        assert val is not None


class TestHtmlEscaping:
    """Test HTML escaping in text"""

    def test_text_escapes_html(self):
        """Test that text handles HTML properly"""
        html = '<div>&lt;script&gt;alert("XSS")&lt;/script&gt;</div>'
        d = pq(html)
        text = d.text()
        # Should not execute script
        assert text is not None

    def test_set_text_escapes(self):
        """Test that setting text escapes HTML"""
        d = pq('<div></div>')
        d.text('<script>alert("test")</script>')
        html = str(d)
        # Text should be escaped or safe
        assert True


class TestWhitespaceHandling:
    """Test whitespace handling"""

    def test_whitespace_squashing(self):
        """Test squashing whitespace"""
        html = '<div>  Multiple   \n  spaces  </div>'
        d = pq(html)
        text = d.text(squash_space=True)
        # Should be cleaned up
        assert text.count(' ') <= text.count(' ') or len(text.split()) >= 1

    def test_preserve_meaningful_whitespace(self):
        """Test preserving meaningful whitespace"""
        html = '<div>Line 1\nLine 2</div>'
        d = pq(html)
        text = d.text()
        assert text is not None

    def test_tab_handling(self):
        """Test handling of tabs"""
        html = '<div>Start\tEnd</div>'
        d = pq(html)
        text = d.text()
        assert text is not None
