import pytest
from pyquery import PyQuery as pq


class TestAttr:
    """Test attr method"""

    def test_attr_get(self):
        """Test getting attribute"""
        d = pq('<div id="test">Content</div>')
        assert d.attr('id') == 'test'

    def test_attr_get_missing(self):
        """Test getting missing attribute"""
        d = pq('<div>Content</div>')
        assert d.attr('id') is None

    def test_attr_set_single(self):
        """Test setting single attribute"""
        d = pq('<div></div>')
        d.attr('id', 'new')
        assert d.attr('id') == 'new'

    def test_attr_set_multiple(self):
        """Test setting multiple attributes at once"""
        d = pq('<div></div>')
        d.attr({'id': 'test', 'class': 'highlight'})
        assert d.attr('id') == 'test'
        assert d.attr('class') == 'highlight'

    def test_attr_set_data_attribute(self):
        """Test setting data attributes"""
        d = pq('<div></div>')
        d.attr('data-value', '123')
        assert d.attr('data-value') == '123'

    def test_attr_overwrite(self):
        """Test overwriting attribute"""
        d = pq('<div id="old"></div>')
        d.attr('id', 'new')
        assert d.attr('id') == 'new'

    def test_attr_on_multiple_elements(self):
        """Test setting attr on multiple elements"""
        d = pq('<div></div><div></div>')
        d.attr('class', 'test')
        assert d.eq(0).attr('class') == 'test'
        assert d.eq(1).attr('class') == 'test'


class TestRemoveAttr:
    """Test remove_attr method"""

    def test_remove_attr_basic(self):
        """Test removing attribute"""
        d = pq('<div id="test" class="highlight">Content</div>')
        d.remove_attr('id')
        assert d.attr('id') is None
        assert d.attr('class') == 'highlight'

    def test_remove_attr_missing(self):
        """Test removing missing attribute"""
        d = pq('<div>Content</div>')
        d.remove_attr('id')  # Should not raise
        assert True

    def test_remove_attr_multiple(self):
        """Test removing from multiple elements"""
        d = pq('<div id="1"></div><div id="2"></div>')
        d.remove_attr('id')
        assert d.eq(0).attr('id') is None
        assert d.eq(1).attr('id') is None


class TestAddClass:
    """Test add_class method"""

    def test_add_class_basic(self):
        """Test adding class"""
        d = pq('<div></div>')
        d.add_class('highlight')
        assert 'highlight' in d.attr('class')

    def test_add_class_existing(self):
        """Test adding class to element with classes"""
        d = pq('<div class="active"></div>')
        d.add_class('highlight')
        classes = d.attr('class')
        assert 'active' in classes
        assert 'highlight' in classes

    def test_add_class_duplicate(self):
        """Test adding duplicate class"""
        d = pq('<div class="highlight"></div>')
        d.add_class('highlight')
        classes = d.attr('class')
        assert classes.count('highlight') >= 1

    def test_add_class_multiple(self):
        """Test adding class to multiple elements"""
        d = pq('<div></div><div></div>')
        d.add_class('active')
        assert 'active' in d.eq(0).attr('class')
        assert 'active' in d.eq(1).attr('class')


class TestRemoveClass:
    """Test remove_class method"""

    def test_remove_class_basic(self):
        """Test removing class"""
        d = pq('<div class="highlight active"></div>')
        d.remove_class('highlight')
        assert 'highlight' not in d.attr('class')
        assert 'active' in d.attr('class')

    def test_remove_class_missing(self):
        """Test removing non-existent class"""
        d = pq('<div class="active"></div>')
        d.remove_class('nonexistent')
        assert d.attr('class') == 'active'

    def test_remove_class_all(self):
        """Test removing only class removes class attribute"""
        d = pq('<div class="highlight"></div>')
        d.remove_class('highlight')
        assert d.attr('class') is None

    def test_remove_class_multiple(self):
        """Test removing class from multiple elements"""
        d = pq('<div class="active"></div><div class="active"></div>')
        d.remove_class('active')
        assert d.eq(0).attr('class') is None
        assert d.eq(1).attr('class') is None


class TestToggleClass:
    """Test toggle_class method"""

    def test_toggle_class_add(self):
        """Test toggling class on (add)"""
        d = pq('<div></div>')
        d.toggle_class('highlight')
        assert 'highlight' in d.attr('class')

    def test_toggle_class_remove(self):
        """Test toggling class off (remove)"""
        d = pq('<div class="highlight"></div>')
        d.toggle_class('highlight')
        assert d.attr('class') is None or 'highlight' not in d.attr('class')

    def test_toggle_class_multiple(self):
        """Test toggling class on multiple elements"""
        d = pq('<div class="active"></div><div></div>')
        d.toggle_class('active')
        # First should be removed, second should be added
        assert True


class TestHasClass:
    """Test has_class method"""

    def test_has_class_true(self):
        """Test has_class returns true"""
        d = pq('<div class="highlight"></div>')
        assert d.has_class('highlight') is True

    def test_has_class_false(self):
        """Test has_class returns false"""
        d = pq('<div class="active"></div>')
        assert d.has_class('highlight') is False

    def test_has_class_empty(self):
        """Test has_class on element without class"""
        d = pq('<div></div>')
        assert d.has_class('highlight') is False

    def test_has_class_multiple_classes(self):
        """Test has_class with multiple classes"""
        d = pq('<div class="active highlight"></div>')
        assert d.has_class('highlight') is True
        assert d.has_class('active') is True
        assert d.has_class('nonexistent') is False


class TestCss:
    """Test css method"""

    def test_css_get(self):
        """Test getting CSS property"""
        d = pq('<div style="color: red;"></div>')
        color = d.css('color')
        assert color is not None

    def test_css_set_single(self):
        """Test setting single CSS property"""
        d = pq('<div></div>')
        d.css('color', 'blue')
        assert 'color' in d.attr('style')
        assert 'blue' in d.attr('style')

    def test_css_set_multiple(self):
        """Test setting multiple CSS properties"""
        d = pq('<div></div>')
        d.css({'color': 'red', 'background': 'yellow'})
        style = d.attr('style')
        assert 'color' in style
        assert 'red' in style

    def test_css_overwrite(self):
        """Test overwriting CSS property"""
        d = pq('<div style="color: red;"></div>')
        d.css('color', 'blue')
        style = d.attr('style')
        assert 'blue' in style

    def test_css_multiple_elements(self):
        """Test setting CSS on multiple elements"""
        d = pq('<div></div><div></div>')
        d.css('display', 'block')
        assert 'block' in d.eq(0).attr('style')
        assert 'block' in d.eq(1).attr('style')


class TestHeight:
    """Test height method"""

    def test_height_get(self):
        """Test getting height"""
        d = pq('<div style="height: 100px;"></div>')
        height = d.height()
        assert height is not None

    def test_height_set(self):
        """Test setting height"""
        d = pq('<div></div>')
        d.height('200px')
        assert '200px' in d.attr('style')

    def test_height_no_value_get(self):
        """Test getting height without value"""
        d = pq('<div></div>')
        height = d.height()
        assert height is None


class TestWidth:
    """Test width method"""

    def test_width_get(self):
        """Test getting width"""
        d = pq('<div style="width: 100px;"></div>')
        width = d.width()
        assert width is not None

    def test_width_set(self):
        """Test setting width"""
        d = pq('<div></div>')
        d.width('200px')
        assert '200px' in d.attr('style')


class TestHide:
    """Test hide method"""

    def test_hide_basic(self):
        """Test hiding element"""
        d = pq('<div></div>')
        d.hide()
        assert 'display' in d.attr('style')
        assert 'none' in d.attr('style')


class TestShow:
    """Test show method"""

    def test_show_basic(self):
        """Test showing element"""
        d = pq('<div></div>')
        d.show()
        assert 'display' in d.attr('style')
        assert 'block' in d.attr('style')
