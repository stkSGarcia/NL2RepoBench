"""
Six is a Python 2 and 3 compatibility library.

It provides utilities for writing code that runs on both Python 2 and Python 3.
"""

import sys
import operator
import functools
import io
import re

__version__ = "1.16.0"
__author__ = "Benjamin Peterson"
__license__ = "MIT"

PY2 = sys.version_info[0] == 2
PY3 = sys.version_info[0] == 3
PY34 = sys.version_info[:2] >= (3, 4)

if PY3:
    string_types = (str,)
    integer_types = (int,)
    class_types = (type,)
    text_type = str
    binary_type = bytes
else:
    string_types = (basestring,)
    integer_types = (int, long)
    class_types = (type, types.ClassType)
    text_type = unicode
    binary_type = str

MAXSIZE = sys.maxsize


def _add_doc(func, doc):
    """Add documentation to a function."""
    func.__doc__ = doc
    return func


def _import_module(name):
    """Import module, returning the module after the last dot."""
    __import__(name)
    return sys.modules[name]


class _LazyModule(type(sys)):
    """Lazy module loader."""

    def __init__(self, name):
        super(_LazyModule, self).__init__(name)
        self.__dict__['__doc__'] = self.__class__.__doc__

    def __dir__(self):
        attrs = ["__doc__", "__name__"]
        attrs += [attr['name'] for attr in self.__dict__.get('_moved_attributes', [])]
        return attrs

    __path__ = []
    _moved_attributes = []


class MovedModule(object):
    """A moved module mapping."""

    def __init__(self, name, old, new=None):
        self.name = name
        if PY3:
            if new is None:
                new = name
            self.mod = new
        else:
            self.mod = old
        self.old = old
        self.new = new if new is not None else name

    def _resolve(self):
        return _import_module(self.mod)

    def __repr__(self):
        return "<%s for module %s at 0x%x>" % (self.__class__.__name__, self.name, id(self))


class MovedAttribute(object):
    """A moved attribute mapping."""

    def __init__(self, name, old_mod, new_mod, old_attr=None, new_attr=None):
        self.name = name
        if old_attr is None:
            old_attr = name
        if new_attr is None:
            new_attr = old_attr
        self.old_mod = old_mod
        self.new_mod = new_mod
        self.old_attr = old_attr
        self.new_attr = new_attr

    def _resolve(self):
        if PY3:
            mod = _import_module(self.new_mod)
            attr = self.new_attr
        else:
            mod = _import_module(self.old_mod)
            attr = self.old_attr
        return getattr(mod, attr)

    def __repr__(self):
        return "<%s for attribute %s at 0x%x>" % (self.__class__.__name__, self.name, id(self))


class _SixMetaPathImporter(object):
    """A meta path importer for six.moves and its submodules."""

    def __init__(self, six_module_name):
        self.name = six_module_name
        self.known_modules = {}

    def _add_module(self, mod, *fullnames):
        for fullname in fullnames:
            self.known_modules[self.name + "." + fullname] = mod

    def _get_module(self, fullname):
        try:
            return self.known_modules[fullname]
        except KeyError:
            raise ImportError("This loader does not know module " + fullname)

    def find_module(self, fullname, path=None):
        if fullname in self.known_modules:
            return self
        return None

    def find_spec(self, fullname, path, target=None):
        if fullname in self.known_modules:
            try:
                from importlib.util import spec_from_loader
                return spec_from_loader(fullname, self, is_package=True)
            except ImportError:
                return None
        return None

    def load_module(self, fullname):
        try:
            mod = self.known_modules[fullname]
        except KeyError:
            raise ImportError("This loader does not know module " + fullname)
        if fullname in sys.modules:
            return sys.modules[fullname]
        if isinstance(mod, MovedModule):
            mod = mod._resolve()
        else:
            mod.__loader__ = self
        sys.modules[fullname] = mod
        return mod

    def is_package(self, fullname):
        try:
            module = self.known_modules[fullname]
        except KeyError:
            return False
        return hasattr(module, "__path__")

    def get_code(self, fullname):
        return None

    get_source = get_code

    def create_module(self, spec):
        return self.load_module(spec.name)

    def exec_module(self, module):
        pass


# urllib submodules
class Module_six_moves_urllib_parse(_LazyModule):
    """Lazy loading of urllib.parse"""
    pass


_urllib_parse_moved_attributes = [
    MovedAttribute("ParseResult", "urlparse", "urllib.parse"),
    MovedAttribute("SplitResult", "urlparse", "urllib.parse"),
    MovedAttribute("parse_qs", "urlparse", "urllib.parse"),
    MovedAttribute("parse_qsl", "urlparse", "urllib.parse"),
    MovedAttribute("urldefrag", "urlparse", "urllib.parse"),
    MovedAttribute("urljoin", "urlparse", "urllib.parse"),
    MovedAttribute("urlparse", "urlparse", "urllib.parse"),
    MovedAttribute("urlsplit", "urlparse", "urllib.parse"),
    MovedAttribute("urlunparse", "urlparse", "urllib.parse"),
    MovedAttribute("urlunsplit", "urlparse", "urllib.parse"),
    MovedAttribute("quote", "urllib", "urllib.parse"),
    MovedAttribute("quote_plus", "urllib", "urllib.parse"),
    MovedAttribute("unquote", "urllib", "urllib.parse"),
    MovedAttribute("unquote_plus", "urllib", "urllib.parse"),
    MovedAttribute("unquote_to_bytes", "urllib", "urllib.parse", "unquote", "unquote_to_bytes"),
    MovedAttribute("urlencode", "urllib", "urllib.parse"),
    MovedAttribute("splitquery", "urllib", "urllib.parse"),
    MovedAttribute("splittag", "urllib", "urllib.parse"),
    MovedAttribute("splituser", "urllib", "urllib.parse"),
    MovedAttribute("splitvalue", "urllib", "urllib.parse"),
    MovedAttribute("uses_fragment", "urlparse", "urllib.parse"),
    MovedAttribute("uses_netloc", "urlparse", "urllib.parse"),
    MovedAttribute("uses_params", "urlparse", "urllib.parse"),
    MovedAttribute("uses_query", "urlparse", "urllib.parse"),
    MovedAttribute("uses_relative", "urlparse", "urllib.parse"),
]

for attr in _urllib_parse_moved_attributes:
    setattr(Module_six_moves_urllib_parse, attr.name, attr)

Module_six_moves_urllib_parse._moved_attributes = _urllib_parse_moved_attributes


class Module_six_moves_urllib_error(_LazyModule):
    """Lazy loading of urllib.error"""
    pass


_urllib_error_moved_attributes = [
    MovedAttribute("URLError", "urllib2", "urllib.error"),
    MovedAttribute("HTTPError", "urllib2", "urllib.error"),
    MovedAttribute("ContentTooShortError", "urllib", "urllib.error"),
]

for attr in _urllib_error_moved_attributes:
    setattr(Module_six_moves_urllib_error, attr.name, attr)

Module_six_moves_urllib_error._moved_attributes = _urllib_error_moved_attributes


class Module_six_moves_urllib_request(_LazyModule):
    """Lazy loading of urllib.request"""
    pass


_urllib_request_moved_attributes = [
    MovedAttribute("urlopen", "urllib2", "urllib.request"),
    MovedAttribute("install_opener", "urllib2", "urllib.request"),
    MovedAttribute("build_opener", "urllib2", "urllib.request"),
    MovedAttribute("pathname2url", "urllib", "urllib.request"),
    MovedAttribute("url2pathname", "urllib", "urllib.request"),
    MovedAttribute("getproxies", "urllib", "urllib.request"),
    MovedAttribute("Request", "urllib2", "urllib.request"),
    MovedAttribute("OpenerDirector", "urllib2", "urllib.request"),
    MovedAttribute("HTTPDefaultErrorHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPRedirectHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPCookieProcessor", "urllib2", "urllib.request"),
    MovedAttribute("ProxyHandler", "urllib2", "urllib.request"),
    MovedAttribute("BaseHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPPasswordMgr", "urllib2", "urllib.request"),
    MovedAttribute("HTTPPasswordMgrWithDefaultRealm", "urllib2", "urllib.request"),
    MovedAttribute("AbstractBasicAuthHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPBasicAuthHandler", "urllib2", "urllib.request"),
    MovedAttribute("ProxyBasicAuthHandler", "urllib2", "urllib.request"),
    MovedAttribute("AbstractDigestAuthHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPDigestAuthHandler", "urllib2", "urllib.request"),
    MovedAttribute("ProxyDigestAuthHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPSHandler", "urllib2", "urllib.request"),
    MovedAttribute("FileHandler", "urllib2", "urllib.request"),
    MovedAttribute("FTPHandler", "urllib2", "urllib.request"),
    MovedAttribute("CacheFTPHandler", "urllib2", "urllib.request"),
    MovedAttribute("UnknownHandler", "urllib2", "urllib.request"),
    MovedAttribute("HTTPErrorProcessor", "urllib2", "urllib.request"),
    MovedAttribute("urlretrieve", "urllib", "urllib.request"),
    MovedAttribute("urlcleanup", "urllib", "urllib.request"),
    MovedAttribute("proxy_bypass", "urllib", "urllib.request"),
    MovedAttribute("parse_http_list", "urllib2", "urllib.request"),
    MovedAttribute("parse_keqv_list", "urllib2", "urllib.request"),
]

if sys.version_info < (3, 14):
    _urllib_request_moved_attributes.extend([
        MovedAttribute("URLopener", "urllib", "urllib.request"),
        MovedAttribute("FancyURLopener", "urllib", "urllib.request"),
    ])

for attr in _urllib_request_moved_attributes:
    setattr(Module_six_moves_urllib_request, attr.name, attr)

Module_six_moves_urllib_request._moved_attributes = _urllib_request_moved_attributes


class Module_six_moves_urllib_response(_LazyModule):
    """Lazy loading of urllib.response"""
    pass


_urllib_response_moved_attributes = [
    MovedAttribute("addbase", "urllib", "urllib.response"),
    MovedAttribute("addclosehook", "urllib", "urllib.response"),
    MovedAttribute("addinfo", "urllib", "urllib.response"),
    MovedAttribute("addinfourl", "urllib", "urllib.response"),
]

for attr in _urllib_response_moved_attributes:
    setattr(Module_six_moves_urllib_response, attr.name, attr)

Module_six_moves_urllib_response._moved_attributes = _urllib_response_moved_attributes


class Module_six_moves_urllib_robotparser(_LazyModule):
    """Lazy loading of urllib.robotparser"""
    pass


_urllib_robotparser_moved_attributes = [
    MovedAttribute("RobotFileParser", "robotparser", "urllib.robotparser"),
]

for attr in _urllib_robotparser_moved_attributes:
    setattr(Module_six_moves_urllib_robotparser, attr.name, attr)

Module_six_moves_urllib_robotparser._moved_attributes = _urllib_robotparser_moved_attributes


class Module_six_moves_urllib(_LazyModule):
    """Create a six.moves.urllib namespace that resembles the Python 3 namespace."""

    def __dir__(self):
        return ['parse', 'error', 'request', 'response', 'robotparser']


sys.modules[__name__ + ".moves.urllib_parse"] = Module_six_moves_urllib_parse(__name__ + ".moves.urllib_parse")
sys.modules[__name__ + ".moves.urllib_error"] = Module_six_moves_urllib_error(__name__ + ".moves.urllib_error")
sys.modules[__name__ + ".moves.urllib_request"] = Module_six_moves_urllib_request(__name__ + ".moves.urllib_request")
sys.modules[__name__ + ".moves.urllib_response"] = Module_six_moves_urllib_response(__name__ + ".moves.urllib_response")
sys.modules[__name__ + ".moves.urllib_robotparser"] = Module_six_moves_urllib_robotparser(__name__ + ".moves.urllib_robotparser")

_urllib = Module_six_moves_urllib(__name__ + ".moves.urllib")
_urllib.parse = sys.modules[__name__ + ".moves.urllib_parse"]
_urllib.error = sys.modules[__name__ + ".moves.urllib_error"]
_urllib.request = sys.modules[__name__ + ".moves.urllib_request"]
_urllib.response = sys.modules[__name__ + ".moves.urllib_response"]
_urllib.robotparser = sys.modules[__name__ + ".moves.urllib_robotparser"]
sys.modules[__name__ + ".moves.urllib"] = _urllib


class _MovedItems(_LazyModule):
    """Lazy loading of moved objects."""
    __path__ = []


_moved_attributes = [
    MovedAttribute("cStringIO", "cStringIO", "io", "StringIO"),
    MovedAttribute("filter", "itertools", "builtins", "ifilter", "filter"),
    MovedAttribute("filterfalse", "itertools", "itertools", "ifilterfalse", "filterfalse"),
    MovedAttribute("input", "__builtin__", "builtins", "raw_input", "input"),
    MovedAttribute("intern", "__builtin__", "sys"),
    MovedAttribute("map", "itertools", "builtins", "imap", "map"),
    MovedAttribute("getcwd", "os", "os", "getcwdu", "getcwd"),
    MovedAttribute("getcwdb", "os", "os", "getcwd", "getcwdb"),
    MovedAttribute("getoutput", "commands", "subprocess"),
    MovedAttribute("range", "__builtin__", "builtins", "xrange", "range"),
    MovedAttribute("reload_module", "__builtin__", "importlib" if PY34 else "imp", "reload"),
    MovedAttribute("reduce", "__builtin__", "functools"),
    MovedAttribute("shlex_quote", "pipes", "shlex", "quote"),
    MovedAttribute("StringIO", "StringIO", "io"),
    MovedAttribute("UserDict", "UserDict", "collections", "IterableUserDict", "UserDict"),
    MovedAttribute("UserList", "UserList", "collections"),
    MovedAttribute("UserString", "UserString", "collections"),
    MovedAttribute("xrange", "__builtin__", "builtins", "xrange", "range"),
    MovedAttribute("zip", "itertools", "builtins", "izip", "zip"),
    MovedAttribute("zip_longest", "itertools", "itertools", "izip_longest", "zip_longest"),
    MovedModule("builtins", "__builtin__"),
    MovedModule("configparser", "ConfigParser"),
    MovedModule("collections_abc", "collections", "collections.abc" if sys.version_info >= (3, 3) else "collections"),
    MovedModule("copyreg", "copy_reg"),
    MovedModule("dbm_gnu", "gdbm", "dbm.gnu"),
    MovedModule("dbm_ndbm", "dbm", "dbm.ndbm"),
    MovedModule("_dummy_thread", "dummy_thread", "_dummy_thread" if sys.version_info < (3, 9) else "_thread"),
    MovedModule("http_cookiejar", "cookielib", "http.cookiejar"),
    MovedModule("http_cookies", "Cookie", "http.cookies"),
    MovedModule("html_entities", "htmlentitydefs", "html.entities"),
    MovedModule("html_parser", "HTMLParser", "html.parser"),
    MovedModule("http_client", "httplib", "http.client"),
    MovedModule("email_mime_base", "email.MIMEBase", "email.mime.base"),
    MovedModule("email_mime_image", "email.MIMEImage", "email.mime.image"),
    MovedModule("email_mime_multipart", "email.MIMEMultipart", "email.mime.multipart"),
    MovedModule("email_mime_nonmultipart", "email.MIMENonMultipart", "email.mime.nonmultipart"),
    MovedModule("email_mime_text", "email.MIMEText", "email.mime.text"),
    MovedModule("BaseHTTPServer", "BaseHTTPServer", "http.server"),
    MovedModule("CGIHTTPServer", "CGIHTTPServer", "http.server"),
    MovedModule("SimpleHTTPServer", "SimpleHTTPServer", "http.server"),
    MovedModule("cPickle", "cPickle", "pickle"),
    MovedModule("queue", "Queue"),
    MovedModule("reprlib", "repr"),
    MovedModule("socketserver", "SocketServer"),
    MovedModule("_thread", "thread", "_thread"),
    MovedModule("tkinter", "Tkinter"),
    MovedModule("tkinter_dialog", "Dialog", "tkinter.dialog"),
    MovedModule("tkinter_filedialog", "FileDialog", "tkinter.filedialog"),
    MovedModule("tkinter_scrolledtext", "ScrolledText", "tkinter.scrolledtext"),
    MovedModule("tkinter_simpledialog", "SimpleDialog", "tkinter.simpledialog"),
    MovedModule("tkinter_tix", "Tix", "tkinter.tix"),
    MovedModule("tkinter_ttk", "ttk", "tkinter.ttk"),
    MovedModule("tkinter_constants", "Tkconstants", "tkinter.constants"),
    MovedModule("tkinter_dnd", "Tkdnd", "tkinter.dnd"),
    MovedModule("tkinter_colorchooser", "tkColorChooser", "tkinter.colorchooser"),
    MovedModule("tkinter_commondialog", "tkCommonDialog", "tkinter.commondialog"),
    MovedModule("tkinter_tkfiledialog", "tkFileDialog", "tkinter.filedialog"),
    MovedModule("tkinter_font", "tkFont", "tkinter.font"),
    MovedModule("tkinter_messagebox", "tkMessageBox", "tkinter.messagebox"),
    MovedModule("tkinter_tksimpledialog", "tkSimpleDialog", "tkinter.simpledialog"),
    MovedModule("urllib_parse", __name__ + ".moves.urllib_parse", "urllib.parse"),
    MovedModule("urllib_error", __name__ + ".moves.urllib_error", "urllib.error"),
    MovedModule("urllib", __name__ + ".moves.urllib", __name__ + ".moves.urllib"),
    MovedModule("urllib_robotparser", "robotparser", "urllib.robotparser"),
    MovedModule("xmlrpc_client", "xmlrpclib", "xmlrpc.client"),
    MovedModule("xmlrpc_server", "SimpleXMLRPCServer", "xmlrpc.server"),
]

if sys.platform == "win32":
    _moved_attributes.append(MovedModule("winreg", "_winreg"))

for attr in _moved_attributes:
    setattr(_MovedItems, attr.name, attr)

_MovedItems._moved_attributes = [{'name': attr.name} for attr in _moved_attributes]


_importer = _SixMetaPathImporter(__name__)
_importer._add_module(sys.modules[__name__ + ".moves.urllib_parse"], "moves.urllib_parse", "moves.urllib.parse")
_importer._add_module(sys.modules[__name__ + ".moves.urllib_error"], "moves.urllib_error", "moves.urllib.error")
_importer._add_module(sys.modules[__name__ + ".moves.urllib_request"], "moves.urllib_request", "moves.urllib.request")
_importer._add_module(sys.modules[__name__ + ".moves.urllib_response"], "moves.urllib_response", "moves.urllib.response")
_importer._add_module(sys.modules[__name__ + ".moves.urllib_robotparser"], "moves.urllib_robotparser", "moves.urllib.robotparser")
_importer._add_module(_urllib, "moves.urllib")
_importer._add_module(_MovedItems(__name__ + ".moves"), "moves")

class Module_six_moves(_LazyModule):
    """Lazy loading of six.moves."""
    __path__ = []
    __package__ = __name__ + ".moves"

for attr in _moved_attributes:
    setattr(Module_six_moves, attr.name, attr)

sys.modules[__name__ + ".moves"] = Module_six_moves(__name__ + ".moves")

sys.meta_path.append(_importer)

moves = sys.modules[__name__ + ".moves"]


# Iterator and next() compatibility
def next(it):
    return it.__next__() if hasattr(it, '__next__') else it.next()


class Iterator(object):
    """Base class for iterators."""
    def __next__(self):
        raise NotImplementedError

    def next(self):
        return self.__next__()

    def __iter__(self):
        return self


# Dictionary iteration compatibility
def iterkeys(d):
    try:
        return iter(d.keys())
    except AttributeError:
        return d.iterkeys()


def itervalues(d):
    try:
        return iter(d.values())
    except AttributeError:
        return d.itervalues()


def iteritems(d):
    try:
        return iter(d.items())
    except AttributeError:
        return d.iteritems()


def iterlists(d):
    try:
        return iter(d.lists())
    except AttributeError:
        return d.iterlists()


def viewkeys(d):
    try:
        return d.keys()
    except AttributeError:
        return d.viewkeys()


def viewvalues(d):
    try:
        return d.values()
    except AttributeError:
        return d.viewvalues()


def viewitems(d):
    try:
        return d.items()
    except AttributeError:
        return d.viewitems()


# Byte and string compatibility
def b(s):
    if isinstance(s, text_type):
        return s.encode("latin-1")
    return s


def u(s):
    if isinstance(s, binary_type):
        return s.decode("utf-8")
    return s


def unichr(c):
    if PY3:
        return chr(c)
    return unichr(c)


def int2byte(i):
    if PY3:
        return bytes((i,))
    return chr(i)


def byte2int(bs):
    if PY3:
        return bs[0]
    return ord(bs[0])


def ensure_str(s, encoding="utf-8", errors="strict"):
    if isinstance(s, text_type):
        return s
    if isinstance(s, binary_type):
        return s.decode(encoding, errors)
    raise TypeError("not expecting type %r" % type(s))


def ensure_binary(s, encoding="utf-8", errors="strict"):
    if isinstance(s, binary_type):
        return s
    if isinstance(s, text_type):
        return s.encode(encoding, errors)
    raise TypeError("not expecting type %r" % type(s))


def ensure_text(s, encoding="utf-8", errors="strict"):
    if isinstance(s, text_type):
        return s
    if isinstance(s, binary_type):
        return s.decode(encoding, errors)
    raise TypeError("not expecting type %r" % type(s))


# Function attribute access compatibility
if PY3:
    get_function_code = operator.attrgetter("__code__")
    get_function_globals = operator.attrgetter("__globals__")
    get_function_defaults = operator.attrgetter("__defaults__")
    get_function_closure = operator.attrgetter("__closure__")
    get_function_dict = operator.attrgetter("__dict__")
    def get_method_function(meth):
        return meth.__func__
    def get_method_self(meth):
        return meth.__self__
    def get_unbound_function(meth):
        return meth
    create_bound_method = lambda func, obj: func.__get__(obj, type(obj))
else:
    get_function_code = operator.attrgetter("func_code")
    get_function_globals = operator.attrgetter("func_globals")
    get_function_defaults = operator.attrgetter("func_defaults")
    get_function_closure = operator.attrgetter("func_closure")
    get_function_dict = operator.attrgetter("func_dict")
    def get_method_function(meth):
        return meth.im_func
    def get_method_self(meth):
        return meth.im_self
    def get_unbound_function(meth):
        return meth.im_func
    def create_bound_method(func, obj):
        return func.__get__(obj, type(obj))


def create_unbound_method(func, cls):
    return func


# Syntax compatibility
if PY3:
    import builtins
    exec_ = getattr(builtins, "exec")
    def print_(*args, **kwargs):
        return builtins.print(*args, **kwargs)
else:
    def exec_(_code_, _globs_=None, _locs_=None):
        if _globs_ is None:
            frame = sys._getframe(1)
            _globs_ = frame.f_globals
            if _locs_ is None:
                _locs_ = frame.f_locals
            del frame
        elif _locs_ is None:
            _locs_ = _globs_
        exec("""exec _code_ in _globs_, _locs_""")

    def print_(*args, **kwargs):
        fp = kwargs.pop("file", sys.stdout)
        if fp is None:
            return
        def write(data):
            if not isinstance(data, basestring):
                data = str(data)
            if isinstance(fp, file):
                mode = getattr(fp, "mode", None)
                if "b" in mode:
                    data = data.encode("utf-8")
            fp.write(data)
        want_unicode = False
        sep = kwargs.pop("sep", None)
        if sep is not None:
            if isinstance(sep, unicode):
                want_unicode = True
            elif not isinstance(sep, str):
                raise TypeError("sep must be None or a string")
        end = kwargs.pop("end", None)
        if end is not None:
            if isinstance(end, unicode):
                want_unicode = True
            elif not isinstance(end, str):
                raise TypeError("end must be None or a string")
        if kwargs:
            raise TypeError("invalid keyword arguments to print()")
        if not want_unicode:
            for arg in args:
                if isinstance(arg, unicode):
                    want_unicode = True
                    break
        if want_unicode:
            newline = unicode("\n")
            space = unicode(" ")
        else:
            newline = "\n"
            space = " "
        if sep is None:
            sep = space
        if end is None:
            end = newline
        for i, arg in enumerate(args):
            if i:
                write(sep)
            write(arg)
        write(end)


if PY3:
    def raise_from(value, from_value):
        if from_value is None:
            raise value
        raise value from from_value

    def reraise(tp, value, tb=None):
        try:
            if value is None:
                value = tp()
            if value.__traceback__ is not tb:
                raise value.with_traceback(tb)
            raise value
        finally:
            value = None
            tb = None
else:
    exec_("""def reraise(tp, value, tb=None):
    raise tp, value, tb
""")

    def raise_from(value, from_value):
        raise value


# Metaclass compatibility
def with_metaclass(meta, *bases):
    """Create a base class with a metaclass."""
    if not bases:
        bases = (object,)
    return meta("temporary_class", bases, {})


def add_metaclass(metaclass):
    """Class decorator for creating a class with a metaclass."""
    def wrapper(cls):
        orig_vars = cls.__dict__.copy()
        slots = orig_vars.get('__slots__')
        if slots is not None:
            if isinstance(slots, str):
                slots = [slots]
            for slots_var in slots:
                orig_vars.pop(slots_var)
        orig_vars.pop('__dict__', None)
        orig_vars.pop('__weakref__', None)
        return metaclass(cls.__name__, cls.__bases__, orig_vars)
    return wrapper


def python_2_unicode_compatible(cls):
    """A decorator that defines __unicode__ and __str__ methods under Python 2."""
    if PY3:
        return cls
    if not hasattr(cls, '__unicode__'):
        raise ValueError("@python_2_unicode_compatible requires a __unicode__ method")
    cls.__str__ = lambda self: self.__unicode__().encode('utf-8')
    return cls


# StringIO and BytesIO compatibility
StringIO = io.StringIO
BytesIO = io.BytesIO


# wraps decorator compatibility
wraps = functools.wraps


# unittest assertion compatibility
def assertCountEqual(test, first, second, msg=None):
    if hasattr(test, 'assertCountEqual'):
        return test.assertCountEqual(first, second, msg)
    return test.assertEquals(sorted(first), sorted(second), msg)


def assertRaisesRegex(test, exception, regex, callable_obj=None, *args, **kwargs):
    if hasattr(test, 'assertRaisesRegex'):
        return test.assertRaisesRegex(exception, regex, callable_obj, *args, **kwargs)
    return test.assertRaisesRegexp(exception, regex, callable_obj, *args, **kwargs)


def assertRegex(test, text, regex, msg=None):
    if hasattr(test, 'assertRegex'):
        return test.assertRegex(text, regex, msg)
    return test.assertRegexpMatches(text, regex, msg)


def assertNotRegex(test, text, regex, msg=None):
    if hasattr(test, 'assertNotRegex'):
        return test.assertNotRegex(text, regex, msg)
    return test.assertNotRegexpMatches(text, regex, msg)


__all__ = [
    "PY2", "PY3", "PY34",
    "string_types", "integer_types", "class_types", "text_type", "binary_type",
    "MAXSIZE",
    "next", "Iterator",
    "iterkeys", "itervalues", "iteritems", "iterlists",
    "viewkeys", "viewvalues", "viewitems",
    "b", "u", "unichr", "int2byte", "byte2int",
    "ensure_str", "ensure_binary", "ensure_text",
    "get_function_code", "get_function_globals", "get_function_defaults", "get_function_closure", "get_function_dict",
    "get_method_function", "get_method_self", "get_unbound_function", "create_bound_method", "create_unbound_method",
    "exec_", "print_", "raise_from", "reraise",
    "with_metaclass", "add_metaclass", "python_2_unicode_compatible",
    "StringIO", "BytesIO",
    "wraps",
    "assertCountEqual", "assertRaisesRegex", "assertRegex", "assertNotRegex",
    "MovedModule", "MovedAttribute",
    "moves",
]
