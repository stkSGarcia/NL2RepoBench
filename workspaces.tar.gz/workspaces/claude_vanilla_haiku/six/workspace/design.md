# Six Library Implementation Design

## Overview

This document describes the implementation of the Six Python 2/3 compatibility library and the design decisions made during development.

## Implementation Approach

### Core Architecture

The Six library is implemented as a single-file module (`six.py`) that provides compatibility utilities across Python 2 and Python 3. The implementation follows the original Six design philosophy:

1. **Minimal external dependencies**: Uses only Python standard library
2. **Lazy loading**: Defers imports until actually needed
3. **Runtime version detection**: Detects Python version at import time
4. **Direct compatibility mappings**: Maps Python 2 functions/modules to their Python 3 equivalents

### Key Components

#### 1. Version Detection
- `PY2`, `PY3`, `PY34` constants detect the current Python version at import time
- These constants are checked at runtime, not compile time, allowing the same code to adapt to different Python versions

#### 2. Type Constants
- `string_types`, `integer_types`, `class_types`: Tuples of types for isinstance checks
- `text_type`, `binary_type`: The native string/bytes types for each Python version
- `MAXSIZE`: Container size limit from sys.maxsize

#### 3. Lazy Module Loading (_SixMetaPathImporter)
The `_SixMetaPathImporter` class implements PEP 302/451 module loading:
- Registers as a meta path importer with sys.meta_path
- Provides `find_module()` (PEP 302) and `find_spec()` (PEP 451) methods
- Lazily resolves `MovedModule` and `MovedAttribute` objects
- Caches resolved modules in sys.modules for subsequent imports

#### 4. Moved Modules and Attributes
- `MovedModule`: Maps module names that changed between Python 2/3 (e.g., `Queue` → `queue`)
- `MovedAttribute`: Maps individual attributes/functions that moved between modules (e.g., `urlparse.urlparse` → `urllib.parse.urlparse`)
- Uses lazy resolution to avoid importing unused modules

#### 5. six.moves Package
The `six.moves` module provides:
- Standard library renames (`queue`, `configparser`, etc.)
- urllib submodule compatibility (parse, error, request, response, robotparser)
- Iterator/function renames (`range`, `zip`, `map`, `filter`, etc.)
- Custom attribute mappings for functions that changed

#### 6. Compatibility Functions
Organized into categories:
- **Iterator compatibility**: `next()`, `Iterator` class
- **Dictionary iteration**: `iterkeys()`, `itervalues()`, `iteritems()`, view functions
- **String/byte conversion**: `b()`, `u()`, `ensure_binary()`, `ensure_text()`, `ensure_str()`
- **Function attributes**: `get_function_code()`, `get_function_globals()`, etc.
- **Method attributes**: `get_method_function()`, `get_method_self()`, etc.
- **Syntax compatibility**: `exec_()`, `print_()`, `raise_from()`, `reraise()`
- **Metaclass support**: `with_metaclass()`, `add_metaclass()`, `python_2_unicode_compatible()`
- **IO compatibility**: `StringIO`, `BytesIO`
- **unittest compatibility**: `assertCountEqual()`, `assertRegex()`, etc.

## Design Decisions and Assumptions

### Assumptions

#### Assumption 1: Target Python Version
**Assumption**: The implementation is designed for Python 3.12+, with compatibility maintained for Python 2.7 and Python 3.3+
**Justification**: The spec mentions Python 3.12.4 as the environment, but the library should support the full range of Python 2/3 versions
**Implementation**: Some Python 2-specific code uses conditional imports and string literals that may not work in Python 3.12 without proper handling

#### Assumption 2: Import Behavior
**Assumption**: The six.moves module is lazily loaded to avoid importing unnecessary modules
**Justification**: In Python 2, some modules don't exist, and in Python 3, others were restructured. Lazy loading prevents import errors and improves startup time
**Implementation**: Uses `_SixMetaPathImporter` and lazy descriptor classes

#### Assumption 3: String/Bytes Handling
**Assumption**: When Python version is not explicitly specified, functions default to Python 3 semantics:
- `text_type` = `str` (text in both Python 2 and 3)
- `binary_type` = `bytes` (binary in Python 3, `str` in Python 2)
**Justification**: Most modern code targets Python 3
**Implementation**: Conditional checks on `PY2` and `PY3` constants

#### Assumption 4: Metaclass Implementation
**Assumption**: `with_metaclass()` creates a temporary base class that tricks Python into using the specified metaclass
**Justification**: Python 2 and 3 have incompatible syntax for specifying metaclasses
**Implementation**: Returns a temporary class with the metaclass applied as the metaclass of the temporary class

#### Assumption 5: Exception Handling
**Assumption**: Python 3 `raise ... from ...` syntax is used when available, with fallback to Python 2 `exec` for Python 2
**Justification**: The specification requires both Python 2 and Python 3 compatibility
**Implementation**: `raise_from()` uses `exec_()` under the hood for Python 2

#### Assumption 6: Print Function
**Assumption**: `print_()` implementation uses `exec_()` to handle the differences in print semantics
**Justification**: In Python 2, `print` is a statement; in Python 3, it's a function
**Implementation**: The function signature mimics Python 3's `print()` function with `file`, `sep`, and `end` keyword arguments

### Design Rationale

#### Why Single File?
- Simplicity: All functionality in one easily importable module
- No dependency issues: Single file to distribute
- Fast imports: Lazy loading prevents unnecessary compilation

#### Why Lazy Loading?
- Performance: Don't import modules that aren't used
- Compatibility: Avoid import errors on Python 2 or 3
- Flexibility: Allow sys.modules manipulation before importing

#### Why _SixMetaPathImporter?
- Cleanest approach: Uses Python's standard import machinery
- Compatible: Works with both import and reloading
- Extensible: Can add new moved modules dynamically

#### Why Conditional isinstance Checks?
- Type safety: Works with isinstance() and type() checks consistently
- Performance: Direct tuple checks are fast
- Clarity: Explicit about what types are being checked

## Known Limitations and Trade-offs

### Limitation 1: Python 2 Only in Six Context
The implementation is written and tested primarily in Python 3, which means:
- Some Python 2-specific code uses string literals that may have edge cases
- Comprehensive testing would require running on actual Python 2 (2.7)
- **Workaround**: The code follows Python 2 semantics but may have subtle differences

### Limitation 2: Limited urllib.robotparser Compatibility
The urllib.robotparser moved attribute is defined but may have limited testing:
- **Assumption**: It follows the same pattern as other urllib modules
- **Workaround**: If needed, can be extended with more specific handling

### Limitation 3: Windows-Specific Code
The `winreg` module is only added on Windows:
- **Assumption**: The implementation correctly detects Windows via `sys.platform == "win32"`
- **Note**: macOS and Linux don't have `winreg`, which is correct

### Limitation 4: Print_ Implementation
The `print_()` function implementation relies on `exec_()`:
- **Assumption**: Works correctly in both Python 2 and 3
- **Trade-off**: Not as efficient as native print, but necessary for compatibility

### Limitation 5: Metaclass Decorator
The `add_metaclass()` decorator creates a temporary class:
- **Assumption**: The temporary class doesn't interfere with the actual class
- **Trade-off**: Slightly less efficient than direct metaclass specification, but necessary for syntax compatibility

## Testing Considerations

### Test Categories

1. **Type Constants**: Verify `string_types`, `integer_types`, etc. work correctly
2. **Iterator Functions**: Test `next()`, dictionary iteration functions
3. **String/Byte Functions**: Test all conversion functions
4. **six.moves Imports**: Verify common modules can be imported
5. **Metaclass Support**: Test `with_metaclass()` and `add_metaclass()`
6. **Function Attributes**: Test getting function internals
7. **Exception Handling**: Test `raise_from()` and `reraise()`

### How to Run Tests

```bash
# Install the package
pip install -e .

# Run tests (assuming six_tests.py exists)
pytest six_tests.py

# Or run with tox for multiple Python versions
tox
```

## Future Enhancements

1. **Performance**: Could cache more resolved modules
2. **Documentation**: Could expand inline documentation
3. **Testing**: Add comprehensive test suite
4. **Type Hints**: Could add type hints for Python 3.5+
5. **Python 4**: Prepare for future Python versions

## Conclusion

The implementation follows the original Six design philosophy while adapting to the specification requirements. It provides a clean, maintainable way to write Python code that works on both Python 2 and Python 3, with lazy loading and minimal overhead.
