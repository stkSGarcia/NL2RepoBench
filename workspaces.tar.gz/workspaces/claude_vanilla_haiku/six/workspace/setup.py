#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
Setup configuration for Six - Python 2 and 3 compatibility library
"""

from setuptools import setup

with open("README.rst", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name="six",
    version="1.16.0",
    description="Python 2 and 3 compatibility utilities",
    long_description=long_description,
    long_description_content_type="text/x-rst",
    author="Benjamin Peterson",
    author_email="benjamin@python.org",
    url="https://github.com/benjaminp/six",
    license="MIT",
    py_modules=["six"],
    python_requires=">=2.7, !=3.0.*, !=3.1.*, !=3.2.*",
    classifiers=[
        "Development Status :: 5 - Production/Stable",
        "Environment :: Console",
        "Intended Audience :: Developers",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 2",
        "Programming Language :: Python :: 2.7",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.3",
        "Programming Language :: Python :: 3.4",
        "Programming Language :: Python :: 3.5",
        "Programming Language :: Python :: 3.6",
        "Programming Language :: Python :: 3.7",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Programming Language :: Python :: Implementation :: CPython",
        "Programming Language :: Python :: Implementation :: PyPy",
        "Programming Language :: Python :: Implementation :: Jython",
    ],
    install_requires=[
        "setuptools",
    ],
    extras_require={
        "dev": [
            "flake8>=3.7.9",
            "isort>=4.3.21",
            "mypy>=0.770",
            "pre-commit>=2.0.1",
            "pytest>=5.4.0",
            "tox>=3.14.0",
            "black>=19.10b0",
            "sphinx>=2.4.0",
        ],
    },
)
