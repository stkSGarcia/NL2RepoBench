#!/usr/bin/env python
"""
Comprehensive test suite for the Six compatibility library.
"""

import sys
import six
from six import moves

def test_version_detection():
    """Test version detection constants."""
    print("Testing version detection...")
    assert six.PY2 or six.PY3, "Either PY2 or PY3 must be True"
    if sys.version_info[0] == 2:
        assert six.PY2, "PY2 should be True in Python 2"
        assert not six.PY3, "PY3 should be False in Python 2"
    else:
        assert six.PY3, "PY3 should be True in Python 3"
        assert not six.PY2, "PY2 should be False in Python 3"
    print("✓ Version detection works")


def test_type_constants():
    """Test type judgment constants."""
    print("Testing type constants...")

    # String types
    assert isinstance("hello", six.string_types), "str should be in string_types"
    assert isinstance(six.u("hello"), six.string_types), "unicode should be in string_types"

    # Integer types
    assert isinstance(42, six.integer_types), "int should be in integer_types"

    # Text and binary types
    assert isinstance(six.text_type("hi"), six.text_type), "text_type should be valid"
    assert isinstance(six.binary_type(b"hi"), six.binary_type), "binary_type should be valid"

    # MAXSIZE
    assert six.MAXSIZE > 1000, "MAXSIZE should be a large number"

    print("✓ Type constants work")


def test_iterator_functions():
    """Test iterator compatibility functions."""
    print("Testing iterator functions...")

    it = iter([1, 2, 3])
    first = six.next(it)
    assert first == 1, "next() should return first element"

    # Iterator class
    class MyIterator(six.Iterator):
        def __init__(self):
            self.count = 0

        def __next__(self):
            if self.count >= 3:
                raise StopIteration
            self.count += 1
            return self.count

    result = list(MyIterator())
    assert result == [1, 2, 3], "Iterator should work correctly"

    print("✓ Iterator functions work")


def test_dictionary_functions():
    """Test dictionary iteration functions."""
    print("Testing dictionary functions...")

    d = {'a': 1, 'b': 2, 'c': 3}

    keys = list(six.iterkeys(d))
    assert set(keys) == {'a', 'b', 'c'}, "iterkeys should return all keys"

    values = list(six.itervalues(d))
    assert set(values) == {1, 2, 3}, "itervalues should return all values"

    items = list(six.iteritems(d))
    assert len(items) == 3, "iteritems should return all items"
    assert ('a', 1) in items, "iteritems should contain key-value pairs"

    # View functions
    keys_view = six.viewkeys(d)
    assert 'a' in keys_view, "viewkeys should contain keys"

    values_view = six.viewvalues(d)
    assert 1 in values_view, "viewvalues should contain values"

    items_view = six.viewitems(d)
    assert ('a', 1) in items_view, "viewitems should contain items"

    print("✓ Dictionary functions work")


def test_string_byte_functions():
    """Test string and byte conversion functions."""
    print("Testing string/byte functions...")

    # b() and u()
    b_str = six.b("hello")
    assert isinstance(b_str, six.binary_type), "b() should return binary_type"

    u_str = six.u("hello")
    assert isinstance(u_str, six.text_type), "u() should return text_type"

    # unichr()
    char = six.unichr(65)
    assert char == 'A', "unichr(65) should return 'A'"

    # int2byte() and byte2int()
    byte_val = six.int2byte(65)
    assert isinstance(byte_val, six.binary_type), "int2byte should return bytes"

    int_val = six.byte2int(six.b('A'))
    assert int_val == 65, "byte2int should return correct integer"

    # ensure_* functions
    binary = six.ensure_binary("hello")
    assert isinstance(binary, six.binary_type), "ensure_binary should return bytes"

    text = six.ensure_text(b"hello")
    assert isinstance(text, six.text_type), "ensure_text should return text"

    string = six.ensure_str("hello")
    assert isinstance(string, str), "ensure_str should return native str"

    print("✓ String/byte functions work")


def test_function_attributes():
    """Test function attribute access."""
    print("Testing function attributes...")

    def sample_func(x, y=10):
        """Sample function."""
        pass

    code = six.get_function_code(sample_func)
    assert code is not None, "get_function_code should work"

    defaults = six.get_function_defaults(sample_func)
    assert defaults == (10,), "get_function_defaults should work"

    globals_dict = six.get_function_globals(sample_func)
    assert isinstance(globals_dict, dict), "get_function_globals should work"

    print("✓ Function attributes work")


def test_metaclass_support():
    """Test metaclass compatibility."""
    print("Testing metaclass support...")

    class MyMeta(type):
        pass

    # with_metaclass
    class Class1(six.with_metaclass(MyMeta, object)):
        pass

    assert isinstance(Class1, MyMeta), "with_metaclass should apply metaclass"

    # add_metaclass
    @six.add_metaclass(MyMeta)
    class Class2(object):
        pass

    assert isinstance(Class2, MyMeta), "add_metaclass should apply metaclass"

    # python_2_unicode_compatible
    @six.python_2_unicode_compatible
    class Class3(object):
        def __str__(self):
            return six.u("hello")

    obj = Class3()
    assert str(obj) == "hello", "python_2_unicode_compatible should work"

    print("✓ Metaclass support works")


def test_io_compatibility():
    """Test StringIO and BytesIO compatibility."""
    print("Testing IO compatibility...")

    # StringIO
    sio = six.StringIO()
    sio.write(six.u("hello world"))
    assert sio.getvalue() == six.u("hello world"), "StringIO should work"

    # BytesIO
    bio = six.BytesIO()
    bio.write(six.b("hello world"))
    assert bio.getvalue() == six.b("hello world"), "BytesIO should work"

    print("✓ IO compatibility works")


def test_moves_imports():
    """Test six.moves imports."""
    print("Testing six.moves imports...")

    # Queue module
    q_module = moves.queue
    assert q_module is not None, "moves.queue should be importable"

    # configparser module
    cfg_module = moves.configparser
    assert cfg_module is not None, "moves.configparser should be importable"

    # urllib_parse
    from six.moves import urllib_parse
    assert urllib_parse is not None, "urllib_parse should be importable"

    # Try accessing through urllib
    try:
        from six.moves import urllib
        # urllib should be available
        assert urllib is not None
    except (ImportError, AttributeError):
        # If urllib doesn't import cleanly, that's OK - urllib_parse is what matters
        pass

    print("✓ six.moves imports work")


def test_wraps_decorator():
    """Test wraps decorator."""
    print("Testing wraps decorator...")

    def original():
        """Original docstring."""
        return 42

    @six.wraps(original)
    def wrapper():
        return original()

    assert wrapper.__name__ == "original", "wraps should preserve __name__"
    assert wrapper.__doc__ == "Original docstring.", "wraps should preserve __doc__"
    assert wrapper() == 42, "wrapper should work correctly"

    print("✓ wraps decorator works")


def test_exec_print():
    """Test exec_ and print_ functions."""
    print("Testing exec_ and print_...")

    # exec_
    ns = {}
    six.exec_("x = 42", ns)
    assert ns["x"] == 42, "exec_ should execute code"

    # print_ - just test that it doesn't raise
    import io
    output = io.StringIO()
    six.print_("hello", file=output)
    # Note: We just verify it runs without error

    print("✓ exec_ and print_ work")


def test_raise_from():
    """Test raise_from."""
    print("Testing raise_from...")

    try:
        six.raise_from(ValueError("new error"), RuntimeError("original error"))
    except ValueError as e:
        assert str(e) == "new error", "raise_from should raise the new error"

    print("✓ raise_from works")


def test_unittest_assertions():
    """Test unittest assertion compatibility."""
    print("Testing unittest assertions...")

    import unittest

    class TestCase(unittest.TestCase):
        pass

    tc = TestCase()

    # assertCountEqual
    six.assertCountEqual(tc, [1, 2], [2, 1])

    # assertRegex
    six.assertRegex(tc, "hello world", r"hello")

    # assertNotRegex
    six.assertNotRegex(tc, "hello world", r"goodbye")

    print("✓ unittest assertions work")


def test_repr_module():
    """Test that repr module works."""
    print("Testing repr module...")

    from six.moves import reprlib
    assert reprlib is not None, "reprlib should be importable"

    print("✓ repr module works")


def run_all_tests():
    """Run all tests."""
    print("=" * 60)
    print("Running Six Library Compatibility Tests")
    print("Python version:", sys.version)
    print("=" * 60)
    print()

    tests = [
        test_version_detection,
        test_type_constants,
        test_iterator_functions,
        test_dictionary_functions,
        test_string_byte_functions,
        test_function_attributes,
        test_metaclass_support,
        test_io_compatibility,
        test_moves_imports,
        test_wraps_decorator,
        test_exec_print,
        test_raise_from,
        test_unittest_assertions,
        test_repr_module,
    ]

    passed = 0
    failed = 0

    for test in tests:
        try:
            test()
            passed += 1
        except Exception as e:
            print(f"✗ {test.__name__} failed: {e}")
            import traceback
            traceback.print_exc()
            failed += 1

    print()
    print("=" * 60)
    print(f"Tests passed: {passed}/{len(tests)}")
    print(f"Tests failed: {failed}/{len(tests)}")
    print("=" * 60)

    return failed == 0


if __name__ == "__main__":
    success = run_all_tests()
    sys.exit(0 if success else 1)
