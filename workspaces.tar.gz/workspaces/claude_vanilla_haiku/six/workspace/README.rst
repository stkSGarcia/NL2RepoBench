======
 Six
======

Six is a Python 2 and 3 compatibility library. It provides utilities for writing
code that runs on both Python 2 and Python 3.

Version
=======

This is the version 1.16.0 of Six.

Features
========

Six provides:

* Type judgment constants for cross-version compatibility (``string_types``, ``integer_types``, etc.)
* A unified ``six.moves`` module for standard library imports that changed between Python 2 and 3
* Iterator and dictionary operation utilities
* Byte and string processing helpers
* Function and method attribute access utilities
* Syntax compatibility helpers for ``exec``, ``print``, and exception handling
* Metaclass and class decorator compatibility tools
* unittest assertion compatibility
* StringIO and BytesIO compatibility objects

Usage
=====

Basic imports::

    import six
    from six import moves

Type checking::

    if isinstance(obj, six.string_types):
        # obj is a string in both Python 2 and 3
        pass

Standard library imports::

    from six.moves import queue
    from six.moves import configparser

String/byte processing::

    # Ensure binary
    data = six.ensure_binary("hello")

    # Ensure text
    text = six.ensure_text(b"hello")

Dictionary iteration::

    for key, value in six.iteritems(d):
        pass

More Examples
=============

Iterator compatibility::

    class MyIterator(six.Iterator):
        def __next__(self):
            # implementation
            pass

Metaclass compatibility::

    @six.add_metaclass(MyMeta)
    class MyClass(object):
        pass

    # or use with_metaclass
    class MyClass(six.with_metaclass(MyMeta, object)):
        pass

Installation
============

Install six with pip::

    pip install six

Or from source::

    python setup.py install

Testing
=======

Run tests with::

    pytest

Documentation
==============

See the full documentation in the ``documentation`` directory or visit
https://six.readthedocs.io/

License
=======

Six is released under the MIT license.
