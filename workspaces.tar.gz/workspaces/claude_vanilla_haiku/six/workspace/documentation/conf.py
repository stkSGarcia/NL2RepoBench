# -*- coding: utf-8 -*-
"""
Sphinx configuration file for Six documentation
"""

import sys
import os

sys.path.insert(0, os.path.abspath('..'))

# Project information
project = u'Six'
copyright = u'2010-2023, Benjamin Peterson'
version = '1.16.0'
release = '1.16.0'

# General configuration
extensions = ['sphinx.ext.autodoc', 'sphinx.ext.intersphinx']
templates_path = ['_templates']
source_suffix = '.rst'
master_doc = 'index'
language = 'en'
exclude_patterns = ['_build']
pygments_style = 'sphinx'

# HTML output options
html_theme = 'default'
html_static_path = ['_static']
html_theme_options = {}

# LaTeX output options
latex_elements = {
    'papersize': 'letterpaper',
    'pointsize': '10pt',
}

latex_documents = [
    ('index', 'Six.tex', u'Six Documentation',
     u'Benjamin Peterson', 'manual'),
]

# Man page output
man_pages = [
    ('index', 'six', u'Six Documentation',
     [u'Benjamin Peterson'], 1)
]

# Texinfo output
texinfo_documents = [
    ('index', 'Six', u'Six Documentation',
     u'Benjamin Peterson', 'Six', 'Python 2 and 3 Compatibility',
     'Miscellaneous'),
]

# Intersphinx mapping
intersphinx_mapping = {
    'python': ('https://docs.python.org/3', None),
}

# Autodoc options
autodoc_member_order = 'bysource'
