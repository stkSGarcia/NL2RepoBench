======
 Six
======

Six is a Python 2 and 3 compatibility library. It provides utilities for writing
code that runs on both Python 2 and Python 3.

Contents
========

.. toctree::
   :maxdepth: 2

   overview
   api


Overview
========

Six provides utilities for writing code that works on both Python 2 and Python 3:

* Type judgment constants (``string_types``, ``integer_types``, etc.)
* A unified module for standard library imports
* Iterator and dictionary operation utilities
* Byte and string processing helpers
* Function attribute access utilities
* Syntax compatibility helpers
* Metaclass and decorator compatibility tools
* unittest assertion compatibility

Installation
============

Install six with pip::

    pip install six

Or from source::

    python setup.py install

Quick Start
===========

Basic imports::

    import six
    from six import moves

Type checking::

    if isinstance(obj, six.string_types):
        # obj is a string in both Python 2 and 3
        pass

Standard library imports::

    from six.moves import queue
    from six.moves import configparser

String/byte processing::

    # Ensure binary
    data = six.ensure_binary("hello")

    # Ensure text
    text = six.ensure_text(b"hello")

Dictionary iteration::

    for key, value in six.iteritems(d):
        pass

Version
=======

This is Six 1.16.0.

License
=======

Six is released under the MIT license.
