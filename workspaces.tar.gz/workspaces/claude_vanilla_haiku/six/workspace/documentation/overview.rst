========
Overview
========

Six is a Python 2 and 3 compatibility library. It provides utilities that abstract away
the differences between Python 2 and Python 3, allowing developers to write code that
runs on both versions with minimal branching and compatibility checks.

History
=======

Python 3 introduced significant changes to the language and standard library,
breaking backwards compatibility with Python 2. Six was created to make it easier
for developers to maintain code that works on both versions.

Core Philosophy
===============

Six's philosophy is:

1. **Minimize code duplication**: Provide unified interfaces instead of requiring
   different implementations for Python 2 and 3.

2. **Use native Python semantics**: Six typically defaults to Python 3 behavior
   and provides compatibility shims for Python 2.

3. **Lazy imports**: Most compatibility modules are lazily imported to minimize
   overhead and allow using only what you need.

4. **No external dependencies**: Six is a standalone library with no external
   dependencies beyond the Python standard library.

Key Problem Areas
=================

Python 2 vs Python 3 differences addressed by Six:

**String and Bytes**
  - Python 2: ``str`` is bytes, ``unicode`` is text
  - Python 3: ``str`` is text, ``bytes`` is bytes
  - Six provides: ``text_type``, ``binary_type``, ``string_types``, and conversion functions

**Standard Library Renames**
  - Many modules were renamed or restructured
  - Six provides: ``six.moves`` for unified imports

**Metaclass Syntax**
  - Python 2: ``class Foo(Base): __metaclass__ = Meta``
  - Python 3: ``class Foo(Base, metaclass=Meta):``
  - Six provides: ``with_metaclass()``, ``add_metaclass()``

**Print Statement vs Function**
  - Python 2: ``print "hello"`` (statement)
  - Python 3: ``print("hello")`` (function)
  - Six provides: ``print_()``

**Iterator Differences**
  - Python 2: many functions returned lists, had ``.next()`` methods
  - Python 3: many functions return iterators, use ``__next__()`` methods
  - Six provides: ``next()``, ``Iterator``, ``iteritems()``, etc.

**Exception Handling**
  - Python 2: ``raise Exception, value`` or ``except Exception, e:``
  - Python 3: ``raise Exception(value)`` or ``except Exception as e:``
  - Six provides: ``raise_from()``, ``reraise()``

Common Usage Patterns
====================

Type Checking
~~~~~~~~~~~~~

Instead of::

    if isinstance(x, basestring):  # Doesn't exist in Python 3
        pass

Use::

    if isinstance(x, six.string_types):
        pass

Dictionary Iteration
~~~~~~~~~~~~~~~~~~~~

Instead of::

    for key, value in d.iteritems():  # iteritems() doesn't exist in Python 3
        pass

Use::

    for key, value in six.iteritems(d):
        pass

String Handling
~~~~~~~~~~~~~~~

Instead of::

    if isinstance(x, basestring):
        x = x.encode('utf-8')

Use::

    x = six.ensure_binary(x)

Standard Library Imports
~~~~~~~~~~~~~~~~~~~~~~~~

Instead of::

    try:
        from Queue import Queue  # Python 2 name
    except ImportError:
        from queue import Queue  # Python 3 name

Use::

    from six.moves import queue
    q = queue.Queue()

Metaclasses
~~~~~~~~~~~

Instead of::

    class MyClass(object):
        __metaclass__ = MyMeta

Use::

    class MyClass(six.with_metaclass(MyMeta, object)):
        pass

When to Use Six
===============

Six is useful when:

- You need to maintain code that runs on both Python 2 and Python 3
- You want to provide a library that works on multiple Python versions
- You're migrating from Python 2 to Python 3 gradually
- You need maximum compatibility across versions

Six may not be necessary if:

- You only target Python 3
- You only target Python 2
- You use a framework that handles compatibility for you

Best Practices
==============

1. Always use Six's type constants instead of checking for specific types
2. Always import from six.moves instead of doing try/except imports
3. Use Six's string handling functions (ensure_text, ensure_binary) for handling strings
4. Test your code on both Python 2 and Python 3
5. Consider using tox to manage testing across multiple Python versions

See the API Reference for detailed information on all available utilities.
