API Reference
=============

Version Detection
-----------------

.. py:data:: PY2

   Boolean indicating if running under Python 2

.. py:data:: PY3

   Boolean indicating if running under Python 3

.. py:data:: PY34

   Boolean indicating if running under Python 3.4 or higher

Type Constants
--------------

.. py:data:: string_types

   A tuple of string types in the current Python version.
   Python 2: ``(basestring,)``
   Python 3: ``(str,)``

.. py:data:: integer_types

   A tuple of integer types in the current Python version.
   Python 2: ``(int, long)``
   Python 3: ``(int,)``

.. py:data:: class_types

   A tuple of class types in the current Python version.

.. py:data:: text_type

   The text string type in the current Python version.
   Python 2: ``unicode``
   Python 3: ``str``

.. py:data:: binary_type

   The binary bytes type in the current Python version.
   Python 2: ``str``
   Python 3: ``bytes``

.. py:data:: MAXSIZE

   The maximum size of containers (same as sys.maxsize)

Iterator Functions
------------------

.. py:function:: next(iterator)

   Get the next item from an iterator.
   Python 2: calls ``iterator.next()``
   Python 3: calls ``next(iterator)``

.. py:class:: Iterator

   Abstract base class for iterators.
   Provides both ``__next__`` and ``next`` methods for compatibility.

Dictionary Functions
---------------------

.. py:function:: iterkeys(d)

   Return an iterator over dictionary keys.

.. py:function:: itervalues(d)

   Return an iterator over dictionary values.

.. py:function:: iteritems(d)

   Return an iterator over dictionary key-value pairs.

.. py:function:: viewkeys(d)

   Return a view of dictionary keys.

.. py:function:: viewvalues(d)

   Return a view of dictionary values.

.. py:function:: viewitems(d)

   Return a view of dictionary key-value pairs.

String and Byte Functions
--------------------------

.. py:function:: b(s)

   Convert a string to bytes.

.. py:function:: u(s)

   Convert bytes to a unicode/text string.

.. py:function:: unichr(i)

   Convert an integer to a character.
   Python 2: ``unichr(i)``
   Python 3: ``chr(i)``

.. py:function:: int2byte(i)

   Convert an integer to a single byte.

.. py:function:: byte2int(bs)

   Convert a single byte to an integer.

.. py:function:: ensure_str(s, encoding='utf-8', errors='strict')

   Ensure the argument is a native string (str in both Python 2 and 3).

.. py:function:: ensure_binary(s, encoding='utf-8', errors='strict')

   Ensure the argument is binary bytes.

.. py:function:: ensure_text(s, encoding='utf-8', errors='strict')

   Ensure the argument is text (unicode in Python 2, str in Python 3).

Function Utilities
-------------------

.. py:function:: get_function_code(f)

   Get the code object from a function.

.. py:function:: get_function_globals(f)

   Get the global namespace dict from a function.

.. py:function:: get_function_defaults(f)

   Get the default arguments from a function.

.. py:function:: get_function_closure(f)

   Get the closure variables from a function.

.. py:function:: get_method_function(m)

   Get the function from a bound method.

.. py:function:: get_method_self(m)

   Get the self object from a bound method.

.. py:function:: get_unbound_function(m)

   Get the unbound function from a method.

Syntax Compatibility
--------------------

.. py:function:: exec_(code, globals=None, locals=None)

   Execute Python code. Compatible with both Python 2 and 3 exec syntax.

.. py:function:: print_(*args, **kwargs)

   Print function compatible with both Python 2 and 3.
   Supports file, sep, and end keyword arguments.

.. py:function:: raise_from(value, from_value)

   Raise a new exception from an existing one (Python 3 style).

.. py:function:: reraise(tp, value, tb=None)

   Re-raise an exception with its traceback.

Metaclass Utilities
-------------------

.. py:function:: with_metaclass(meta, *bases)

   Create a base class with a metaclass. Usage::

       class MyClass(six.with_metaclass(MyMeta, object)):
           pass

.. py:function:: add_metaclass(metaclass)

   Class decorator to add a metaclass. Usage::

       @six.add_metaclass(MyMeta)
       class MyClass(object):
           pass

.. py:function:: python_2_unicode_compatible(cls)

   Class decorator for making a class compatible with both Python 2 and 3 unicode handling.

IO Compatibility
----------------

.. py:data:: StringIO

   Text IO class compatible with both Python 2 and 3.

.. py:data:: BytesIO

   Binary IO class compatible with both Python 2 and 3.

.. py:function:: wraps(wrapped)

   Decorator for wrapping functions. Preserves metadata like ``__name__`` and ``__doc__``.

unittest Assertions
-------------------

.. py:function:: assertCountEqual(test, first, second, msg=None)

   Assert that two sequences have the same elements (same counts, different order OK).

.. py:function:: assertRaisesRegex(test, exception, regex, callable_obj=None, *args, **kwargs)

   Assert that calling callable_obj raises exception with a message matching regex.

.. py:function:: assertRegex(test, text, regex, msg=None)

   Assert that regex matches text.

.. py:function:: assertNotRegex(test, text, regex, msg=None)

   Assert that regex does not match text.

six.moves Module
-----------------

The ``six.moves`` module provides unified imports for modules that were renamed
or restructured between Python 2 and Python 3.

**Common Imports:**

.. code-block:: python

    from six.moves import queue
    from six.moves import configparser
    from six.moves import http_client
    from six.moves import urllib
    from six.moves import builtins
    from six.moves import _thread
    from six.moves import socketserver
    from six.moves import dbm_ndbm
    from six.moves import email_mime_text
    from six.moves import tkinter
    from six.moves.urllib import parse
    from six.moves.urllib import request
    from six.moves.urllib import error
    from six.moves.urllib import robotparser

MovedModule and MovedAttribute
-------------------------------

These classes are used internally for defining moved modules and attributes in six.moves.

.. py:class:: MovedModule(name, old, new=None)

   Maps a module that was renamed between Python 2 and 3.

.. py:class:: MovedAttribute(name, old_mod, new_mod, old_attr=None, new_attr=None)

   Maps an attribute that was moved between modules in Python 2 and 3.

Example Usage
=============

Basic Compatibility
~~~~~~~~~~~~~~~~~~~

.. code-block:: python

    import six

    if isinstance(obj, six.string_types):
        obj = six.ensure_text(obj)

Standard Library Imports
~~~~~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

    from six.moves import queue
    from six.moves.urllib import parse

    q = queue.Queue()
    result = parse.urlparse("http://example.com")

Dictionary Iteration
~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

    import six

    for key, value in six.iteritems(d):
        print(key, value)

Metaclass Definition
~~~~~~~~~~~~~~~~~~~~

.. code-block:: python

    import six

    class MyMeta(type):
        pass

    class MyClass(six.with_metaclass(MyMeta, object)):
        pass

Conditional Code
~~~~~~~~~~~~~~~~

.. code-block:: python

    import six

    if six.PY2:
        # Python 2 specific code
        pass
    elif six.PY3:
        # Python 3 specific code
        pass
