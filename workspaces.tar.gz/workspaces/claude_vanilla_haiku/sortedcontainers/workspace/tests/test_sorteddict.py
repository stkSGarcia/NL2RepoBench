"""Tests for SortedDict."""

import pytest
from sortedcontainers import SortedDict, SortedKeysView, SortedValuesView, SortedItemsView


class TestSortedDict:
    """Test cases for SortedDict."""

    def test_init_empty(self):
        """Test initialization of empty SortedDict."""
        sd = SortedDict()
        assert len(sd) == 0
        assert list(sd) == []

    def test_init_with_dict(self):
        """Test initialization with a dictionary."""
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        assert list(sd.keys()) == ['a', 'b', 'c']
        assert list(sd.values()) == [1, 2, 3]

    def test_init_with_pairs(self):
        """Test initialization with pairs."""
        sd = SortedDict([('c', 3), ('a', 1), ('b', 2)])
        assert list(sd.keys()) == ['a', 'b', 'c']

    def test_init_with_kwargs(self):
        """Test initialization with keyword arguments."""
        sd = SortedDict(a=1, b=2, c=3)
        assert list(sd.keys()) == ['a', 'b', 'c']

    def test_setitem(self):
        """Test setting items."""
        sd = SortedDict()
        sd['c'] = 3
        sd['a'] = 1
        sd['b'] = 2
        assert list(sd.keys()) == ['a', 'b', 'c']

    def test_getitem(self):
        """Test getting items."""
        sd = SortedDict({'a': 1, 'b': 2, 'c': 3})
        assert sd['a'] == 1
        assert sd['b'] == 2
        assert sd['c'] == 3

    def test_getitem_missing(self):
        """Test getting missing item."""
        sd = SortedDict()
        with pytest.raises(KeyError):
            _ = sd['missing']

    def test_delitem(self):
        """Test deleting items."""
        sd = SortedDict({'a': 1, 'b': 2, 'c': 3})
        del sd['b']
        assert list(sd.keys()) == ['a', 'c']

    def test_contains(self):
        """Test membership check."""
        sd = SortedDict({'a': 1, 'b': 2, 'c': 3})
        assert 'a' in sd
        assert 'd' not in sd

    def test_iter(self):
        """Test iteration over keys."""
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        assert list(iter(sd)) == ['a', 'b', 'c']

    def test_len(self):
        """Test length."""
        sd = SortedDict({'a': 1, 'b': 2, 'c': 3})
        assert len(sd) == 3

    def test_clear(self):
        """Test clearing."""
        sd = SortedDict({'a': 1, 'b': 2, 'c': 3})
        sd.clear()
        assert len(sd) == 0

    def test_copy(self):
        """Test copying."""
        sd = SortedDict({'a': 1, 'b': 2, 'c': 3})
        sd2 = sd.copy()
        assert dict(sd2) == {'a': 1, 'b': 2, 'c': 3}
        sd2['d'] = 4
        assert 'd' not in sd

    def test_get(self):
        """Test get with default."""
        sd = SortedDict({'a': 1})
        assert sd.get('a') == 1
        assert sd.get('missing') is None
        assert sd.get('missing', 'default') == 'default'

    def test_pop(self):
        """Test pop."""
        sd = SortedDict({'a': 1, 'b': 2})
        assert sd.pop('a') == 1
        assert 'a' not in sd
        assert sd.pop('missing', 'default') == 'default'

    def test_pop_missing(self):
        """Test pop missing key."""
        sd = SortedDict()
        with pytest.raises(KeyError):
            sd.pop('missing')

    def test_popitem(self):
        """Test popitem."""
        sd = SortedDict({'a': 1, 'b': 2, 'c': 3})
        key, value = sd.popitem()
        assert key == 'c'
        assert value == 3

    def test_popitem_empty(self):
        """Test popitem on empty dict."""
        sd = SortedDict()
        with pytest.raises(KeyError):
            sd.popitem()

    def test_setdefault(self):
        """Test setdefault."""
        sd = SortedDict({'a': 1})
        assert sd.setdefault('a') == 1
        assert sd.setdefault('b', 2) == 2
        assert sd['b'] == 2

    def test_update(self):
        """Test update."""
        sd = SortedDict({'a': 1})
        sd.update({'b': 2, 'c': 3})
        assert list(sd.keys()) == ['a', 'b', 'c']

    def test_update_with_kwargs(self):
        """Test update with keyword arguments."""
        sd = SortedDict({'a': 1})
        sd.update(b=2, c=3)
        assert list(sd.keys()) == ['a', 'b', 'c']

    def test_keys_view(self):
        """Test keys view."""
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        keys = sd.keys()
        assert isinstance(keys, SortedKeysView)
        assert list(keys) == ['a', 'b', 'c']

    def test_values_view(self):
        """Test values view."""
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        values = sd.values()
        assert isinstance(values, SortedValuesView)
        assert list(values) == [1, 2, 3]

    def test_items_view(self):
        """Test items view."""
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        items = sd.items()
        assert isinstance(items, SortedItemsView)
        assert list(items) == [('a', 1), ('b', 2), ('c', 3)]

    def test_equality(self):
        """Test equality comparison."""
        sd1 = SortedDict({'a': 1, 'b': 2})
        sd2 = SortedDict({'a': 1, 'b': 2})
        d = {'a': 1, 'b': 2}
        assert sd1 == sd2
        assert sd1 == d

    def test_inequality(self):
        """Test inequality comparison."""
        sd1 = SortedDict({'a': 1, 'b': 2})
        sd2 = SortedDict({'a': 1, 'b': 3})
        assert sd1 != sd2

    def test_repr(self):
        """Test string representation."""
        sd = SortedDict({'a': 1, 'b': 2})
        assert 'SortedDict' in repr(sd)

    def test_repr_empty(self):
        """Test string representation of empty dict."""
        sd = SortedDict()
        assert repr(sd) == 'SortedDict()'

    def test_keys_view_contains(self):
        """Test keys view contains."""
        sd = SortedDict({'a': 1, 'b': 2})
        keys = sd.keys()
        assert 'a' in keys
        assert 'c' not in keys

    def test_keys_view_indexing(self):
        """Test keys view indexing."""
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        keys = sd.keys()
        assert keys[0] == 'a'
        assert keys[1] == 'b'
        assert keys[2] == 'c'

    def test_values_view_indexing(self):
        """Test values view indexing."""
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        values = sd.values()
        assert values[0] == 1
        assert values[1] == 2
        assert values[2] == 3

    def test_items_view_indexing(self):
        """Test items view indexing."""
        sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
        items = sd.items()
        assert items[0] == ('a', 1)
        assert items[1] == ('b', 2)
        assert items[2] == ('c', 3)

    def test_keys_view_len(self):
        """Test keys view length."""
        sd = SortedDict({'a': 1, 'b': 2, 'c': 3})
        keys = sd.keys()
        assert len(keys) == 3

    def test_values_view_contains(self):
        """Test values view contains."""
        sd = SortedDict({'a': 1, 'b': 2})
        values = sd.values()
        assert 1 in values
        assert 3 not in values

    def test_items_view_contains(self):
        """Test items view contains."""
        sd = SortedDict({'a': 1, 'b': 2})
        items = sd.items()
        assert ('a', 1) in items
        assert ('a', 2) not in items

    def test_update_maintains_order(self):
        """Test that update maintains sorted order."""
        sd = SortedDict({'c': 3, 'a': 1})
        sd.update({'b': 2})
        assert list(sd.keys()) == ['a', 'b', 'c']

    def test_large_dataset(self):
        """Test with a large dataset."""
        import random
        data = {chr(65 + i): i for i in range(26)}
        random.shuffle(list(data.items()))
        sd = SortedDict(data)
        expected_keys = [chr(65 + i) for i in range(26)]
        assert list(sd.keys()) == expected_keys
