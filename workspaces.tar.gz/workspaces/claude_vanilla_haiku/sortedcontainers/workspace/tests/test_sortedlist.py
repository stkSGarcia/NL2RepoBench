"""Tests for SortedList."""

import pytest
from operator import neg
from sortedcontainers import SortedList, SortedKeyList, SortedListWithKey


class TestSortedList:
    """Test cases for SortedList."""

    def test_init_empty(self):
        """Test initialization of empty SortedList."""
        sl = SortedList()
        assert len(sl) == 0
        assert list(sl) == []

    def test_init_with_iterable(self):
        """Test initialization with iterable."""
        sl = SortedList([3, 1, 2, 5, 4])
        assert len(sl) == 5
        assert list(sl) == [1, 2, 3, 4, 5]

    def test_init_with_key_returns_sorted_key_list(self):
        """Test that key argument returns SortedKeyList."""
        sl = SortedList([3, 1, 2], key=neg)
        assert isinstance(sl, SortedKeyList)
        assert list(sl) == [3, 2, 1]

    def test_add(self):
        """Test adding values."""
        sl = SortedList()
        sl.add(3)
        sl.add(1)
        sl.add(2)
        assert list(sl) == [1, 2, 3]

    def test_add_duplicates(self):
        """Test adding duplicate values."""
        sl = SortedList()
        sl.add(1)
        sl.add(1)
        sl.add(1)
        assert list(sl) == [1, 1, 1]
        assert len(sl) == 3

    def test_update(self):
        """Test updating with an iterable."""
        sl = SortedList([1, 5])
        sl.update([3, 2, 4])
        assert list(sl) == [1, 2, 3, 4, 5]

    def test_contains(self):
        """Test membership check."""
        sl = SortedList([1, 2, 3, 4, 5])
        assert 3 in sl
        assert 0 not in sl
        assert 6 not in sl

    def test_remove(self):
        """Test removing a value."""
        sl = SortedList([1, 2, 3, 4, 5])
        sl.remove(3)
        assert list(sl) == [1, 2, 4, 5]

    def test_remove_not_found(self):
        """Test removing a value that doesn't exist."""
        sl = SortedList([1, 2, 3])
        with pytest.raises(ValueError):
            sl.remove(0)

    def test_discard(self):
        """Test discarding a value."""
        sl = SortedList([1, 2, 3, 4, 5])
        sl.discard(3)
        assert list(sl) == [1, 2, 4, 5]

    def test_discard_not_found(self):
        """Test discarding a value that doesn't exist."""
        sl = SortedList([1, 2, 3])
        sl.discard(0)  # Should not raise
        assert list(sl) == [1, 2, 3]

    def test_getitem(self):
        """Test indexing."""
        sl = SortedList('abcde')
        assert sl[0] == 'a'
        assert sl[2] == 'c'
        assert sl[-1] == 'e'

    def test_getitem_slice(self):
        """Test slicing."""
        sl = SortedList('abcde')
        assert sl[1:3] == ['b', 'c']
        assert sl[::2] == ['a', 'c', 'e']

    def test_getitem_out_of_range(self):
        """Test indexing out of range."""
        sl = SortedList([1, 2, 3])
        with pytest.raises(IndexError):
            _ = sl[10]

    def test_delitem(self):
        """Test deleting by index."""
        sl = SortedList('abcde')
        del sl[2]
        assert list(sl) == ['a', 'b', 'd', 'e']

    def test_delitem_slice(self):
        """Test deleting by slice."""
        sl = SortedList('abcde')
        del sl[1:3]
        assert list(sl) == ['a', 'd', 'e']

    def test_pop(self):
        """Test pop operation."""
        sl = SortedList('abcde')
        assert sl.pop() == 'e'
        assert sl.pop(2) == 'c'
        assert list(sl) == ['a', 'b', 'd']

    def test_pop_from_empty(self):
        """Test pop from empty list."""
        sl = SortedList()
        with pytest.raises(IndexError):
            sl.pop()

    def test_clear(self):
        """Test clearing the list."""
        sl = SortedList([1, 2, 3])
        sl.clear()
        assert len(sl) == 0
        assert list(sl) == []

    def test_bisect_left(self):
        """Test bisect_left."""
        sl = SortedList([10, 11, 12, 13, 14])
        assert sl.bisect_left(12) == 2
        assert sl.bisect_left(9) == 0
        assert sl.bisect_left(15) == 5

    def test_bisect_right(self):
        """Test bisect_right."""
        sl = SortedList([10, 11, 12, 13, 14])
        assert sl.bisect_right(12) == 3
        assert sl.bisect_right(9) == 0
        assert sl.bisect_right(15) == 5

    def test_count(self):
        """Test counting occurrences."""
        sl = SortedList([1, 2, 2, 3, 3, 3, 4, 4, 4, 4])
        assert sl.count(1) == 1
        assert sl.count(2) == 2
        assert sl.count(3) == 3
        assert sl.count(4) == 4
        assert sl.count(0) == 0

    def test_index(self):
        """Test finding index."""
        sl = SortedList('abcde')
        assert sl.index('a') == 0
        assert sl.index('c') == 2
        assert sl.index('e') == 4

    def test_index_not_found(self):
        """Test index of non-existent value."""
        sl = SortedList('abcde')
        with pytest.raises(ValueError):
            sl.index('z')

    def test_iter(self):
        """Test iteration."""
        sl = SortedList([3, 1, 2])
        result = list(iter(sl))
        assert result == [1, 2, 3]

    def test_reversed(self):
        """Test reverse iteration."""
        sl = SortedList([1, 2, 3, 4, 5])
        result = list(reversed(sl))
        assert result == [5, 4, 3, 2, 1]

    def test_len(self):
        """Test length."""
        sl = SortedList([1, 2, 3])
        assert len(sl) == 3

    def test_copy(self):
        """Test copying."""
        sl = SortedList([1, 2, 3])
        sl2 = sl.copy()
        assert list(sl2) == [1, 2, 3]
        sl2.add(4)
        assert 4 not in sl

    def test_add_operator(self):
        """Test addition operator."""
        sl1 = SortedList('bat')
        sl2 = SortedList('cat')
        result = sl1 + sl2
        assert list(result) == ['a', 'a', 'b', 'c', 't', 't']

    def test_iadd_operator(self):
        """Test in-place addition operator."""
        sl = SortedList('bat')
        sl += 'cat'
        assert list(sl) == ['a', 'a', 'b', 'c', 't', 't']

    def test_mul_operator(self):
        """Test multiplication operator."""
        sl = SortedList('abc')
        result = sl * 3
        assert list(result) == ['a', 'a', 'a', 'b', 'b', 'b', 'c', 'c', 'c']

    def test_imul_operator(self):
        """Test in-place multiplication operator."""
        sl = SortedList('abc')
        sl *= 3
        assert list(sl) == ['a', 'a', 'a', 'b', 'b', 'b', 'c', 'c', 'c']

    def test_large_dataset(self):
        """Test with a large dataset."""
        import random
        data = list(range(10000))
        random.shuffle(data)
        sl = SortedList(data)
        assert len(sl) == 10000
        assert list(sl) == list(range(10000))

    def test_setitem_raises(self):
        """Test that setitem raises NotImplementedError."""
        sl = SortedList([1, 2, 3])
        with pytest.raises(NotImplementedError):
            sl[0] = 5

    def test_append_raises(self):
        """Test that append raises NotImplementedError."""
        sl = SortedList()
        with pytest.raises(NotImplementedError):
            sl.append(1)

    def test_extend_raises(self):
        """Test that extend raises NotImplementedError."""
        sl = SortedList()
        with pytest.raises(NotImplementedError):
            sl.extend([1, 2, 3])

    def test_insert_raises(self):
        """Test that insert raises NotImplementedError."""
        sl = SortedList()
        with pytest.raises(NotImplementedError):
            sl.insert(0, 1)

    def test_reverse_raises(self):
        """Test that reverse raises NotImplementedError."""
        sl = SortedList([1, 2, 3])
        with pytest.raises(NotImplementedError):
            sl.reverse()


class TestSortedKeyList:
    """Test cases for SortedKeyList."""

    def test_init_with_key(self):
        """Test initialization with key function."""
        skl = SortedKeyList([3, 1, 2], key=neg)
        assert list(skl) == [3, 2, 1]

    def test_key_property(self):
        """Test key property."""
        skl = SortedKeyList([3, 1, 2], key=neg)
        assert skl.key == neg

    def test_add_with_key(self):
        """Test adding with key function."""
        skl = SortedKeyList(key=neg)
        skl.add(3)
        skl.add(1)
        skl.add(2)
        assert list(skl) == [3, 2, 1]

    def test_count_with_key(self):
        """Test counting with key function."""
        skl = SortedKeyList([1, 2, 2, 3, 3, 3], key=neg)
        assert skl.count(2) == 2
        assert skl.count(3) == 3

    def test_bisect_left_with_key(self):
        """Test bisect_left with key function."""
        skl = SortedKeyList([5, 4, 3, 2, 1], key=neg)
        assert skl.bisect_left(3) == 2

    def test_bisect_right_with_key(self):
        """Test bisect_right with key function."""
        skl = SortedKeyList([5, 4, 3, 2, 1], key=neg)
        assert skl.bisect_right(3) == 3

    def test_remove_with_key(self):
        """Test removing with key function."""
        skl = SortedKeyList([3, 1, 2], key=neg)
        skl.remove(2)
        assert list(skl) == [3, 1]

    def test_contains_with_key(self):
        """Test membership with key function."""
        skl = SortedKeyList([3, 1, 2], key=neg)
        assert 2 in skl
        assert 0 not in skl

    def test_duplicate_keys(self):
        """Test handling duplicate keys."""
        skl = SortedKeyList([1, 1, 2, 2, 3, 3], key=abs)
        assert len(skl) == 6
        assert skl.count(1) == 2

    def test_large_dataset_with_key(self):
        """Test with a large dataset and key function."""
        import random
        data = list(range(1000))
        random.shuffle(data)
        skl = SortedKeyList(data, key=neg)
        assert len(skl) == 1000
        assert list(skl) == list(range(999, -1, -1))

    def test_backward_compat_name(self):
        """Test SortedListWithKey backward compatibility."""
        from sortedcontainers import SortedListWithKey
        sl = SortedListWithKey([3, 1, 2], key=neg)
        assert isinstance(sl, SortedKeyList)
        assert list(sl) == [3, 2, 1]
