"""Tests for SortedSet."""

import pytest
from sortedcontainers import SortedSet


class TestSortedSet:
    """Test cases for SortedSet."""

    def test_init_empty(self):
        """Test initialization of empty SortedSet."""
        ss = SortedSet()
        assert len(ss) == 0
        assert list(ss) == []

    def test_init_with_iterable(self):
        """Test initialization with iterable."""
        ss = SortedSet([3, 1, 2, 3, 1])
        assert len(ss) == 3
        assert list(ss) == [1, 2, 3]

    def test_add(self):
        """Test adding values."""
        ss = SortedSet()
        ss.add(3)
        ss.add(1)
        ss.add(2)
        assert list(ss) == [1, 2, 3]

    def test_add_duplicate(self):
        """Test adding duplicate values."""
        ss = SortedSet([1, 2, 3])
        ss.add(2)
        assert len(ss) == 3
        assert list(ss) == [1, 2, 3]

    def test_discard(self):
        """Test discarding values."""
        ss = SortedSet([1, 2, 3])
        ss.discard(2)
        assert list(ss) == [1, 3]

    def test_discard_missing(self):
        """Test discarding missing value."""
        ss = SortedSet([1, 2, 3])
        ss.discard(4)  # Should not raise
        assert list(ss) == [1, 2, 3]

    def test_remove(self):
        """Test removing values."""
        ss = SortedSet([1, 2, 3])
        ss.remove(2)
        assert list(ss) == [1, 3]

    def test_remove_missing(self):
        """Test removing missing value."""
        ss = SortedSet([1, 2, 3])
        with pytest.raises(KeyError):
            ss.remove(4)

    def test_pop(self):
        """Test pop operation."""
        ss = SortedSet([1, 2, 3])
        assert ss.pop() == 3
        assert list(ss) == [1, 2]

    def test_pop_empty(self):
        """Test pop from empty set."""
        ss = SortedSet()
        with pytest.raises(KeyError):
            ss.pop()

    def test_clear(self):
        """Test clearing."""
        ss = SortedSet([1, 2, 3])
        ss.clear()
        assert len(ss) == 0

    def test_contains(self):
        """Test membership check."""
        ss = SortedSet([1, 2, 3])
        assert 2 in ss
        assert 4 not in ss

    def test_iter(self):
        """Test iteration."""
        ss = SortedSet([3, 1, 2])
        assert list(ss) == [1, 2, 3]

    def test_reversed(self):
        """Test reverse iteration."""
        ss = SortedSet([1, 2, 3, 4, 5])
        assert list(reversed(ss)) == [5, 4, 3, 2, 1]

    def test_len(self):
        """Test length."""
        ss = SortedSet([1, 2, 3])
        assert len(ss) == 3

    def test_copy(self):
        """Test copying."""
        ss = SortedSet([1, 2, 3])
        ss2 = ss.copy()
        assert list(ss2) == [1, 2, 3]
        ss2.add(4)
        assert 4 not in ss

    def test_union(self):
        """Test union operation."""
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([2, 3, 4])
        result = ss1.union(ss2)
        assert list(result) == [1, 2, 3, 4]

    def test_union_operator(self):
        """Test union using | operator."""
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([2, 3, 4])
        result = ss1 | ss2
        assert list(result) == [1, 2, 3, 4]

    def test_ior_operator(self):
        """Test union using |= operator."""
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([2, 3, 4])
        ss1 |= ss2
        assert list(ss1) == [1, 2, 3, 4]

    def test_intersection(self):
        """Test intersection operation."""
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([2, 3, 4, 5])
        result = ss1.intersection(ss2)
        assert list(result) == [2, 3, 4]

    def test_intersection_operator(self):
        """Test intersection using & operator."""
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([2, 3, 4, 5])
        result = ss1 & ss2
        assert list(result) == [2, 3, 4]

    def test_iand_operator(self):
        """Test intersection using &= operator."""
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([2, 3, 4, 5])
        ss1 &= ss2
        assert list(ss1) == [2, 3, 4]

    def test_difference(self):
        """Test difference operation."""
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([2, 3, 5])
        result = ss1.difference(ss2)
        assert list(result) == [1, 4]

    def test_difference_operator(self):
        """Test difference using - operator."""
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([2, 3, 5])
        result = ss1 - ss2
        assert list(result) == [1, 4]

    def test_isub_operator(self):
        """Test difference using -= operator."""
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([2, 3, 5])
        ss1 -= ss2
        assert list(ss1) == [1, 4]

    def test_symmetric_difference(self):
        """Test symmetric difference operation."""
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([2, 3, 5, 6])
        result = ss1.symmetric_difference(ss2)
        assert list(result) == [1, 4, 5, 6]

    def test_symmetric_difference_operator(self):
        """Test symmetric difference using ^ operator."""
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([2, 3, 5, 6])
        result = ss1 ^ ss2
        assert list(result) == [1, 4, 5, 6]

    def test_ixor_operator(self):
        """Test symmetric difference using ^= operator."""
        ss1 = SortedSet([1, 2, 3, 4])
        ss2 = SortedSet([2, 3, 5, 6])
        ss1 ^= ss2
        assert list(ss1) == [1, 4, 5, 6]

    def test_isdisjoint(self):
        """Test isdisjoint method."""
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([4, 5, 6])
        ss3 = SortedSet([2, 3, 4])
        assert ss1.isdisjoint(ss2)
        assert not ss1.isdisjoint(ss3)

    def test_issubset(self):
        """Test issubset method."""
        ss1 = SortedSet([1, 2])
        ss2 = SortedSet([1, 2, 3])
        ss3 = SortedSet([2, 3, 4])
        assert ss1.issubset(ss2)
        assert not ss1.issubset(ss3)

    def test_issuperset(self):
        """Test issuperset method."""
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([1, 2])
        ss3 = SortedSet([2, 3, 4])
        assert ss1.issuperset(ss2)
        assert not ss1.issuperset(ss3)

    def test_update(self):
        """Test update method."""
        ss = SortedSet([1, 2])
        ss.update([2, 3, 4])
        assert list(ss) == [1, 2, 3, 4]

    def test_intersection_update(self):
        """Test intersection_update method."""
        ss = SortedSet([1, 2, 3, 4])
        ss.intersection_update([2, 3, 5])
        assert list(ss) == [2, 3]

    def test_difference_update(self):
        """Test difference_update method."""
        ss = SortedSet([1, 2, 3, 4])
        ss.difference_update([2, 3, 5])
        assert list(ss) == [1, 4]

    def test_symmetric_difference_update(self):
        """Test symmetric_difference_update method."""
        ss = SortedSet([1, 2, 3, 4])
        ss.symmetric_difference_update([2, 3, 5, 6])
        assert list(ss) == [1, 4, 5, 6]

    def test_equality(self):
        """Test equality comparison."""
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([1, 2, 3])
        s = {1, 2, 3}
        assert ss1 == ss2
        assert ss1 == s

    def test_inequality(self):
        """Test inequality comparison."""
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([1, 2, 4])
        assert ss1 != ss2

    def test_less_than(self):
        """Test less than comparison."""
        ss1 = SortedSet([1, 2])
        ss2 = SortedSet([1, 2, 3])
        assert ss1 < ss2
        assert not ss2 < ss1

    def test_less_equal(self):
        """Test less than or equal comparison."""
        ss1 = SortedSet([1, 2])
        ss2 = SortedSet([1, 2, 3])
        ss3 = SortedSet([1, 2])
        assert ss1 <= ss2
        assert ss1 <= ss3

    def test_greater_than(self):
        """Test greater than comparison."""
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([1, 2])
        assert ss1 > ss2
        assert not ss2 > ss1

    def test_greater_equal(self):
        """Test greater than or equal comparison."""
        ss1 = SortedSet([1, 2, 3])
        ss2 = SortedSet([1, 2])
        ss3 = SortedSet([1, 2, 3])
        assert ss1 >= ss2
        assert ss1 >= ss3

    def test_repr(self):
        """Test string representation."""
        ss = SortedSet([1, 2, 3])
        assert 'SortedSet' in repr(ss)

    def test_repr_empty(self):
        """Test string representation of empty set."""
        ss = SortedSet()
        assert repr(ss) == 'SortedSet()'

    def test_union_with_list(self):
        """Test union with regular list."""
        ss = SortedSet([1, 2, 3])
        result = ss.union([2, 3, 4])
        assert list(result) == [1, 2, 3, 4]

    def test_intersection_with_list(self):
        """Test intersection with regular list."""
        ss = SortedSet([1, 2, 3, 4])
        result = ss.intersection([2, 3, 5])
        assert list(result) == [2, 3]

    def test_large_dataset(self):
        """Test with a large dataset."""
        import random
        data = list(range(1000))
        random.shuffle(data)
        ss = SortedSet(data)
        assert len(ss) == 1000
        assert list(ss) == list(range(1000))
