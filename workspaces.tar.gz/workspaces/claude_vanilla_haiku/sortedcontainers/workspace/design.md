# SortedContainers Library Design

## Architecture Overview

This is a pure Python implementation of sorted container data structures. The library provides three main container types:

1. **SortedList**: A sorted list that maintains elements in sorted order with O(log n) insertion, deletion, and lookup
2. **SortedDict**: A dictionary that maintains keys in sorted order
3. **SortedSet**: A set that maintains elements in sorted order with set operations

## Core Implementation Strategy

### SortedList Internal Structure
- Uses a segmented list approach with multiple sub-lists (segments) to balance performance
- Each segment is a standard Python list
- A load factor (default 1000) controls maximum segment size
- An index structure (binary tree) enables O(log n) positional lookups
- Maxes array tracks the maximum value in each segment for binary search

Key attributes:
- `_lists`: List of segments (each is a regular Python list)
- `_maxes`: Maximum value in each segment for binary search
- `_index`: Binary tree index for position calculations
- `_offset`: Start of leaf nodes in the binary tree
- `_load`: Load factor for segment size control
- `_len`: Total number of elements

### SortedKeyList
- Subclass of SortedList that applies a key function to all comparisons
- Stores keys separately in `_keys` list parallel to `_lists`
- Supports all SortedList methods with key-based comparison
- Additional methods: `bisect_key_left()`, `bisect_key_right()`, `irange_key()`

### SortedDict
- Uses SortedList internally to maintain sorted keys
- Maps to values via a regular dict
- Provides dict-like interface (keys(), values(), items())
- View objects reflect real-time changes

### SortedSet
- Uses SortedList internally to store elements
- Provides set operations: union, intersection, difference, symmetric_difference
- Supports both mutating and non-mutating variants

### View Objects
- `SortedKeysView`, `SortedValuesView`, `SortedItemsView`
- Provide indexed access to dictionary elements
- Reflect real-time changes to the underlying dictionary

## Implementation Approach

### Algorithm Decisions

1. **Binary Search**: Use bisect_left and bisect_right on segment maxes to find target segment
2. **Insertion**: Find position in segment, insert, check if segment exceeds load factor
3. **Deletion**: Find and remove element, merge segments if needed
4. **Indexing**: Build/maintain binary tree index for O(log n) position lookup
5. **Load Factor**: Default 1000 balances memory and performance

### Performance Characteristics

All major operations (add, remove, contains, getitem) are O(log n) time:
- Binary search: O(log m) where m is number of segments
- Segment operations: O(k) where k is load factor
- Overall: O(log n) amortized

## Assumptions

1. **Comparable Values**: All values in a SortedList must be comparable (unless using custom key)
2. **Immutable During Iteration**: The sorted list should not be modified while iterating
3. **Key Function Stability**: Key functions should return consistent results for the same value
4. **Standard Python**: No C extensions, pure Python only
5. **Python 3.10+**: Uses modern Python features and type hints where appropriate
6. **Load Factor Range**: Load factor should be positive integer, typically 100-10000

## Module Organization

```
src/sortedcontainers/
├── __init__.py          # Public API exports
├── sortedlist.py        # SortedList and SortedKeyList classes
├── sorteddict.py        # SortedDict class and view objects
└── sortedset.py         # SortedSet class
```

## API Compliance

The implementation follows Python standard library conventions:
- Sequence operations (MutableSequence protocol)
- Mapping operations (MutableMapping protocol)
- Set operations (MutableSet protocol)
- Special methods: `__getitem__`, `__setitem__`, `__delitem__`, `__iter__`, `__len__`, etc.

## Testing Strategy

Comprehensive tests cover:
- Basic operations (add, remove, insert, delete)
- Edge cases (empty containers, single element, duplicates)
- Boundary conditions (negative indices, out of range)
- Key functions (custom sorting, complex objects)
- Performance with large datasets (100k+ elements)
- Set operations and intersections
- Iterator behavior and validity

## Performance Targets

- Add operation: O(log n) amortized
- Remove operation: O(log n) amortized
- Lookup/contains: O(log n)
- Getitem (by index): O(log n)
- Iteration: O(n)
- Large dataset support: 100,000+ elements efficiently
