# Quick Start Guide

This is a complete, production-ready implementation of the Python SortedContainers library. The project can be run directly from this directory without installation.

## Running the Project

### Direct Usage (No Installation)

You can use the library directly from the `src/` directory:

```python
import sys
sys.path.insert(0, 'src')

from sortedcontainers import SortedList, SortedDict, SortedSet
```

### Installation

To install the package for system-wide use:

```bash
pip install -e .
```

After installation, import normally:

```python
from sortedcontainers import SortedList, SortedDict, SortedSet
```

## Basic Examples

### SortedList - Maintaining Sorted Order

```python
from sortedcontainers import SortedList

# Create and populate
sl = SortedList([5, 2, 8, 1, 9])
print(list(sl))  # [1, 2, 5, 8, 9]

# Add elements
sl.add(3)
sl.add(7)

# Access by index (O(log n))
print(sl[0])    # 1 (first element)
print(sl[-1])   # 9 (last element)
print(sl[2])    # 3

# Search operations
print(sl.count(3))              # 1
print(sl.bisect_left(5))        # Position to insert 5 (left)
print(sl.bisect_right(5))       # Position to insert 5 (right)

# Remove elements
sl.remove(5)
sl.discard(7)

# Iteration
for value in sl:
    print(value)

# Slicing
print(sl[1:4])  # Values at indices 1-3
del sl[1:3]     # Delete indices 1-2
```

### SortedKeyList - Custom Sorting

```python
from sortedcontainers import SortedKeyList
from operator import neg

# Sort in descending order using neg key
skl = SortedKeyList([3, 1, 4, 1, 5, 9, 2, 6], key=neg)
print(list(skl))  # [9, 6, 5, 4, 3, 2, 1, 1]

# All SortedList operations work with custom keys
skl.add(7)
print(3 in skl)      # True
skl.remove(3)

# Custom key example: Sort by absolute value
skl2 = SortedKeyList([-5, 3, -1, 4, 2], key=abs)
print(list(skl2))  # [-1, 2, 3, 4, -5]
```

### SortedDict - Sorted Keys

```python
from sortedcontainers import SortedDict

# Create from dictionary
sd = SortedDict({'charlie': 3, 'alpha': 1, 'bravo': 2})

# Keys are always sorted
print(list(sd.keys()))      # ['alpha', 'bravo', 'charlie']
print(list(sd.values()))    # [1, 2, 3]
print(list(sd.items()))     # [('alpha', 1), ('bravo', 2), ('charlie', 3)]

# Indexed access (O(log n))
print(sd.keys()[0])         # 'alpha'
print(sd.values()[1])       # 2
print(sd.items()[2])        # ('charlie', 3)

# Standard dict operations
print(sd.get('alpha'))      # 1
sd['delta'] = 4
del sd['bravo']

# View objects reflect real-time changes
keys_view = sd.keys()
sd['aaa'] = 0
print(list(keys_view))      # Updated automatically
```

### SortedSet - Sorted Elements with Set Operations

```python
from sortedcontainers import SortedSet

# Create sets
ss1 = SortedSet([1, 2, 3, 4, 5])
ss2 = SortedSet([4, 5, 6, 7, 8])

# Set operations
print(list(ss1 | ss2))              # Union: [1, 2, 3, 4, 5, 6, 7, 8]
print(list(ss1 & ss2))              # Intersection: [4, 5]
print(list(ss1 - ss2))              # Difference: [1, 2, 3]
print(list(ss1 ^ ss2))              # Symmetric difference: [1, 2, 3, 6, 7, 8]

# Set comparisons
print(SortedSet([1, 2]) < SortedSet([1, 2, 3]))  # True (proper subset)
print(SortedSet([1, 2]).issubset(SortedSet([1, 2, 3])))  # True

# Element operations
ss1.add(9)
ss1.remove(1)
value = ss1.pop()  # Remove and return largest element

# Update operations
ss1 |= ss2         # Union update
ss1 &= ss2         # Intersection update
ss1 -= ss2         # Difference update
```

## Performance Characteristics

All main operations have O(log n) time complexity:

| Operation | Time Complexity | Notes |
|-----------|-----------------|-------|
| add() | O(log n) | Insertion in correct position |
| remove() | O(log n) | Removal maintains sorted order |
| pop() | O(log n) | Remove from end (fastest) |
| contains | O(log n) | Binary search |
| getitem | O(log n) | Index lookup |
| bisect_left | O(log n) | Find insertion point |
| bisect_right | O(log n) | Find insertion point |
| iteration | O(n) | Linear traversal |

## Large Dataset Support

The library efficiently handles large datasets:

```python
from sortedcontainers import SortedList

# Create with 1,000,000 elements
sl = SortedList(range(1000000, 0, -1))

# All operations are still fast
print(sl[500000])      # O(log n)
sl.add(500000)         # O(log n)
sl.remove(500000)      # O(log n)
```

## Running Tests

Test the implementation:

```bash
# Using sys.path
python3 << 'EOF'
import sys
sys.path.insert(0, 'src')

# Run your test script
from sortedcontainers import SortedList
sl = SortedList([3, 1, 2])
assert list(sl) == [1, 2, 3]
print("✓ Tests passed!")
EOF
```

Or after installation with pip:

```bash
pytest tests/ -v
```

## API Reference

### SortedList Methods

- `add(value)` - Add value in sorted order
- `remove(value)` - Remove first occurrence
- `discard(value)` - Remove if exists
- `pop(index=-1)` - Remove and return at index
- `clear()` - Remove all elements
- `copy()` - Return shallow copy
- `count(value)` - Count occurrences
- `index(value)` - Find first index
- `bisect_left(value)` - Find insertion point (left)
- `bisect_right(value)` - Find insertion point (right)
- `islice(start, stop, reverse)` - Iterator over slice
- `irange(minimum, maximum, inclusive, reverse)` - Iterator over range

### SortedDict Methods

- `keys()` - Return SortedKeysView
- `values()` - Return SortedValuesView
- `items()` - Return SortedItemsView
- `get(key, default)` - Get with default
- `pop(key, default)` - Remove and return
- `popitem()` - Remove and return arbitrary item
- `setdefault(key, default)` - Set default if missing
- `update(other)` - Update from dict or pairs
- `clear()` - Remove all items

### SortedSet Methods

- `add(value)` - Add element
- `remove(value)` - Remove element
- `discard(value)` - Remove if exists
- `pop()` - Remove and return largest
- `clear()` - Remove all elements
- `copy()` - Return shallow copy
- `union(*others)` - Return union
- `intersection(*others)` - Return intersection
- `difference(*others)` - Return difference
- `symmetric_difference(other)` - Return symmetric difference
- `isdisjoint(other)` - Check no common elements
- `issubset(other)` - Check subset relationship
- `issuperset(other)` - Check superset relationship

## Project Structure

```
sortedcontainers/
├── README.rst                 # Full project documentation
├── IMPLEMENTATION_SUMMARY.md  # Detailed implementation notes
├── design.md                  # Architecture and design decisions
├── pyproject.toml            # Modern Python packaging
├── setup.py                  # Legacy setup.py
├── src/
│   └── sortedcontainers/
│       ├── __init__.py
│       ├── sortedlist.py
│       ├── sorteddict.py
│       └── sortedset.py
└── tests/
    ├── test_sortedlist.py
    ├── test_sorteddict.py
    └── test_sortedset.py
```

## Features

✅ Pure Python implementation - no C extensions required
✅ O(log n) complexity for insert, delete, and lookup
✅ Support for custom key functions
✅ Full set operations with operators
✅ Efficient handling of large datasets (100k+ elements)
✅ Pickle serialization support
✅ View objects for dictionaries
✅ Comprehensive docstrings
✅ Compatible with Python standard library protocols

## Requirements

- Python 3.9+ (3.10+ recommended based on design)
- No external dependencies

## License

Apache License 2.0 - See LICENSE file for details
