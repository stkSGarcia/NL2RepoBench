2.4.0
-----

Released 2024-05-18

* Initial release of pure Python implementation
* Implement SortedList with O(log n) operations
* Implement SortedKeyList with custom key function support
* Implement SortedDict maintaining sorted keys
* Implement SortedSet with set operations
* Add comprehensive test suite
* Add view objects for SortedDict access
