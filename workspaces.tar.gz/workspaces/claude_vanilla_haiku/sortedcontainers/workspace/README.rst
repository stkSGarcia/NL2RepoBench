Python Sorted Containers
========================

Sorted Containers is an Apache2 licensed library written in pure Python. It provides
sorted list, sorted dict, and sorted set data structures.

The SortedList data structure provides a high-performance, pure Python sorted list
that maintains elements in sorted order while providing O(log n) insert, delete, and
lookup operations.

The SortedDict data structure maintains keys in sorted order and provides a
dict-like interface with sorted key iteration.

The SortedSet data structure maintains elements in sorted order and provides a
set-like interface with sorted element iteration.

Features
--------

- **Pure Python**: No C extensions or compiled code required
- **High Performance**: O(log n) complexity for insertion, deletion, and lookup
- **Standard Library Compatible**: Implements MutableSequence, MutableMapping, and MutableSet protocols
- **Key Functions**: Support for custom key functions for sorting
- **View Objects**: SortedKeysView, SortedValuesView, SortedItemsView for SortedDict
- **Set Operations**: Union, intersection, difference, symmetric difference
- **Large Dataset Support**: Efficiently handles 100,000+ elements

Installation
------------

Install using pip::

    pip install sortedcontainers

Or install from source::

    python -m pip install -e .

Quick Start
-----------

SortedList
~~~~~~~~~~

.. code-block:: python

    from sortedcontainers import SortedList

    sl = SortedList([3, 1, 2, 5, 4])
    print(list(sl))  # [1, 2, 3, 4, 5]

    sl.add(3)
    sl.remove(2)
    print(sl[0])  # 1
    print(3 in sl)  # True

SortedDict
~~~~~~~~~~

.. code-block:: python

    from sortedcontainers import SortedDict

    sd = SortedDict({'c': 3, 'a': 1, 'b': 2})
    print(list(sd.keys()))  # ['a', 'b', 'c']
    print(list(sd.values()))  # [1, 2, 3]

    sd['d'] = 4
    del sd['b']

SortedSet
~~~~~~~~~

.. code-block:: python

    from sortedcontainers import SortedSet

    ss1 = SortedSet([1, 2, 3, 4])
    ss2 = SortedSet([2, 3, 5])

    print(list(ss1 | ss2))  # [1, 2, 3, 4, 5] (union)
    print(list(ss1 & ss2))  # [2, 3] (intersection)
    print(list(ss1 - ss2))  # [1, 4] (difference)

SortedKeyList
~~~~~~~~~~~~~

.. code-block:: python

    from sortedcontainers import SortedKeyList
    from operator import neg

    skl = SortedKeyList([3, 1, 2], key=neg)
    print(list(skl))  # [3, 2, 1] (sorted in descending order)

Documentation
--------------

For full documentation, see the online docs at http://www.grantjenks.com/docs/sortedcontainers/

Testing
-------

Run tests using pytest::

    pytest tests/

License
-------

Copyright (c) 2012-2024 Grant Jenks

Licensed under the Apache License, Version 2.0 (the "License");
you may not use this file except in compliance with the License.
You may obtain a copy of the License at

    http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software
distributed under the License is distributed on an "AS IS" BASIS,
WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
See the License for the specific language governing permissions and
limitations under the License.
