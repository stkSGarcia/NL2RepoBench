"""Sorted set implementation with set operations."""

from collections.abc import MutableSet
from sortedcontainers.sortedlist import SortedList


class SortedSet(MutableSet):
    """A set that maintains elements in sorted order."""

    def __init__(self, iterable=None):
        """Initialize a SortedSet."""
        self._list = SortedList()

        if iterable is not None:
            for item in iterable:
                if item not in self._list:
                    self._list.add(item)

    def add(self, value):
        """Add a value to the sorted set."""
        if value not in self._list:
            self._list.add(value)

    def discard(self, value):
        """Remove a value from the sorted set if it exists."""
        self._list.discard(value)

    def remove(self, value):
        """Remove a value from the sorted set.

        Raises KeyError if value is not present.
        """
        try:
            self._list.remove(value)
        except ValueError:
            raise KeyError(value)

    def pop(self):
        """Remove and return an arbitrary element from the sorted set."""
        if not self._list:
            raise KeyError('pop from an empty set')
        return self._list.pop()

    def clear(self):
        """Remove all elements from the sorted set."""
        self._list.clear()

    def __contains__(self, value):
        """Check if a value is in the sorted set."""
        return value in self._list

    def __iter__(self):
        """Iterate over elements in sorted order."""
        return iter(self._list)

    def __reversed__(self):
        """Return a reverse iterator over elements."""
        return reversed(self._list)

    def __len__(self):
        """Return the number of elements."""
        return len(self._list)

    def __repr__(self):
        """Return a string representation."""
        if not self:
            return f'{self.__class__.__name__}()'
        return f'{self.__class__.__name__}({list(self)!r})'

    def __eq__(self, other):
        """Check equality with another set."""
        if isinstance(other, SortedSet):
            return list(self._list) == list(other._list)
        if isinstance(other, set):
            return set(self._list) == other
        return NotImplemented

    def __ne__(self, other):
        """Check inequality with another set."""
        return not self.__eq__(other)

    def __lt__(self, other):
        """Check if this set is a proper subset of another."""
        if isinstance(other, SortedSet):
            other = set(other._list)
        elif not isinstance(other, set):
            return NotImplemented
        return set(self._list) < other

    def __le__(self, other):
        """Check if this set is a subset of another."""
        if isinstance(other, SortedSet):
            other = set(other._list)
        elif not isinstance(other, set):
            return NotImplemented
        return set(self._list) <= other

    def __gt__(self, other):
        """Check if this set is a proper superset of another."""
        if isinstance(other, SortedSet):
            other = set(other._list)
        elif not isinstance(other, set):
            return NotImplemented
        return set(self._list) > other

    def __ge__(self, other):
        """Check if this set is a superset of another."""
        if isinstance(other, SortedSet):
            other = set(other._list)
        elif not isinstance(other, set):
            return NotImplemented
        return set(self._list) >= other

    def copy(self):
        """Return a shallow copy of the sorted set."""
        return self.__class__(self._list)

    def union(self, *others):
        """Return the union of this set and others."""
        result = self.copy()
        for other in others:
            if isinstance(other, SortedSet):
                result.update(other._list)
            else:
                result.update(other)
        return result

    def __or__(self, other):
        """Return the union using the | operator."""
        if not isinstance(other, (set, SortedSet)):
            return NotImplemented
        return self.union(other)

    def __ror__(self, other):
        """Return the union using the | operator (reversed)."""
        if not isinstance(other, (set, SortedSet)):
            return NotImplemented
        if isinstance(other, SortedSet):
            return other.union(self)
        return self.union(other)

    def __ior__(self, other):
        """Update this set with the union using the |= operator."""
        if isinstance(other, SortedSet):
            self.update(other._list)
        else:
            self.update(other)
        return self

    def intersection(self, *others):
        """Return the intersection of this set and others."""
        if not others:
            return self.copy()

        result = SortedSet()
        for value in self._list:
            if all(value in other for other in others):
                result.add(value)
        return result

    def __and__(self, other):
        """Return the intersection using the & operator."""
        if not isinstance(other, (set, SortedSet)):
            return NotImplemented
        return self.intersection(other)

    def __rand__(self, other):
        """Return the intersection using the & operator (reversed)."""
        if not isinstance(other, (set, SortedSet)):
            return NotImplemented
        if isinstance(other, SortedSet):
            return other.intersection(self)
        return self.intersection(other)

    def __iand__(self, other):
        """Update this set with the intersection using the &= operator."""
        if isinstance(other, SortedSet):
            other = set(other._list)
        else:
            other = set(other)

        to_remove = []
        for value in self._list:
            if value not in other:
                to_remove.append(value)

        for value in to_remove:
            self.discard(value)

        return self

    def difference(self, *others):
        """Return the difference of this set and others."""
        result = self.copy()
        for other in others:
            if isinstance(other, SortedSet):
                for value in other._list:
                    result.discard(value)
            else:
                for value in other:
                    result.discard(value)
        return result

    def __sub__(self, other):
        """Return the difference using the - operator."""
        if not isinstance(other, (set, SortedSet)):
            return NotImplemented
        return self.difference(other)

    def __rsub__(self, other):
        """Return the difference using the - operator (reversed)."""
        if not isinstance(other, (set, SortedSet)):
            return NotImplemented
        if isinstance(other, SortedSet):
            return other.difference(self)
        result = SortedSet(other)
        for value in self._list:
            result.discard(value)
        return result

    def __isub__(self, other):
        """Update this set with the difference using the -= operator."""
        if isinstance(other, SortedSet):
            for value in other._list:
                self.discard(value)
        else:
            for value in other:
                self.discard(value)
        return self

    def symmetric_difference(self, other):
        """Return the symmetric difference of this set and another."""
        if isinstance(other, SortedSet):
            other_set = set(other._list)
        else:
            other_set = set(other)

        result = SortedSet()
        for value in self._list:
            if value not in other_set:
                result.add(value)

        for value in other_set:
            if value not in self._list:
                result.add(value)

        return result

    def __xor__(self, other):
        """Return the symmetric difference using the ^ operator."""
        if not isinstance(other, (set, SortedSet)):
            return NotImplemented
        return self.symmetric_difference(other)

    def __rxor__(self, other):
        """Return the symmetric difference using the ^ operator (reversed)."""
        if not isinstance(other, (set, SortedSet)):
            return NotImplemented
        if isinstance(other, SortedSet):
            return other.symmetric_difference(self)
        return self.symmetric_difference(other)

    def __ixor__(self, other):
        """Update this set with the symmetric difference using the ^= operator."""
        if isinstance(other, SortedSet):
            other_list = list(other._list)
        else:
            other_list = list(other)

        to_remove = []
        for value in self._list:
            if value in other_list:
                to_remove.append(value)

        for value in to_remove:
            self.discard(value)

        for value in other_list:
            if value not in self._list:
                self.add(value)

        return self

    def isdisjoint(self, other):
        """Return True if this set has no elements in common with other."""
        if isinstance(other, SortedSet):
            for value in self._list:
                if value in other._list:
                    return False
        else:
            for value in self._list:
                if value in other:
                    return False
        return True

    def issubset(self, other):
        """Return True if this set is a subset of other."""
        if isinstance(other, SortedSet):
            other = set(other._list)
        else:
            other = set(other)
        return set(self._list) <= other

    def issuperset(self, other):
        """Return True if this set is a superset of other."""
        if isinstance(other, SortedSet):
            other = set(other._list)
        else:
            other = set(other)
        return set(self._list) >= other

    def update(self, *others):
        """Update the sorted set with elements from others."""
        for other in others:
            if isinstance(other, SortedSet):
                for value in other._list:
                    self.add(value)
            else:
                for value in other:
                    self.add(value)

    def intersection_update(self, *others):
        """Update the sorted set keeping only elements found in all."""
        if not others:
            return

        other_sets = []
        for other in others:
            if isinstance(other, SortedSet):
                other_sets.append(set(other._list))
            else:
                other_sets.append(set(other))

        to_remove = []
        for value in self._list:
            if not all(value in other for other in other_sets):
                to_remove.append(value)

        for value in to_remove:
            self.discard(value)

    def difference_update(self, *others):
        """Update the sorted set removing elements found in others."""
        for other in others:
            if isinstance(other, SortedSet):
                for value in other._list:
                    self.discard(value)
            else:
                for value in other:
                    self.discard(value)

    def symmetric_difference_update(self, other):
        """Update the sorted set keeping only unique elements."""
        if isinstance(other, SortedSet):
            other_set = set(other._list)
        else:
            other_set = set(other)

        to_remove = []
        for value in self._list:
            if value in other_set:
                to_remove.append(value)

        for value in to_remove:
            self.discard(value)

        for value in other_set:
            if value not in self._list:
                self.add(value)

    def __getstate__(self):
        """Support for pickle."""
        return list(self._list)

    def __setstate__(self, state):
        """Support for pickle."""
        self._list = SortedList(state)
