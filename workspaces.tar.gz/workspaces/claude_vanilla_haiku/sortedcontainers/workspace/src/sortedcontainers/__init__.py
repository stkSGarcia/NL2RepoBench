"""Sorted Containers – Sorted List, Sorted Dict, Sorted Set."""

__version__ = '2.4.0'

from sortedcontainers.sortedlist import SortedList, SortedKeyList
from sortedcontainers.sorteddict import (
    SortedDict,
    SortedKeysView,
    SortedValuesView,
    SortedItemsView,
)
from sortedcontainers.sortedset import SortedSet

# Alias for backwards compatibility
SortedListWithKey = SortedKeyList

__all__ = [
    'SortedList',
    'SortedKeyList',
    'SortedListWithKey',
    'SortedDict',
    'SortedSet',
    'SortedKeysView',
    'SortedValuesView',
    'SortedItemsView',
]
