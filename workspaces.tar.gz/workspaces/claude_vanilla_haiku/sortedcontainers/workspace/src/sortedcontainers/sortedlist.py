"""Sorted list implementation providing sorted container data structure."""

import bisect
import sys
from collections.abc import MutableSequence, Sequence
from itertools import chain
from functools import wraps
from operator import itemgetter


def identity(value):
    """Identity function - returns value unchanged."""
    return value


def recursive_repr(fillvalue='...'):
    """Decorator to preserve recursive repr."""
    def decorating_function(user_function):
        repr_running = set()

        @wraps(user_function)
        def wrapper(self):
            key = id(self)
            if key in repr_running:
                return fillvalue
            repr_running.add(key)
            try:
                result = user_function(self)
            finally:
                repr_running.discard(key)
            return result
        return wrapper
    return decorating_function


class SortedList(MutableSequence):
    """A sorted list maintaining values in sorted order.

    All values must be comparable. The total ordering of values must not
    change while they are stored in the sorted list.
    """

    DEFAULT_LOAD_FACTOR = 1000

    def __init__(self, iterable=None, key=None):
        """Initialize a SortedList instance.

        Optional iterable argument provides initial values.
        Runtime complexity: O(n*log(n))
        """
        if key is not None:
            raise TypeError('SortedList takes no key argument')

        self._len = 0
        self._load = self.DEFAULT_LOAD_FACTOR
        self._lists = []
        self._maxes = []
        self._index = []
        self._offset = 0

        if iterable is not None:
            self._update(iterable)

    def __new__(cls, iterable=None, key=None):
        """Create a SortedList or SortedKeyList instance.

        If key function is provided, returns SortedKeyList instance.
        """
        if key is None:
            return object.__new__(cls)
        return SortedKeyList(iterable, key)

    @property
    def key(self):
        """Key function for sorting (None for SortedList)."""
        return None

    def clear(self):
        """Remove all values from the sorted list."""
        self._len = 0
        del self._lists[:]
        del self._maxes[:]
        del self._index[:]
        self._offset = 0

    _clear = clear

    def add(self, value):
        """Add a value to the sorted list.

        Runtime complexity: O(log(n)) approximate.
        """
        _lists = self._lists
        _maxes = self._maxes

        if not _lists:
            _lists.append([value])
            _maxes.append(value)
            self._len = 1
            self._index = []
            self._offset = 0
            return

        pos = bisect.bisect_right(_maxes, value)

        if pos == len(_lists):
            pos -= 1

        _lists[pos].insert(bisect.bisect_right(_lists[pos], value), value)
        _maxes[pos] = _lists[pos][-1]
        self._len += 1
        self._index = []
        self._offset = 0

        if len(_lists[pos]) > (self._load << 1):
            self._expand(pos)

    def _expand(self, pos):
        """Split a sublist if it exceeds double the load factor."""
        _lists = self._lists
        _maxes = self._maxes
        _load = self._load

        sublist = _lists[pos]
        mid = len(sublist) >> 1
        _lists.insert(pos + 1, sublist[mid:])
        sublist[:] = sublist[:mid]
        _maxes[pos] = sublist[-1]
        _maxes.insert(pos + 1, _lists[pos + 1][-1])
        self._index = []
        self._offset = 0

    def update(self, iterable):
        """Update the sorted list with values from iterable.

        Runtime complexity: O(k*log(n)) approximate.
        """
        _len = self._len

        for value in iterable:
            self.add(value)

    _update = update

    def __contains__(self, value):
        """Check if value is in the sorted list.

        Runtime complexity: O(log(n))
        """
        _lists = self._lists
        _maxes = self._maxes

        if not _lists:
            return False

        pos = bisect.bisect_right(_maxes, value)
        if pos == len(_lists):
            pos -= 1

        sublist = _lists[pos]
        return value in sublist

    def discard(self, value):
        """Remove value from the sorted list if it exists."""
        _lists = self._lists
        _maxes = self._maxes

        if not _lists:
            return

        pos = bisect.bisect_right(_maxes, value)
        if pos == len(_lists):
            pos -= 1

        sublist = _lists[pos]
        idx = bisect.bisect_left(sublist, value)

        if idx < len(sublist) and sublist[idx] == value:
            self._delete(pos, idx)

    def remove(self, value):
        """Remove value from the sorted list.

        Raises ValueError if value is not present.
        """
        _lists = self._lists
        _maxes = self._maxes

        if not _lists:
            raise ValueError(f'{value!r} not in list')

        pos = bisect.bisect_right(_maxes, value)
        if pos == len(_lists):
            pos -= 1

        sublist = _lists[pos]
        idx = bisect.bisect_left(sublist, value)

        if idx < len(sublist) and sublist[idx] == value:
            self._delete(pos, idx)
        else:
            raise ValueError(f'{value!r} not in list')

    def _delete(self, pos, idx):
        """Delete value at position (pos, idx)."""
        _lists = self._lists
        _maxes = self._maxes
        _load = self._load

        _lists[pos].pop(idx)
        self._len -= 1

        if not _lists[pos]:
            _lists.pop(pos)
            _maxes.pop(pos)
            return

        _maxes[pos] = _lists[pos][-1]

        if len(_lists[pos]) < (_load >> 1):
            if pos > 0 and len(_lists[pos - 1]) < (_load >> 1):
                _lists[pos - 1].extend(_lists[pos])
                _maxes[pos - 1] = _lists[pos - 1][-1]
                _lists.pop(pos)
                _maxes.pop(pos)
            elif pos < len(_lists) - 1 and len(_lists[pos + 1]) < (_load >> 1):
                _lists[pos].extend(_lists[pos + 1])
                _maxes[pos] = _lists[pos][-1]
                _lists.pop(pos + 1)
                _maxes.pop(pos + 1)

        self._index = []
        self._offset = 0

    def _build_index(self):
        """Build the positional index for efficient indexing."""
        _lists = self._lists
        _len = self._len

        if not _lists:
            self._index = []
            self._offset = 0
            return

        lens = list(map(len, _lists))
        self._offset = offset = len(lens)
        self._index = index = [_len]

        while len(lens) > 1:
            lens = [sum(lens[i:i+2]) for i in range(0, len(lens), 2)]
            index.extend(lens)

    def _pos(self, index):
        """Convert index to (pos, idx) pair."""
        if index < 0:
            index += self._len

        if index < 0 or index >= self._len:
            raise IndexError('index out of range')

        _lists = self._lists
        pos = 0
        for i, sublist in enumerate(_lists):
            if index < len(sublist):
                return i, index
            index -= len(sublist)

        raise IndexError('index out of range')

    def _loc(self, pos, idx):
        """Convert (pos, idx) pair to index."""
        _lists = self._lists
        total = idx
        for i in range(pos):
            total += len(_lists[i])
        return total

    def __delitem__(self, index):
        """Remove value at index from the sorted list.

        Supports slicing.
        Runtime complexity: O(log(n))
        """
        _len = self._len

        if isinstance(index, slice):
            start, stop, step = index.indices(_len)
            if step == 1:
                indices = list(range(start, stop))
            else:
                indices = list(range(start, stop, step))
            for i in sorted(indices, reverse=True):
                del self[i]
        else:
            if index < 0:
                index += _len
            if index < 0 or index >= _len:
                raise IndexError('index out of range')

            pos, idx = self._pos(index)
            self._delete(pos, idx)

    def __getitem__(self, index):
        """Get value at index from the sorted list.

        Supports slicing.
        Runtime complexity: O(log(n))
        """
        _len = self._len
        _lists = self._lists

        if isinstance(index, slice):
            start, stop, step = index.indices(_len)
            if step == 1:
                return [self[i] for i in range(start, stop)]
            else:
                return [self[i] for i in range(start, stop, step)]

        if index < 0:
            index += _len

        if index < 0 or index >= _len:
            raise IndexError('index out of range')

        pos, idx = self._pos(index)
        return _lists[pos][idx]

    _getitem = __getitem__

    def __setitem__(self, index, value):
        """Raise NotImplementedError."""
        msg = 'use ``del sl[index]`` and ``sl.add(value)`` instead'
        raise NotImplementedError(msg)

    def __iter__(self):
        """Return an iterator over the sorted list."""
        return chain.from_iterable(self._lists)

    def __reversed__(self):
        """Return a reverse iterator over the sorted list."""
        return chain.from_iterable(map(reversed, reversed(self._lists)))

    def reverse(self):
        """Raise NotImplementedError."""
        raise NotImplementedError('use ``reversed(sl)`` instead')

    def islice(self, start=None, stop=None, reverse=False):
        """Return an iterator that slices the sorted list."""
        _len = self._len

        if start is None:
            start = 0
        elif start < 0:
            start += _len
        start = max(0, min(start, _len))

        if stop is None:
            stop = _len
        elif stop < 0:
            stop += _len
        stop = max(0, min(stop, _len))

        if start >= stop:
            return iter([])

        if reverse:
            return self._islice(self._pos(stop - 1)[0], self._pos(stop - 1)[1],
                               self._pos(start)[0], self._pos(start)[1], reverse)
        return self._islice(self._pos(start)[0], self._pos(start)[1],
                           self._pos(stop - 1)[0], self._pos(stop - 1)[1], reverse)

    def _islice(self, min_pos, min_idx, max_pos, max_idx, reverse):
        """Return an iterator slicing the sorted list using index pairs."""
        _lists = self._lists

        if reverse:
            if min_pos == max_pos:
                for i in range(max_idx, min_idx - 1, -1):
                    yield _lists[min_pos][i]
            else:
                for i in range(max_idx, -1, -1):
                    yield _lists[max_pos][i]
                for pos in range(max_pos - 1, min_pos, -1):
                    for i in range(len(_lists[pos]) - 1, -1, -1):
                        yield _lists[pos][i]
                for i in range(len(_lists[min_pos]) - 1, min_idx - 1, -1):
                    yield _lists[min_pos][i]
        else:
            if min_pos == max_pos:
                for i in range(min_idx, max_idx + 1):
                    yield _lists[min_pos][i]
            else:
                for i in range(min_idx, len(_lists[min_pos])):
                    yield _lists[min_pos][i]
                for pos in range(min_pos + 1, max_pos):
                    for val in _lists[pos]:
                        yield val
                for i in range(max_idx + 1):
                    yield _lists[max_pos][i]

    def irange(self, minimum=None, maximum=None, inclusive=(True, True), reverse=False):
        """Create an iterator of values between minimum and maximum."""
        if minimum is None:
            min_pos = 0
            min_idx = 0
        else:
            try:
                min_pos, min_idx = self._pos(self.bisect_left(minimum))
            except IndexError:
                return iter([])

        if maximum is None:
            max_pos = len(self._lists) - 1
            max_idx = len(self._lists[-1]) - 1 if self._lists else 0
        else:
            try:
                max_pos, max_idx = self._pos(self.bisect_right(maximum))
                if max_idx > 0:
                    max_idx -= 1
                elif max_pos > 0:
                    max_pos -= 1
                    max_idx = len(self._lists[max_pos]) - 1
                else:
                    return iter([])
            except IndexError:
                return iter([])

        if not inclusive[0] and minimum is not None:
            if self._lists[min_pos][min_idx] == minimum:
                if min_idx < len(self._lists[min_pos]) - 1:
                    min_idx += 1
                elif min_pos < len(self._lists) - 1:
                    min_pos += 1
                    min_idx = 0

        if not inclusive[1] and maximum is not None:
            if self._lists[max_pos][max_idx] == maximum:
                if max_idx > 0:
                    max_idx -= 1
                elif max_pos > 0:
                    max_pos -= 1
                    max_idx = len(self._lists[max_pos]) - 1
                else:
                    return iter([])

        return self._islice(min_pos, min_idx, max_pos, max_idx, reverse)

    def __len__(self):
        """Return the size of the sorted list."""
        return self._len

    def bisect_left(self, value):
        """Return an index to insert value in the sorted list (left)."""
        _lists = self._lists
        _maxes = self._maxes

        if not _lists:
            return 0

        pos = bisect.bisect_left(_maxes, value)

        if pos == len(_lists):
            pos -= 1

        idx = bisect.bisect_left(_lists[pos], value)

        return self._loc(pos, idx)

    def bisect_right(self, value):
        """Return an index to insert value in the sorted list (right)."""
        _lists = self._lists
        _maxes = self._maxes

        if not _lists:
            return 0

        pos = bisect.bisect_right(_maxes, value)

        if pos == len(_lists):
            pos -= 1

        idx = bisect.bisect_right(_lists[pos], value)

        return self._loc(pos, idx)

    bisect = bisect_right
    _bisect_right = bisect_right

    def count(self, value):
        """Return the number of occurrences of value."""
        _lists = self._lists
        _maxes = self._maxes

        if not _lists:
            return 0

        pos = bisect.bisect_right(_maxes, value)
        if pos == len(_lists):
            pos -= 1

        sublist = _lists[pos]
        start = bisect.bisect_left(sublist, value)
        end = bisect.bisect_right(sublist, value)

        return end - start

    def copy(self):
        """Return a shallow copy of the sorted list."""
        return self.__class__(self)

    __copy__ = copy

    def append(self, value):
        """Raise NotImplementedError."""
        raise NotImplementedError('use ``sl.add(value)`` instead')

    def extend(self, values):
        """Raise NotImplementedError."""
        raise NotImplementedError('use ``sl.update(values)`` instead')

    def insert(self, index, value):
        """Raise NotImplementedError."""
        raise NotImplementedError('use ``sl.add(value)`` instead')

    def pop(self, index=-1):
        """Remove and return value at index."""
        _len = self._len

        if not _len:
            raise IndexError('pop from empty list')

        if index < 0:
            index += _len

        if index < 0 or index >= _len:
            raise IndexError('pop index out of range')

        pos, idx = self._pos(index)
        value = self._lists[pos][idx]
        self._delete(pos, idx)
        return value

    def index(self, value, start=None, stop=None):
        """Return the first index of value.

        Raises ValueError if value is not present.
        """
        _len = self._len

        if start is None:
            start = 0
        elif start < 0:
            start += _len
        start = max(0, min(start, _len))

        if stop is None:
            stop = _len
        elif stop < 0:
            stop += _len
        stop = max(0, min(stop, _len))

        idx = self.bisect_left(value)

        if start <= idx < stop and idx < _len and self[idx] == value:
            return idx

        raise ValueError(f'{value!r} is not in list')

    def __add__(self, other):
        """Return a new sorted list with values from both lists."""
        if isinstance(other, SortedList):
            return self.__class__(chain(self, other))
        return self.__class__(chain(self, other))

    __radd__ = __add__

    def __iadd__(self, other):
        """Update the sorted list with values from other."""
        self.update(other)
        return self

    def __mul__(self, num):
        """Return a new sorted list with num copies of values."""
        return self.__class__(chain.from_iterable([self] * num))

    __rmul__ = __mul__

    def __imul__(self, num):
        """Update the sorted list with num copies of values."""
        if num <= 0:
            self.clear()
        else:
            self.update(chain.from_iterable([list(self)] * (num - 1)))
        return self

    def __eq__(self, other):
        """Check equality with another sequence."""
        if isinstance(other, SortedList):
            return list(self) == list(other)
        return list(self) == list(other)

    def __ne__(self, other):
        """Check inequality with another sequence."""
        return not self.__eq__(other)

    def __lt__(self, other):
        """Check if less than another sequence."""
        return list(self) < list(other)

    def __le__(self, other):
        """Check if less than or equal to another sequence."""
        return list(self) <= list(other)

    def __gt__(self, other):
        """Check if greater than another sequence."""
        return list(self) > list(other)

    def __ge__(self, other):
        """Check if greater than or equal to another sequence."""
        return list(self) >= list(other)

    def __reduce__(self):
        """Support for pickle."""
        return (self.__class__, (list(self),))

    @recursive_repr()
    def __repr__(self):
        """Return a string representation of the sorted list."""
        return f'{self.__class__.__name__}({list(self)!r})'

    def _check(self):
        """Check invariants of the sorted list."""
        _lists = self._lists
        _len = self._len
        _maxes = self._maxes

        assert len(_lists) == len(_maxes)

        total_len = sum(len(sublist) for sublist in _lists)
        assert total_len == _len

        for pos, sublist in enumerate(_lists):
            assert len(sublist) > 0
            assert _maxes[pos] == sublist[-1]
            if pos > 0:
                assert _lists[pos - 1][-1] <= sublist[0]

    def _reset(self, load):
        """Reset the load factor."""
        self._load = load
        if self._len:
            values = list(self)
            self.clear()
            self.update(values)


class SortedKeyList(SortedList):
    """A sorted list with a key function for comparison."""

    def __init__(self, iterable=None, key=identity):
        """Initialize a SortedKeyList instance."""
        self._key = key
        self._len = 0
        self._load = self.DEFAULT_LOAD_FACTOR
        self._lists = []
        self._keys = []
        self._maxes = []
        self._index = []
        self._offset = 0

        if iterable is not None:
            self._update(iterable)

    def __new__(cls, iterable=None, key=identity):
        """Create a SortedKeyList instance."""
        return object.__new__(cls)

    @property
    def key(self):
        """The key function used for sorting."""
        return self._key

    def clear(self):
        """Remove all values from the sorted list."""
        self._len = 0
        del self._lists[:]
        del self._keys[:]
        del self._maxes[:]
        del self._index[:]
        self._offset = 0

    _clear = clear

    def add(self, value):
        """Add a value to the sorted list."""
        _lists = self._lists
        _keys = self._keys
        _maxes = self._maxes
        _key = self._key

        key_value = _key(value)

        if not _lists:
            _lists.append([value])
            _keys.append([key_value])
            _maxes.append(key_value)
            self._len = 1
            self._index = []
            self._offset = 0
            return

        pos = bisect.bisect_right(_maxes, key_value)
        if pos == len(_lists):
            pos -= 1

        idx = bisect.bisect_right(_keys[pos], key_value)
        _lists[pos].insert(idx, value)
        _keys[pos].insert(idx, key_value)
        _maxes[pos] = _keys[pos][-1]
        self._len += 1
        self._index = []
        self._offset = 0

        if len(_lists[pos]) > (self._load << 1):
            self._expand(pos)

    def _expand(self, pos):
        """Split a sublist if it exceeds double the load factor."""
        _lists = self._lists
        _keys = self._keys
        _maxes = self._maxes

        sublist = _lists[pos]
        subkeys = _keys[pos]
        mid = len(sublist) >> 1

        _lists.insert(pos + 1, sublist[mid:])
        _keys.insert(pos + 1, subkeys[mid:])
        sublist[:] = sublist[:mid]
        subkeys[:] = subkeys[:mid]

        _maxes[pos] = _keys[pos][-1]
        _maxes.insert(pos + 1, _keys[pos + 1][-1])
        self._index = []
        self._offset = 0

    def update(self, iterable):
        """Update the sorted list with values from iterable."""
        for value in iterable:
            self.add(value)

    _update = update

    def __contains__(self, value):
        """Check if value is in the sorted list."""
        _lists = self._lists
        _keys = self._keys
        _maxes = self._maxes
        _key = self._key

        if not _lists:
            return False

        key_value = _key(value)
        pos = bisect.bisect_right(_maxes, key_value)
        if pos == len(_lists):
            pos -= 1

        sublist = _lists[pos]
        idx = bisect.bisect_left(_keys[pos], key_value)

        while idx < len(sublist) and _keys[pos][idx] == key_value:
            if sublist[idx] == value:
                return True
            idx += 1

        return False

    def discard(self, value):
        """Remove value from the sorted list if it exists."""
        _lists = self._lists
        _keys = self._keys
        _maxes = self._maxes
        _key = self._key

        if not _lists:
            return

        key_value = _key(value)
        pos = bisect.bisect_right(_maxes, key_value)
        if pos == len(_lists):
            pos -= 1

        sublist = _lists[pos]
        idx = bisect.bisect_left(_keys[pos], key_value)

        while idx < len(sublist) and _keys[pos][idx] == key_value:
            if sublist[idx] == value:
                self._delete(pos, idx)
                return
            idx += 1

    def remove(self, value):
        """Remove value from the sorted list.

        Raises ValueError if value is not present.
        """
        _lists = self._lists
        _keys = self._keys
        _maxes = self._maxes
        _key = self._key

        if not _lists:
            raise ValueError(f'{value!r} not in list')

        key_value = _key(value)
        pos = bisect.bisect_right(_maxes, key_value)
        if pos == len(_lists):
            pos -= 1

        sublist = _lists[pos]
        idx = bisect.bisect_left(_keys[pos], key_value)

        while idx < len(sublist) and _keys[pos][idx] == key_value:
            if sublist[idx] == value:
                self._delete(pos, idx)
                return
            idx += 1

        raise ValueError(f'{value!r} not in list')

    def _delete(self, pos, idx):
        """Delete value at position (pos, idx)."""
        _lists = self._lists
        _keys = self._keys
        _maxes = self._maxes

        _lists[pos].pop(idx)
        _keys[pos].pop(idx)
        self._len -= 1

        if not _lists[pos]:
            _lists.pop(pos)
            _keys.pop(pos)
            _maxes.pop(pos)
            return

        _maxes[pos] = _keys[pos][-1]

        if len(_lists[pos]) < (self._load >> 1):
            if pos > 0 and len(_lists[pos - 1]) < (self._load >> 1):
                _lists[pos - 1].extend(_lists[pos])
                _keys[pos - 1].extend(_keys[pos])
                _maxes[pos - 1] = _keys[pos - 1][-1]
                _lists.pop(pos)
                _keys.pop(pos)
                _maxes.pop(pos)
            elif pos < len(_lists) - 1 and len(_lists[pos + 1]) < (self._load >> 1):
                _lists[pos].extend(_lists[pos + 1])
                _keys[pos].extend(_keys[pos + 1])
                _maxes[pos] = _keys[pos][-1]
                _lists.pop(pos + 1)
                _keys.pop(pos + 1)
                _maxes.pop(pos + 1)

        self._index = []
        self._offset = 0

    def bisect_left(self, value):
        """Return an index to insert value in the sorted list (left)."""
        _lists = self._lists
        _keys = self._keys
        _maxes = self._maxes
        _key = self._key

        if not _lists:
            return 0

        key_value = _key(value)
        pos = bisect.bisect_left(_maxes, key_value)

        idx = bisect.bisect_left(_keys[pos], key_value)
        return self._loc(pos, idx)

    def bisect_right(self, value):
        """Return an index to insert value in the sorted list (right)."""
        _lists = self._lists
        _keys = self._keys
        _maxes = self._maxes
        _key = self._key

        if not _lists:
            return 0

        key_value = _key(value)
        pos = bisect.bisect_right(_maxes, key_value)
        if pos == len(_lists):
            pos -= 1

        idx = bisect.bisect_right(_keys[pos], key_value)
        return self._loc(pos, idx)

    bisect = bisect_right
    _bisect_right = bisect_right

    def count(self, value):
        """Return the number of occurrences of value."""
        _lists = self._lists
        _keys = self._keys
        _maxes = self._maxes
        _key = self._key

        if not _lists:
            return 0

        key_value = _key(value)
        pos = bisect.bisect_right(_maxes, key_value)
        if pos == len(_lists):
            pos -= 1

        start = bisect.bisect_left(_keys[pos], key_value)
        end = bisect.bisect_right(_keys[pos], key_value)

        return end - start

    def irange(self, minimum=None, maximum=None, inclusive=(True, True), reverse=False):
        """Create an iterator of values between minimum and maximum."""
        _key = self._key

        if minimum is None:
            min_key = None
        else:
            min_key = _key(minimum)

        if maximum is None:
            max_key = None
        else:
            max_key = _key(maximum)

        if minimum is not None:
            try:
                min_pos, min_idx = self._pos(self.bisect_left(minimum))
            except IndexError:
                return iter([])
        else:
            min_pos, min_idx = 0, 0

        if maximum is not None:
            try:
                max_pos, max_idx = self._pos(self.bisect_right(maximum))
                if max_idx > 0:
                    max_idx -= 1
                elif max_pos > 0:
                    max_pos -= 1
                    max_idx = len(self._lists[max_pos]) - 1
                else:
                    return iter([])
            except IndexError:
                return iter([])
        else:
            if self._lists:
                max_pos = len(self._lists) - 1
                max_idx = len(self._lists[-1]) - 1
            else:
                return iter([])

        return self._islice(min_pos, min_idx, max_pos, max_idx, reverse)
