"""Sorted dictionary implementation maintaining keys in sorted order."""

from collections.abc import MutableMapping
from sortedcontainers.sortedlist import SortedList


class SortedKeysView:
    """A view of sorted dictionary keys with indexed access."""

    def __init__(self, sorted_dict):
        """Initialize a SortedKeysView."""
        self._dict = sorted_dict

    def __iter__(self):
        """Iterate over keys in sorted order."""
        return iter(self._dict._keys)

    def __len__(self):
        """Return the number of keys."""
        return len(self._dict._keys)

    def __contains__(self, key):
        """Check if a key is in the view."""
        return key in self._dict._keys

    def __getitem__(self, index):
        """Get a key by index."""
        return self._dict._keys[index]

    def __reversed__(self):
        """Return a reverse iterator over keys."""
        return reversed(self._dict._keys)

    def __repr__(self):
        """Return a string representation."""
        return f'SortedKeysView({list(self)!r})'


class SortedValuesView:
    """A view of sorted dictionary values with indexed access."""

    def __init__(self, sorted_dict):
        """Initialize a SortedValuesView."""
        self._dict = sorted_dict

    def __iter__(self):
        """Iterate over values in key order."""
        for key in self._dict._keys:
            yield self._dict._dict[key]

    def __len__(self):
        """Return the number of values."""
        return len(self._dict._keys)

    def __contains__(self, value):
        """Check if a value is in the view."""
        return value in self._dict._dict.values()

    def __getitem__(self, index):
        """Get a value by index."""
        key = self._dict._keys[index]
        return self._dict._dict[key]

    def __reversed__(self):
        """Return a reverse iterator over values."""
        for key in reversed(self._dict._keys):
            yield self._dict._dict[key]

    def __repr__(self):
        """Return a string representation."""
        return f'SortedValuesView({list(self)!r})'


class SortedItemsView:
    """A view of sorted dictionary items with indexed access."""

    def __init__(self, sorted_dict):
        """Initialize a SortedItemsView."""
        self._dict = sorted_dict

    def __iter__(self):
        """Iterate over items in key order."""
        for key in self._dict._keys:
            yield (key, self._dict._dict[key])

    def __len__(self):
        """Return the number of items."""
        return len(self._dict._keys)

    def __contains__(self, item):
        """Check if an item is in the view."""
        if not isinstance(item, tuple) or len(item) != 2:
            return False
        key, value = item
        return key in self._dict._dict and self._dict._dict[key] == value

    def __getitem__(self, index):
        """Get an item by index."""
        key = self._dict._keys[index]
        return (key, self._dict._dict[key])

    def __reversed__(self):
        """Return a reverse iterator over items."""
        for key in reversed(self._dict._keys):
            yield (key, self._dict._dict[key])

    def __repr__(self):
        """Return a string representation."""
        return f'SortedItemsView({list(self)!r})'


class SortedDict(MutableMapping):
    """A dictionary that maintains keys in sorted order."""

    def __init__(self, *args, **kwargs):
        """Initialize a SortedDict."""
        self._keys = SortedList()
        self._dict = {}

        if args:
            if len(args) > 1:
                raise TypeError(f'SortedDict expected at most 1 argument, got {len(args)}')
            other = args[0]
            if isinstance(other, dict):
                for key, value in other.items():
                    self[key] = value
            elif hasattr(other, 'items'):
                for key, value in other.items():
                    self[key] = value
            else:
                for key, value in other:
                    self[key] = value

        for key, value in kwargs.items():
            self[key] = value

    def __setitem__(self, key, value):
        """Set a key-value pair."""
        if key not in self._dict:
            self._keys.add(key)
        self._dict[key] = value

    def __getitem__(self, key):
        """Get a value by key."""
        return self._dict[key]

    def __delitem__(self, key):
        """Delete a key-value pair."""
        self._keys.remove(key)
        del self._dict[key]

    def __iter__(self):
        """Iterate over keys in sorted order."""
        return iter(self._keys)

    def __len__(self):
        """Return the number of items."""
        return len(self._dict)

    def __repr__(self):
        """Return a string representation."""
        if not self:
            return f'{self.__class__.__name__}()'
        items = ', '.join(f'{k!r}: {v!r}' for k, v in self.items())
        return f'{self.__class__.__name__}({{{items}}})'

    def __eq__(self, other):
        """Check equality with another dictionary."""
        if not isinstance(other, dict):
            return NotImplemented
        return self._dict == other

    def __ne__(self, other):
        """Check inequality with another dictionary."""
        return not self.__eq__(other)

    def __contains__(self, key):
        """Check if a key is in the dictionary."""
        return key in self._dict

    def clear(self):
        """Remove all items from the dictionary."""
        self._keys.clear()
        self._dict.clear()

    def copy(self):
        """Return a shallow copy of the sorted dictionary."""
        return self.__class__(self)

    def get(self, key, default=None):
        """Get a value by key with a default."""
        return self._dict.get(key, default)

    def pop(self, key, *args):
        """Remove and return a value by key."""
        if key in self._dict:
            self._keys.remove(key)
        return self._dict.pop(key, *args)

    def popitem(self):
        """Remove and return an arbitrary (key, value) pair."""
        if not self._dict:
            raise KeyError('popitem(): dictionary is empty')
        key = self._keys.pop()
        value = self._dict.pop(key)
        return key, value

    def setdefault(self, key, default=None):
        """Set a key with a default value if not already present."""
        if key not in self._dict:
            self[key] = default
        return self._dict[key]

    def update(self, *args, **kwargs):
        """Update the dictionary with key-value pairs."""
        if args:
            other = args[0]
            if isinstance(other, dict):
                for key, value in other.items():
                    self[key] = value
            elif hasattr(other, 'items'):
                for key, value in other.items():
                    self[key] = value
            else:
                for key, value in other:
                    self[key] = value

        for key, value in kwargs.items():
            self[key] = value

    def keys(self):
        """Return a view of the dictionary's keys."""
        return SortedKeysView(self)

    def values(self):
        """Return a view of the dictionary's values."""
        return SortedValuesView(self)

    def items(self):
        """Return a view of the dictionary's items."""
        return SortedItemsView(self)

    def __getstate__(self):
        """Support for pickle."""
        return self._dict.copy(), list(self._keys)

    def __setstate__(self, state):
        """Support for pickle."""
        items, keys = state
        self._dict = items
        self._keys = SortedList(keys)
