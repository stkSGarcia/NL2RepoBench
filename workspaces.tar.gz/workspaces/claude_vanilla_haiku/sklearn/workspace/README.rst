sklearn-pandas
==============

A bridge connecting Scikit-Learn and pandas. It provides utilities to map pandas DataFrame columns to scikit-learn transformers, enabling seamless feature engineering workflows.

Features
--------

- **DataFrame Mapper**: Map columns to transformers with automatic column tracking
- **Numerical Transformer**: Built-in support for log and log1p transformations
- **Feature Generator**: Batch generation of feature definitions
- **Pipeline Integration**: Compatible with scikit-learn pipelines
- **Sparse Matrix Support**: Efficient handling of sparse matrices
- **DataFrame Output**: Option to return results as pandas DataFrames

Installation
------------

.. code-block:: bash

    pip install sklearn-pandas

Quick Start
-----------

.. code-block:: python

    from sklearn_pandas import DataFrameMapper
    from sklearn.preprocessing import StandardScaler
    import pandas as pd

    # Create a simple DataFrame
    df = pd.DataFrame({'a': [1, 2, 3], 'b': [4, 5, 6]})

    # Define transformations
    mapper = DataFrameMapper([
        ('a', StandardScaler()),
        ('b', None)
    ], df_out=True)

    # Fit and transform
    result = mapper.fit_transform(df)

Documentation
-------------

For detailed documentation, examples, and tutorials, please refer to the package documentation and tests.

License
-------

BSD License
