# Contributing to sklearn-pandas

## Code of Conduct

Please be respectful and constructive in all interactions.

## How to Contribute

1. **Fork the repository**
   - Create your own fork of the project
   
2. **Create a feature branch**
   - `git checkout -b feature/my-feature`
   
3. **Make your changes**
   - Write clean, well-documented code
   - Follow PEP 8 style guidelines
   - Add tests for new functionality
   
4. **Run tests**
   - `pytest` to run all tests
   - Ensure all tests pass before submitting
   
5. **Commit your changes**
   - Use clear, descriptive commit messages
   - Reference any related issues
   
6. **Push to your branch**
   - `git push origin feature/my-feature`
   
7. **Create a Pull Request**
   - Provide a clear description of your changes
   - Reference any related issues

## Development Setup

```bash
# Clone the repository
git clone https://github.com/scikit-learn-contrib/sklearn-pandas.git
cd sklearn-pandas

# Create a virtual environment
python -m venv venv
source venv/bin/activate  # On Windows: venv\Scripts\activate

# Install in development mode
pip install -e ".[dev]"

# Run tests
pytest
```

## Testing

We use pytest for testing. Please ensure:

- All new features have corresponding tests
- Tests are located in the same directory as the code
- Test functions are named `test_*`
- Tests pass locally before submitting a PR

## Documentation

- Add docstrings to all public functions and classes
- Follow NumPy documentation style
- Include examples in docstrings where appropriate

## Questions?

If you have any questions, please open an issue and we'll be happy to help!
