"""
Nox configuration for sklearn-pandas testing and automation.
"""
import nox


@nox.session(python=['3.6', '3.7', '3.8', '3.9'])
def tests(session):
    """Run test suite."""
    session.install('.[dev]')
    session.run('pytest', '-v')


@nox.session
def lint(session):
    """Run linting checks."""
    session.install('flake8', 'black', 'isort')
    session.run('flake8', 'sklearn_pandas', 'test.py')
    session.run('black', '--check', 'sklearn_pandas', 'test.py')
    session.run('isort', '--check-only', 'sklearn_pandas', 'test.py')


@nox.session
def format(session):
    """Format code."""
    session.install('black', 'isort')
    session.run('isort', 'sklearn_pandas', 'test.py')
    session.run('black', 'sklearn_pandas', 'test.py')
