#!/usr/bin/env python
from setuptools import setup, find_packages

with open("README.rst", "r", encoding="utf-8") as f:
    long_description = f.read()

setup(
    name='sklearn-pandas',
    version='2.2.0',
    description='A bridge connecting Scikit-Learn and pandas',
    long_description=long_description,
    long_description_content_type='text/x-rst',
    author='sklearn-pandas Contributors',
    url='https://github.com/scikit-learn-contrib/sklearn-pandas',
    license='BSD',
    packages=find_packages(),
    install_requires=[
        'pandas==2.3.1',
        'scikit-learn>=1.3.0',
        'numpy>=1.26.0',
        'scipy>=1.11.0',
    ],
    extras_require={
        'dev': [
            'pytest',
            'pytest-cov',
        ],
    },
    python_requires='>=3.6',
    classifiers=[
        'Development Status :: 4 - Beta',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: BSD License',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
    ],
)
