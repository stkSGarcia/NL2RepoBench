# sklearn-pandas Design Documentation

## Project Overview

sklearn-pandas is a bridge library that connects pandas DataFrames with scikit-learn transformers. It provides a flexible and efficient way to apply different transformations to different columns of a DataFrame, enabling seamless feature engineering workflows.

## Architecture

### Module Structure

```
sklearn_pandas/
├── __init__.py              # Package entry point, exports main classes and functions
├── dataframe_mapper.py      # Core DataFrameMapper class and helper functions
├── transformers.py          # NumericalTransformer class
├── pipeline.py              # TransformerPipeline class
├── features_generator.py    # Feature generation utilities
└── cross_validation.py      # Cross-validation utilities (reserved for future)
```

### Core Components

#### 1. DataFrameMapper
The main class that maps DataFrame columns to transformers.

**Key Features:**
- Maps single or multiple columns to transformers
- Supports default transformers for unmapped columns
- Can output as numpy arrays or pandas DataFrames
- Handles sparse matrices efficiently
- Provides detailed column naming for transformed features
- Includes robust exception handling with column context

**Key Methods:**
- `fit(X, y=None)` - Fit transformers
- `transform(X)` - Transform data
- `fit_transform(X, y=None)` - Fit and transform
- `get_names(columns, transformer, x, ...)` - Generate column names

#### 2. NumericalTransformer
A transformer for common numerical operations (log, log1p).

**Key Features:**
- Supports `log` and `log1p` transformations
- Simple interface consistent with scikit-learn
- Includes deprecation warning (to be replaced by custom TransformerMixin)

#### 3. TransformerPipeline
A pipeline implementation optimized for transformers (not estimators).

**Key Features:**
- Chains multiple transformers
- All steps must implement fit and transform
- Compatible with scikit-learn's Pipeline for integration

#### 4. Feature Generator (gen_features)
Utility function for batch generation of feature definitions.

**Key Features:**
- Simplifies feature definition for multiple columns
- Supports flexible class instantiation with parameters
- Allows prefix/suffix for feature naming

### Helper Functions

- `_handle_feature(fea)` - Converts 1D arrays to 2D column vectors
- `_build_transformer(transformers)` - Builds a single transformer or pipeline
- `_build_feature(columns, transformers, options, X)` - Constructs feature definitions
- `_get_feature_names(estimator)` - Extracts feature names from transformers

## Design Decisions

### Assumptions

1. **Callable Columns**: Column selectors can be callable (functions) that return column names based on the DataFrame. This is evaluated during the `_build` phase.

2. **Sparse Matrix Handling**: Sparse matrices from different transformers are combined using `sparse.hstack()`. Dense matrices are converted to sparse if needed.

3. **Default Transformer Behavior**:
   - `default=False` (default) - Drop unmapped columns
   - `default=None` - Pass unmapped columns through unchanged
   - `default=<transformer>` - Apply transformer to unmapped columns

4. **Exception Context**: All exceptions raised during fit/transform include the column name for debugging.

5. **Column Ordering**: When using callable column selectors, columns are evaluated at fit time and preserved in order during transform.

6. **Input Data Format**: The input to transformers can be:
   - numpy arrays (default)
   - pandas DataFrame/Series (if `input_df=True`)

7. **Feature Naming Convention**:
   - Single column, single output: Original column name
   - Multiple columns: Column names joined with `_`
   - Multiple outputs: Numbered with `_0`, `_1`, etc.
   - With alias: Use alias instead of column names
   - With prefix/suffix: Applied to final names

### Implementation Details

#### Column Selection and Data Extraction

The `_get_col_subset()` method handles:
- String selectors (single column)
- List selectors (multiple columns)
- Callable selectors (evaluated on DataFrame)

Data is converted to numpy arrays by default, or kept as DataFrame/Series if `input_df=True`.

#### Transformation Pipeline

1. Build feature list (resolving callables if X is provided)
2. Build default transformer if needed
3. For each feature:
   - Extract column subset
   - Apply transformer (if not None)
   - Convert to 2D array if necessary
   - Extract and rename columns
4. Handle unselected columns with default transformer
5. Combine all arrays (handling sparse vs dense)
6. Return as numpy array or DataFrame

#### Error Handling

Exception messages include column context in format: `"{column_name}: {original_error}"`

For multi-column features, columns are joined with commas.

## Data Type Handling

### Input Types
- pandas DataFrame (primary)
- numpy ndarray (converted internally)

### Output Types
- numpy ndarray (default)
- pandas DataFrame (if `df_out=True`)
- scipy.sparse.csr_matrix (if sparse output)

### Sparse Matrix Support

When `sparse=True`:
- Sparse matrices from transformers are combined with `sparse.hstack()`
- Dense matrices are converted to sparse using `sparse.csr_matrix()`
- Result is in CSR format

When `sparse=False`:
- Sparse matrices are converted to dense using `toarray()`
- All arrays are combined with `np.hstack()`

## Limitations and Future Improvements

### Current Limitations

1. **Serialization**: While basic pickling is supported via `__getstate__`/`__setstate__`, complex transformers may not serialize correctly.

2. **Parallel Processing**: The implementation is single-threaded. Parallel processing could be added for CPU-intensive transformations.

3. **Memory Efficiency**: Large DataFrames are fully materialized in memory. Chunked processing could be added.

4. **Column Ordering**: With callable selectors, column ordering depends on DataFrame column order.

### Potential Improvements

1. Add parallel processing for independent transformations
2. Add chunked processing for large datasets
3. Add caching of transformation results
4. Add metadata tracking for feature importance
5. Add support for more transformer types (custom estimators, etc.)

## Testing Strategy

The test suite covers:

1. **Basic Transformations**: Simple and complex DataFrames
2. **Feature Naming**: Single, binary, Unicode names
3. **Label Encoding**: LabelBinarizer, OneHotEncoder
4. **Multi-Column Operations**: PCA, feature selection
5. **Feature Generation**: Batch generation with various configurations
6. **Numerical Transformations**: Log, log1p operations
7. **Pipeline Integration**: Integration with scikit-learn pipelines
8. **Sparse Matrices**: Sparse feature processing and disabling
9. **Exception Handling**: Column context in error messages
10. **Column Selection**: Dynamic selection with callable selectors
11. **Helper Functions**: Internal utility functions
12. **DataFrame Output**: Output as pandas DataFrames
13. **Default Transformers**: Handling of unmapped columns

## API Consistency with scikit-learn

The library follows scikit-learn conventions:

- All transformers implement `fit()`, `transform()`, and `fit_transform()`
- Classes inherit from `BaseEstimator` and `TransformerMixin` where appropriate
- Parameters are passed to `__init__()` and stored as attributes
- Methods return `self` for chaining

## Version Compatibility

- **Python**: 3.6+
- **pandas**: 2.3.1
- **scikit-learn**: >=1.3.0
- **numpy**: >=1.26.0
- **scipy**: >=1.11.0

## Performance Considerations

### Time Complexity

- `fit()`: O(n * m) where n is number of samples, m is number of columns
- `transform()`: O(n * m) - linear in data size
- `fit_transform()`: O(n * m) - same as fit + transform

### Space Complexity

- O(n * k) where k is number of transformed columns
- Sparse matrices use space proportional to non-zero elements

### Optimization Tips

1. Use callable column selectors to defer evaluation
2. Use sparse matrices for high-dimensional sparse data
3. Use `input_df=False` (default) for faster processing
4. Pre-scale numerical features when possible

## Security Considerations

1. **No Input Validation**: Assumes transformers are from trusted sources
2. **Code Execution**: gen_features instantiates arbitrary classes (should only be used with trusted sources)
3. **Serialization**: Pickle-based serialization can execute arbitrary code (standard Python limitation)

## Future API Stability

The following are considered stable and unlikely to change:

- `DataFrameMapper` class signature
- `fit()`, `transform()`, `fit_transform()` methods
- `NumericalTransformer` (though deprecated)
- `TransformerPipeline` class

The following may change in future versions:

- `_build_feature()` and other private functions (prefixed with `_`)
- `_handle_feature()` implementation
- Internal data structures

## Related Work

This library is inspired by:

- scikit-learn's `ColumnTransformer` (newer version)
- pandas' own transformation capabilities
- Other feature engineering libraries

## Contributing

See CONTRIBUTING.md for guidelines on:

- Code style
- Testing requirements
- Documentation standards
- Pull request process
