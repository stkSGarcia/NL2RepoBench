"""
Comprehensive test suite for sklearn-pandas.
"""
import tempfile
import warnings
import numpy as np
import pandas as pd
import pytest
import joblib
from scipy import sparse

from sklearn.preprocessing import StandardScaler, LabelBinarizer, OneHotEncoder
from sklearn.decomposition import PCA
from sklearn.feature_selection import SelectKBest, chi2
from sklearn.pipeline import Pipeline
from sklearn.svm import SVC
from sklearn.model_selection import cross_val_score
from sklearn.datasets import load_iris
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.compose import make_column_selector

from sklearn_pandas import (
    DataFrameMapper,
    NumericalTransformer,
    TransformerPipeline,
    gen_features,
    _handle_feature,
    _build_transformer,
)


# ============================================================================
# Fixtures
# ============================================================================

@pytest.fixture
def simple_dataframe():
    """Create a simple test DataFrame."""
    return pd.DataFrame({'a': [1, 2, 3]})


@pytest.fixture
def complex_dataframe():
    """Create a complex test DataFrame."""
    return pd.DataFrame({
        'target': ['a', 'a', 'b', 'b', 'c', 'c'],
        'feat1': [1, 2, 3, 4, 5, 6],
        'feat2': [1.0, 2.0, 3.0, 2.0, 3.0, 4.0]
    })


@pytest.fixture
def iris_dataframe():
    """Create an iris dataset DataFrame."""
    iris = load_iris()
    return pd.DataFrame({
        'petal length (cm)': iris.data[:, 0],
        'petal width (cm)': iris.data[:, 1],
        'sepal length (cm)': iris.data[:, 2],
        'sepal width (cm)': iris.data[:, 3],
        'species': [iris.target_names[e] for e in iris.target]
    })


@pytest.fixture
def simple_dataset():
    """Create a simple numerical dataset."""
    return pd.DataFrame({
        'feat1': [1, 2, 1, 3, 1],
        'feat2': [1, 2, 2, 2, 3],
        'feat3': [1, 2, 3, 4, 5],
    })


# ============================================================================
# Helper Classes for Testing
# ============================================================================

class MockClass:
    """Mock transformer class for testing."""
    def __init__(self, value=1, name='class'):
        self.value = value
        self.name = name

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return X * self.value


class ToSparseTransformer:
    """Transformer that converts data to sparse format."""
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return sparse.csr_matrix(X)


class FailingTransformer:
    """Transformer that always fails."""
    def fit(self, X, y=None):
        return self

    def transform(self, X):
        raise ValueError("Transform failed")


class FailingFitter:
    """Fitter that always fails."""
    def fit(self, X, y=None):
        raise ValueError("Fit failed")

    def transform(self, X):
        return X


class NoTransformT:
    """Transformer without transform method."""
    def fit(self, X, y=None):
        return self


class NoFitT:
    """Transformer without fit method."""
    def transform(self, X):
        return X


class MockImageTransformer:
    """Mock transformer for image data."""
    def __init__(self, scale=1):
        self.scale = scale

    def fit(self, X, y=None):
        return self

    def transform(self, X):
        return np.array([img * self.scale for img in X])


# ============================================================================
# Basic Transformation Tests
# ============================================================================

class TestSimpleDataFrameTransformation:
    """Test simple DataFrame transformation."""

    def test_simple_df(self, simple_dataframe):
        """Test transformation of simple DataFrame with no transformer."""
        df = simple_dataframe
        mapper = DataFrameMapper([('a', None)], df_out=True)
        transformed = mapper.fit_transform(df)
        assert type(transformed) == pd.DataFrame
        assert len(transformed["a"]) == len(simple_dataframe["a"])

    def test_simple_df_fit_transform_consistency(self, simple_dataframe):
        """Test consistency between fit+transform and fit_transform."""
        df = simple_dataframe
        mapper1 = DataFrameMapper([('a', None)], df_out=True)
        result1 = mapper1.fit_transform(df)

        mapper2 = DataFrameMapper([('a', None)], df_out=True)
        mapper2.fit(df)
        result2 = mapper2.transform(df)

        pd.testing.assert_frame_equal(result1, result2)


class TestComplexDataFrameTransformation:
    """Test complex DataFrame transformation."""

    def test_complex_df(self, complex_dataframe):
        """Test transformation of complex DataFrame."""
        df = complex_dataframe
        mapper = DataFrameMapper([
            ('target', None),
            ('feat1', None),
            ('feat2', None)
        ], df_out=True)
        transformed = mapper.fit_transform(df)
        assert len(transformed) == len(complex_dataframe)
        for c in df.columns:
            assert len(transformed[c]) == len(df[c])


# ============================================================================
# Feature Name Tests
# ============================================================================

class TestFeatureNames:
    """Test feature name generation."""

    def test_transformed_names_simple(self, simple_dataframe):
        """Test simple feature name generation."""
        df = simple_dataframe
        mapper = DataFrameMapper([('a', None)])
        mapper.fit_transform(df)
        assert mapper.transformed_names_ == ['a']

    def test_transformed_names_binarizer(self, complex_dataframe):
        """Test feature names from LabelBinarizer."""
        df = complex_dataframe
        mapper = DataFrameMapper([('target', LabelBinarizer())], default=False)
        mapper.fit_transform(df)
        assert mapper.transformed_names_ == ['target_a', 'target_b', 'target_c']

    def test_transformed_names_binarizer_unicode(self):
        """Test unicode feature name generation."""
        df = pd.DataFrame({'target': [u'ñ', u'á', u'é']})
        mapper = DataFrameMapper([('target', LabelBinarizer())], default=False)
        mapper.fit_transform(df)
        expected_names = {u'target_ñ', u'target_á', u'target_é'}
        assert set(mapper.transformed_names_) == expected_names


# ============================================================================
# Label Encoding Tests
# ============================================================================

class TestLabelEncoding:
    """Test label encoding transformations."""

    def test_binarizer_df(self):
        """Test LabelBinarizer with DataFrame output."""
        df = pd.DataFrame({'target': ['a', 'a', 'b', 'b', 'c', 'a']})
        mapper = DataFrameMapper([('target', LabelBinarizer())], df_out=True)
        transformed = mapper.fit_transform(df)
        cols = transformed.columns
        assert len(cols) == 3
        assert cols[0] == 'target_a'
        assert cols[1] == 'target_b'
        assert cols[2] == 'target_c'

    def test_binarizer_int_df(self):
        """Test LabelBinarizer with integer labels."""
        df = pd.DataFrame({'target': [5, 5, 6, 6, 7, 5]})
        mapper = DataFrameMapper([('target', LabelBinarizer())], df_out=True)
        transformed = mapper.fit_transform(df)
        cols = transformed.columns
        assert len(cols) == 3
        assert cols[0] == 'target_5'
        assert cols[1] == 'target_6'
        assert cols[2] == 'target_7'

    def test_onehot_df(self):
        """Test OneHotEncoder with DataFrame output."""
        df = pd.DataFrame({'target': [0, 0, 1, 1, 2, 3, 0]})
        mapper = DataFrameMapper([(['target'], OneHotEncoder())], df_out=True)
        transformed = mapper.fit_transform(df)
        cols = transformed.columns
        assert len(cols) == 4


# ============================================================================
# Multi-Column Transformation Tests
# ============================================================================

class TestMultiColumnTransformation:
    """Test multi-column transformations."""

    def test_pca(self, complex_dataframe):
        """Test PCA dimensionality reduction."""
        df = complex_dataframe
        mapper = DataFrameMapper([
            (['feat1', 'feat2'], PCA(2))
        ], df_out=True, default=False)
        transformed = mapper.fit_transform(df)
        cols = transformed.columns
        assert len(cols) == 2
        # PCA returns generic names
        assert cols[0].startswith('feat1_feat2')
        assert cols[1].startswith('feat1_feat2')

    def test_fit_with_required_y_arg(self, complex_dataframe):
        """Test transformation with required y argument (SelectKBest)."""
        df = complex_dataframe
        mapper = DataFrameMapper([(['feat1', 'feat2'], SelectKBest(chi2, k=1))])

        # fit_transform
        ft_arr = mapper.fit_transform(df[['feat1', 'feat2']], df['feat1'])
        assert ft_arr.shape[1] == 1

        # transform
        t_arr = mapper.transform(df[['feat1', 'feat2']])
        assert t_arr.shape[1] == 1


# ============================================================================
# Feature Generation Tests
# ============================================================================

class TestFeatureGeneration:
    """Test feature generation functionality."""

    def test_generate_features_with_default_parameters(self):
        """Test feature generation with default parameters."""
        columns = ['colA', 'colB', 'colC']
        feature_defs = gen_features(columns=columns, classes=[MockClass])
        assert len(feature_defs) == len(columns)

        for feature in feature_defs:
            assert feature[2] == {}

        feature_dict = dict([_[0:2] for _ in feature_defs])
        assert columns == sorted(feature_dict.keys())

    def test_generate_features_with_several_classes(self):
        """Test feature generation with multiple class definitions."""
        feature_defs = gen_features(
            columns=['colA', 'colB', 'colC'],
            classes=[
                {'class': MockClass},
                {'class': MockClass, 'name': 'mockA'},
                {'class': MockClass, 'name': 'mockB', 'value': None}
            ]
        )

        for col, transformers, params in feature_defs:
            assert len(transformers) == 3
            assert transformers[0].name == 'class'
            assert transformers[1].name == 'mockA'
            assert transformers[2].name == 'mockB'

    def test_generate_features_with_prefix_suffix(self):
        """Test feature generation with prefix and suffix."""
        feature_defs = gen_features(
            columns=['colA', 'colB'],
            classes=[MockClass],
            prefix='pre_',
            suffix='_suf'
        )

        for col, transformers, params in feature_defs:
            assert 'prefix' in params
            assert params['prefix'] == 'pre_'
            assert 'suffix' in params
            assert params['suffix'] == '_suf'


# ============================================================================
# Numerical Transformation Tests
# ============================================================================

class TestNumericalTransformer:
    """Test numerical transformation functionality."""

    def test_numerical_transformer_deprecation(self):
        """Test that NumericalTransformer shows deprecation warning."""
        with warnings.catch_warnings(record=True) as w:
            warnings.simplefilter("always")
            transformer = NumericalTransformer('log')
            assert len(w) == 1
            assert issubclass(w[-1].category, DeprecationWarning)

    def test_common_numerical_transformer(self, simple_dataset):
        """Test numerical transformation with log function."""
        transformer = DataFrameMapper([
            ('feat1', NumericalTransformer('log'))
        ], df_out=True, default=False)
        df = simple_dataset
        outDF = transformer.fit_transform(df)
        assert list(outDF.columns) == ['feat1']
        assert np.allclose(df['feat1'].apply(np.log).values, outDF.feat1.values)

    def test_numerical_transformer_log1p(self, simple_dataset):
        """Test numerical transformation with log1p function."""
        transformer = DataFrameMapper([
            ('feat1', NumericalTransformer('log1p'))
        ], df_out=True, default=False)
        df = simple_dataset
        outDF = transformer.fit_transform(df)
        assert list(outDF.columns) == ['feat1']
        assert np.allclose(df['feat1'].apply(np.log1p).values, outDF.feat1.values)

    def test_numerical_transformer_serialization(self, simple_dataset):
        """Test serialization of numerical transformers."""
        transformer = DataFrameMapper([
            ('feat1', NumericalTransformer('log'))
        ])

        df = simple_dataset
        transformer.fit(df)

        with tempfile.NamedTemporaryFile(delete=True) as f:
            joblib.dump(transformer, f.name)
            transformer2 = joblib.load(f.name)
            result1 = transformer.transform(df)
            result2 = transformer2.transform(df)
            assert np.allclose(result1, result2)

    def test_numerical_transformer_invalid_func(self):
        """Test that invalid function raises assertion error."""
        with pytest.raises(AssertionError):
            NumericalTransformer('invalid')


# ============================================================================
# Pipeline Integration Tests
# ============================================================================

class TestPipelineIntegration:
    """Test integration with sklearn pipelines."""

    def test_with_iris_dataframe(self, iris_dataframe):
        """Test with iris dataset and SVC classifier."""
        pipeline = Pipeline([
            ("preprocess", DataFrameMapper([
                ("petal length (cm)", None),
                ("petal width (cm)", None),
                ("sepal length (cm)", None),
                ("sepal width (cm)", None),
            ])),
            ("classify", SVC(kernel='linear'))
        ])
        data = iris_dataframe.drop("species", axis=1)
        labels = iris_dataframe["species"]
        scores = cross_val_score(pipeline, data, labels)
        assert scores.mean() > 0.96

    def test_transformer_pipeline(self):
        """Test TransformerPipeline class."""
        steps = [
            ('step1', StandardScaler()),
            ('step2', StandardScaler())
        ]
        pipeline = TransformerPipeline(steps)

        X = np.array([[1, 2], [3, 4], [5, 6]])
        X_transformed = pipeline.fit_transform(X)

        assert X_transformed.shape == X.shape

    def test_transformer_pipeline_invalid_steps(self):
        """Test TransformerPipeline with invalid steps."""
        with pytest.raises(TypeError):
            TransformerPipeline([('step', NoTransformT())])

        with pytest.raises(TypeError):
            TransformerPipeline([('step', NoFitT())])


# ============================================================================
# Sparse Matrix Tests
# ============================================================================

class TestSparseMatrices:
    """Test sparse matrix support."""

    def test_sparse_features(self, simple_dataframe):
        """Test sparse feature processing."""
        df = simple_dataframe
        mapper = DataFrameMapper([
            ("a", ToSparseTransformer())
        ], sparse=True)
        result = mapper.fit_transform(df)
        assert sparse.issparse(result)
        assert result.shape == (3, 1)

    def test_sparse_off(self, simple_dataframe):
        """Test disabling sparse output."""
        df = simple_dataframe
        mapper = DataFrameMapper([
            ("a", ToSparseTransformer())
        ], sparse=False)
        result = mapper.fit_transform(df)
        assert not sparse.issparse(result)
        assert isinstance(result, np.ndarray)


# ============================================================================
# Exception Handling Tests
# ============================================================================

class TestExceptionHandling:
    """Test exception handling with column context."""

    def test_exception_column_context_transform(self, simple_dataframe):
        """Test exception message includes column context during transform."""
        df = simple_dataframe
        mapper = DataFrameMapper([('a', FailingTransformer())])
        mapper.fit(df)

        with pytest.raises(Exception, match='a: Transform failed'):
            mapper.transform(df)

    def test_exception_column_context_fit(self, simple_dataframe):
        """Test exception message includes column context during fit."""
        df = simple_dataframe
        mapper = DataFrameMapper([('a', FailingFitter())])

        with pytest.raises(Exception, match='a: Fit failed'):
            mapper.fit(df)


# ============================================================================
# Column Selection Tests
# ============================================================================

class TestColumnSelection:
    """Test column selection and processing."""

    def test_make_column_selector(self, iris_dataframe):
        """Test make_column_selector for dynamic column selection."""
        mapper = DataFrameMapper([
            (make_column_selector(dtype_include=np.number), None, {'alias': 'x'}),
        ], df_out=True, default=False)

        transformed = mapper.fit_transform(iris_dataframe)
        # Should have 4 numeric columns from iris dataset
        assert transformed.shape[1] == 4
        # All columns should start with 'x_'
        for col in transformed.columns:
            assert col.startswith('x_')

    def test_heterogeneous_output_types_input_df(self):
        """Test mixed types with input_df=True."""
        df = pd.DataFrame({
            'feat1': [1, 2, 3, 4, 5, 6],
            'feat2': [1.0, 2.0, 3.0, 2.0, 3.0, 4.0]
        })
        mapper = DataFrameMapper([
            (['feat2'], StandardScaler())
        ], input_df=True, df_out=True, default=None)

        transformed = mapper.fit_transform(df)
        # When combining arrays with different types, numpy promotes to float64
        # Check columns and types
        assert 'feat1' in transformed.columns or transformed.columns[0] == 'feat1'
        assert transformed.shape == (6, 2)
        # All columns become float64 due to type promotion
        for col in transformed.columns:
            assert transformed[col].dtype in [np.dtype('float64'), np.dtype('int64')]


# ============================================================================
# Helper Function Tests
# ============================================================================

class TestHelperFunctions:
    """Test helper functions."""

    def test_handle_feature_1d_array(self):
        """Test _handle_feature converts 1D to 2D."""
        arr = np.array([1, 2, 3])
        result = _handle_feature(arr)
        assert len(result.shape) == 2
        assert result.shape == (3, 1)

    def test_handle_feature_2d_array(self):
        """Test _handle_feature preserves 2D arrays."""
        arr = np.array([[1, 2], [3, 4]])
        result = _handle_feature(arr)
        assert result.shape == arr.shape

    def test_build_transformer_none(self):
        """Test _build_transformer with None."""
        result = _build_transformer(None)
        assert result is None

    def test_build_transformer_single(self):
        """Test _build_transformer with single transformer."""
        transformer = StandardScaler()
        result = _build_transformer(transformer)
        assert result is transformer

    def test_build_transformer_list_single(self):
        """Test _build_transformer with list of single transformer."""
        transformer = StandardScaler()
        result = _build_transformer([transformer])
        assert result is transformer

    def test_build_transformer_list_multiple(self):
        """Test _build_transformer with multiple transformers."""
        transformers = [StandardScaler(), StandardScaler()]
        result = _build_transformer(transformers)
        assert isinstance(result, TransformerPipeline)


# ============================================================================
# DataFrame Output Tests
# ============================================================================

class TestDataFrameOutput:
    """Test DataFrame output functionality."""

    def test_df_out_with_transformers(self):
        """Test DataFrame output with transformers."""
        df = pd.DataFrame({
            'a': [1, 2, 3],
            'b': [4.0, 5.0, 6.0]
        })
        mapper = DataFrameMapper([
            ('a', StandardScaler()),
            ('b', StandardScaler())
        ], df_out=True)

        result = mapper.fit_transform(df)
        assert isinstance(result, pd.DataFrame)
        # StandardScaler may or may not generate feature names, depending on sklearn version
        # Just verify we get a DataFrame with 2 columns
        assert result.shape == (3, 2)

    def test_df_out_incompatible_with_sparse(self):
        """Test that df_out and sparse are incompatible."""
        with pytest.raises(ValueError, match="Can not use df_out"):
            DataFrameMapper([('a', None)], df_out=True, sparse=True)

    def test_df_out_incompatible_with_default(self):
        """Test that df_out and default (when not False/None) are incompatible."""
        # default=None is allowed with df_out, only transformers are not allowed
        mapper = DataFrameMapper([('a', None)], df_out=True, default=None)

        # But a transformer as default is not allowed
        with pytest.raises(ValueError, match="Can not use df_out"):
            DataFrameMapper([('a', None)], df_out=True, default=StandardScaler())


# ============================================================================
# Default Transformer Tests
# ============================================================================

class TestDefaultTransformer:
    """Test default transformer functionality."""

    def test_default_false_drops_unselected(self):
        """Test that default=False drops unselected columns."""
        df = pd.DataFrame({
            'selected': [1, 2, 3],
            'unselected': [4, 5, 6]
        })
        mapper = DataFrameMapper([
            ('selected', None)
        ], default=False, df_out=True)

        result = mapper.fit_transform(df)
        assert list(result.columns) == ['selected']

    def test_default_none_passes_through(self):
        """Test that default=None passes through unselected columns."""
        df = pd.DataFrame({
            'selected': [1, 2, 3],
            'unselected': [4, 5, 6]
        })
        mapper = DataFrameMapper([
            ('selected', None)
        ], default=None, df_out=True)

        result = mapper.fit_transform(df)
        assert set(result.columns) == {'selected', 'unselected'}

    def test_default_transformer(self):
        """Test default transformer applied to unselected columns."""
        df = pd.DataFrame({
            'selected': [1, 2, 3],
            'unselected': [4.0, 5.0, 6.0]
        })
        mapper = DataFrameMapper([
            ('selected', None)
        ], default=StandardScaler())

        result = mapper.fit_transform(df)
        assert result.shape == (3, 2)


# ============================================================================
# Run Tests
# ============================================================================

if __name__ == '__main__':
    pytest.main([__file__, '-v', '--tb=short'])
