"""
sklearn-pandas: A bridge connecting Scikit-Learn and pandas.
"""

__version__ = '2.2.0'

from .dataframe_mapper import (
    DataFrameMapper,
    _handle_feature,
    _build_transformer,
    _build_feature,
)
from .transformers import NumericalTransformer
from .pipeline import TransformerPipeline, _call_fit
from .features_generator import gen_features

__all__ = [
    'DataFrameMapper',
    '_handle_feature',
    '_build_transformer',
    '_build_feature',
    'NumericalTransformer',
    'TransformerPipeline',
    '_call_fit',
    'gen_features',
]
