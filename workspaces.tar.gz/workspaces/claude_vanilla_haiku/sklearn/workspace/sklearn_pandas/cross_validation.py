"""
Cross-validation utilities for sklearn-pandas.
"""
