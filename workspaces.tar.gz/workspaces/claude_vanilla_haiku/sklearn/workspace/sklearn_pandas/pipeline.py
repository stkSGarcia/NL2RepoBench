from sklearn.pipeline import Pipeline
from sklearn.utils.metaestimators import _BaseComposition


def tosequence(X):
    """Convert to sequence if necessary."""
    if not isinstance(X, (list, tuple)):
        return [X]
    return list(X)


def _call_fit(transformer, X_transformed, y, **fit_params):
    """
    Helper function to call fit on a transformer.

    Parameters
    ----------
    transformer : object
        The transformer to fit.
    X_transformed : array-like
        The transformed data.
    y : array-like, optional
        The target data.
    **fit_params : dict
        Additional fit parameters.

    Returns
    -------
    object
        The fitted transformer.
    """
    if hasattr(transformer, 'fit_transform'):
        return transformer.fit_transform(X_transformed, y, **fit_params)
    else:
        return transformer.fit(X_transformed, y, **fit_params).transform(X_transformed)


class TransformerPipeline(Pipeline):
    """
    Pipeline that expects all steps to be transformers taking a single X
    argument, an optional y argument, and having fit and transform methods.

    Code is adapted from sklearn's Pipeline.
    """

    def __init__(self, steps):
        """
        Initialize the TransformerPipeline.

        Parameters
        ----------
        steps : list
            List of (name, transformer) tuples that are chained in order.
        """
        names, estimators = zip(*steps)
        if len(dict(steps)) != len(steps):
            raise ValueError(
                "Provided step names are not unique: %s" % (names,))

        # shallow copy of steps
        self.steps = tosequence(steps)
        estimator = estimators[-1]

        for e in estimators:
            if (not (hasattr(e, "fit") or hasattr(e, "fit_transform")) or not
                    hasattr(e, "transform")):
                raise TypeError("All steps of the chain should "
                                "be transforms and implement fit and transform"
                                " '%s' (type %s) doesn't)" % (e, type(e)))

        if not hasattr(estimator, "fit"):
            raise TypeError("Last step of chain should implement fit "
                            "'%s' (type %s) doesn't)"
                            % (estimator, type(estimator)))

    def _pre_transform(self, X, y=None, **fit_params):
        """
        Pre-transform the data through all but the last estimator.

        Parameters
        ----------
        X : array-like
            The input data.
        y : array-like, optional
            The target data.
        **fit_params : dict
            Parameters for fit.

        Returns
        -------
        X_transformed : array-like
            The transformed data.
        y : array-like, optional
            The target data (unchanged).
        """
        fit_transform_one_cached = lambda transformer, X, y, weight, message_clsname='': \
            self._fit_transform_one(transformer, X, y, weight, message_clsname)

        Xt = X
        for step_idx, name, transformer in self._iter(with_final=False,
                                                      message_clsname='Pipeline'):
            if hasattr(transformer, 'fit_transform'):
                Xt = transformer.fit_transform(Xt, y, **fit_params)
            else:
                Xt = transformer.fit(Xt, y, **fit_params).transform(Xt)

        return Xt, y

    def fit(self, X, y=None, **fit_params):
        """
        Fit the pipeline.

        Parameters
        ----------
        X : array-like
            The input data.
        y : array-like, optional
            The target data.
        **fit_params : dict
            Parameters for fit.

        Returns
        -------
        self
        """
        Xt, fit_params = self._fit(X, y, **fit_params)
        return self

    def fit_transform(self, X, y=None, **fit_params):
        """
        Fit the pipeline and transform the data.

        Parameters
        ----------
        X : array-like
            The input data.
        y : array-like, optional
            The target data.
        **fit_params : dict
            Parameters for fit.

        Returns
        -------
        X_transformed : array-like
            The transformed data.
        """
        Xt, fit_params = self._fit(X, y, **fit_params)

        last_step = self._final_estimator
        with _print_elapsed_time('Pipeline', self._log_message(len(self.steps) - 1)):
            if hasattr(last_step, 'fit_transform'):
                return last_step.fit_transform(Xt, y, **fit_params)
            else:
                return last_step.fit(Xt, y, **fit_params).transform(Xt)

    def _fit(self, X, y=None, **fit_params):
        """
        Fit the pipeline with all but the final estimator.

        Parameters
        ----------
        X : array-like
            The input data.
        y : array-like, optional
            The target data.
        **fit_params : dict
            Parameters for fit.

        Returns
        -------
        X_transformed : array-like
            The transformed data.
        fit_params : dict
            The fit parameters.
        """
        self.steps = list(self.steps)
        self._validate_steps()

        Xt = X
        for step_idx, name, transformer in self._iter(with_final=False,
                                                      message_clsname='Pipeline'):
            if hasattr(transformer, 'fit_transform'):
                Xt = transformer.fit_transform(Xt, y, **fit_params)
            else:
                Xt = transformer.fit(Xt, y, **fit_params).transform(Xt)

        return Xt, fit_params

    def _log_message(self, step):
        """Log message for a pipeline step."""
        if self._final_estimator is None or self._final_estimator == 'passthrough':
            return None
        return self._final_estimator.__class__.__name__

    def _iter(self, with_final=False, filter_passthrough=False, message_clsname=None):
        """
        Generate (step_number, name, transformer) tuples from self.steps.
        """
        stop = len(self.steps)
        if not with_final:
            stop -= 1

        for idx, (name, transformer) in enumerate(self.steps[:stop]):
            if filter_passthrough and transformer == 'passthrough':
                continue
            yield idx, name, transformer

        if with_final:
            yield len(self.steps) - 1, self.steps[-1][0], self._final_estimator

    @property
    def _final_estimator(self):
        estimator = self.steps[-1][1]
        return 'passthrough' if estimator is None else estimator

    def _validate_steps(self):
        """Validate the pipeline steps."""
        pass


def _print_elapsed_time(source, message=None):
    """Context manager to log elapsed time."""
    class DummyContext:
        def __enter__(self):
            return self
        def __exit__(self, *args):
            pass

    return DummyContext()
