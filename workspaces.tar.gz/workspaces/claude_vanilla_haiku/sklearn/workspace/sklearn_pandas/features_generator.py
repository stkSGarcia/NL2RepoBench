"""
Feature generation utilities for sklearn-pandas.
"""


def gen_features(columns, classes, prefix='', suffix=''):
    """
    Generate feature definitions in batches.

    This function simplifies the feature definition process by automatically
    generating feature definitions for a list of columns and transformer classes.

    Parameters
    ----------
    columns : list of str
        List of column names to generate features for.
    classes : list
        List of transformer classes or class dictionaries. Each class can be:
        - A class object (e.g., MockClass)
        - A dictionary with 'class' key and optional parameters

    prefix : str, optional
        Prefix to add to generated feature names. Default is ''.
    suffix : str, optional
        Suffix to add to generated feature names. Default is ''.

    Returns
    -------
    list of tuple
        List of feature definitions where each tuple contains:
        (column_name, [transformer_instances], options_dict)

    Examples
    --------
    >>> feature_defs = gen_features(['col1', 'col2'], classes=[MyClass])
    >>> # Returns [('col1', [MyClass()], {}), ('col2', [MyClass()], {})]

    >>> feature_defs = gen_features(
    ...     columns=['col1', 'col2'],
    ...     classes=[{'class': MyClass, 'param': value}]
    ... )
    """
    feature_defs = []

    for column in columns:
        transformers = []
        options = {}

        # Add prefix and suffix if provided
        if prefix or suffix:
            options['prefix'] = prefix
            options['suffix'] = suffix

        for cls_def in classes:
            if isinstance(cls_def, dict):
                # Extract class and parameters
                cls = cls_def.get('class')
                params = {k: v for k, v in cls_def.items() if k != 'class'}
                transformer = cls(**params) if params else cls()
            else:
                # Direct class reference
                transformer = cls_def()

            transformers.append(transformer)

        feature_defs.append((column, transformers, options))

    return feature_defs
