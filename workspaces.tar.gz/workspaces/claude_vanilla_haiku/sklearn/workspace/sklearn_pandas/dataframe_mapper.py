import warnings
import numpy as np
import pandas as pd
from scipy import sparse
from sklearn.base import BaseEstimator, TransformerMixin
from sklearn.pipeline import Pipeline

from .pipeline import TransformerPipeline


def _handle_feature(fea):
    """
    Convert 1-dimensional arrays to 2-dimensional column vectors.

    Parameters
    ----------
    fea : numpy.ndarray
        The feature array to be handled.

    Returns
    -------
    numpy.ndarray
        The handled feature (converted to 2D if necessary).
    """
    if len(fea.shape) == 1:
        fea = np.array([fea]).T
    return fea


def _build_transformer(transformers):
    """
    Build a transformer or list of transformers.

    Parameters
    ----------
    transformers : object or list
        A single transformer or list of transformers.

    Returns
    -------
    object
        A transformer pipeline if multiple transformers, else the single transformer.
    """
    if isinstance(transformers, list):
        if len(transformers) == 0:
            return None
        elif len(transformers) == 1:
            return transformers[0]
        else:
            return TransformerPipeline([
                (f'transformer_{i}', t) for i, t in enumerate(transformers)
            ])
    return transformers


def _build_feature(columns, transformers, options=None, X=None):
    """
    Build a feature definition.

    Parameters
    ----------
    columns : str, list, or callable
        The columns to select from the DataFrame.
    transformers : object or list
        The transformer(s) to apply.
    options : dict, optional
        Additional options for the transformation.
    X : pandas.DataFrame, optional
        The data to use for building (if columns is callable).

    Returns
    -------
    tuple
        A tuple of (columns, transformer, options).
    """
    if options is None:
        options = {}

    transformer = _build_transformer(transformers)

    if X is None:
        return (columns, transformer, options)

    # If columns is callable and X is provided, evaluate it
    cols = columns(X) if callable(columns) else columns
    return (cols, transformer, options)


def _get_feature_names(estimator):
    """
    Get feature names from an estimator.

    Parameters
    ----------
    estimator : object
        The estimator to get feature names from.

    Returns
    -------
    list or None
        Feature names if available, None otherwise.
    """
    if estimator is None:
        return None

    # Try get_feature_names_out first (sklearn 1.0+)
    if hasattr(estimator, 'get_feature_names_out'):
        try:
            names = estimator.get_feature_names_out()
            if names is not None:
                return list(names) if not isinstance(names, list) else names
        except (TypeError, ValueError, AttributeError):
            pass

    # Try get_feature_names (older sklearn)
    if hasattr(estimator, 'get_feature_names'):
        try:
            names = estimator.get_feature_names()
            if names is not None:
                return list(names) if not isinstance(names, list) else names
        except (TypeError, ValueError, AttributeError):
            pass

    # Try classes_ for classifiers
    if hasattr(estimator, 'classes_'):
        try:
            return list(estimator.classes_)
        except (TypeError, ValueError):
            pass

    return None


class DataFrameMapper(BaseEstimator, TransformerMixin):
    """
    Map Pandas DataFrame column subsets to their own sklearn transformation.
    """

    def __init__(self, features, default=False, sparse=False, df_out=False,
                 input_df=False, drop_cols=None):
        """
        Initialize the DataFrameMapper.

        Parameters
        ----------
        features : list of tuple
            A list of tuples with feature definitions. Each tuple contains:
            - columns: str or list of str (column selector)
            - transformer: object or list (sklearn transformer(s))
            - options: dict, optional (transformation options)

        default : bool or object, optional
            Default transformer for unmapped columns.
            - False: discard unmapped columns (default)
            - None: pass unmapped columns through unchanged
            - transformer: apply to unmapped columns

        sparse : bool, optional
            If True, return sparse matrix if any feature is sparse. Default is False.

        df_out : bool, optional
            If True, return a pandas DataFrame. Default is False.

        input_df : bool, optional
            If True, pass selected columns as DataFrame/Series to transformer.
            Default is False.

        drop_cols : list, optional
            List of columns to drop. Default is None.
        """
        self.features = features
        self.default = default
        self.built_default = None
        self.sparse = sparse
        self.df_out = df_out
        self.input_df = input_df
        self.drop_cols = [] if drop_cols is None else drop_cols
        self.transformed_names_ = []
        self.built_features = None

        if (df_out and (sparse or (default is not False and default is not None))):
            raise ValueError("Can not use df_out with sparse or default")

    def _build(self, X=None):
        """
        Build attributes built_features and built_default.

        Parameters
        ----------
        X : pandas.DataFrame, optional
            The input data to be transformed.
        """
        if X is not None:
            self.built_features = [
                _build_feature(*feat, X=X) if len(feat) < 4 else feat
                for feat in self.features
            ]
            self.built_default = self.default
        else:
            self.built_features = self.features
            self.built_default = self.default

    @property
    def _selected_columns(self):
        """
        Return a set of selected columns in the feature list.

        Returns
        -------
        set
            Set of selected column names.
        """
        cols = set()
        for feat in self.built_features or self.features:
            col = feat[0]
            if isinstance(col, str):
                cols.add(col)
            elif isinstance(col, list):
                cols.update(col)
        return cols

    def _unselected_columns(self, X):
        """
        Return list of columns in X not explicitly selected in features.

        Parameters
        ----------
        X : pandas.DataFrame
            The input DataFrame.

        Returns
        -------
        list
            List of unselected column names in order.
        """
        selected = self._selected_columns
        unselected = [col for col in X.columns if col not in selected]
        return unselected

    def _get_col_subset(self, X, cols, input_df=False):
        """
        Get a subset of columns from the given DataFrame.

        Parameters
        ----------
        X : pandas.DataFrame
            The DataFrame to select columns from.
        cols : str, list, or callable
            The columns to select.
        input_df : bool, optional
            If True, return as DataFrame/Series. If False, return as ndarray.

        Returns
        -------
        ndarray or DataFrame/Series
            The selected columns.
        """
        if callable(cols):
            cols = cols(X)

        if isinstance(cols, str):
            result = X[[cols]]
        elif isinstance(cols, list):
            result = X[cols]
        else:
            result = X[cols]

        if input_df:
            if isinstance(cols, str):
                return result[cols]
            return result
        else:
            return result.values

    def fit(self, X, y=None):
        """
        Fit the transformers.

        Parameters
        ----------
        X : pandas.DataFrame
            The input data to fit.
        y : array-like, optional
            The target data.

        Returns
        -------
        self
        """
        self._build(X)

        for col, transformer, options in self.built_features:
            if transformer is not None:
                subset = self._get_col_subset(X, col, self.input_df)
                try:
                    if hasattr(transformer, 'fit'):
                        # Try to fit with y, fall back to without y
                        try:
                            transformer.fit(subset, y)
                        except TypeError:
                            transformer.fit(subset)
                except Exception as e:
                    col_name = col if isinstance(col, str) else ','.join(col) if isinstance(col, list) else str(col)
                    raise Exception(f"{col_name}: {str(e)}")

        if self.built_default not in (None, False):
            unselected = self._unselected_columns(X)
            if unselected:
                try:
                    if hasattr(self.built_default, 'fit'):
                        try:
                            self.built_default.fit(X[unselected], y)
                        except TypeError:
                            self.built_default.fit(X[unselected])
                except Exception as e:
                    raise Exception(f"default: {str(e)}")

        return self

    def transform(self, X):
        """
        Transform the data.

        Parameters
        ----------
        X : pandas.DataFrame
            The input data to transform.

        Returns
        -------
        ndarray or DataFrame
            The transformed data.
        """
        return self._transform(X, do_fit=False)

    def fit_transform(self, X, y=None):
        """
        Fit and transform the data.

        Parameters
        ----------
        X : pandas.DataFrame
            The input data.
        y : array-like, optional
            The target data.

        Returns
        -------
        ndarray or DataFrame
            The transformed data.
        """
        return self._transform(X, y, do_fit=True)

    def get_names(self, columns, transformer, x, alias=None, prefix='', suffix=''):
        """
        Return names for the transformed columns.

        Parameters
        ----------
        columns : str or list
            The original column name(s).
        transformer : object
            The transformer used.
        x : ndarray
            The transformed data.
        alias : str, optional
            Alternative name for the columns.
        prefix : str, optional
            Prefix for column names.
        suffix : str, optional
            Suffix for column names.

        Returns
        -------
        list
            List of column names.
        """
        if alias:
            col_name = alias
        elif isinstance(columns, str):
            col_name = columns
        elif isinstance(columns, list):
            col_name = '_'.join(columns)
        else:
            col_name = str(columns)

        feature_names = _get_feature_names(transformer)

        # Check if feature_names is not None and not empty
        if feature_names is not None and len(feature_names) > 0:
            names = [f"{col_name}_{fn}" for fn in feature_names]
        elif len(x.shape) == 1 or x.shape[1] == 1:
            names = [col_name]
        else:
            names = [f"{col_name}_{i}" for i in range(x.shape[1])]

        if prefix or suffix:
            names = [f"{prefix}{n}{suffix}" for n in names]

        return names

    def _transform(self, X, y=None, do_fit=False):
        """
        Transform the data, optionally fitting first.

        Parameters
        ----------
        X : pandas.DataFrame
            The input data.
        y : array-like, optional
            The target data.
        do_fit : bool, optional
            Whether to fit before transforming.

        Returns
        -------
        ndarray or DataFrame
            The transformed data.
        """
        if do_fit:
            self.fit(X, y)

        if not hasattr(self, 'built_features'):
            self._build(X)

        transformed_arrays = []
        self.transformed_names_ = []

        for col, transformer, options in self.built_features:
            subset = self._get_col_subset(X, col, self.input_df)

            if transformer is None:
                try:
                    if self.input_df and isinstance(col, str):
                        x = X[[col]].values
                    elif self.input_df and isinstance(col, list):
                        x = X[col].values
                    else:
                        x = subset
                    x = _handle_feature(x)
                except Exception as e:
                    col_name = col if isinstance(col, str) else ','.join(col) if isinstance(col, list) else str(col)
                    raise Exception(f"{col_name}: {str(e)}")
            else:
                try:
                    x = transformer.transform(subset)
                    x = _handle_feature(x)
                except Exception as e:
                    col_name = col if isinstance(col, str) else ','.join(col) if isinstance(col, list) else str(col)
                    raise Exception(f"{col_name}: {str(e)}")

            # Get column names
            alias = options.get('alias')
            prefix = options.get('prefix', '')
            suffix = options.get('suffix', '')
            names = self.get_names(col, transformer, x, alias, prefix, suffix)
            self.transformed_names_.extend(names)

            transformed_arrays.append(x)

        # Handle default transformer for unselected columns
        unselected = self._unselected_columns(X)
        if unselected:
            if self.built_default is None:
                # Pass through unselected columns unchanged
                unselected_data = X[unselected].values
                transformed_arrays.append(unselected_data)
                self.transformed_names_.extend(unselected)
            elif self.built_default is not False:
                # Apply transformer to unselected columns
                unselected_data = X[unselected].values
                try:
                    transformed = self.built_default.transform(unselected_data)
                    transformed = _handle_feature(transformed)
                except Exception as e:
                    raise Exception(f"default: {str(e)}")
                transformed_arrays.append(transformed)
                for col_name in unselected:
                    self.transformed_names_.append(col_name)

        # Combine all transformed arrays
        if not transformed_arrays:
            if self.df_out:
                return pd.DataFrame()
            else:
                return np.array([])

        # Check if any array is sparse
        has_sparse = any(sparse.issparse(arr) for arr in transformed_arrays)

        if has_sparse and self.sparse:
            # Convert all to sparse and concatenate
            sparse_arrays = []
            for arr in transformed_arrays:
                if not sparse.issparse(arr):
                    sparse_arrays.append(sparse.csr_matrix(arr))
                else:
                    sparse_arrays.append(arr)
            result = sparse.hstack(sparse_arrays).tocsr()
        else:
            # Convert sparse to dense if necessary
            if has_sparse:
                transformed_arrays = [
                    arr.toarray() if sparse.issparse(arr) else arr
                    for arr in transformed_arrays
                ]
            result = np.hstack(transformed_arrays)

        if self.df_out:
            return pd.DataFrame(result, columns=self.transformed_names_)

        return result

    def __setstate__(self, state):
        """Restore state for pickling."""
        super().__setstate__(state)
        self.features = [_build_feature(*feat) for feat in state['features']]
        self.sparse = state.get('sparse', False)
        self.default = state.get('default', False)
        self.df_out = state.get('df_out', False)
        self.input_df = state.get('input_df', False)
        self.drop_cols = state.get('drop_cols', [])
        self.built_features = state.get('built_features', self.features)
        self.built_default = state.get('built_default', self.default)
        self.transformed_names_ = state.get('transformed_names_', [])

    def __getstate__(self):
        """Get state for pickling."""
        state = super().__getstate__()
        state['features'] = self.features
        state['sparse'] = self.sparse
        state['default'] = self.default
        state['df_out'] = self.df_out
        state['input_df'] = self.input_df
        state['drop_cols'] = self.drop_cols
        state['built_features'] = getattr(self, 'built_features', None)
        state['built_default'] = self.built_default
        state['transformed_names_'] = self.transformed_names_
        return state
