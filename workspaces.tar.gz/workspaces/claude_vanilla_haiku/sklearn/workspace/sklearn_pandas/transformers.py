import warnings
import numpy as np
from sklearn.base import TransformerMixin


class NumericalTransformer(TransformerMixin):
    """
    Provides commonly used numerical transformers.
    """
    SUPPORTED_FUNCTIONS = ['log', 'log1p']

    def __init__(self, func):
        """
        Initialize the NumericalTransformer.

        Parameters
        ----------
        func : str
            Function to apply to input columns. Supported functions are
            defined in SUPPORTED_FUNCTIONS variable. Throws assertion error
            if not supported.
        """
        warnings.warn("""
            NumericalTransformer will be deprecated in 3.0 version.
            Please use sklearn.base.TransformerMixin to write
            customer transformers
            """, DeprecationWarning)

        assert func in self.SUPPORTED_FUNCTIONS, \
            f"Only following func are supported: {self.SUPPORTED_FUNCTIONS}"
        super(NumericalTransformer, self).__init__()
        self._func = func

    def fit(self, X, y=None):
        """
        Fit the transformer (no-op for this transformer).

        Parameters
        ----------
        X : pandas.DataFrame or numpy.ndarray
            The input data to be transformed.
        y : pandas.Series or numpy.ndarray, optional
            The target data.

        Returns
        -------
        self
        """
        return self

    def transform(self, X, y=None):
        """
        Apply the transformation to the input data.

        Parameters
        ----------
        X : pandas.DataFrame or numpy.ndarray
            The input data to be transformed.
        y : pandas.Series or numpy.ndarray, optional
            The target data.

        Returns
        -------
        pandas.DataFrame or numpy.ndarray
            The transformed data.
        """
        if self._func == 'log':
            return np.log(X)
        elif self._func == 'log1p':
            return np.log1p(X)
        else:
            raise ValueError(f"Unknown function: {self._func}")
