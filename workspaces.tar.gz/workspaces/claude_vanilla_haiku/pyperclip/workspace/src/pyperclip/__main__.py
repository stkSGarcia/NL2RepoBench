"""Command-line interface for pyperclip."""

import sys
import argparse
import pyperclip


def main():
    """Main CLI entry point."""
    parser = argparse.ArgumentParser(
        description='Pyperclip: A cross-platform clipboard utility'
    )

    group = parser.add_mutually_exclusive_group(required=True)
    group.add_argument(
        '-c', '--copy',
        nargs='?',
        const='',
        metavar='TEXT',
        help='Copy text to clipboard. If no text is provided, read from stdin.'
    )
    group.add_argument(
        '-p', '--paste',
        action='store_true',
        help='Paste text from clipboard to stdout.'
    )

    args = parser.parse_args()

    if args.paste:
        # Paste mode
        text = pyperclip.paste()
        sys.stdout.write(text)
    elif args.copy is not None:
        # Copy mode
        if args.copy == '':
            # No text provided, read from stdin
            text = sys.stdin.read()
        else:
            # Text provided as argument
            text = args.copy
        pyperclip.copy(text)


if __name__ == '__main__':
    main()
