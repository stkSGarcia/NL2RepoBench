"""Linux and Unix clipboard implementations."""

import subprocess
import os
import sys
from .exceptions import PyperclipException


def init_xclip_clipboard():
    """Initialize xclip clipboard."""

    def copy_xclip(text, primary=False):
        selection = "primary" if primary else "clipboard"
        text_bytes = text.encode('utf-8')
        try:
            process = subprocess.Popen(
                ['xclip', '-selection', selection, '-i'],
                stdin=subprocess.PIPE,
                close_fds=True
            )
            process.communicate(text_bytes)
            if process.returncode != 0:
                raise PyperclipException("xclip copy failed")
        except FileNotFoundError:
            raise PyperclipException("xclip command not found")

    def paste_xclip(primary=False):
        selection = "primary" if primary else "clipboard"
        try:
            process = subprocess.Popen(
                ['xclip', '-selection', selection, '-o'],
                stdout=subprocess.PIPE,
                close_fds=True
            )
            stdout, _ = process.communicate()
            if process.returncode != 0:
                raise PyperclipException("xclip paste failed")
            return stdout.decode('utf-8')
        except FileNotFoundError:
            raise PyperclipException("xclip command not found")

    return copy_xclip, paste_xclip


def init_xsel_clipboard():
    """Initialize xsel clipboard."""

    def copy_xsel(text, primary=False):
        selection = "--primary" if primary else "--clipboard"
        text_bytes = text.encode('utf-8')
        try:
            process = subprocess.Popen(
                ['xsel', selection, '--input'],
                stdin=subprocess.PIPE,
                close_fds=True
            )
            process.communicate(text_bytes)
            if process.returncode != 0:
                raise PyperclipException("xsel copy failed")
        except FileNotFoundError:
            raise PyperclipException("xsel command not found")

    def paste_xsel(primary=False):
        selection = "--primary" if primary else "--clipboard"
        try:
            process = subprocess.Popen(
                ['xsel', selection, '--output'],
                stdout=subprocess.PIPE,
                close_fds=True
            )
            stdout, _ = process.communicate()
            if process.returncode != 0:
                raise PyperclipException("xsel paste failed")
            return stdout.decode('utf-8')
        except FileNotFoundError:
            raise PyperclipException("xsel command not found")

    return copy_xsel, paste_xsel


def init_wl_clipboard():
    """Initialize Wayland wl-clipboard."""

    def copy_wl(text, primary=False):
        selection = ["--primary"] if primary else []
        text_bytes = text.encode('utf-8')
        try:
            process = subprocess.Popen(
                ['wl-copy'] + selection,
                stdin=subprocess.PIPE,
                close_fds=True
            )
            process.communicate(text_bytes)
            if process.returncode != 0:
                raise PyperclipException("wl-copy failed")
        except FileNotFoundError:
            raise PyperclipException("wl-copy command not found")

    def paste_wl(primary=False):
        selection = ["--primary"] if primary else []
        try:
            process = subprocess.Popen(
                ['wl-paste'] + selection,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                close_fds=True
            )
            stdout, stderr = process.communicate()
            if process.returncode != 0:
                # If paste fails, return empty string
                return ""
            return stdout.decode('utf-8')
        except FileNotFoundError:
            raise PyperclipException("wl-paste command not found")

    return copy_wl, paste_wl


def init_klipper_clipboard():
    """Initialize KDE Klipper clipboard."""

    def copy_klipper(text):
        text_bytes = text.encode('utf-8')
        try:
            process = subprocess.Popen(
                ['qdbus', 'org.kde.klipper', '/klipper', 'setClipboardContents'],
                stdin=subprocess.PIPE,
                close_fds=True
            )
            process.communicate(text_bytes)
            if process.returncode != 0:
                raise PyperclipException("klipper copy failed")
        except FileNotFoundError:
            raise PyperclipException("qdbus command not found")

    def paste_klipper():
        try:
            process = subprocess.Popen(
                ['qdbus', 'org.kde.klipper', '/klipper', 'getClipboardContents'],
                stdout=subprocess.PIPE,
                close_fds=True
            )
            stdout, _ = process.communicate()
            if process.returncode != 0:
                raise PyperclipException("klipper paste failed")
            # Remove trailing newline added by klipper
            text = stdout.decode('utf-8')
            if text.endswith('\n'):
                text = text[:-1]
            return text
        except FileNotFoundError:
            raise PyperclipException("qdbus command not found")

    return copy_klipper, paste_klipper


def init_dev_clipboard_clipboard():
    """Initialize Cygwin /dev/clipboard."""

    def copy_dev_clipboard(text):
        text_bytes = text.encode('utf-8')
        try:
            with open('/dev/clipboard', 'wb') as f:
                f.write(text_bytes)
        except Exception as e:
            raise PyperclipException(f"/dev/clipboard write failed: {e}")

    def paste_dev_clipboard():
        try:
            with open('/dev/clipboard', 'rb') as f:
                return f.read().decode('utf-8')
        except Exception as e:
            raise PyperclipException(f"/dev/clipboard read failed: {e}")

    return copy_dev_clipboard, paste_dev_clipboard


def init_wsl_clipboard():
    """Initialize Windows Subsystem for Linux clipboard."""

    def copy_wsl(text):
        text_bytes = text.encode('utf-16-le')
        try:
            process = subprocess.Popen(
                ['clip.exe'],
                stdin=subprocess.PIPE,
                close_fds=True
            )
            process.communicate(text_bytes)
            if process.returncode != 0:
                raise PyperclipException("clip.exe failed")
        except FileNotFoundError:
            raise PyperclipException("clip.exe not found")

    def paste_wsl():
        try:
            # Use powershell to get clipboard content and encode as base64
            process = subprocess.Popen(
                ['powershell.exe', '-NoProfile', '-Command',
                 '[Console]::Out.Write([System.Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes((Get-Clipboard))))'],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                close_fds=True
            )
            stdout, _ = process.communicate()
            if process.returncode != 0:
                return ""

            # Decode base64
            import base64
            try:
                base64_str = stdout.decode('utf-8').strip()
                if not base64_str:
                    return ""
                text = base64.b64decode(base64_str).decode('utf-8')
                return text
            except Exception:
                return ""
        except FileNotFoundError:
            raise PyperclipException("powershell.exe not found")

    return copy_wsl, paste_wsl


def init_qt_clipboard():
    """Initialize Qt clipboard."""
    try:
        # Try qtpy first (abstraction layer)
        try:
            from qtpy.QtGui import QGuiApplication
            from qtpy.QtCore import QCoreApplication
        except ImportError:
            # Fall back to PyQt5
            from PyQt5.QtGui import QGuiApplication
            from PyQt5.QtCore import QCoreApplication

        from PyQt5.QtWidgets import QApplication
    except ImportError:
        raise PyperclipException("PyQt5 or qtpy is not installed")

    app = None

    def copy_qt(text):
        nonlocal app
        if app is None:
            try:
                app = QApplication.instance()
                if app is None:
                    app = QApplication([])
            except Exception:
                try:
                    app = QGuiApplication.instance()
                    if app is None:
                        app = QGuiApplication([])
                except Exception:
                    raise PyperclipException("Failed to create Qt application")

        try:
            clipboard = app.clipboard()
            clipboard.setText(text)
        except Exception as e:
            raise PyperclipException(f"Qt copy failed: {e}")

    def paste_qt():
        nonlocal app
        if app is None:
            try:
                app = QApplication.instance()
                if app is None:
                    app = QApplication([])
            except Exception:
                try:
                    app = QGuiApplication.instance()
                    if app is None:
                        app = QGuiApplication([])
                except Exception:
                    raise PyperclipException("Failed to create Qt application")

        try:
            clipboard = app.clipboard()
            text = clipboard.text()
            return text if text is not None else ""
        except Exception as e:
            raise PyperclipException(f"Qt paste failed: {e}")

    return copy_qt, paste_qt
