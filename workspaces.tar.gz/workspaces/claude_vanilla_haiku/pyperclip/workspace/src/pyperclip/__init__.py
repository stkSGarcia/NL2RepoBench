"""Pyperclip: A cross-platform clipboard library for Python."""

import sys
import os
import platform
import shutil
import subprocess

from .exceptions import (
    PyperclipException,
    PyperclipWindowsException,
    PyperclipTimeoutException,
)

__version__ = "1.0.0"

ENCODING = 'utf-8'

# Determine if we're running Python 2 or 3
_IS_RUNNING_PYTHON_2 = sys.version_info[0] == 2


def _executable_exists(name):
    """Check if a system command exists."""
    return shutil.which(name) is not None


# Import platform-specific implementations
from ._windows import init_windows_clipboard
from ._osx import init_osx_pbcopy_clipboard, init_osx_pyobjc_clipboard
from ._linux import (
    init_xclip_clipboard,
    init_xsel_clipboard,
    init_wl_clipboard,
    init_klipper_clipboard,
    init_dev_clipboard_clipboard,
    init_wsl_clipboard,
    init_qt_clipboard,
)


def init_no_clipboard():
    """Initialize no clipboard support (for testing)."""

    def copy_no_clipboard(text):
        raise PyperclipException(
            "Pyperclip could not find a copy/paste mechanism for your system. "
            "For more information, please visit "
            "https://github.com/asweigart/pyperclip/blob/master/README.md"
        )

    def paste_no_clipboard():
        raise PyperclipException(
            "Pyperclip could not find a copy/paste mechanism for your system. "
            "For more information, please visit "
            "https://github.com/asweigart/pyperclip/blob/master/README.md"
        )

    return copy_no_clipboard, paste_no_clipboard


def _convert_text(text):
    """Convert text to string, handling common types."""
    if isinstance(text, str):
        return text
    elif isinstance(text, (int, float)):
        return str(text)
    elif isinstance(text, bool):
        return str(text)
    elif text is None:
        raise PyperclipException(
            "Pyperclip does not support copying None. "
            "Use copy('') to clear the clipboard or copy(str(value))."
        )
    else:
        raise PyperclipException(
            f"Pyperclip does not support copying {type(text).__name__} objects. "
            f"Please convert to str first: copy(str(value))"
        )


def determine_clipboard():
    """Automatically determine and return the best clipboard mechanism."""
    system = platform.system()

    # Windows
    if system == "Windows" or os.name == "nt":
        return init_windows_clipboard()

    # macOS
    if system == "Darwin":
        try:
            import Foundation  # Check if PyObjC is available
            return init_osx_pyobjc_clipboard()
        except ImportError:
            return init_osx_pbcopy_clipboard()

    # Linux and Unix-like systems
    if system == "Linux" or system.startswith("CYGWIN") or system == "MSYS":
        # Check for WSL
        if os.path.exists('/proc/version'):
            try:
                with open('/proc/version', 'r') as f:
                    if 'microsoft' in f.read().lower():
                        try:
                            return init_wsl_clipboard()
                        except PyperclipException:
                            pass
            except Exception:
                pass

        # Check for Cygwin
        if os.path.exists('/dev/clipboard'):
            try:
                return init_dev_clipboard_clipboard()
            except PyperclipException:
                pass

        # Check for Wayland
        if os.environ.get('WAYLAND_DISPLAY'):
            if _executable_exists('wl-copy') and _executable_exists('wl-paste'):
                try:
                    return init_wl_clipboard()
                except PyperclipException:
                    pass

        # Check for xclip
        if _executable_exists('xclip'):
            try:
                return init_xclip_clipboard()
            except PyperclipException:
                pass

        # Check for xsel
        if _executable_exists('xsel'):
            try:
                return init_xsel_clipboard()
            except PyperclipException:
                pass

        # Check for wl-clipboard (X11 or Wayland)
        if _executable_exists('wl-copy') and _executable_exists('wl-paste'):
            try:
                return init_wl_clipboard()
            except PyperclipException:
                pass

        # Check for Klipper
        if _executable_exists('qdbus') and _executable_exists('klipper'):
            try:
                return init_klipper_clipboard()
            except PyperclipException:
                pass

        # Check for Qt
        try:
            return init_qt_clipboard()
        except PyperclipException:
            pass

    # Fallback to no clipboard
    return init_no_clipboard()


# Global variables to store the current clipboard functions
_copy_function = None
_paste_function = None
_clipboard_type = None


def _lazy_load_stub_copy(text):
    """Lazy loading wrapper for copy()."""
    global copy, paste, _copy_function, _paste_function
    _copy_function, _paste_function = determine_clipboard()
    copy = _copy_function
    paste = _paste_function
    return copy(text)


def _lazy_load_stub_paste():
    """Lazy loading wrapper for paste()."""
    global copy, paste, _copy_function, _paste_function
    _copy_function, _paste_function = determine_clipboard()
    copy = _copy_function
    paste = _paste_function
    return paste()


# Module-level copy and paste functions with lazy loading
copy = _lazy_load_stub_copy
paste = _lazy_load_stub_paste


def set_clipboard(clipboard):
    """Manually set the clipboard mechanism."""
    global copy, paste, _copy_function, _paste_function, _clipboard_type

    clipboard_map = {
        "windows": init_windows_clipboard,
        "pbcopy": init_osx_pbcopy_clipboard,
        "pyobjc": init_osx_pyobjc_clipboard,
        "qt": init_qt_clipboard,
        "xclip": init_xclip_clipboard,
        "xsel": init_xsel_clipboard,
        "wl-clipboard": init_wl_clipboard,
        "klipper": init_klipper_clipboard,
        "no": init_no_clipboard,
        "dev": init_dev_clipboard_clipboard,
        "wsl": init_wsl_clipboard,
    }

    if clipboard not in clipboard_map:
        raise ValueError(
            f"Unknown clipboard type: {clipboard}. "
            f"Valid options: {', '.join(clipboard_map.keys())}"
        )

    try:
        _copy_function, _paste_function = clipboard_map[clipboard]()
        _clipboard_type = clipboard
        copy = _copy_function
        paste = _paste_function
    except Exception as e:
        raise PyperclipException(f"Failed to initialize {clipboard} clipboard: {e}")


def is_available():
    """Check if clipboard is available (initialized to a real backend)."""
    return (
        copy is not _lazy_load_stub_copy
        and paste is not _lazy_load_stub_paste
    )


# Create wrapper functions that handle type conversion
_original_copy = None
_original_paste = None


def _wrap_copy(copy_func):
    """Wrap copy function to handle type conversion."""
    def wrapped_copy(text):
        converted_text = _convert_text(text)
        return copy_func(converted_text)
    return wrapped_copy


# Monkey-patch the lazy loading stubs to handle type conversion
_original_lazy_copy = _lazy_load_stub_copy
_original_lazy_paste = _lazy_load_stub_paste


def _lazy_load_stub_copy_wrapped(text):
    """Lazy loading wrapper for copy() with type conversion."""
    global copy, paste, _copy_function, _paste_function
    converted_text = _convert_text(text)
    _copy_function, _paste_function = determine_clipboard()
    copy = _wrap_copy(_copy_function)
    paste = _paste_function
    return copy(converted_text)


def _lazy_load_stub_paste_wrapped():
    """Lazy loading wrapper for paste()."""
    global copy, paste, _copy_function, _paste_function
    _copy_function, _paste_function = determine_clipboard()
    copy = _wrap_copy(_copy_function)
    paste = _paste_function
    return paste()


copy = _lazy_load_stub_copy_wrapped
paste = _lazy_load_stub_paste_wrapped


# Export public API
__all__ = [
    'copy',
    'paste',
    'set_clipboard',
    'determine_clipboard',
    'is_available',
    '_executable_exists',
    'PyperclipException',
    'PyperclipWindowsException',
    'PyperclipTimeoutException',
    'init_windows_clipboard',
    'init_osx_pbcopy_clipboard',
    'init_osx_pyobjc_clipboard',
    'init_xclip_clipboard',
    'init_xsel_clipboard',
    'init_wl_clipboard',
    'init_klipper_clipboard',
    'init_dev_clipboard_clipboard',
    'init_wsl_clipboard',
    'init_qt_clipboard',
    'init_no_clipboard',
]
