"""Windows clipboard implementation using ctypes."""

import ctypes
import ctypes.wintypes
from .exceptions import PyperclipWindowsException

CF_UNICODETEXT = 13


def _check_win32_call(result, func, args):
    """Check result of Windows API call."""
    if not result:
        raise PyperclipWindowsException(
            f"Windows API call failed: {func.__name__}"
        )
    return result


class CheckedCall:
    """Wrapper for checked Windows API calls."""

    def __init__(self, func):
        self.func = func
        self.func.argtypes = []
        self.func.restype = ctypes.wintypes.BOOL
        self.func.errcheck = _check_win32_call

    def __call__(self, *args):
        return self.func(*args)


def init_windows_clipboard():
    """Initialize Windows clipboard using Windows API."""
    user32 = ctypes.windll.user32

    # Get clipboard data
    GetClipboardData = user32.GetClipboardData
    GetClipboardData.argtypes = [ctypes.wintypes.UINT]
    GetClipboardData.restype = ctypes.wintypes.HANDLE

    # Set clipboard data
    SetClipboardData = user32.SetClipboardData
    SetClipboardData.argtypes = [ctypes.wintypes.UINT, ctypes.wintypes.HANDLE]
    SetClipboardData.restype = ctypes.wintypes.HANDLE

    # Open clipboard
    OpenClipboard = user32.OpenClipboard
    OpenClipboard.argtypes = [ctypes.wintypes.HWND]
    OpenClipboard.restype = ctypes.wintypes.BOOL

    # Close clipboard
    CloseClipboard = user32.CloseClipboard
    CloseClipboard.argtypes = []
    CloseClipboard.restype = ctypes.wintypes.BOOL

    # Empty clipboard
    EmptyClipboard = user32.EmptyClipboard
    EmptyClipboard.argtypes = []
    EmptyClipboard.restype = ctypes.wintypes.BOOL

    # GlobalLock
    kernel32 = ctypes.windll.kernel32
    GlobalLock = kernel32.GlobalLock
    GlobalLock.argtypes = [ctypes.wintypes.HANDLE]
    GlobalLock.restype = ctypes.wintypes.LPVOID

    # GlobalUnlock
    GlobalUnlock = kernel32.GlobalUnlock
    GlobalUnlock.argtypes = [ctypes.wintypes.HANDLE]
    GlobalUnlock.restype = ctypes.wintypes.BOOL

    # GlobalAlloc
    GlobalAlloc = kernel32.GlobalAlloc
    GlobalAlloc.argtypes = [ctypes.wintypes.UINT, ctypes.c_size_t]
    GlobalAlloc.restype = ctypes.wintypes.HANDLE

    GMEM_MOVEABLE = 0x0002

    def copy_windows(text):
        text = text.encode('utf-16-le')

        if not OpenClipboard(None):
            raise PyperclipWindowsException("Failed to open clipboard")

        try:
            if not EmptyClipboard():
                raise PyperclipWindowsException("Failed to empty clipboard")

            # Allocate global memory
            size = len(text) + 2  # +2 for null terminator
            handle = GlobalAlloc(GMEM_MOVEABLE, size)
            if not handle:
                raise PyperclipWindowsException("Failed to allocate global memory")

            # Lock and copy
            ptr = GlobalLock(handle)
            if not ptr:
                raise PyperclipWindowsException("Failed to lock global memory")

            try:
                ctypes.memmove(ptr, text, len(text))
            finally:
                GlobalUnlock(handle)

            # Set clipboard
            if not SetClipboardData(CF_UNICODETEXT, handle):
                raise PyperclipWindowsException("Failed to set clipboard data")

        finally:
            if not CloseClipboard():
                raise PyperclipWindowsException("Failed to close clipboard")

    def paste_windows():
        if not OpenClipboard(None):
            raise PyperclipWindowsException("Failed to open clipboard")

        try:
            handle = GetClipboardData(CF_UNICODETEXT)
            if not handle:
                # Empty clipboard
                return ""

            # Lock the handle
            ptr = GlobalLock(handle)
            if not ptr:
                raise PyperclipWindowsException("Failed to lock clipboard data")

            try:
                # Get the string data
                text = ctypes.wstring_at(ptr)
            finally:
                GlobalUnlock(handle)

            return text

        finally:
            if not CloseClipboard():
                raise PyperclipWindowsException("Failed to close clipboard")

    return copy_windows, paste_windows
