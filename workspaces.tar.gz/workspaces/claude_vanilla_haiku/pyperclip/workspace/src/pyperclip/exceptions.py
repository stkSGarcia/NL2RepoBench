"""Exception classes for pyperclip."""


class PyperclipException(RuntimeError):
    """Base exception class for clipboard operations."""

    def __init__(self, message):
        self.message = message
        super().__init__(message)


class PyperclipWindowsException(PyperclipException):
    """Windows-specific clipboard exception."""
    pass


class PyperclipTimeoutException(PyperclipException):
    """Timeout exception for clipboard operations."""
    pass
