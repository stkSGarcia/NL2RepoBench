"""macOS clipboard implementations."""

import subprocess
from .exceptions import PyperclipException


def init_osx_pbcopy_clipboard():
    """Initialize macOS clipboard using pbcopy/pbpaste commands."""

    def copy_osx_pbcopy(text):
        text_bytes = text.encode('utf-8')
        try:
            process = subprocess.Popen(
                ['pbcopy'],
                stdin=subprocess.PIPE,
                close_fds=True
            )
            process.communicate(text_bytes)
            if process.returncode != 0:
                raise PyperclipException("pbcopy failed")
        except FileNotFoundError:
            raise PyperclipException("pbcopy command not found")

    def paste_osx_pbcopy():
        try:
            process = subprocess.Popen(
                ['pbpaste'],
                stdout=subprocess.PIPE,
                close_fds=True
            )
            stdout, _ = process.communicate()
            if process.returncode != 0:
                raise PyperclipException("pbpaste failed")
            return stdout.decode('utf-8')
        except FileNotFoundError:
            raise PyperclipException("pbpaste command not found")

    return copy_osx_pbcopy, paste_osx_pbcopy


def init_osx_pyobjc_clipboard():
    """Initialize macOS clipboard using PyObjC framework."""
    try:
        from Foundation import NSPasteboard, NSPasteboardTypeString
        from AppKit import NSApplication
    except ImportError:
        raise PyperclipException("PyObjC is not installed")

    def copy_osx_pyobjc(text):
        try:
            app = NSApplication.sharedApplication()
            pasteboard = NSPasteboard.generalPasteboard()
            pasteboard.clearContents()
            pasteboard.setString_forType_(text, NSPasteboardTypeString)
        except Exception as e:
            raise PyperclipException(f"PyObjC copy failed: {e}")

    def paste_osx_pyobjc():
        try:
            pasteboard = NSPasteboard.generalPasteboard()
            result = pasteboard.stringForType_(NSPasteboardTypeString)
            return result if result is not None else ""
        except Exception as e:
            raise PyperclipException(f"PyObjC paste failed: {e}")

    return copy_osx_pyobjc, paste_osx_pyobjc
