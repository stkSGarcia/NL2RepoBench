"""Comprehensive test suite for pyperclip."""

import unittest
import sys
import os
import platform
import random
import string
import pyperclip
from pyperclip import (
    PyperclipException,
    _executable_exists,
    init_windows_clipboard,
    init_osx_pbcopy_clipboard,
    init_osx_pyobjc_clipboard,
    init_xclip_clipboard,
    init_xsel_clipboard,
    init_wl_clipboard,
    init_klipper_clipboard,
    init_dev_clipboard_clipboard,
    init_wsl_clipboard,
    init_qt_clipboard,
    init_no_clipboard,
)


class TestClipboardBase(unittest.TestCase):
    """Base test class for clipboard operations."""

    @classmethod
    def setUpClass(cls):
        """Set up test fixtures."""
        cls.supports_unicode = True

    def copy(self, text):
        """Helper to copy text."""
        pyperclip.copy(text)

    def paste(self):
        """Helper to paste text."""
        return pyperclip.paste()

    def test_copy_paste_simple(self):
        """Test simple text copy and paste."""
        msg = 'pyperclip'
        self.copy(msg)
        self.assertEqual(self.paste(), msg)

    def test_copy_paste_longer_text(self):
        """Test copying longer text."""
        msg = ''.join(random.choice(string.ascii_letters + string.digits)
                     for _ in range(1000))
        self.copy(msg)
        self.assertEqual(self.paste(), msg)

    def test_copy_paste_whitespace(self):
        """Test whitespace handling."""
        msg = ''.join(random.choice(string.whitespace) for _ in range(100))
        self.copy(msg)
        self.assertEqual(self.paste(), msg)

    def test_copy_blank(self):
        """Test copying blank string."""
        self.copy('TEST')
        self.copy('')
        self.assertEqual(self.paste(), '')

    def test_copy_with_newlines(self):
        """Test text with newlines."""
        msg = 'pyper\r\nclip'
        self.copy(msg)
        self.assertEqual(self.paste(), msg)

    def test_copy_unicode(self):
        """Test Unicode character handling."""
        if not self.supports_unicode:
            self.skipTest("Unicode not supported")
        msg = "ಠ_ಠ"
        self.copy(msg)
        self.assertEqual(self.paste(), msg)

    def test_copy_unicode_emoji(self):
        """Test emoji support."""
        if not self.supports_unicode:
            self.skipTest("Unicode not supported")
        msg = "🙆"
        self.copy(msg)
        self.assertEqual(self.paste(), msg)

    def test_copy_mixed_unicode(self):
        """Test mixed Unicode and ASCII."""
        if not self.supports_unicode:
            self.skipTest("Unicode not supported")
        msg = "Hello, 世界! 🌍"
        self.copy(msg)
        self.assertEqual(self.paste(), msg)

    def test_non_str_int(self):
        """Test copying integers."""
        self.copy(42)
        self.assertEqual(self.paste(), '42')

        self.copy(-1)
        self.assertEqual(self.paste(), '-1')

        self.copy(0)
        self.assertEqual(self.paste(), '0')

    def test_non_str_float(self):
        """Test copying floats."""
        self.copy(3.141592)
        self.assertEqual(self.paste(), '3.141592')

        self.copy(-1.5)
        self.assertEqual(self.paste(), '-1.5')

        self.copy(0.0)
        self.assertEqual(self.paste(), '0.0')

    def test_non_str_bool(self):
        """Test copying booleans."""
        self.copy(True)
        self.assertEqual(self.paste(), 'True')

        self.copy(False)
        self.assertEqual(self.paste(), 'False')

    def test_non_str_none(self):
        """Test that None raises exception."""
        with self.assertRaises(PyperclipException):
            self.copy(None)

    def test_non_str_list(self):
        """Test that lists raise exception."""
        with self.assertRaises(PyperclipException):
            self.copy([2, 4, 6, 8])

    def test_non_str_dict(self):
        """Test that dicts raise exception."""
        with self.assertRaises(PyperclipException):
            self.copy({'a': 1})

    def test_empty_paste(self):
        """Test pasting after clearing clipboard."""
        self.copy('')
        result = self.paste()
        self.assertEqual(result, '')

    def test_multiple_copy_paste(self):
        """Test multiple copy/paste cycles."""
        messages = ['first', 'second', 'third']
        for msg in messages:
            self.copy(msg)
            self.assertEqual(self.paste(), msg)

    def test_special_characters(self):
        """Test special characters."""
        msg = "!@#$%^&*()_+-={}[]|:;<>,.?/"
        self.copy(msg)
        self.assertEqual(self.paste(), msg)

    def test_tabs_and_spaces(self):
        """Test tabs and spaces."""
        msg = "tab\there\nand    spaces"
        self.copy(msg)
        self.assertEqual(self.paste(), msg)


class TestNoClipboard(unittest.TestCase):
    """Test the no clipboard fallback."""

    def test_no_clipboard_copy(self):
        """Test that no clipboard raises exception on copy."""
        copy_func, paste_func = init_no_clipboard()
        with self.assertRaises(PyperclipException):
            copy_func("foo")

    def test_no_clipboard_paste(self):
        """Test that no clipboard raises exception on paste."""
        copy_func, paste_func = init_no_clipboard()
        with self.assertRaises(PyperclipException):
            paste_func()


class TestExecutableExists(unittest.TestCase):
    """Test the _executable_exists utility function."""

    def test_executable_exists_true(self):
        """Test that we can find common executables."""
        # These should exist on most systems
        self.assertTrue(_executable_exists('ls') or _executable_exists('cmd'))

    def test_executable_exists_false(self):
        """Test that non-existent executables return False."""
        self.assertFalse(_executable_exists('this_command_does_not_exist_12345'))


class TestDetermineClipboard(unittest.TestCase):
    """Test clipboard determination."""

    def test_determine_clipboard_returns_tuple(self):
        """Test that determine_clipboard returns a tuple of callables."""
        copy_func, paste_func = pyperclip.determine_clipboard()
        self.assertTrue(callable(copy_func))
        self.assertTrue(callable(paste_func))

    def test_determine_clipboard_works(self):
        """Test that determined clipboard actually works."""
        copy_func, paste_func = pyperclip.determine_clipboard()
        test_msg = "test_message_12345"
        copy_func(test_msg)
        result = paste_func()
        # Result should contain the message (might have newlines added)
        self.assertIn(test_msg, result)


class TestSetClipboard(unittest.TestCase):
    """Test set_clipboard function."""

    def setUp(self):
        """Save the current clipboard state."""
        self.original_copy = pyperclip.copy
        self.original_paste = pyperclip.paste

    def tearDown(self):
        """Restore the original clipboard state."""
        pyperclip.copy = self.original_copy
        pyperclip.paste = self.original_paste

    def test_set_clipboard_no(self):
        """Test setting to 'no' clipboard."""
        pyperclip.set_clipboard('no')
        with self.assertRaises(PyperclipException):
            pyperclip.copy("test")

    def test_set_clipboard_invalid(self):
        """Test that invalid clipboard type raises ValueError."""
        with self.assertRaises(ValueError):
            pyperclip.set_clipboard('invalid_clipboard_type')

    def test_set_clipboard_valid_options(self):
        """Test setting valid clipboard options."""
        # These should not raise errors even if they fail to initialize
        # (they'll just raise during use if unavailable)
        valid_types = [
            'no', 'windows', 'pbcopy', 'pyobjc', 'qt',
            'xclip', 'xsel', 'wl-clipboard', 'klipper', 'dev', 'wsl'
        ]

        for clipboard_type in valid_types:
            try:
                pyperclip.set_clipboard(clipboard_type)
            except (PyperclipException, ValueError):
                # It's ok if the clipboard is not available
                pass

        # Restore to a working clipboard after testing
        pyperclip.determine_clipboard()


class TestIsAvailable(unittest.TestCase):
    """Test is_available function."""

    def test_is_available_after_determine(self):
        """Test that is_available returns True after determine_clipboard."""
        pyperclip.determine_clipboard()
        # After determine_clipboard is called, is_available should be True
        self.assertTrue(pyperclip.is_available())

    def test_is_available_before_use(self):
        """Test is_available status before initialization."""
        # This depends on whether lazy loading has happened
        # Just verify it returns a boolean
        result = pyperclip.is_available()
        self.assertIsInstance(result, bool)


class TestPlatformSpecific(unittest.TestCase):
    """Test platform-specific implementations."""

    def test_windows_clipboard_on_windows(self):
        """Test Windows clipboard on Windows systems."""
        if sys.platform != 'win32':
            self.skipTest("Not on Windows")
        try:
            copy_func, paste_func = init_windows_clipboard()
            self.assertTrue(callable(copy_func))
            self.assertTrue(callable(paste_func))
        except PyperclipException:
            self.skipTest("Windows clipboard not available")

    def test_osx_pbcopy_on_macos(self):
        """Test macOS pbcopy on macOS."""
        if sys.platform != 'darwin':
            self.skipTest("Not on macOS")
        try:
            copy_func, paste_func = init_osx_pbcopy_clipboard()
            self.assertTrue(callable(copy_func))
            self.assertTrue(callable(paste_func))
        except PyperclipException:
            self.skipTest("pbcopy not available")

    def test_osx_pyobjc_on_macos(self):
        """Test macOS PyObjC on macOS."""
        if sys.platform != 'darwin':
            self.skipTest("Not on macOS")
        try:
            copy_func, paste_func = init_osx_pyobjc_clipboard()
            self.assertTrue(callable(copy_func))
            self.assertTrue(callable(paste_func))
        except PyperclipException:
            self.skipTest("PyObjC not available")

    def test_xclip_if_available(self):
        """Test xclip if available."""
        if not _executable_exists('xclip'):
            self.skipTest("xclip not available")
        try:
            copy_func, paste_func = init_xclip_clipboard()
            self.assertTrue(callable(copy_func))
            self.assertTrue(callable(paste_func))
        except PyperclipException:
            self.skipTest("xclip initialization failed")

    def test_xsel_if_available(self):
        """Test xsel if available."""
        if not _executable_exists('xsel'):
            self.skipTest("xsel not available")
        try:
            copy_func, paste_func = init_xsel_clipboard()
            self.assertTrue(callable(copy_func))
            self.assertTrue(callable(paste_func))
        except PyperclipException:
            self.skipTest("xsel initialization failed")

    def test_wl_clipboard_if_available(self):
        """Test wl-clipboard if available."""
        if not _executable_exists('wl-copy') or not _executable_exists('wl-paste'):
            self.skipTest("wl-clipboard not available")
        try:
            copy_func, paste_func = init_wl_clipboard()
            self.assertTrue(callable(copy_func))
            self.assertTrue(callable(paste_func))
        except PyperclipException:
            self.skipTest("wl-clipboard initialization failed")

    def test_klipper_if_available(self):
        """Test klipper if available."""
        if not _executable_exists('qdbus') or not _executable_exists('klipper'):
            self.skipTest("Klipper/qdbus not available")
        try:
            copy_func, paste_func = init_klipper_clipboard()
            self.assertTrue(callable(copy_func))
            self.assertTrue(callable(paste_func))
        except PyperclipException:
            self.skipTest("Klipper initialization failed")

    def test_qt_if_available(self):
        """Test Qt clipboard if available."""
        try:
            copy_func, paste_func = init_qt_clipboard()
            self.assertTrue(callable(copy_func))
            self.assertTrue(callable(paste_func))
        except PyperclipException:
            self.skipTest("Qt not available")


class TestEdgeCases(unittest.TestCase):
    """Test edge cases and corner cases."""

    def setUp(self):
        """Set up for each test."""
        # Make sure we have a working clipboard
        pyperclip.determine_clipboard()

    def test_very_long_string(self):
        """Test copying very long strings."""
        msg = 'a' * 10000
        pyperclip.copy(msg)
        self.assertEqual(pyperclip.paste(), msg)

    def test_null_bytes(self):
        """Test handling null bytes."""
        # Some systems may have issues with null bytes
        msg = "before\x00after"
        try:
            pyperclip.copy(msg)
            result = pyperclip.paste()
            # Behavior may vary by platform
            self.assertIn("before", result)
        except (PyperclipException, ValueError):
            # Some platforms may not support null bytes
            pass

    def test_high_unicode_characters(self):
        """Test high Unicode code points."""
        msg = "𝕳𝖊𝖑𝖑𝖔"  # Mathematical alphanumeric symbols
        try:
            pyperclip.copy(msg)
            self.assertEqual(pyperclip.paste(), msg)
        except PyperclipException:
            # Some platforms may not support all Unicode
            pass


if __name__ == '__main__':
    unittest.main()
