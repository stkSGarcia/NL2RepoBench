# Pyperclip

Pyperclip is a Python library for cross-platform clipboard operations. It enables text copying and pasting on Windows, macOS, and Linux systems with a simple and unified interface.

## Features

- **Cross-platform support**: Works on Windows, macOS, and Linux
- **Multiple backend support**: Automatically detects and uses the best available clipboard mechanism
- **Type conversion**: Automatically converts numbers and booleans to strings
- **Unicode support**: Full support for Unicode characters and emojis
- **Command-line interface**: Use pyperclip from the command line
- **Exception handling**: Comprehensive error handling with custom exceptions

## Installation

Install pyperclip using pip:

```bash
pip install pyperclip
```

### Optional Dependencies

For macOS with PyObjC support:
```bash
pip install pyperclip[osx]
```

For Qt support:
```bash
pip install pyperclip[qt]
```

## Quick Start

### Basic Usage

```python
import pyperclip

# Copy text to clipboard
pyperclip.copy('Hello, World!')

# Paste text from clipboard
text = pyperclip.paste()
print(text)  # Output: Hello, World!
```

### Type Conversion

```python
import pyperclip

# Copy numbers and booleans (automatically converted to strings)
pyperclip.copy(42)        # Copies "42"
pyperclip.copy(3.14)      # Copies "3.14"
pyperclip.copy(True)      # Copies "True"
```

### Unicode and Emojis

```python
import pyperclip

# Copy Unicode text
pyperclip.copy('你好，世界！🌍')
text = pyperclip.paste()
print(text)  # Output: 你好，世界！🌍
```

### Error Handling

```python
import pyperclip
from pyperclip import PyperclipException

try:
    pyperclip.copy('test')
    text = pyperclip.paste()
except PyperclipException as e:
    print(f"Clipboard error: {e}")
```

### Manual Clipboard Selection

```python
import pyperclip

# Automatically detect and use the best clipboard mechanism
pyperclip.determine_clipboard()

# Or manually specify which mechanism to use
pyperclip.set_clipboard('xclip')  # Use xclip on Linux
```

### Check Clipboard Availability

```python
import pyperclip

if pyperclip.is_available():
    print("Clipboard is available")
    pyperclip.copy("Hello")
else:
    print("Clipboard is not available")
```

## Command-Line Usage

Use pyperclip from the command line:

```bash
# Copy text
python -m pyperclip -c "Hello, World!"

# Paste text
python -m pyperclip -p

# Copy from stdin
echo "Hello" | python -m pyperclip -c
```

## Supported Platforms and Mechanisms

- **Windows**: Windows API via ctypes
- **macOS**: pbcopy/pbpaste commands or PyObjC framework
- **Linux (X11)**: xclip, xsel
- **Linux (Wayland)**: wl-clipboard
- **Linux (KDE)**: Klipper with qdbus
- **WSL**: Windows Subsystem for Linux (clip.exe)
- **Cygwin**: /dev/clipboard device
- **Qt**: PyQt5 or qtpy

The library automatically detects your system and uses the most appropriate mechanism.

## API Reference

### Core Functions

#### `copy(text: str | int | float | bool) -> None`

Copy text to the system clipboard. Automatically converts numbers and booleans to strings.

#### `paste() -> str`

Paste text from the system clipboard.

#### `set_clipboard(clipboard_type: str) -> None`

Manually set the clipboard mechanism. Valid options:
- "windows", "pbcopy", "pyobjc", "qt", "xclip", "xsel", "wl-clipboard", "klipper", "no", "dev", "wsl"

#### `determine_clipboard() -> tuple`

Automatically detect and return the best clipboard mechanism as a (copy_func, paste_func) tuple.

#### `is_available() -> bool`

Check if the clipboard mechanism has been initialized.

### Exception Classes

#### `PyperclipException`

Base exception class for clipboard operations.

#### `PyperclipWindowsException`

Windows-specific clipboard exception.

#### `PyperclipTimeoutException`

Timeout exception for clipboard operations.

### Utility Functions

#### `_executable_exists(command: str) -> bool`

Check if a system command exists.

## Testing

Run the test suite:

```bash
python -m pytest tests/
```

## Limitations

- Only text/Unicode data is supported (no binary data)
- No asyncio support (all operations are synchronous)
- Thread safety is basic; concurrent clipboard access may have issues

## License

Pyperclip is released under the BSD license.

## Contributing

Contributions are welcome! Please feel free to submit bug reports and pull requests.

## References

- Original pyperclip: https://github.com/asweigart/pyperclip
