# Pyperclip Implementation Design

## Overview
This document outlines the architectural design and implementation strategy for the pyperclip cross-platform clipboard library.

## Assumptions

1. **Python Version**: Project uses Python 3.10.11 (Python 3 only, no Python 2 support)
   - Assumption: Simplified `_executable_exists()` to use `shutil.which()` which is the standard Python 3 approach
   - Reasoning: This reduces code complexity and aligns with modern Python practices

2. **Module Location**: Using `src/pyperclip/` structure for the main module
   - Assumption: Project will follow the `src/` layout pattern
   - Reasoning: This enables proper namespace isolation and is compatible with modern Python packaging

3. **Lazy Loading Mechanism**:
   - Assumption: Initially, `copy` and `paste` point to lazy loading stubs that trigger `determine_clipboard()` on first use
   - Reasoning: Avoids expensive initialization at import time and supports dynamic clipboard detection

4. **Type Conversion**:
   - Assumption: Only convert str, int, float, and bool types; all others raise PyperclipException
   - Reasoning: Aligns with the API specification for supported types

5. **Unicode Handling**:
   - Assumption: All string operations use UTF-8 encoding by default
   - Reasoning: UTF-8 is the standard for cross-platform text interchange

6. **Platform Detection Order**:
   - Assumption: Detection order on Linux: wl-clipboard (Wayland) → xclip → xsel → klipper → /dev/clipboard (Cygwin)
   - Reasoning: Prioritizes modern display servers and most common tools

7. **Error Handling**:
   - Assumption: When no clipboard backend is available, gracefully fallback to "no_clipboard" which raises exceptions on use
   - Reasoning: Provides graceful degradation and meaningful error messages

## Architecture

### Module Structure
```
pyperclip/
├── __init__.py           # Public API and lazy loading
├── __main__.py           # CLI interface
├── _windows.py           # Windows implementation
├── _osx.py               # macOS implementations
├── _linux.py             # Linux and other Unix implementations
└── exceptions.py         # Exception classes
```

### Core Components

#### 1. Exception Classes (`exceptions.py`)
- `PyperclipException`: Base exception
- `PyperclipWindowsException`: Windows-specific errors
- `PyperclipTimeoutException`: Timeout errors

#### 2. Clipboard Implementations
Each platform has dedicated initialization functions that return (copy_func, paste_func) tuples:

**Windows**:
- `init_windows_clipboard()`: Uses ctypes to call Windows API (user32.dll)

**macOS**:
- `init_osx_pbcopy_clipboard()`: Uses pbcopy/pbpaste commands
- `init_osx_pyobjc_clipboard()`: Uses PyObjC framework

**Linux**:
- `init_xclip_clipboard()`: Uses xclip tool
- `init_xsel_clipboard()`: Uses xsel tool
- `init_wl_clipboard()`: Uses wl-clipboard (Wayland)
- `init_klipper_clipboard()`: Uses KDE Klipper with qdbus
- `init_dev_clipboard_clipboard()`: Uses /dev/clipboard (Cygwin)
- `init_wsl_clipboard()`: Uses clip.exe and powershell.exe (WSL)

**No Clipboard**:
- `init_no_clipboard()`: Fallback that raises exceptions

#### 3. Type Conversion Wrapper
Implement a wrapper that converts supported types (int, float, bool) to strings before passing to backend.

#### 4. CLI Interface (`__main__.py`)
- Support `-c [text]` for copy
- Support `-p` for paste
- Support reading from stdin if no text provided for copy

## Implementation Strategy

### Phase 1: Core Infrastructure
1. Create exception classes
2. Implement `_executable_exists()` utility
3. Set up lazy loading stubs
4. Create type conversion wrapper

### Phase 2: Platform-Specific Implementations
1. Windows clipboard (ctypes + Windows API)
2. macOS clipboard (pbcopy/pbpaste and PyObjC)
3. Linux clipboard (xclip, xsel, wl-clipboard, klipper)
4. WSL and Cygwin support

### Phase 3: Public API
1. Implement `determine_clipboard()`
2. Implement `set_clipboard()`
3. Implement `is_available()`
4. Set up module-level `copy` and `paste` with lazy loading

### Phase 4: CLI and Tests
1. Implement `__main__.py` for CLI
2. Create comprehensive test suite
3. Set up setup.py with dependencies

## Key Design Patterns

### 1. Lazy Loading
```python
copy = lazy_load_stub_copy
paste = lazy_load_stub_paste

def lazy_load_stub_copy(text):
    global copy, paste
    copy, paste = determine_clipboard()
    return copy(text)
```

### 2. Backend Selection
- Detect platform using `sys.platform`, `os.name`, and `platform.system()`
- Check for special environments (WSL, Cygwin)
- Use try/except to test for available tools/libraries

### 3. Primary/Clipboard Selection
- Linux tools (xclip, xsel, wl-clipboard) support both PRIMARY and CLIPBOARD selections
- Default implementation only exposes CLIPBOARD selection
- Internal functions accept `primary` parameter

## Testing Strategy

- Create base test class with common tests for all backends
- Create platform-specific test subclasses that skip if backend unavailable
- Test coverage:
  - Simple text operations
  - Whitespace and special characters
  - Unicode and emojis
  - Type conversion (int, float, bool)
  - Exception cases
  - Each clipboard backend (if available)

## Known Limitations & Future Considerations

1. **No Asyncio Support**: All operations are synchronous
2. **No Binary Data**: Only text/Unicode support
3. **Timeout Handling**: PyperclipTimeoutException is defined but may not be fully utilized in all backends
4. **Thread Safety**: Basic implementation; concurrent clipboard access may have issues

## Implementation Status

### Completed Features ✓

1. **Core API Functions**
   - `copy(text)` - Copy text with type conversion
   - `paste()` - Paste text from clipboard
   - `determine_clipboard()` - Auto-detect best clipboard mechanism
   - `set_clipboard(type)` - Manual clipboard selection
   - `is_available()` - Check clipboard availability

2. **Type Conversion**
   - String: Direct copy
   - Integer: Auto-convert to string
   - Float: Auto-convert to string
   - Boolean: Auto-convert to string (True/False)
   - Other types: Raise PyperclipException

3. **Exception Classes**
   - PyperclipException (base)
   - PyperclipWindowsException (Windows-specific)
   - PyperclipTimeoutException (timeout errors)

4. **Platform-Specific Implementations**
   - Windows: ctypes + Windows API (user32.dll)
   - macOS: pbcopy/pbpaste commands and PyObjC framework
   - Linux: xclip, xsel, wl-clipboard, klipper, Qt
   - WSL: clip.exe and powershell.exe
   - Cygwin: /dev/clipboard device
   - Fallback: No clipboard (graceful degradation)

5. **Lazy Loading Mechanism**
   - Initial stubs for copy/paste
   - Auto-initialization on first use
   - Support for manual determine_clipboard() calls

6. **CLI Interface** (`python -m pyperclip`)
   - `-c [TEXT]` - Copy text (or read from stdin)
   - `-p` - Paste to stdout

7. **Test Coverage**
   - 33 passing tests
   - 7 skipped tests (platform-specific)
   - Covers all major functionality and edge cases

8. **Configuration Files**
   - setup.py (pip installation)
   - pyproject.toml (modern Python packaging)
   - tox.ini (testing)
   - Pipfile (Pipenv support)
   - README.md (documentation)
   - LICENSE.txt, AUTHORS.txt, CHANGES.txt

9. **Unicode & Special Character Support**
   - Full UTF-8 encoding support
   - Emoji support
   - Special characters and whitespace
   - Newlines and line endings

### Test Results
- **Total Tests**: 40
- **Passed**: 33 ✓
- **Skipped**: 7 (platform-specific backends not available)
- **Failed**: 0

### Running the Project

From the current directory:
```bash
# Basic usage
python3 -c "import sys; sys.path.insert(0, 'src'); import pyperclip; pyperclip.copy('test')"

# CLI usage
PYTHONPATH=src python3 -m pyperclip -c "Hello"
PYTHONPATH=src python3 -m pyperclip -p

# Run tests
PYTHONPATH=src python3 -m pytest tests/
```
