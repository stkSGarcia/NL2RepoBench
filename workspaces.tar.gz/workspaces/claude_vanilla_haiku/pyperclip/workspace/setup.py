"""Setup configuration for pyperclip."""

from setuptools import setup, find_packages
import os
import sys

# Read README for long description
here = os.path.abspath(os.path.dirname(__file__))
try:
    with open(os.path.join(here, 'README.md'), encoding='utf-8') as f:
        long_description = f.read()
except FileNotFoundError:
    long_description = 'A cross-platform clipboard library for Python'

# Version
version = '1.0.0'

# Dependencies
install_requires = []

# Test dependencies
tests_require = [
    'pytest==8.4.1',
    'mypy==1.17.1',
]

# Optional dependencies for different platforms
extras_require = {
    'osx': ['PyObjC>=9.0'],
    'qt': ['PyQt5>=5.15.0', 'qtpy>=1.11.0'],
    'dev': [
        'pytest==8.4.1',
        'mypy==1.17.1',
        'setuptools>=65.5.1',
        'wheel>=0.40.0',
    ]
}

setup(
    name='pyperclip',
    version=version,
    description='A cross-platform clipboard library for Python',
    long_description=long_description,
    long_description_content_type='text/markdown',
    author='Al Sweigart',
    author_email='al@inventwithpython.com',
    url='https://github.com/asweigart/pyperclip',
    license='BSD',
    packages=find_packages(where='src'),
    package_dir={'': 'src'},
    python_requires='>=3.6',
    install_requires=install_requires,
    tests_require=tests_require,
    extras_require=extras_require,
    entry_points={
        'console_scripts': [
            'pyperclip=pyperclip.__main__:main',
        ],
    },
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Environment :: Console',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: BSD License',
        'Operating System :: OS Independent',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.6',
        'Programming Language :: Python :: 3.7',
        'Programming Language :: Python :: 3.8',
        'Programming Language :: Python :: 3.9',
        'Programming Language :: Python :: 3.10',
        'Programming Language :: Python :: 3.11',
        'Topic :: Utilities',
    ],
    keywords='clipboard cross-platform copy paste',
    project_urls={
        'Bug Reports': 'https://github.com/asweigart/pyperclip/issues',
        'Source': 'https://github.com/asweigart/pyperclip',
    },
)
