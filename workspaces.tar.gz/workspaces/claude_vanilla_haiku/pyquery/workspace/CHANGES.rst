CHANGES
=======

2.0.2.dev0 (unreleased)
------------------------

* Initial implementation

2.0.1 (2023-01-01)
-------------------

* Bug fixes and improvements

2.0.0 (2022-01-01)
-------------------

* Python 3 support
* Updated dependencies
