PyQuery
=======

PyQuery is a jQuery-like library for Python. It allows you to make jQuery queries on XML and HTML documents.

Installation
------------

.. code-block:: bash

    pip install pyquery

Quick Start
-----------

.. code-block:: python

    from pyquery import PyQuery as pq

    d = pq('<div><p>Hello</p></div>')
    print(d('p').text())  # Hello

    # Load from URL
    d = pq(url='https://example.com')
    print(d('title').text())

    # CSS manipulation
    d('p').css('color', 'red')
    d('p').add_class('highlight')

    # DOM manipulation
    d('p').after('<span>World</span>')
    d('div').append('<footer>Footer</footer>')

Features
--------

* jQuery-style API
* CSS selector support
* jQuery pseudo-class selectors (:first, :last, :even, :odd, :eq, :gt, :lt, etc.)
* DOM traversal (find, children, parent, siblings, etc.)
* DOM manipulation (append, prepend, after, before, etc.)
* Attribute and CSS manipulation
* Form serialization
* URL loading support
* Multiple parsers: html, xml, html5, soup

License
-------

BSD License
