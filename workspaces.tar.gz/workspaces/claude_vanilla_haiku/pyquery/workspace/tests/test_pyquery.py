"""
Comprehensive test suite for PyQuery library.
Covers all core functionality: CSS selectors, DOM traversal/manipulation,
attributes, CSS styles, HTML content, form serialization, and more.
"""
import pytest
from pyquery import PyQuery as pq
from pyquery import fromstring, url_opener, no_default
from pyquery.cssselectpatch import JQueryTranslator, FlexibleElement, NoDefault


# ---------------------------------------------------------------------------
# Fixtures
# ---------------------------------------------------------------------------

HTML = """
<html>
<body>
  <div id="main">
    <h1>Title</h1>
    <p class="intro">Introduction</p>
    <ul id="list">
      <li class="item first">Item 1</li>
      <li class="item">Item 2</li>
      <li class="item last">Item 3</li>
    </ul>
    <form id="form1">
      <input type="text" name="username" value="alice"/>
      <input type="password" name="password" value="secret"/>
      <input type="checkbox" name="remember" value="1" checked="checked"/>
      <input type="radio" name="gender" value="male" checked="checked"/>
      <input type="radio" name="gender" value="female"/>
      <input type="submit" value="Submit"/>
      <textarea name="bio">Hello World</textarea>
      <select name="country">
        <option value="us" selected="selected">USA</option>
        <option value="uk">UK</option>
      </select>
    </form>
    <div class="nested">
      <div class="inner">
        <span>Nested span</span>
      </div>
    </div>
  </div>
</body>
</html>
"""


@pytest.fixture
def d():
    return pq(HTML)


@pytest.fixture
def simple():
    return pq('<div><p class="a">Hello</p><p class="b">World</p></div>')


# ---------------------------------------------------------------------------
# 1. Basic Initialization
# ---------------------------------------------------------------------------

class TestInitialization:
    def test_from_string(self):
        d = pq('<div>Hello</div>')
        assert len(d) == 1

    def test_from_html_string(self):
        d = pq('<html><body><div>test</div></body></html>')
        assert d('div').text() == 'test'

    def test_from_element_list(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        elems = d('p')[:]
        d2 = pq(elems)
        assert len(d2) == 2

    def test_from_pyquery(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        p_elements = d('p')
        d2 = pq(p_elements)
        assert len(d2) == 2

    def test_from_lxml_element(self):
        from lxml import etree
        el = etree.fromstring('<div>test</div>')
        d = pq(el)
        assert len(d) == 1

    def test_selector_with_context(self):
        d = pq('p', '<div><p>Hello</p></div>')
        assert d.text() == 'Hello'

    def test_no_default_repr(self):
        assert repr(no_default) == '<NoDefault>'

    def test_no_default_singleton(self):
        nd = NoDefault()
        assert repr(nd) == '<NoDefault>'

    def test_version(self):
        import pyquery
        assert hasattr(pyquery, '__version__')
        assert pyquery.__version__

    def test_from_filename(self, tmp_path):
        html_file = tmp_path / "test.html"
        html_file.write_text('<div><p>File content</p></div>')
        d = pq(filename=str(html_file))
        assert d('p').text() == 'File content'

    def test_xml_parser(self):
        d = pq('<root><item>value</item></root>', parser='xml')
        assert d('item').text() == 'value'


# ---------------------------------------------------------------------------
# 2. Selectors
# ---------------------------------------------------------------------------

class TestSelectors:
    def test_tag_selector(self, d):
        assert len(d('p')) >= 1

    def test_id_selector(self, d):
        assert d('#main').attr('id') == 'main'

    def test_class_selector(self, d):
        items = d('.item')
        assert len(items) == 3

    def test_combined_selector(self, d):
        assert d('ul#list') is not None
        assert len(d('ul#list')) == 1

    def test_descendant_selector(self, d):
        spans = d('#main span')
        assert len(spans) >= 1

    def test_child_selector(self, d):
        children = d('#main > h1')
        assert len(children) == 1

    def test_adjacent_sibling(self, d):
        # h1 + p should find .intro paragraph
        result = d('h1 + p')
        assert len(result) == 1

    def test_multiple_selectors(self, d):
        result = d('h1, p.intro')
        assert len(result) == 2

    def test_attribute_selector(self, d):
        result = d('input[type="text"]')
        assert len(result) == 1

    def test_attribute_exists_selector(self, d):
        result = d('[name]')
        assert len(result) >= 1


# ---------------------------------------------------------------------------
# 3. jQuery Pseudo-Selectors
# ---------------------------------------------------------------------------

class TestJQueryPseudoSelectors:
    def test_first_pseudo(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        assert d('p:first').text() == '1'

    def test_last_pseudo(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        assert d('p:last').text() == '3'

    def test_even_pseudo(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p><p>4</p></div>')
        texts = d('p:even').map(lambda i, e: pq(e).text())
        assert texts == ['1', '3']

    def test_odd_pseudo(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p><p>4</p></div>')
        texts = d('p:odd').map(lambda i, e: pq(e).text())
        assert texts == ['2', '4']

    def test_eq_function(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        assert d('p:eq(0)').text() == '1'
        assert d('p:eq(1)').text() == '2'
        assert d('p:eq(2)').text() == '3'

    def test_gt_function(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        texts = d('p:gt(0)').map(lambda i, e: pq(e).text())
        assert texts == ['2', '3']

    def test_lt_function(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        texts = d('p:lt(2)').map(lambda i, e: pq(e).text())
        assert texts == ['1', '2']

    def test_checked_pseudo(self):
        d = pq('<form><input type="checkbox" checked="checked"/><input type="checkbox"/></form>')
        assert len(d(':checked')) == 1

    def test_input_pseudo(self):
        d = pq('<form><input/><textarea/><select></select><button/></form>')
        assert len(d(':input')) == 4

    def test_text_pseudo(self):
        d = pq('<form><input type="text"/><input type="password"/></form>')
        assert len(d(':text')) == 1

    def test_password_pseudo(self):
        d = pq('<form><input type="password"/><input type="text"/></form>')
        assert len(d(':password')) == 1

    def test_radio_pseudo(self):
        d = pq('<form><input type="radio"/><input type="radio"/></form>')
        assert len(d(':radio')) == 2

    def test_checkbox_pseudo(self):
        d = pq('<form><input type="checkbox"/></form>')
        assert len(d(':checkbox')) == 1

    def test_submit_pseudo(self):
        d = pq('<form><input type="submit"/><button type="submit"/></form>')
        assert len(d(':submit')) == 2

    def test_file_pseudo(self):
        d = pq('<form><input type="file"/></form>')
        assert len(d(':file')) == 1

    def test_hidden_pseudo(self):
        d = pq('<form><input type="hidden"/></form>')
        assert len(d(':hidden')) == 1

    def test_image_pseudo(self):
        d = pq('<form><input type="image"/></form>')
        assert len(d(':image')) == 1

    def test_reset_pseudo(self):
        d = pq('<form><input type="reset"/></form>')
        assert len(d(':reset')) == 1

    def test_button_pseudo(self):
        d = pq('<form><button/><input type="button"/></form>')
        assert len(d(':button')) == 2

    def test_header_pseudo(self):
        d = pq('<div><h1>1</h1><h2>2</h2><h3>3</h3><p>p</p></div>')
        assert len(d(':header')) == 3

    def test_parent_pseudo(self):
        d = pq('<div><p>has children <span>yes</span></p><p></p></div>')
        # :parent returns elements that have children
        parents = d('p:parent')
        assert len(parents) == 1

    def test_empty_pseudo(self):
        d = pq('<div><p></p><p>not empty</p></div>')
        empties = d('p:empty')
        assert len(empties) == 1

    def test_contains_function(self):
        d = pq('<div><p>Hello World</p><p>Goodbye</p></div>')
        result = d('p:contains("Hello")')
        assert len(result) == 1
        assert result.text() == 'Hello World'


# ---------------------------------------------------------------------------
# 4. DOM Traversal
# ---------------------------------------------------------------------------

class TestDOMTraversal:
    def test_find(self, d):
        spans = d('#main').find('span')
        assert len(spans) >= 1

    def test_children(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        assert len(d('div').children()) == 2

    def test_children_with_selector(self):
        d = pq('<div><p class="a">1</p><p class="b">2</p></div>')
        assert len(d('div').children('.a')) == 1

    def test_parent(self):
        d = pq('<div><p>Hello</p></div>')
        assert d('p').parent()[0].tag == 'div'

    def test_parent_with_selector(self, d):
        result = d('li').parent('#list')
        assert len(result) == 1

    def test_parents(self):
        d = pq('<div><p><span>Hello</span></p></div>')
        parents = d('span').parents()
        assert len(parents) >= 2  # p, div, and possibly body, html - depends on parser

    def test_parents_with_selector(self):
        d = pq('<div class="outer"><div class="inner"><span>Hello</span></div></div>')
        result = d('span').parents('.outer')
        assert len(result) == 1

    def test_siblings(self):
        d = pq('<div><p class="a">1</p><p class="b">2</p><p class="c">3</p></div>')
        siblings = d('p.b').siblings()
        assert len(siblings) == 2

    def test_siblings_with_selector(self):
        d = pq('<div><p class="a">1</p><p class="b">2</p><p class="c">3</p></div>')
        result = d('p.b').siblings('.a')
        assert len(result) == 1

    def test_next(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        assert d('p:first').next().text() == '2'

    def test_next_with_selector(self):
        d = pq('<div><p class="a">1</p><p class="b">2</p><p class="c">3</p></div>')
        result = d('p.a').next('.b')
        assert len(result) == 1

    def test_prev(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        assert d('p:last').prev().text() == '1'

    def test_next_all(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        result = d('p:first').next_all()
        assert len(result) == 2

    def test_prev_all(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        result = d('p:last').prev_all()
        assert len(result) == 2

    def test_next_until(self):
        d = pq('<div><p class="a">1</p><p>2</p><p class="b">3</p><p>4</p></div>')
        result = d('p.a').next_until('p.b')
        assert len(result) == 1

    def test_prev_until(self):
        d = pq('<div><p class="a">1</p><p>2</p><p class="b">3</p></div>')
        result = d('p.b').prev_until('p.a')
        assert len(result) == 1

    def test_closest(self):
        d = pq('<div class="outer"><div class="inner"><span>Hi</span></div></div>')
        result = d('span').closest('.outer')
        assert len(result) == 1
        assert 'outer' in result.attr('class')

    def test_closest_self(self):
        d = pq('<div class="match"><span>Hi</span></div>')
        result = d('div').closest('.match')
        assert len(result) == 1

    def test_eq(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        assert d('p').eq(0).text() == '1'
        assert d('p').eq(1).text() == '2'
        assert d('p').eq(2).text() == '3'
        assert d('p').eq(-1).text() == '3'

    def test_eq_out_of_range(self):
        d = pq('<div><p>1</p></div>')
        assert len(d('p').eq(10)) == 0

    def test_items(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        items = list(d('p').items())
        assert len(items) == 2
        assert all(isinstance(item, pq) for item in items)

    def test_length_property(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        assert d('p').length == 2

    def test_size_method(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        assert d('p').size() == 2

    def test_end(self):
        d = pq('<div><p>Hello</p></div>')
        p = d('p')
        assert p.end() is d


# ---------------------------------------------------------------------------
# 5. Filtering
# ---------------------------------------------------------------------------

class TestFiltering:
    def test_filter_by_selector(self, simple):
        result = simple('p').filter('.a')
        assert len(result) == 1
        assert result.text() == 'Hello'

    def test_filter_by_callable(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        result = d('p').filter(lambda i: i < 2)
        assert len(result) == 2

    def test_not_(self, simple):
        result = simple('p').not_('.a')
        assert len(result) == 1
        assert result.text() == 'World'

    def test_is_true(self, simple):
        assert simple('p').is_('.a') is True

    def test_is_false(self, simple):
        assert simple('p').is_('.nonexistent') is False

    def test_is_empty(self):
        d = pq('<div></div>')
        assert d('span').is_('.anything') is False


# ---------------------------------------------------------------------------
# 6. Attributes
# ---------------------------------------------------------------------------

class TestAttributes:
    def test_attr_get(self, d):
        assert d('#main').attr('id') == 'main'

    def test_attr_set(self):
        d = pq('<div></div>')
        d('div').attr('data-test', 'value')
        assert d('div').attr('data-test') == 'value'

    def test_attr_set_kwargs(self):
        d = pq('<div></div>')
        d('div').attr(data_test='value')
        # Note: data_test gets set as data_test (underscore)
        assert d('div').attr('data_test') == 'value'

    def test_attr_remove_none(self):
        d = pq('<div id="test"></div>')
        d('div').attr('id', None)
        assert d('div').attr('id') is None

    def test_attr_missing(self):
        d = pq('<div></div>')
        assert d('div').attr('nonexistent') is None

    def test_remove_attr(self):
        d = pq('<div class="test" id="myid"></div>')
        d('div').remove_attr('id')
        assert d('div').attr('id') is None
        assert d('div').attr('class') == 'test'

    def test_remove_attr_camel(self):
        d = pq('<div id="test"></div>')
        d('div').removeAttr('id')
        assert d('div').attr('id') is None

    def test_has_class_true(self):
        d = pq('<div class="foo bar">Hello</div>')
        assert d('div').has_class('foo') is True
        assert d('div').has_class('bar') is True

    def test_has_class_false(self):
        d = pq('<div class="foo">Hello</div>')
        assert d('div').has_class('bar') is False

    def test_add_class(self):
        d = pq('<div>Hello</div>')
        d('div').add_class('foo')
        assert d('div').has_class('foo')

    def test_add_class_multiple(self):
        d = pq('<div>Hello</div>')
        d('div').add_class('foo bar')
        assert d('div').has_class('foo')
        assert d('div').has_class('bar')

    def test_remove_class(self):
        d = pq('<div class="foo bar">Hello</div>')
        d('div').remove_class('foo')
        assert not d('div').has_class('foo')
        assert d('div').has_class('bar')

    def test_toggle_class_add(self):
        d = pq('<div>Hello</div>')
        d('div').toggle_class('foo')
        assert d('div').has_class('foo')

    def test_toggle_class_remove(self):
        d = pq('<div class="foo">Hello</div>')
        d('div').toggle_class('foo')
        assert not d('div').has_class('foo')

    def test_attr_flexible_element(self):
        d = pq('<div id="test">Hello</div>')
        # FlexibleElement should work for get
        result = d('div').attr('id')
        assert result == 'test'

    def test_width_get(self):
        d = pq('<img width="100"/>')
        assert d('img').width() == '100'

    def test_width_set(self):
        d = pq('<img/>')
        d('img').width('200')
        assert d('img').attr('width') == '200'

    def test_height_get(self):
        d = pq('<img height="50"/>')
        assert d('img').height() == '50'


# ---------------------------------------------------------------------------
# 7. CSS Styles
# ---------------------------------------------------------------------------

class TestCSSStyles:
    def test_css_get(self):
        d = pq('<div style="color: red; font-size: 12px">Hello</div>')
        assert d('div').css('color') == 'red'

    def test_css_set(self):
        d = pq('<div>Hello</div>')
        d('div').css('color', 'blue')
        assert d('div').css('color') == 'blue'

    def test_css_set_dict(self):
        d = pq('<div>Hello</div>')
        d('div').css({'color': 'red', 'font-size': '14px'})
        assert d('div').css('color') == 'red'
        assert d('div').css('font-size') == '14px'

    def test_hide(self):
        d = pq('<div>Hello</div>')
        d('div').hide()
        assert d('div').css('display') == 'none'

    def test_show(self):
        d = pq('<div style="display: none">Hello</div>')
        d('div').show()
        assert d('div').css('display') == 'block'


# ---------------------------------------------------------------------------
# 8. HTML Content
# ---------------------------------------------------------------------------

class TestHTMLContent:
    def test_text_get(self):
        d = pq('<div><p>Hello</p></div>')
        assert d('p').text() == 'Hello'

    def test_text_set(self):
        d = pq('<div><p>Old</p></div>')
        d('p').text('New')
        assert d('p').text() == 'New'

    def test_html_get(self):
        d = pq('<div><p>Hello</p></div>')
        assert d('div').html() == '<p>Hello</p>'

    def test_html_set(self):
        d = pq('<div></div>')
        d('div').html('<p>Hello</p>')
        assert d('div').find('p').text() == 'Hello'

    def test_outer_html(self):
        d = pq('<div><p>Hello</p></div>')
        outer = d('p').outer_html()
        assert '<p>' in outer
        assert 'Hello' in outer

    def test_outer_html_camel(self):
        d = pq('<div><p>Hello</p></div>')
        outer = d('p').outerHtml()
        assert 'Hello' in outer

    def test_val_input(self):
        d = pq('<input type="text" value="hello"/>')
        assert d('input').val() == 'hello'

    def test_val_set(self):
        d = pq('<input type="text" value=""/>')
        d('input').val('world')
        assert d('input').val() == 'world'

    def test_val_textarea(self):
        d = pq('<textarea>content</textarea>')
        assert d('textarea').val() == 'content'

    def test_val_select(self):
        d = pq('<select><option value="a" selected="selected">A</option><option value="b">B</option></select>')
        assert d('select').val() == 'a'

    def test_val_select_default(self):
        d = pq('<select><option value="a">A</option><option value="b">B</option></select>')
        assert d('select').val() == 'a'

    def test_val_set_select(self):
        d = pq('<select><option value="a">A</option><option value="b">B</option></select>')
        d('select').val('b')
        assert d('select').val() == 'b'

    def test_text_multiple_elements(self):
        d = pq('<div><p>Hello</p><p>World</p></div>')
        # When multiple elements, text joins with space
        text = d('p').text()
        assert 'Hello' in text
        assert 'World' in text

    def test_empty_text(self):
        d = pq('<div></div>')
        assert d('span').text() == ''


# ---------------------------------------------------------------------------
# 9. DOM Manipulation
# ---------------------------------------------------------------------------

class TestDOMManipulation:
    def test_append(self):
        d = pq('<div></div>')
        d('div').append('<p>Hello</p>')
        assert d('div').find('p').text() == 'Hello'

    def test_append_to(self):
        d = pq('<div></div>')
        pq('<p>Hello</p>').append_to(d('div'))
        assert d('div').find('p').text() == 'Hello'

    def test_prepend(self):
        d = pq('<div><p>World</p></div>')
        d('div').prepend('<p>Hello</p>')
        assert d('p:first').text() == 'Hello'

    def test_prepend_to(self):
        d = pq('<div><p>World</p></div>')
        pq('<span>Hello</span>').prepend_to(d('div'))
        assert d('div').children().eq(0)[0].tag == 'span'

    def test_after(self):
        d = pq('<div><p>Hello</p></div>')
        d('p').after('<span>World</span>')
        assert d('p + span').text() == 'World'

    def test_before(self):
        d = pq('<div><p>Hello</p></div>')
        d('p').before('<span>World</span>')
        assert d('span + p').text() == 'Hello'

    def test_insert_after(self):
        d = pq('<div><p>Hello</p></div>')
        pq('<span>World</span>').insert_after(d('p'))
        assert d('p + span').text() == 'World'

    def test_insert_before(self):
        d = pq('<div><p>Hello</p></div>')
        pq('<span>World</span>').insert_before(d('p'))
        assert d('span + p').text() == 'Hello'

    def test_remove(self):
        d = pq('<div><p>Hello</p><span>World</span></div>')
        d('p').remove()
        assert len(d('p')) == 0
        assert d('span').text() == 'World'

    def test_empty(self):
        d = pq('<div><p>Hello</p></div>')
        d('div').empty()
        assert d('div').html() == ''

    def test_clone(self):
        d = pq('<div><p>Hello</p></div>')
        cloned = d('p').clone()
        assert cloned.text() == 'Hello'
        # Modify original
        d('p').text('Changed')
        # Clone should not be affected
        assert cloned.text() == 'Hello'

    def test_wrap(self):
        d = pq('<div><p>Hello</p></div>')
        d('p').wrap('<div class="wrapper"/>')
        assert len(d('div.wrapper')) == 1

    def test_wrap_all(self):
        d = pq('<div><p>Hello</p><p>World</p></div>')
        d('p').wrap_all('<div class="wrapper"/>')
        assert len(d('div.wrapper')) == 1
        assert len(d('div.wrapper p')) == 2

    def test_replace_with(self):
        d = pq('<div><p>Hello</p></div>')
        d('p').replace_with('<span>World</span>')
        assert len(d('p')) == 0
        assert d('span').text() == 'World'

    def test_replace_all(self):
        d = pq('<div><p>Hello</p><p>World</p></div>')
        pq('<span>New</span>').replace_all(d('p'))
        assert len(d('p')) == 0
        assert len(d('span')) == 2


# ---------------------------------------------------------------------------
# 10. Each / Map
# ---------------------------------------------------------------------------

class TestEachMap:
    def test_each(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        results = []
        d('p').each(lambda i, e: results.append(i))
        assert results == [0, 1]

    def test_each_break_on_false(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        results = []

        def collector(i, e):
            results.append(i)
            if i == 1:
                return False

        d('p').each(collector)
        assert results == [0, 1]

    def test_map(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        result = d('p').map(lambda i, e: pq(e).text())
        assert result == ['1', '2']

    def test_map_returns_list(self):
        d = pq('<div><p>a</p><p>b</p></div>')
        result = d('p').map(lambda i, e: [i, pq(e).text()])
        assert result == [0, 'a', 1, 'b']


# ---------------------------------------------------------------------------
# 11. Form Serialization
# ---------------------------------------------------------------------------

class TestFormSerialization:
    def test_serialize_basic(self, d):
        result = d('#form1').serialize()
        assert 'username=alice' in result
        assert 'bio=Hello%20World' in result or 'bio=Hello' in result

    def test_serialize_array(self, d):
        result = d('#form1').serialize_array()
        assert isinstance(result, list)
        names = [item['name'] for item in result]
        assert 'username' in names

    def test_serialize_pairs(self, d):
        result = d('#form1').serialize_pairs()
        assert isinstance(result, list)
        names = [p[0] for p in result]
        assert 'username' in names

    def test_serialize_dict(self, d):
        result = d('#form1').serialize_dict()
        assert 'username' in result
        assert result['username'] == 'alice'

    def test_serialize_excludes_submit(self, d):
        result = d('#form1').serialize_pairs()
        names = [p[0] for p in result]
        assert 'Submit' not in names

    def test_serialize_excludes_unchecked(self):
        d = pq('<form><input type="checkbox" name="x" value="1"/></form>')
        result = d('form').serialize_pairs()
        names = [p[0] for p in result]
        assert 'x' not in names

    def test_serialize_includes_checked(self, d):
        result = d('#form1').serialize_pairs()
        names = [p[0] for p in result]
        assert 'remember' in names

    def test_serialize_radio(self, d):
        result = d('#form1').serialize_pairs()
        gender_vals = [p[1] for p in result if p[0] == 'gender']
        assert 'male' in gender_vals

    def test_serialize_select(self, d):
        result = d('#form1').serialize_dict()
        assert result.get('country') == 'us'

    def test_serialize_textarea(self, d):
        result = d('#form1').serialize_dict()
        bio = result.get('bio', '')
        assert 'Hello' in bio

    def test_serialize_excludes_disabled(self):
        d = pq('<form><input name="x" value="1" disabled="disabled"/></form>')
        result = d('form').serialize_pairs()
        assert len(result) == 0

    def test_serialize_password_excluded_from_array(self):
        # password SHOULD be included in serialization
        d = pq('<form><input type="password" name="pwd" value="secret"/></form>')
        result = d('form').serialize_pairs()
        names = [p[0] for p in result]
        assert 'pwd' in names

    def test_serialize_empty_form(self):
        d = pq('<form></form>')
        assert d('form').serialize() == ''
        assert d('form').serialize_array() == []
        assert d('form').serialize_pairs() == []


# ---------------------------------------------------------------------------
# 12. Namespace Support
# ---------------------------------------------------------------------------

class TestNamespace:
    def test_remove_namespaces(self):
        xml = '<root xmlns="http://example.com"><item>value</item></root>'
        d = pq(xml, parser='xml')
        d.remove_namespaces()
        assert d('item').text() == 'value'

    def test_xhtml_to_html(self):
        xhtml = '<html xmlns="http://www.w3.org/1999/xhtml"><body><p>test</p></body></html>'
        d = pq(xhtml, parser='xml')
        d.xhtml_to_html()
        # After conversion, should be able to find p without namespace
        assert len(d('p')) >= 0  # Just check no error


# ---------------------------------------------------------------------------
# 13. fromstring function
# ---------------------------------------------------------------------------

class TestFromstring:
    def test_fromstring_html(self):
        elements = fromstring('<div><p>Hello</p></div>')
        assert len(elements) > 0

    def test_fromstring_xml(self):
        elements = fromstring('<root><item>val</item></root>', parser='xml')
        assert len(elements) == 1

    def test_fromstring_bytes(self):
        elements = fromstring(b'<div>Hello</div>')
        assert len(elements) > 0

    def test_fromstring_fragments(self):
        elements = fromstring('<p>Hello</p><span>World</span>', parser='html_fragments')
        tags = [el.tag for el in elements if hasattr(el, 'tag')]
        assert 'p' in tags or len(elements) > 0


# ---------------------------------------------------------------------------
# 14. CamelCase Aliases
# ---------------------------------------------------------------------------

class TestCamelCaseAliases:
    def test_add_class_camel(self):
        d = pq('<div>Hello</div>')
        d('div').addClass('foo')
        assert d('div').has_class('foo')

    def test_remove_class_camel(self):
        d = pq('<div class="foo">Hello</div>')
        d('div').removeClass('foo')
        assert not d('div').has_class('foo')

    def test_has_class_camel(self):
        d = pq('<div class="foo">Hello</div>')
        assert d('div').hasClass('foo')

    def test_toggle_class_camel(self):
        d = pq('<div>Hello</div>')
        d('div').toggleClass('foo')
        assert d('div').has_class('foo')

    def test_next_all_camel(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        result = d('p:first').nextAll()
        assert len(result) == 2

    def test_prev_all_camel(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        result = d('p:last').prevAll()
        assert len(result) == 2

    def test_append_to_camel(self):
        d = pq('<div></div>')
        pq('<p>Hello</p>').appendTo(d('div'))
        assert d('p').text() == 'Hello'

    def test_prepend_to_camel(self):
        d = pq('<div><p>World</p></div>')
        pq('<span>Hello</span>').prependTo(d('div'))
        assert d('div').children().eq(0)[0].tag == 'span'

    def test_replace_with_camel(self):
        d = pq('<div><p>Old</p></div>')
        d('p').replaceWith('<span>New</span>')
        assert d('span').text() == 'New'

    def test_insert_after_camel(self):
        d = pq('<div><p>Hello</p></div>')
        pq('<span>World</span>').insertAfter(d('p'))
        assert d('p + span').text() == 'World'

    def test_insert_before_camel(self):
        d = pq('<div><p>Hello</p></div>')
        pq('<span>World</span>').insertBefore(d('p'))
        assert len(d('span')) == 1

    def test_serialize_array_camel(self):
        d = pq('<form><input name="a" value="1"/></form>')
        result = d('form').serializeArray()
        assert len(result) == 1

    def test_serialize_pairs_camel(self):
        d = pq('<form><input name="a" value="1"/></form>')
        result = d('form').serializePairs()
        assert result == [('a', '1')]

    def test_serialize_dict_camel(self):
        d = pq('<form><input name="a" value="1"/></form>')
        result = d('form').serializeDict()
        assert result['a'] == '1'

    def test_wrap_all_camel(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        d('p').wrapAll('<div class="wrapper"/>')
        assert len(d('div.wrapper')) == 1

    def test_outer_html_camel(self):
        d = pq('<div><p>Hello</p></div>')
        assert 'Hello' in d('p').outerHtml()

    def test_next_until_camel(self):
        d = pq('<div><p class="a">1</p><p>2</p><p class="b">3</p></div>')
        result = d('p.a').nextUntil('p.b')
        assert len(result) == 1

    def test_prev_until_camel(self):
        d = pq('<div><p class="a">1</p><p>2</p><p class="b">3</p></div>')
        result = d('p.b').prevUntil('p.a')
        assert len(result) == 1

    def test_remove_attr_camel(self):
        d = pq('<div id="test">Hello</div>')
        d('div').removeAttr('id')
        assert d('div').attr('id') is None

    def test_replace_all_camel(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        pq('<span>New</span>').replaceAll(d('p'))
        assert len(d('p')) == 0


# ---------------------------------------------------------------------------
# 15. String Representation
# ---------------------------------------------------------------------------

class TestStringRepresentation:
    def test_repr(self):
        d = pq('<div><p>Hello</p></div>')
        r = repr(d('p'))
        assert '<p>' in r

    def test_str(self):
        d = pq('<div><p>Hello</p></div>')
        s = str(d('p'))
        assert 'Hello' in s

    def test_html_method(self):
        d = pq('<div><p>Hello</p></div>')
        h = d('p').__html__()
        assert 'Hello' in h

    def test_repr_with_class(self):
        d = pq('<div class="foo bar">Hello</div>')
        r = repr(d('div'))
        assert 'foo' in r


# ---------------------------------------------------------------------------
# 16. Root and Encoding
# ---------------------------------------------------------------------------

class TestRootAndEncoding:
    def test_root_property(self):
        d = pq('<div>Hello</div>')
        assert d.root is not None

    def test_encoding_property(self):
        d = pq('<div>Hello</div>')
        # encoding may be None or a string
        enc = d.encoding
        assert enc is None or isinstance(enc, str)

    def test_base_url_default(self):
        d = pq('<div>Hello</div>')
        assert d.base_url is None


# ---------------------------------------------------------------------------
# 17. Edge Cases
# ---------------------------------------------------------------------------

class TestEdgeCases:
    def test_empty_pyquery(self):
        d = pq('<div></div>')
        assert d('span').text() == ''
        assert d('span').html() is None

    def test_chaining(self):
        d = pq('<div><p class="a">Hello</p><p class="b">World</p></div>')
        result = d('p').filter('.a').text()
        assert result == 'Hello'

    def test_add_operator(self):
        d = pq('<div><p class="a">1</p><p class="b">2</p></div>')
        a = d('p.a')
        b = d('p.b')
        combined = a + b
        assert len(combined) == 2

    def test_multiple_append(self):
        d = pq('<div></div>')
        d('div').append('<p>1</p>').append('<p>2</p>')
        assert len(d('p')) == 2

    def test_nested_find(self):
        d = pq('<div><ul><li><span>Text</span></li></ul></div>')
        result = d('div').find('span')
        assert result.text() == 'Text'

    def test_not_method(self):
        d = pq('<div><p class="a">1</p><p class="b">2</p><p class="c">3</p></div>')
        result = d('p').not_('.b')
        assert len(result) == 2

    def test_filter_keeps_order(self):
        d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        texts = d('p').filter(lambda i: i % 2 == 0).map(lambda i, e: pq(e).text())
        assert texts == ['1', '3']

    def test_contents(self):
        d = pq('<div>text<p>elem</p>tail</div>')
        contents = d('div').contents()
        assert len(contents) > 0

    def test_val_empty_select(self):
        d = pq('<select></select>')
        val = d('select').val()
        assert val is None or val == ''

    def test_form_with_multiple_select(self):
        d = pq('<form><select name="colors" multiple="multiple">'
               '<option value="red" selected="selected">Red</option>'
               '<option value="blue" selected="selected">Blue</option>'
               '</select></form>')
        pairs = d('form').serialize_pairs()
        vals = [v for n, v in pairs if n == 'colors']
        assert 'red' in vals
        assert 'blue' in vals

    def test_attr_returns_none_for_empty(self):
        d = pq('<div></div>')
        assert d('p').attr('class') is None

    def test_xhtml_to_html_noop(self):
        d = pq('<div>Hello</div>')
        result = d.xhtml_to_html()
        assert result is not None

    def test_remove_namespaces_noop(self):
        d = pq('<div>Hello</div>')
        result = d.remove_namespaces()
        assert result is not None

    def test_css_none_removes(self):
        d = pq('<div style="color: red; font-size: 12px">Hello</div>')
        d('div').css('color', None)
        assert d('div').css('color') is None

    def test_make_links_absolute_no_base(self):
        d = pq('<div><a href="/path">Link</a></div>')
        result = d.make_links_absolute()
        # Without base_url, should not change
        assert result is not None

    def test_pyquery_fn_custom_method(self):
        def greet():
            return 'Hello from fn'
        pq.fn.greet = greet
        d = pq('<div>Hello</div>')
        assert d('div').greet() == 'Hello from fn'

    def test_end_returns_no_default_initially(self):
        d = pq('<div>Hello</div>')
        # end() on a root PyQuery returns _parent which is no_default
        parent = d.end()
        assert parent is no_default


# ---------------------------------------------------------------------------
# 18. Additional Selectors
# ---------------------------------------------------------------------------

class TestAdditionalSelectors:
    def test_selected_pseudo(self):
        d = pq('<select><option selected="selected">A</option><option>B</option></select>')
        assert len(d(':selected')) == 1

    def test_disabled_input(self):
        d = pq('<form><input disabled="disabled"/><input/></form>')
        assert len(d(':disabled')) == 1

    def test_enabled_input(self):
        d = pq('<form><input disabled="disabled"/><input/></form>')
        assert len(d(':enabled')) == 1

    def test_not_selector_css(self):
        d = pq('<div><p class="a">1</p><p>2</p></div>')
        result = d('p:not(.a)')
        assert len(result) == 1
        assert result.text() == '2'

    def test_first_child_selector(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        result = d('p:first-child')
        assert result.text() == '1'

    def test_last_child_selector(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        result = d('p:last-child')
        assert result.text() == '2'


# ---------------------------------------------------------------------------
# 19. JQueryTranslator
# ---------------------------------------------------------------------------

class TestJQueryTranslator:
    def test_translator_instance(self):
        t = JQueryTranslator()
        assert t is not None

    def test_css_to_xpath_basic(self):
        t = JQueryTranslator()
        xpath = t.css_to_xpath('div.foo')
        assert 'div' in xpath

    def test_css_to_xpath_id(self):
        t = JQueryTranslator()
        xpath = t.css_to_xpath('#myid')
        assert 'myid' in xpath


# ---------------------------------------------------------------------------
# 20. Parser Options
# ---------------------------------------------------------------------------

class TestParserOptions:
    def test_default_html_parser(self):
        d = pq('<div>Hello</div>')
        assert d('div').text() == 'Hello'

    def test_xml_parser_basic(self):
        d = pq('<root><child>val</child></root>', parser='xml')
        assert d('child').text() == 'val'

    def test_html_fragments_parser(self):
        elements = fromstring('<p>Hello</p><p>World</p>', parser='html_fragments')
        assert len(elements) >= 1

    def test_soup_parser(self):
        try:
            from lxml.html import soupparser
            d = pq('<div><p>Hello</p></div>', parser='soup')
            assert 'Hello' in d.text()
        except ImportError:
            pytest.skip("soup parser not available")


# ---------------------------------------------------------------------------
# 21. Functional Tests
# ---------------------------------------------------------------------------

class TestFunctional:
    def test_scrape_like_usage(self):
        html = '''
        <html>
        <body>
          <div class="product" id="p1">
            <h2 class="name">Product 1</h2>
            <span class="price">$10.00</span>
          </div>
          <div class="product" id="p2">
            <h2 class="name">Product 2</h2>
            <span class="price">$20.00</span>
          </div>
        </body>
        </html>
        '''
        d = pq(html)
        products = d('.product')
        assert len(products) == 2

        names = products.find('.name').map(lambda i, e: pq(e).text())
        assert names == ['Product 1', 'Product 2']

        prices = products.find('.price').map(lambda i, e: pq(e).text())
        assert '$10.00' in prices
        assert '$20.00' in prices

    def test_form_processing(self):
        html = '''
        <form action="/submit" method="post">
          <input type="hidden" name="csrf" value="token123"/>
          <input type="text" name="email" value="user@example.com"/>
          <input type="checkbox" name="agree" value="yes" checked="checked"/>
          <select name="plan">
            <option value="free">Free</option>
            <option value="pro" selected="selected">Pro</option>
          </select>
          <textarea name="message">Hello there</textarea>
          <input type="submit" value="Send"/>
        </form>
        '''
        d = pq(html)
        data = d('form').serialize_dict()
        assert data['csrf'] == 'token123'
        assert data['email'] == 'user@example.com'
        assert data['agree'] == 'yes'
        assert data['plan'] == 'pro'
        assert 'Hello there' in data['message']

    def test_dom_building(self):
        d = pq('<ul></ul>')
        for i in range(5):
            d('ul').append('<li>Item %d</li>' % i)
        assert len(d('li')) == 5

    def test_chain_operations(self):
        d = pq('<div><p class="a">Hello</p><p class="b">World</p></div>')
        # Chain: find all p, filter to .a, get text
        result = d('div').children('p').filter('.a').text()
        assert result == 'Hello'

    def test_modify_and_extract(self):
        d = pq('<div><p>Original</p></div>')
        d('p').text('Modified').add_class('changed')
        assert d('p.changed').text() == 'Modified'


# ---------------------------------------------------------------------------
# 22. Text Extraction
# ---------------------------------------------------------------------------

class TestTextExtraction:
    def test_nested_text(self):
        d = pq('<div><p>Hello <strong>World</strong></p></div>')
        text = d('p').text()
        assert 'Hello' in text
        assert 'World' in text

    def test_text_with_br(self):
        d = pq('<div>Line1<br/>Line2</div>')
        text = d('div').text()
        assert 'Line1' in text
        assert 'Line2' in text

    def test_plain_text(self):
        d = pq('<p>Simple text</p>')
        assert d('p').text() == 'Simple text'

    def test_whitespace_normalization(self):
        d = pq('<p>   Hello   World   </p>')
        text = d('p').text()
        assert 'Hello' in text
        assert 'World' in text


# ---------------------------------------------------------------------------
# 23. FlexibleElement
# ---------------------------------------------------------------------------

class TestFlexibleElement:
    def test_attr_flexible_get(self):
        d = pq('<div id="test" class="foo">Hello</div>')
        assert d('div').attr('id') == 'test'

    def test_attr_del(self):
        d = pq('<div id="test">Hello</div>')
        del d('div').attr['id']
        assert d('div').attr('id') is None

    def test_attr_set_via_descriptor(self):
        d = pq('<div>Hello</div>')
        d('div').attr['class'] = 'new-class'
        assert d('div').attr('class') == 'new-class'


# ---------------------------------------------------------------------------
# 24. Extend and Add
# ---------------------------------------------------------------------------

class TestExtendAndAdd:
    def test_extend(self):
        d = pq('<div><p>1</p><p>2</p></div>')
        p1 = d('p:first')
        p2 = d('p:last')
        p1.extend(p2)
        assert len(p1) == 2

    def test_add_operator(self):
        d = pq('<div><p class="a">1</p><p class="b">2</p></div>')
        combined = d('p.a') + d('p.b')
        assert len(combined) == 2
