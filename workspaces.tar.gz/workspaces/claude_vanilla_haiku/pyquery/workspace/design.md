# PyQuery Design Document

## Architecture

The PyQuery library is organized into four modules:

| Module | Purpose |
|---|---|
| `pyquery/cssselectpatch.py` | CSS-to-XPath translation, jQuery pseudo-classes, `FlexibleElement`, `NoDefault`, decorator helpers |
| `pyquery/openers.py` | URL fetching (`url_opener`), HTML/XML parsing (`fromstring`) |
| `pyquery/text.py` | Intelligent text extraction respecting inline vs block tag semantics |
| `pyquery/pyquery.py` | `PyQuery` class with the full jQuery-like API |

## Assumptions

1. **`attr` descriptor behavior**: The `FlexibleElement` descriptor on `attr` allows `d.attr('id')`, `d.attr['id']`, and `d.attr.id` to all call the underlying getter. When the descriptor's `__set__` is triggered (e.g. `d('div').attr['class'] = 'foo'`), it delegates to the setter form of `attr`. The `pdel` slot maps to `remove_attr`.

2. **`filter()` with callables**: When `filter(lambda i: ...)` is passed a one-argument lambda, the argument is assumed to be the element index. When `filter(lambda i, this: ...)` is passed a two-argument lambda, arguments are index and element. The global `this` is injected in both cases for consistency with `each()` and `map()`.

3. **`text()` whitespace behavior**: By default (`squash_space=True`), consecutive whitespace characters (including newlines from block-level elements) are collapsed into a single space or newline. The `squash_space=False` option preserves whitespace as-is in the text nodes.

4. **`html()` method behavior**: The `html()` getter returns the inner HTML of the first element as a string. The method=`html` kwarg is passed through to `lxml.etree.tostring` for XHTML-compatible output. When setting HTML, a temporary `<div>` wrapper is used to parse the fragment.

5. **Parser auto-selection**: When no `parser` kwarg is provided and the context is an HTML string, the `html` parser is used (via `lxml.html.document_fromstring`). XML strings require explicit `parser='xml'`.

6. **`url_opener` signature**: The spec shows two signatures (`url_opener(url, timeout, headers, **kwargs)` and `url_opener(url, kwargs)`). We implement the `url_opener(url, kwargs={})` form that accepts a dict, since PyQuery's `__init__` calls it as `url_opener(url, kwargs)`.

7. **`wrap()` return value**: `wrap()` modifies the DOM in-place and returns `self` (the wrapped elements, now children of the new wrapper). To get the wrapper element, use `.parent()`.

8. **`serialize_pairs` filtering**: Follows jQuery rules: excluded are elements with no `name`, `disabled` elements, elements inside a disabled `fieldset` (unless inside the first `legend`), and `input` types `submit`, `button`, `image`, `reset`, `file`. Unchecked checkboxes and radio buttons are also excluded.

9. **Multiline values in serialization**: textarea and select option values have `\n` normalized to `\r\n` per the HTML form submission spec.

10. **`remove_namespaces()`**: Strips `{namespace}` prefixes from element tags and removes namespace-prefixed attributes. This is a simple string manipulation approach rather than using `lxml`'s `cleanup_namespaces()`.

11. **`contents()` return value**: Returns a Python list containing a mix of text strings and `lxml._Element` objects (representing text nodes and element children). This is consistent with jQuery's `.contents()` which returns text nodes and element nodes.

12. **`end()` with no parent**: When called on a root-level PyQuery object (no `_parent`), `end()` returns `no_default`. This is the expected behavior per the start.md spec.

13. **`__repr__` format**: Follows the `[<tag.class1.class2>, ...]` format as shown in the doctests throughout the spec (e.g. `[<p.hello>]`).

14. **`outer_html()` default method**: Defaults to `method='html'` (using `lxml.html.tostring`) so that HTML5 void elements like `<br>`, `<input>` are rendered without the trailing `/`. Pass `method='xml'` for self-closing tags.

15. **CSS case sensitivity**: In `html` parser mode (default), CSS selectors are case-insensitive for element names (as per HTML spec). In `xml` parser mode, the `JQueryTranslator(xhtml=True)` is used which treats selectors as case-sensitive.
