from setuptools import setup, find_packages

setup(
    name='pyquery',
    version='2.0.2.dev0',
    description='A jquery-like library for python',
    long_description=open('README.rst').read() if __import__('os').path.exists('README.rst') else '',
    author='Olivier Lauzanne',
    author_email='olauzanne@gmail.com',
    url='https://github.com/gawel/pyquery',
    license='BSD',
    packages=find_packages(),
    python_requires='>=3.6',
    install_requires=[
        'lxml>=2.1',
        'cssselect>=1.2.0',
        'requests',
    ],
    extras_require={
        'test': ['pytest', 'webtest', 'webob'],
    },
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: BSD License',
        'Programming Language :: Python :: 3',
        'Topic :: Text Processing :: Markup :: HTML',
        'Topic :: Text Processing :: Markup :: XML',
    ],
)
