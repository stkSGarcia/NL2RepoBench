"""
PyQuery - A jQuery-like library for Python.
"""
from .pyquery import PyQuery
from .cssselectpatch import (
    no_default, NoDefault, JQueryTranslator, FlexibleElement
)
from .openers import url_opener, fromstring

__version__ = '2.0.2.dev0'
__all__ = [
    'PyQuery',
    'no_default',
    'NoDefault',
    'JQueryTranslator',
    'FlexibleElement',
    'url_opener',
    'fromstring',
]
