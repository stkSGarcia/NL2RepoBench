"""
Main PyQuery class - a jQuery-like library for Python.
"""
import inspect
import re
import sys
from copy import deepcopy
from urllib.parse import urlencode, urljoin

from lxml import etree

from .cssselectpatch import (
    JQueryTranslator, no_default, NoDefault,
    FlexibleElement, with_camel_case_alias, build_camel_case_aliases,
    callback, getargspec
)
from .openers import url_opener, fromstring
from .text import extract_text, INLINE_TAGS

basestring = str


class PyQuery(list):
    """
    A jQuery-like class for querying and manipulating HTML/XML documents.

    Basic usage::

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>Hello</p></div>')
        >>> d('p').text()
        'Hello'
    """

    _translator_class = JQueryTranslator

    def __init__(self, *args, **kwargs):
        html = None
        elements = []
        self._base_url = None
        self.parser = kwargs.pop('parser', None)

        if 'parent' in kwargs:
            self._parent = kwargs.pop('parent')
        else:
            self._parent = no_default

        if 'css_translator' in kwargs:
            self._translator = kwargs.pop('css_translator')
        elif self.parser in ('xml',):
            self._translator = self._translator_class(xhtml=True)
        elif self._parent is not no_default:
            self._translator = self._parent._translator
        else:
            self._translator = self._translator_class(xhtml=False)

        self.namespaces = kwargs.pop('namespaces', None)

        if kwargs:
            if 'filename' in kwargs:
                filename = kwargs.pop('filename')
                encoding = kwargs.pop('encoding', 'utf-8')
                html = open(filename, encoding=encoding)
            elif 'url' in kwargs:
                url = kwargs.pop('url')
                if 'opener' in kwargs:
                    opener = kwargs.pop('opener')
                    html = opener(url, **kwargs)
                else:
                    html = url_opener(url, kwargs)
                if not self.parser:
                    self.parser = 'html'
                self._base_url = url
            else:
                raise ValueError('Invalid keyword arguments %s' % kwargs)

            elements = fromstring(html, self.parser)
            if hasattr(html, 'close'):
                try:
                    html.close()
                except Exception:
                    pass
        else:
            selector = context = no_default
            length = len(args)
            if length == 1:
                context = args[0]
            elif length == 2:
                selector, context = args
            elif length == 0:
                pass
            else:
                raise ValueError("You can't do that. Please, provide arguments")

            # If we have a parent and a single string arg, treat as CSS selector
            # applied to the parent's elements
            if (context is not no_default and selector is no_default
                    and isinstance(context, basestring)
                    and self._parent is not no_default):
                # Treat context as selector on parent
                selector = context
                context = self._parent
                # Fall through to selector logic below

            if context is not no_default:
                if isinstance(context, self.__class__):
                    elements = context[:]
                elif isinstance(context, list):
                    elements = context
                elif isinstance(context, etree._Element):
                    elements = [context]
                elif isinstance(context, basestring):
                    try:
                        elements = fromstring(context, self.parser)
                    except Exception:
                        raise
                elif hasattr(context, 'read'):
                    try:
                        elements = fromstring(context.read(), self.parser)
                    except Exception:
                        raise
                else:
                    try:
                        # Try treating it as an element anyway
                        elements = [context]
                    except Exception:
                        raise TypeError("Unsupported context type: %s" % type(context))

                if elements and selector is not no_default:
                    xpath = self._css_to_xpath(selector)
                    results = []
                    for tag in elements:
                        try:
                            results.extend(tag.xpath(xpath, namespaces=self.namespaces or {}))
                        except Exception:
                            pass
                    elements = results

        list.__init__(self, elements)

    def _css_to_xpath(self, selector, prefix='descendant-or-self::'):
        """Convert a CSS selector to XPath expression."""
        return self._translator.css_to_xpath(selector, prefix)

    def _copy(self, *args, **kwargs):
        """Create a copy of this PyQuery with given args, using self as parent."""
        kwargs['parent'] = self
        return self.__class__(*args, **kwargs)

    def __call__(self, *args, **kwargs):
        """Allow calling instance as function to find elements."""
        if not args and not kwargs:
            return self
        return self._copy(*args, **kwargs)

    _append = list.append
    _extend = list.extend

    def __add__(self, other):
        """Combine two PyQuery objects."""
        return self._copy(self[:] + other[:])

    def extend(self, other):
        """Extend list with elements from another PyQuery."""
        list.extend(self, other[:])
        return self

    def items(self, selector=None):
        """Iterate over elements as PyQuery objects.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>a</p><p>b</p></div>')
        >>> [repr(i) for i in d('p').items()]
        ['[<p>]', '[<p>]']
        """
        elems = self
        if selector:
            elems = self(selector)
        for elem in elems:
            yield self._copy(elem)

    def xhtml_to_html(self):
        """Convert XHTML to HTML by removing XHTML namespace.

        >>> from pyquery import PyQuery as pq
        >>> doc = pq('<html xmlns="http://www.w3.org/1999/xhtml"></html>', parser='xml')
        >>> doc.xhtml_to_html()
        [<html>]
        """
        xhtml = 'http://www.w3.org/1999/xhtml'
        prefix = '{%s}' % xhtml
        for tag in self:
            for elem in tag.iter():
                if isinstance(elem.tag, str) and elem.tag.startswith(prefix):
                    elem.tag = elem.tag[len(prefix):]
        return self

    def remove_namespaces(self):
        """Remove all namespaces from elements.

        >>> from pyquery import PyQuery as pq
        >>> doc = pq('<foo xmlns="http://example.com/foo"></foo>', parser='xml')
        >>> doc.remove_namespaces()
        [<foo>]
        """
        for tag in self:
            for elem in tag.iter():
                if isinstance(elem.tag, str) and elem.tag.startswith('{'):
                    elem.tag = re.sub(r'\{[^}]+\}', '', elem.tag)
                for key in list(elem.attrib.keys()):
                    if key.startswith('{'):
                        del elem.attrib[key]
        return self

    def __str__(self):
        """Return string representation of elements."""
        return ''.join(
            [etree.tostring(tag, encoding='unicode') for tag in self]
        )

    def __unicode__(self):
        return self.__str__()

    def __html__(self):
        """Return HTML representation of elements."""
        from lxml import html as lhtml
        return ''.join(
            [lhtml.tostring(tag, encoding='unicode') for tag in self]
        )

    def __repr__(self):
        """Return repr of elements."""
        r = []
        for el in self:
            el_str = el.tag
            if isinstance(el_str, str):
                # Keep namespace prefix as {ns}tag format (matching lxml convention)
                # but strip it for the class suffix
                tag_local = re.sub(r'\{[^}]+\}', '', el_str)
                c = el.get('class', '')
                if c:
                    el_str += '.' + '.'.join(c.split())
                else:
                    el_str = el_str
            r.append('<%s>' % el_str)
        return '[%s]' % ', '.join(r)

    @property
    def root(self):
        """Return root tree of first element."""
        if self:
            return self[0].getroottree()
        return None

    @property
    def encoding(self):
        """Return encoding of document."""
        root = self.root
        if root is not None:
            return root.docinfo.encoding
        return None

    # --- Traversal ---

    def _filter_only(self, selector, elements, reverse=False, unique=False):
        """Filter elements by selector, with optional reverse/unique."""
        if selector is None:
            result = elements
        elif isinstance(selector, str):
            xpath = self._css_to_xpath(selector, prefix='self::')
            result = [el for el in elements
                      if isinstance(el.tag, str) and el.xpath(xpath, namespaces=self.namespaces or {})]
        elif callable(selector):
            result = [el for el in elements if callback(selector, el)]
        else:
            result = elements

        if reverse:
            result = list(reversed(result))
        if unique:
            seen = set()
            unique_result = []
            for el in result:
                el_id = id(el)
                if el_id not in seen:
                    seen.add(el_id)
                    unique_result.append(el)
            result = unique_result
        return self._copy(result)

    def parent(self, selector=None):
        """Return parent element(s).

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>Hello</p></div>')
        >>> d('p').parent()
        [<div>]
        """
        parents = [el.getparent() for el in self if el.getparent() is not None]
        return self._filter_only(selector, parents, unique=True)

    def prev(self, selector=None):
        """Return previous sibling element(s).

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>1</p><p>2</p></div>')
        >>> d('p:last').prev()
        [<p>]
        """
        prevs = [el.getprevious() for el in self if el.getprevious() is not None]
        return self._filter_only(selector, prevs)

    def next(self, selector=None):
        """Return next sibling element(s).

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>1</p><p>2</p></div>')
        >>> d('p:first').next()
        [<p>]
        """
        nexts = [el.getnext() for el in self if el.getnext() is not None]
        return self._filter_only(selector, nexts)

    def _traverse(self, method):
        """Traverse siblings in one direction."""
        for el in self:
            current = getattr(el, method)()
            while current is not None:
                if isinstance(current.tag, str):
                    yield current
                current = getattr(current, method)()

    def _traverse_parent_topdown(self):
        """Traverse all parents from closest to root."""
        for el in self:
            parent = el.getparent()
            while parent is not None:
                yield parent
                parent = parent.getparent()

    def _next_all(self):
        """Get all next siblings."""
        result = []
        for el in self:
            current = el.getnext()
            while current is not None:
                if isinstance(current.tag, str):
                    result.append(current)
                current = current.getnext()
        return result

    @with_camel_case_alias
    def next_all(self, selector=None):
        """Return all next sibling elements.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        >>> d('p:first').next_all()
        [<p>, <p>]
        """
        return self._filter_only(selector, self._next_all())

    @with_camel_case_alias
    def next_until(self, selector, filter_=None):
        """Return all next siblings until selector is matched."""
        result = []
        xpath = self._css_to_xpath(selector, prefix='self::')
        for el in self:
            current = el.getnext()
            while current is not None:
                if isinstance(current.tag, str):
                    if current.xpath(xpath, namespaces=self.namespaces or {}):
                        break
                    result.append(current)
                current = current.getnext()
        if filter_:
            return self._filter_only(filter_, result)
        return self._copy(result)

    def _prev_all(self):
        """Get all previous siblings."""
        result = []
        for el in self:
            current = el.getprevious()
            while current is not None:
                if isinstance(current.tag, str):
                    result.append(current)
                current = current.getprevious()
        return result

    @with_camel_case_alias
    def prev_all(self, selector=None):
        """Return all previous sibling elements.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>1</p><p>2</p><p>3</p></div>')
        >>> d('p:last').prev_all()
        [<p>, <p>]
        """
        return self._filter_only(selector, self._prev_all())

    @with_camel_case_alias
    def prev_until(self, selector, filter_=None):
        """Return all previous siblings until selector is matched."""
        result = []
        xpath = self._css_to_xpath(selector, prefix='self::')
        for el in self:
            current = el.getprevious()
            while current is not None:
                if isinstance(current.tag, str):
                    if current.xpath(xpath, namespaces=self.namespaces or {}):
                        break
                    result.append(current)
                current = current.getprevious()
        if filter_:
            return self._filter_only(filter_, result)
        return self._copy(result)

    def siblings(self, selector=None):
        """Return sibling elements.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>1</p><p class="x">2</p><p>3</p></div>')
        >>> d('p.x').siblings()
        [<p>, <p>]
        """
        result = []
        for el in self:
            parent = el.getparent()
            if parent is not None:
                for child in parent:
                    if child is not el and isinstance(child.tag, str):
                        result.append(child)
        return self._filter_only(selector, result)

    def parents(self, selector=None):
        """Return all ancestor elements.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p><span>Hello</span></p></div>')
        >>> d('span').parents('..')  # doctest: +SKIP
        [<p>, <div>]
        """
        parents = list(self._traverse_parent_topdown())
        return self._filter_only(selector, parents, unique=True)

    def children(self, selector=None):
        """Return child elements.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>1</p><p>2</p></div>')
        >>> d('div').children()
        [<p>, <p>]
        """
        result = []
        for el in self:
            for child in el:
                if isinstance(child.tag, str):
                    result.append(child)
        return self._filter_only(selector, result)

    def closest(self, selector=None):
        """Return the closest ancestor matching selector.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div class="a"><p><span>Hello</span></p></div>')
        >>> d('span').closest('.a')
        [<div.a>]
        """
        if selector is None:
            return self._copy([])
        xpath = self._css_to_xpath(selector, prefix='self::')
        result = []
        for el in self:
            current = el
            while current is not None:
                if isinstance(current.tag, str) and current.xpath(xpath, namespaces=self.namespaces or {}):
                    result.append(current)
                    break
                current = current.getparent()
        return self._copy(result)

    def contents(self):
        """Return all children including text nodes."""
        result = []
        for el in self:
            if el.text:
                result.append(el.text)
            for child in el:
                result.append(child)
                if child.tail:
                    result.append(child.tail)
        return result

    def filter(self, selector):
        """Filter elements matching selector.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p class="a">1</p><p class="b">2</p></div>')
        >>> d('p').filter('.a')
        [<p.a>]
        """
        if isinstance(selector, str):
            xpath = self._css_to_xpath(selector, prefix='self::')
            elements = [el for el in self if el.xpath(xpath, namespaces=self.namespaces or {})]
            return self._copy(elements)
        elif callable(selector):
            elements = []
            for i, el in enumerate(self):
                try:
                    argspec = getargspec(selector)
                    nargs = len(argspec.args)
                    if argspec.varargs is not None:
                        nargs = 2  # pass all
                except TypeError:
                    nargs = 1

                # Inject 'this' global
                if hasattr(selector, '__globals__'):
                    selector.__globals__['this'] = el

                if nargs == 0:
                    result = selector()
                elif nargs == 1:
                    result = selector(i)
                else:
                    result = selector(i, el)

                if result:
                    elements.append(el)
            return self._copy(elements)
        else:
            return self._copy([])

    def not_(self, selector):
        """Return elements not matching selector.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p class="a">1</p><p class="b">2</p></div>')
        >>> d('p').not_('.a')
        [<p.b>]
        """
        if isinstance(selector, str):
            xpath = self._css_to_xpath(selector, prefix='self::')
            elements = [el for el in self if not el.xpath(xpath, namespaces=self.namespaces or {})]
        elif callable(selector):
            elements = []
            for i, el in enumerate(self):
                if hasattr(selector, '__globals__'):
                    selector.__globals__['this'] = el
                result = callback(selector, i, el)
                if not result:
                    elements.append(el)
        else:
            elements = list(self)
        return self._copy(elements)

    def is_(self, selector):
        """Return True if any element matches the selector.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p class="a">1</p></div>')
        >>> d('p').is_('.a')
        True
        """
        if not self:
            return False
        if isinstance(selector, str):
            xpath = self._css_to_xpath(selector, prefix='self::')
            for el in self:
                if el.xpath(xpath, namespaces=self.namespaces or {}):
                    return True
        elif callable(selector):
            for i, el in enumerate(self):
                if callback(selector, i, el):
                    return True
        return False

    def find(self, selector):
        """Find descendant elements matching selector.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p><span>Hello</span></p></div>')
        >>> d('div').find('span')
        [<span>]
        """
        xpath = self._css_to_xpath(selector)
        results = []
        for el in self:
            try:
                results.extend(el.xpath(xpath, namespaces=self.namespaces or {}))
            except Exception:
                pass
        return self._copy(results)

    def eq(self, index):
        """Return element at given index.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>1</p><p>2</p></div>')
        >>> d('p').eq(0)
        [<p>]
        """
        if index < 0:
            if abs(index) > len(self):
                return self._copy([])
            return self._copy([self[index]])
        if index >= len(self):
            return self._copy([])
        return self._copy([self[index]])

    def each(self, func):
        """Call func for each element.

        >>> from pyquery import PyQuery as pq
        >>> results = []
        >>> d = pq('<div><p>1</p><p>2</p></div>')
        >>> _ = d('p').each(lambda i, e: results.append(i))
        >>> results
        [0, 1]
        """
        for i, el in enumerate(self):
            result = callback(func, i, el)
            if result is False:
                break
        return self

    def map(self, func):
        """Apply func to each element and return list of results.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>1</p><p>2</p></div>')
        >>> d('p').map(lambda i, e: i)
        [0, 1]
        """
        results = []
        for i, el in enumerate(self):
            result = callback(func, i, el)
            if isinstance(result, list):
                results.extend(result)
            elif result is not None:
                results.append(result)
        return results

    @property
    def length(self):
        """Return number of elements."""
        return len(self)

    def size(self):
        """Return number of elements."""
        return len(self)

    def end(self):
        """Return parent PyQuery object."""
        return self._parent

    # --- Attributes ---

    def _attr_get_set_del(self, *args, **kwargs):
        """Handle attr get/set/del."""
        if not self:
            if args and len(args) == 1 and not kwargs:
                return None
            return self

        if args:
            if len(args) == 1 and not kwargs:
                # Get
                return self[0].get(args[0])
            elif len(args) == 2:
                name, value = args
                for el in self:
                    if value is None:
                        if name in el.attrib:
                            del el.attrib[name]
                    else:
                        el.set(name, str(value))
                return self

        if kwargs:
            for name, value in kwargs.items():
                for el in self:
                    if value is None:
                        if name in el.attrib:
                            del el.attrib[name]
                    else:
                        el.set(name, str(value))
            return self

        return None

    def attr(self, *args, **kwargs):
        """Get or set element attribute.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div id="test">Hello</div>')
        >>> d('div').attr('id')
        'test'
        """
        return self._attr_get_set_del(*args, **kwargs)

    @with_camel_case_alias
    def remove_attr(self, name):
        """Remove attribute from elements.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div id="test">Hello</div>')
        >>> d('div').remove_attr('id')
        [<div>]
        """
        for el in self:
            if name in el.attrib:
                del el.attrib[name]
        return self

    def _attr_set(self, name, value=no_default):
        """Set attribute - used as pset for FlexibleElement."""
        if value is no_default:
            # Called as pset(instance, value) - value is the name=value dict/string
            if isinstance(name, dict):
                return self._attr_get_set_del(**name)
            return self
        return self._attr_get_set_del(name, value)

    attr = FlexibleElement(pget=attr, pset=_attr_set, pdel=remove_attr)

    def height(self, value=no_default):
        """Get or set height attribute."""
        if value is no_default:
            return self._attr_get_set_del('height')
        return self._attr_get_set_del('height', value)

    def width(self, value=no_default):
        """Get or set width attribute."""
        if value is no_default:
            return self._attr_get_set_del('width')
        return self._attr_get_set_del('width', value)

    @with_camel_case_alias
    def has_class(self, name):
        """Return True if element has class.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div class="a b">Hello</div>')
        >>> d('div').has_class('a')
        True
        """
        return self.is_('.%s' % name)

    @with_camel_case_alias
    def add_class(self, value):
        """Add class to elements.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div>Hello</div>')
        >>> d('div').add_class('test')
        [<div.test>]
        """
        for el in self:
            classes = set(el.get('class', '').split())
            for cls in value.split():
                classes.add(cls)
            el.set('class', ' '.join(sorted(classes)))
        return self

    @with_camel_case_alias
    def remove_class(self, value):
        """Remove class from elements.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div class="a b">Hello</div>')
        >>> d('div').remove_class('a')
        [<div.b>]
        """
        for el in self:
            classes = set(el.get('class', '').split())
            for cls in value.split():
                classes.discard(cls)
            new_class = ' '.join(classes)
            if new_class:
                el.set('class', new_class)
            elif 'class' in el.attrib:
                del el.attrib['class']
        return self

    @with_camel_case_alias
    def toggle_class(self, value):
        """Toggle class on elements."""
        for el in self:
            classes = set(el.get('class', '').split())
            for cls in value.split():
                if cls in classes:
                    classes.discard(cls)
                else:
                    classes.add(cls)
            new_class = ' '.join(classes)
            if new_class:
                el.set('class', new_class)
            elif 'class' in el.attrib:
                del el.attrib['class']
        return self

    def _css_get_set(self, *args, **kwargs):
        """Handle css get/set."""
        if not self:
            return self

        def _parse_style(style_str):
            result = {}
            if not style_str:
                return result
            for item in style_str.split(';'):
                item = item.strip()
                if ':' in item:
                    key, val = item.split(':', 1)
                    result[key.strip()] = val.strip()
            return result

        def _make_style(style_dict):
            return '; '.join('%s: %s' % (k, v) for k, v in style_dict.items() if v)

        if args and len(args) == 1 and isinstance(args[0], dict):
            # Set multiple
            for el in self:
                style = _parse_style(el.get('style', ''))
                style.update(args[0])
                el.set('style', _make_style(style))
            return self
        elif args and len(args) == 1 and isinstance(args[0], str) and not kwargs:
            # Get single
            style = _parse_style(self[0].get('style', ''))
            return style.get(args[0])
        elif args and len(args) == 2:
            prop, value = args
            for el in self:
                style = _parse_style(el.get('style', ''))
                if value is None:
                    style.pop(prop, None)
                else:
                    style[prop] = str(value)
                el.set('style', _make_style(style))
            return self
        elif kwargs:
            for el in self:
                style = _parse_style(el.get('style', ''))
                style.update({k.replace('_', '-'): v for k, v in kwargs.items()})
                el.set('style', _make_style(style))
            return self
        return self

    def css(self, *args, **kwargs):
        """Get or set CSS style.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div style="color: red">Hello</div>')
        >>> d('div').css('color')
        'red'
        """
        return self._css_get_set(*args, **kwargs)

    css = FlexibleElement(pget=css, pset=_css_get_set)

    def hide(self):
        """Hide elements by setting display: none."""
        return self._css_get_set('display', 'none')

    def show(self):
        """Show elements by setting display: block."""
        return self._css_get_set('display', 'block')

    # --- HTML content ---

    def val(self, value=no_default):
        """Get or set form element value.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<input type="text" value="hello"/>')
        >>> d('input').val()
        'hello'
        """
        if not self:
            return None

        def _get_value(tag):
            tag_name = tag.tag.lower() if isinstance(tag.tag, str) else ''
            if tag_name == 'textarea':
                return tag.text_content() if hasattr(tag, 'text_content') else (tag.text or '')
            elif tag_name == 'select':
                multiple = tag.get('multiple') is not None
                options = tag.xpath('.//option[@selected]')
                if multiple:
                    return [opt.get('value', opt.text or '') for opt in options]
                if options:
                    return options[0].get('value', options[0].text or '')
                options = tag.xpath('.//option')
                if options:
                    return options[0].get('value', options[0].text or '')
                return None
            else:
                return tag.get('value')

        def _set_value(pq, value):
            for tag in pq:
                tag_name = tag.tag.lower() if isinstance(tag.tag, str) else ''
                if tag_name == 'textarea':
                    tag.text = value
                elif tag_name == 'select':
                    multiple = tag.get('multiple') is not None
                    if multiple:
                        if not isinstance(value, list):
                            value = [value]
                        for opt in tag.xpath('.//option'):
                            opt_val = opt.get('value', opt.text or '')
                            if opt_val in value:
                                opt.set('selected', 'selected')
                            elif 'selected' in opt.attrib:
                                del opt.attrib['selected']
                    else:
                        for opt in tag.xpath('.//option'):
                            opt_val = opt.get('value', opt.text or '')
                            if opt_val == value:
                                opt.set('selected', 'selected')
                            elif 'selected' in opt.attrib:
                                del opt.attrib['selected']
                else:
                    tag.set('value', str(value) if value is not None else '')

        if value is no_default:
            return _get_value(self[0])
        else:
            _set_value(self, value)
            return self

    def html(self, value=no_default, **kwargs):
        """Get or set inner HTML.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>Hello</p></div>')
        >>> d('div').html()
        '<p>Hello</p>'
        """
        if value is no_default:
            if not self:
                return None
            el = self[0]
            # Get inner HTML
            method = kwargs.get('method', 'html')
            from lxml import html as lhtml
            result = el.text or ''
            for child in el:
                if method == 'xml':
                    result += etree.tostring(child, encoding='unicode', method='xml')
                else:
                    result += lhtml.tostring(child, encoding='unicode', method='html')
                if child.tail:
                    result += child.tail
            return result
        else:
            for el in self:
                # Clear existing children
                for child in list(el):
                    el.remove(child)
                el.text = None
                # Parse new value
                if value:
                    try:
                        new_elements = fromstring('<div>%s</div>' % value, 'html_fragments')
                        # Extract from wrapper
                        if new_elements:
                            wrapper = new_elements[0] if hasattr(new_elements[0], 'tag') else None
                            if wrapper is not None and hasattr(wrapper, 'tag'):
                                tag_name = re.sub(r'\{[^}]+\}', '', str(wrapper.tag)).lower()
                                if tag_name == 'div':
                                    el.text = wrapper.text
                                    for child in wrapper:
                                        el.append(deepcopy(child))
                                else:
                                    for elem in new_elements:
                                        if hasattr(elem, 'tag'):
                                            el.append(deepcopy(elem))
                    except Exception:
                        el.text = value
            return self

    @with_camel_case_alias
    def outer_html(self, method='html'):
        """Return outer HTML of first element.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>Hello</p></div>')
        >>> d('p').outer_html()
        '<p>Hello</p>'
        """
        if not self:
            return ''
        el = self[0]
        # Temporarily remove tail so it's not included in serialization
        old_tail = el.tail
        el.tail = None
        try:
            if method == 'html':
                from lxml import html as lhtml
                result = lhtml.tostring(el, encoding='unicode', method='html')
            else:
                result = etree.tostring(el, encoding='unicode', method=method)
        finally:
            el.tail = old_tail
        return result

    def text(self, value=no_default, **kwargs):
        """Get or set text content.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>Hello</p></div>')
        >>> d('p').text()
        'Hello'
        """
        if value is no_default:
            squash_space = kwargs.get('squash_space', True)
            if not self:
                return ''
            # Extract text from all elements
            parts = []
            for i, el in enumerate(self):
                text = extract_text(el, squash_space=squash_space)
                if text:
                    if i > 0:
                        parts.append(' ')
                    parts.append(text)
            return ''.join(parts)
        else:
            for el in self:
                for child in list(el):
                    el.remove(child)
                el.text = value
            return self

    # --- DOM Manipulation ---

    def _get_root(self, value):
        """Convert value to PyQuery for manipulation."""
        if isinstance(value, PyQuery):
            # If the PyQuery contains document-level elements (html/body), unwrap them
            elements = self._unwrap_doc_elements(list(value))
            return PyQuery(elements), None
        if isinstance(value, etree._Element):
            return PyQuery([value]), None
        if isinstance(value, str):
            try:
                # Use html_fragments to avoid wrapping in full document
                elements = fromstring(value, 'html_fragments')
                # Filter to only element nodes
                elem_only = [el for el in elements if hasattr(el, 'tag') and isinstance(el.tag, str)]
                return PyQuery(elem_only), None
            except Exception:
                return PyQuery([]), None
        return PyQuery([]), None

    def _self_elements(self):
        """Get the actual elements from self, unwrapping document nodes."""
        return self._unwrap_doc_elements(list(self))

    @staticmethod
    def _unwrap_doc_elements(elements):
        """If elements are document-level (html/body), extract body children."""
        result = []
        for el in elements:
            tag = el.tag if isinstance(el.tag, str) else ''
            tag = re.sub(r'\{[^}]+\}', '', tag).lower()
            if tag == 'html':
                # Find body element
                body = None
                for child in el:
                    child_tag = child.tag if isinstance(child.tag, str) else ''
                    child_tag = re.sub(r'\{[^}]+\}', '', child_tag).lower()
                    if child_tag == 'body':
                        body = child
                        break
                if body is None:
                    # Try deeper
                    body = el.find('.//{*}body') or el.find('.//body')
                if body is not None:
                    for child in body:
                        if isinstance(child.tag, str):
                            result.append(child)
                else:
                    result.append(el)
            elif tag == 'body':
                for child in el:
                    if isinstance(child.tag, str):
                        result.append(child)
            else:
                result.append(el)
        return result

    def append(self, value):
        """Append value to each element.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div></div>')
        >>> d('div').append('<p>Hello</p>')
        [<div>]
        """
        root, _ = self._get_root(value)
        for el in self:
            for new_el in root:
                el.append(deepcopy(new_el))
        return self

    @with_camel_case_alias
    def append_to(self, value):
        """Append elements to value."""
        root, _ = self._get_root(value)
        src_elements = self._self_elements()
        for new_el in root:
            for el in src_elements:
                new_el.append(deepcopy(el))
        return self

    def prepend(self, value):
        """Prepend value to each element.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>World</p></div>')
        >>> d('div').prepend('<p>Hello</p>')
        [<div>]
        """
        root, _ = self._get_root(value)
        for el in self:
            for i, new_el in enumerate(root):
                el.insert(i, deepcopy(new_el))
        return self

    @with_camel_case_alias
    def prepend_to(self, value):
        """Prepend elements to value."""
        root, _ = self._get_root(value)
        src_elements = self._self_elements()
        for new_el in root:
            for i, el in enumerate(src_elements):
                new_el.insert(i, deepcopy(el))
        return self

    def after(self, value):
        """Insert value after each element.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>Hello</p></div>')
        >>> d('p').after('<span>World</span>')
        [<p>]
        """
        root, _ = self._get_root(value)
        for el in self:
            parent = el.getparent()
            if parent is not None:
                idx = list(parent).index(el)
                for i, new_el in enumerate(root):
                    parent.insert(idx + 1 + i, deepcopy(new_el))
        return self

    @with_camel_case_alias
    def insert_after(self, value):
        """Insert elements after value."""
        root, _ = self._get_root(value)
        src_elements = self._self_elements()
        for anchor in root:
            parent = anchor.getparent()
            if parent is not None:
                idx = list(parent).index(anchor)
                for i, el in enumerate(src_elements):
                    parent.insert(idx + 1 + i, deepcopy(el))
        return self

    def before(self, value):
        """Insert value before each element.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>Hello</p></div>')
        >>> d('p').before('<span>World</span>')
        [<p>]
        """
        root, _ = self._get_root(value)
        for el in self:
            parent = el.getparent()
            if parent is not None:
                idx = list(parent).index(el)
                for i, new_el in enumerate(root):
                    parent.insert(idx + i, deepcopy(new_el))
        return self

    @with_camel_case_alias
    def insert_before(self, value):
        """Insert elements before value."""
        root, _ = self._get_root(value)
        src_elements = self._self_elements()
        for anchor in root:
            parent = anchor.getparent()
            if parent is not None:
                idx = list(parent).index(anchor)
                for i, el in enumerate(src_elements):
                    parent.insert(idx + i, deepcopy(el))
        return self

    def wrap(self, value):
        """Wrap each element in value.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>Hello</p></div>')
        >>> d('p').wrap('<span/>')
        [<p>]
        """
        root, _ = self._get_root(value)
        for el in self:
            parent = el.getparent()
            wrapper = deepcopy(root[0])
            # Find deepest element in wrapper
            deepest = wrapper
            while len(deepest):
                deepest = deepest[-1]
            if parent is not None:
                idx = list(parent).index(el)
                parent.insert(idx, wrapper)
                parent.remove(el)
            deepest.append(el)
        return self

    @with_camel_case_alias
    def wrap_all(self, value):
        """Wrap all elements together in value."""
        if not self:
            return self
        root, _ = self._get_root(value)
        if not root:
            return self
        wrapper = deepcopy(root[0])
        deepest = wrapper
        while len(deepest):
            deepest = deepest[-1]
        first = self[0]
        parent = first.getparent()
        if parent is not None:
            idx = list(parent).index(first)
            parent.insert(idx, wrapper)
            for el in self:
                if el.getparent() is not None:
                    el.getparent().remove(el)
                deepest.append(el)
        return self._copy(wrapper)

    @with_camel_case_alias
    def replace_with(self, value):
        """Replace each element with value.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>Hello</p></div>')
        >>> d('p').replace_with('<span>World</span>')
        [<p>]
        """
        if callable(value):
            for i, el in enumerate(self):
                parent = el.getparent()
                if parent is not None:
                    if hasattr(value, '__globals__'):
                        value.__globals__['this'] = el
                    result = callback(value, i, el)
                    if isinstance(result, str):
                        new_elements = fromstring(result, None)
                        idx = list(parent).index(el)
                        parent.remove(el)
                        for j, new_el in enumerate(new_elements):
                            if hasattr(new_el, 'tag'):
                                parent.insert(idx + j, new_el)
        else:
            root, _ = self._get_root(value)
            for el in self:
                parent = el.getparent()
                if parent is not None:
                    idx = list(parent).index(el)
                    parent.remove(el)
                    for j, new_el in enumerate(root):
                        parent.insert(idx + j, deepcopy(new_el))
        return self

    @with_camel_case_alias
    def replace_all(self, expr):
        """Replace target elements with this PyQuery."""
        if isinstance(expr, str):
            target = self._copy(expr)
        else:
            target = expr
        src_elements = self._self_elements()
        for el in target:
            parent = el.getparent()
            if parent is not None:
                idx = list(parent).index(el)
                parent.remove(el)
                for j, new_el in enumerate(src_elements):
                    parent.insert(idx + j, deepcopy(new_el))
        return self

    def clone(self):
        """Return deep copy of elements."""
        return PyQuery([deepcopy(tag) for tag in self])

    def empty(self):
        """Remove all children from elements.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>Hello</p></div>')
        >>> d('div').empty()
        [<div>]
        """
        for el in self:
            el.text = None
            for child in list(el):
                el.remove(child)
        return self

    def remove(self, expr=no_default):
        """Remove elements from DOM.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<div><p>Hello</p><span>World</span></div>')
        >>> d('p').remove()
        [<p>]
        """
        if expr is no_default:
            for el in self:
                parent = el.getparent()
                if parent is not None:
                    if el.tail:
                        prev = el.getprevious()
                        if prev is not None:
                            prev.tail = (prev.tail or '') + el.tail
                        else:
                            parent.text = (parent.text or '') + el.tail
                    parent.remove(el)
        else:
            # Remove only matching children
            sub = self.filter(expr)
            sub.remove()
        return self

    class Fn(object):
        """Namespace for adding custom methods."""

        def __setattr__(self, name, func):
            def fn(self, *args, **kwargs):
                if hasattr(func, '__globals__'):
                    func.__globals__['this'] = self
                return func(*args, **kwargs)
            fn.__name__ = name
            setattr(PyQuery, name, fn)

    fn = Fn()

    # --- Form ---

    @with_camel_case_alias
    def serialize_array(self):
        """Serialize form as array of name/value dicts.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<form><input name="a" value="1"/></form>')
        >>> d('form').serialize_array()
        [{'name': 'a', 'value': '1'}]
        """
        return [{'name': name, 'value': value}
                for name, value in self.serialize_pairs()]

    def serialize(self):
        """Serialize form as query string.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<form><input name="a" value="1"/></form>')
        >>> d('form').serialize()
        'a=1'
        """
        return urlencode(self.serialize_pairs()).replace('+', '%20')

    @with_camel_case_alias
    def serialize_pairs(self):
        """Serialize form as list of (name, value) pairs.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<form><input name="a" value="1"/><input name="b" value="2"/></form>')
        >>> d('form').serialize_pairs()
        [('a', '1'), ('b', '2')]
        """
        result = []

        # Find all form elements
        elements = []
        for el in self:
            elements.extend(el.xpath(
                './/input|.//textarea|.//select',
                namespaces={}
            ))

        for el in elements:
            tag = el.tag.lower() if isinstance(el.tag, str) else ''
            name = el.get('name')

            if not name:
                continue

            # Skip disabled elements
            if el.get('disabled') is not None:
                continue

            # Check if ancestor fieldset is disabled
            parent = el.getparent()
            fieldset_disabled = False
            while parent is not None:
                parent_tag = parent.tag.lower() if isinstance(parent.tag, str) else ''
                if parent_tag == 'fieldset' and parent.get('disabled') is not None:
                    # Check if we're in a legend that is the first legend
                    in_first_legend = False
                    leg = el
                    while leg is not None and leg is not parent:
                        leg_tag = leg.tag.lower() if isinstance(leg.tag, str) else ''
                        if leg_tag == 'legend':
                            # Check if it's the first legend child of the fieldset
                            legends = [c for c in parent if c.tag.lower() == 'legend']
                            if legends and legends[0] is leg:
                                in_first_legend = True
                            break
                        leg = leg.getparent()
                    if not in_first_legend:
                        fieldset_disabled = True
                        break
                parent = parent.getparent()

            if fieldset_disabled:
                continue

            if tag == 'input':
                input_type = (el.get('type') or 'text').lower()
                if input_type in ('submit', 'button', 'image', 'reset', 'file'):
                    continue
                if input_type in ('checkbox', 'radio') and el.get('checked') is None:
                    continue
                value = el.get('value', '')
                result.append((name, value))
            elif tag == 'textarea':
                value = el.text or ''
                # Normalize line endings to \r\n
                value = value.replace('\r\n', '\n').replace('\r', '\n').replace('\n', '\r\n')
                result.append((name, value))
            elif tag == 'select':
                multiple = el.get('multiple') is not None
                selected_options = el.xpath('.//option[@selected]')
                if not selected_options:
                    options = el.xpath('.//option')
                    if options and not multiple:
                        opt = options[0]
                        if 'value' in opt.attrib:
                            val = opt.get('value', '')
                        else:
                            val = opt.text_content() if hasattr(opt, 'text_content') else (opt.text or '')
                        result.append((name, val))
                else:
                    for opt in selected_options:
                        if 'value' in opt.attrib:
                            val = opt.get('value', '')
                        else:
                            val = opt.text_content() if hasattr(opt, 'text_content') else (opt.text or '')
                        # Normalize line endings
                        val = val.replace('\r\n', '\n').replace('\r', '\n').replace('\n', '\r\n')
                        result.append((name, val))

        return result

    @with_camel_case_alias
    def serialize_dict(self):
        """Serialize form as ordered dict.

        >>> from pyquery import PyQuery as pq
        >>> d = pq('<form><input name="a" value="1"/></form>')
        >>> dict(d('form').serialize_dict())
        {'a': '1'}
        """
        from collections import OrderedDict
        result = OrderedDict()
        for name, value in self.serialize_pairs():
            if name in result:
                existing = result[name]
                if isinstance(existing, list):
                    existing.append(value)
                else:
                    result[name] = [existing, value]
            else:
                result[name] = value
        return result

    @property
    def base_url(self):
        """Return base URL of document."""
        return self._base_url

    def make_links_absolute(self, base_url=None):
        """Make all links absolute using base_url."""
        if base_url is None:
            base_url = self._base_url
        if base_url is None:
            return self

        for attr in ('href', 'src', 'action'):
            for el in self:
                for child in el.xpath('.//*[@%s]' % attr) + ([el] if el.get(attr) else []):
                    val = child.get(attr)
                    if val and not val.startswith(('http://', 'https://', '//', '#', 'mailto:', 'javascript:')):
                        child.set(attr, urljoin(base_url, val))

        return self


# Build camelCase aliases after class definition
build_camel_case_aliases(PyQuery)
