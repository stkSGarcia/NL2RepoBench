"""
Text extraction utilities for PyQuery.
"""
import re

INLINE_TAGS = {
    'a', 'abbr', 'acronym', 'b', 'bdo', 'big', 'br', 'button', 'cite',
    'code', 'dfn', 'em', 'i', 'img', 'input', 'kbd', 'label', 'map',
    'object', 'q', 'samp', 'script', 'select', 'small', 'span', 'strong',
    'sub', 'sup', 'textarea', 'time', 'tt', 'var'
}
SEPARATORS = {'br'}
WHITESPACE_RE = re.compile(r'[\x20\x09\x0C​\x0A\x0D]+')


def squash_html_whitespace(text):
    """Replace runs of whitespace with a single space."""
    return WHITESPACE_RE.sub(' ', text) if text else text


def _squash_artifical_nl(parts):
    """Collapse consecutive newlines to a single newline."""
    result = []
    prev_nl = False
    for part in parts:
        if part == '\n':
            if not prev_nl:
                result.append(part)
            prev_nl = True
        else:
            result.append(part)
            prev_nl = False
    return result


def _strip_artifical_nl(parts):
    """Strip leading/trailing newlines from parts list."""
    while parts and parts[0] == '\n':
        parts = parts[1:]
    while parts and parts[-1] == '\n':
        parts = parts[:-1]
    return parts


def _merge_original_parts(parts):
    """Merge consecutive string parts."""
    result = []
    current = []

    def flush():
        if current:
            result.append(''.join(current))
            current.clear()

    for part in parts:
        if isinstance(part, str):
            current.append(part)
        else:
            flush()
            result.append(part)
    flush()
    return result


def extract_text_array(dom, squash_artifical_nl=True, strip_artifical_nl=True):
    """Extract text from DOM as a list of string parts."""
    from lxml import etree
    parts = []

    def _get_tag(el):
        if el.tag is None:
            return ''
        if callable(el.tag):
            return ''
        try:
            tag = etree.QName(el.tag).localname
        except Exception:
            tag = el.tag
        return tag.lower() if tag else ''

    def _process(el, is_root=False):
        tag = _get_tag(el)

        is_inline = tag in INLINE_TAGS
        is_separator = tag in SEPARATORS

        if not is_inline and not is_separator and not is_root:
            parts.append('\n')

        if is_separator:
            parts.append('\n')
            return

        # Process text before children
        if el.text:
            parts.append(el.text)

        # Process children
        for child in el:
            if isinstance(child.tag, str):
                _process(child)
            elif callable(child.tag):
                # Comment or PI nodes
                pass

            # Text after child (tail)
            if child.tail:
                parts.append(child.tail)

        if not is_inline and not is_root:
            parts.append('\n')

    if hasattr(dom, 'tag') and callable(dom.tag):
        # Comment/PI node
        return []

    _process(dom, is_root=True)

    if squash_artifical_nl:
        parts = _squash_artifical_nl(parts)
    if strip_artifical_nl:
        parts = _strip_artifical_nl(parts)

    return parts


def extract_text(dom, block_symbol='\n', sep_symbol='\n', squash_space=True):
    """Extract text content from DOM element."""
    parts = extract_text_array(dom,
                                squash_artifical_nl=squash_space,
                                strip_artifical_nl=squash_space)

    if squash_space:
        result_parts = []
        for part in parts:
            if part == '\n':
                result_parts.append(part)
            else:
                result_parts.append(squash_html_whitespace(part))
        parts = result_parts

    text = ''.join(parts)
    return text
