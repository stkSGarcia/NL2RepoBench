"""
Patch for cssselect to add jQuery pseudo-class support.
"""
import inspect
import re

from cssselect import xpath as cssselect_xpath

XPathExprOrig = cssselect_xpath.XPathExpr


class NoDefault:
    """Sentinel class for no default value."""

    def __repr__(self):
        return '<NoDefault>'


no_default = NoDefault()


class XPathExpr(XPathExprOrig):
    """Extended XPathExpr supporting post-conditions."""

    def __init__(self, path='', element='*', condition='', star_prefix=False):
        self.path = path
        self.element = element
        self.condition = condition
        self.post_condition = None

    def add_post_condition(self, post_condition):
        if self.post_condition:
            self.post_condition = '%s and %s' % (self.post_condition, post_condition)
        else:
            self.post_condition = post_condition

    def __str__(self):
        path = XPathExprOrig.__str__(self)
        if self.post_condition:
            path = '%s[%s]' % (path, self.post_condition)
        return path

    def join(self, combiner, other, closing_combiner=None, has_inner_condition=False):
        res = XPathExprOrig.join(self, combiner, other)
        self.post_condition = getattr(res, 'post_condition', None)
        return res


class JQueryTranslator(cssselect_xpath.HTMLTranslator):
    """Translator that adds jQuery pseudo-class selectors."""

    xpathexpr_cls = XPathExpr

    def xpath_first_pseudo(self, xpath):
        xpath.add_post_condition('position() = 1')
        return xpath

    def xpath_last_pseudo(self, xpath):
        xpath.add_post_condition('position() = last()')
        return xpath

    def xpath_even_pseudo(self, xpath):
        # 0-indexed even: positions 1, 3, 5, ... (1-indexed odd)
        xpath.add_post_condition('position() mod 2 = 1')
        return xpath

    def xpath_odd_pseudo(self, xpath):
        # 0-indexed odd: positions 2, 4, 6, ... (1-indexed even)
        xpath.add_post_condition('position() mod 2 = 0')
        return xpath

    def xpath_checked_pseudo(self, xpath):
        xpath.add_condition('@checked')
        return xpath

    def xpath_selected_pseudo(self, xpath):
        xpath.add_condition('@selected')
        return xpath

    def xpath_disabled_pseudo(self, xpath):
        # WHATWG spec with fieldset/legend handling
        xpath.add_condition(
            "(name()='input' or name()='button' or name()='select' or name()='textarea') and @disabled "
            "or (name()='input' or name()='button' or name()='select' or name()='textarea') "
            "and ancestor::fieldset[@disabled] "
            "and not(ancestor::legend[parent::fieldset[@disabled] and not(preceding-sibling::legend)])"
        )
        return xpath

    def xpath_enabled_pseudo(self, xpath):
        xpath.add_condition(
            "(name()='input' or name()='button' or name()='select' or name()='textarea') and not(@disabled) "
            "and not(ancestor::fieldset[@disabled] "
            "and not(ancestor::legend[parent::fieldset[@disabled] and not(preceding-sibling::legend)]))"
        )
        return xpath

    def xpath_file_pseudo(self, xpath):
        xpath.add_condition("@type = 'file'")
        return xpath

    def xpath_input_pseudo(self, xpath):
        xpath.add_condition(
            "name() = 'input' or name() = 'button' or name() = 'select' or name() = 'textarea'"
        )
        return xpath

    def xpath_button_pseudo(self, xpath):
        xpath.add_condition(
            "(name()='input' and @type='button') or name()='button'"
        )
        return xpath

    def xpath_radio_pseudo(self, xpath):
        xpath.add_condition("name()='input' and @type='radio'")
        return xpath

    def xpath_text_pseudo(self, xpath):
        xpath.add_condition("name()='input' and (@type='text' or not(@type))")
        return xpath

    def xpath_checkbox_pseudo(self, xpath):
        xpath.add_condition("name()='input' and @type='checkbox'")
        return xpath

    def xpath_password_pseudo(self, xpath):
        xpath.add_condition("name()='input' and @type='password'")
        return xpath

    def xpath_submit_pseudo(self, xpath):
        xpath.add_condition(
            "(name()='input' or name()='button') and @type='submit'"
        )
        return xpath

    def xpath_hidden_pseudo(self, xpath):
        xpath.add_condition("name()='input' and @type='hidden'")
        return xpath

    def xpath_image_pseudo(self, xpath):
        xpath.add_condition("name()='input' and @type='image'")
        return xpath

    def xpath_reset_pseudo(self, xpath):
        xpath.add_condition("name()='input' and @type='reset'")
        return xpath

    def xpath_header_pseudo(self, xpath):
        xpath.add_condition(
            "name()='h1' or name()='h2' or name()='h3' "
            "or name()='h4' or name()='h5' or name()='h6'"
        )
        return xpath

    def xpath_parent_pseudo(self, xpath):
        xpath.add_condition('*')
        return xpath

    def xpath_empty_pseudo(self, xpath):
        xpath.add_condition('not(* or text())')
        return xpath

    def _get_function_arg(self, function, default=0):
        """Extract numeric argument from cssselect function."""
        try:
            # cssselect >= 1.2 uses function.arguments list
            args = function.arguments
            if args:
                return int(args[0].value)
        except (AttributeError, IndexError, ValueError, TypeError):
            pass
        try:
            # Older API: function.argument.value
            return int(function.argument.value)
        except (AttributeError, ValueError, TypeError):
            pass
        return default

    def _get_function_str_arg(self, function, default=''):
        """Extract string argument from cssselect function."""
        try:
            args = function.arguments
            if args:
                return str(args[0].value)
        except (AttributeError, IndexError):
            pass
        try:
            return str(function.argument.value)
        except AttributeError:
            pass
        return default

    def xpath_eq_function(self, xpath, function):
        index = self._get_function_arg(function, 0)
        xpath.add_post_condition('position() = %d' % (index + 1))
        return xpath

    def xpath_gt_function(self, xpath, function):
        index = self._get_function_arg(function, 0)
        xpath.add_post_condition('position() > %d' % (index + 1))
        return xpath

    def xpath_lt_function(self, xpath, function):
        index = self._get_function_arg(function, 0)
        xpath.add_post_condition('position() < %d' % (index + 1))
        return xpath

    def xpath_contains_function(self, xpath, function):
        value = self._get_function_str_arg(function, '')
        xpath.add_condition("contains(., '%s')" % value.replace("'", "\\'"))
        return xpath

    def xpath_has_function(self, xpath, function):
        try:
            value = self._get_function_str_arg(function, '')
            if value:
                inner_xpath = self.css_to_xpath(value, prefix='descendant-or-self::')
                xpath.add_condition('%s' % inner_xpath.lstrip('/'))
        except Exception:
            pass
        return xpath


class FlexibleElement(object):
    """Descriptor for flexible element access (get/set/del)."""

    def __init__(self, pget, pset=no_default, pdel=no_default):
        self.pget = pget
        self.pset = pset
        self.pdel = pdel

    def __get__(self, instance, klass):
        if instance is None:
            return self
        pget = self.pget
        pset = self.pset
        pdel = self.pdel

        class _element(object):
            def __call__(prop, *args, **kwargs):
                return pget(instance, *args, **kwargs)

            def __getattr__(prop, name):
                return pget(instance, name)

            def __getitem__(prop, name):
                return pget(instance, name)

            def __setattr__(prop, name, value):
                if pset is not no_default:
                    return pset(instance, name, value)
                raise NotImplementedError()

            def __setitem__(prop, name, value):
                if pset is not no_default:
                    return pset(instance, name, value)
                raise NotImplementedError()

            def __delitem__(prop, name):
                if pdel is not no_default:
                    return pdel(instance, name)
                raise NotImplementedError()

            def __delattr__(prop, name):
                if pdel is not no_default:
                    return pdel(instance, name)
                raise NotImplementedError()

            def __repr__(prop):
                return '<flexible_element %s>' % pget.__name__

        return _element()

    def __set__(self, instance, value):
        if self.pset is not no_default:
            self.pset(instance, value)
        else:
            raise NotImplementedError()


def getargspec(func):
    """Get function argument specification using inspect.getfullargspec."""
    return inspect.getfullargspec(func)


def callback(func, *args):
    """Call func with appropriate number of args, injecting 'this' global."""
    try:
        argspec = getargspec(func)
        if argspec.varargs is not None:
            # Accepts *args, pass all
            return func(*args)
        nargs = len(argspec.args)
        if hasattr(func, '__self__'):
            # bound method, subtract self
            nargs -= 1
    except TypeError:
        nargs = len(args)

    # Inject 'this' into the function's globals if possible
    if hasattr(func, '__globals__') and args:
        func.__globals__['this'] = args[-1] if args else None

    if nargs == 0:
        return func()
    elif nargs >= len(args):
        return func(*args)
    else:
        return func(*args[:nargs])


def with_camel_case_alias(func):
    """Mark a function for camelCase aliasing."""
    func._camel_case_alias = True
    return func


def build_camel_case_aliases(PyQuery):
    """Build camelCase versions of all decorated methods on PyQuery class."""
    for name in list(vars(PyQuery)):
        val = getattr(PyQuery, name)
        if callable(val) and getattr(val, '_camel_case_alias', False):
            # Convert snake_case to camelCase
            camel = re.sub(r'_([a-z])', lambda m: m.group(1).upper(), name)
            if camel != name:
                setattr(PyQuery, camel, val)
