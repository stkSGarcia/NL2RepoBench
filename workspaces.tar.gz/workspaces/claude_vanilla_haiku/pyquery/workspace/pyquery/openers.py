"""
URL opener and HTML/XML parser functions for PyQuery.
"""

DEFAULT_TIMEOUT = 60


def _query(url, method, kwargs):
    """Process URL and data for HTTP requests."""
    from urllib.parse import urlencode, urlparse, urlunparse

    data = kwargs.pop('data', None)
    if data is not None and not isinstance(data, str):
        data = urlencode(data)

    if method == 'get' and data:
        # Append data to URL as query string
        parsed = urlparse(url)
        new_query = parsed.query + ('&' if parsed.query else '') + data
        url = urlunparse(parsed._replace(query=new_query))
        data = None

    if data is not None:
        data = data.encode('utf-8') if isinstance(data, str) else data

    return url, data


def _requests(url, kwargs):
    """Fetch URL content using the requests library."""
    import requests

    method = kwargs.pop('method', 'get').lower()
    timeout = kwargs.pop('timeout', DEFAULT_TIMEOUT)
    session = kwargs.pop('session', None)
    headers = kwargs.pop('headers', {})

    url, data = _query(url, method, kwargs)

    requester = session or requests
    if method == 'get':
        response = requester.get(url, headers=headers, timeout=timeout, **kwargs)
    else:
        response = requester.post(url, data=data, headers=headers, timeout=timeout, **kwargs)

    return response.content


def _urllib(url, kwargs):
    """Fetch URL content using urllib."""
    from urllib import request as urllib_request

    method = kwargs.pop('method', 'get').lower()
    timeout = kwargs.pop('timeout', DEFAULT_TIMEOUT)
    kwargs.pop('session', None)
    headers = kwargs.pop('headers', {})

    url, data = _query(url, method, kwargs)

    req = urllib_request.Request(url, data=data, headers=headers)
    response = urllib_request.urlopen(req, timeout=timeout)
    return response.read()


def url_opener(url, kwargs={}):
    """Open a URL and return the content.

    Prefers the requests library if available, otherwise falls back to urllib.
    """
    if isinstance(kwargs, dict):
        kwargs = dict(kwargs)
    else:
        kwargs = {}

    try:
        import requests  # noqa: F401
        return _requests(url, kwargs)
    except ImportError:
        return _urllib(url, kwargs)


def fromstring(context, parser=None, custom_parser=None):
    """Parse HTML/XML content and return list of elements.

    Args:
        context: HTML/XML content (str, bytes, or file-like object)
        parser: One of None, 'html', 'xml', 'html_fragments', 'soup', 'html5'
        custom_parser: Optional callable that takes context and returns elements

    Returns:
        List of lxml elements
    """
    from lxml import etree, html as lhtml

    if custom_parser is not None:
        return custom_parser(context)

    if hasattr(context, 'read'):
        context = context.read()

    if isinstance(context, bytes):
        try:
            context_str = context.decode('utf-8', errors='replace')
        except Exception:
            context_str = context.decode('latin-1', errors='replace')
    else:
        context_str = context

    if parser == 'xml':
        if isinstance(context, str):
            context = context.encode('utf-8')
        try:
            root = etree.fromstring(context)
        except etree.XMLSyntaxError:
            # Try with recovery
            p = etree.XMLParser(recover=True)
            root = etree.fromstring(context, parser=p)
        return [root]

    elif parser == 'html_fragments':
        if isinstance(context, str):
            context = context.encode('utf-8')
        elements = lhtml.fragments_fromstring(context)
        return elements

    elif parser == 'soup':
        from lxml.html import soupparser
        if isinstance(context, str):
            context = context.encode('utf-8')
        root = soupparser.fromstring(context)
        return [root]

    elif parser == 'html5':
        try:
            import html5_parser
            if isinstance(context, str):
                context = context.encode('utf-8')
            root = html5_parser.parse(context, treebuilder='lxml', namespaceHTMLElements=False)
            return [root]
        except ImportError:
            pass
        try:
            import html5lib
            root = html5lib.parse(context_str, treebuilder='lxml', namespaceHTMLElements=False)
            return [root]
        except ImportError:
            pass
        # Fall through to html parser
        parser = 'html'

    # Default HTML parser
    if isinstance(context, bytes):
        doc = lhtml.document_fromstring(context)
    else:
        doc = lhtml.document_fromstring(context.encode('utf-8'))
    return [doc]
