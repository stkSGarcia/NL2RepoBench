"""Example usage of pypinyin library."""

from pypinyin import pinyin, lazy_pinyin, slug, Style

# Example 1: Basic pinyin conversion
print("Example 1: Basic pinyin conversion")
print("=" * 40)
result = pinyin('你好')
print(f"pinyin('你好') = {result}")

result = lazy_pinyin('你好')
print(f"lazy_pinyin('你好') = {result}")
print()

# Example 2: Different styles
print("Example 2: Different pinyin styles")
print("=" * 40)
text = '中国'

styles = {
    'TONE': Style.TONE,
    'TONE2': Style.TONE2,
    'TONE3': Style.TONE3,
    'NORMAL': Style.NORMAL,
    'INITIALS': Style.INITIALS,
    'FINALS': Style.FINALS,
    'FIRST_LETTER': Style.FIRST_LETTER,
}

for style_name, style in styles.items():
    result = lazy_pinyin(text, style=style)
    print(f"{style_name:20} : {result}")
print()

# Example 3: Polyphone handling
print("Example 3: Polyphone (heteronym) handling")
print("=" * 40)
result = pinyin('中', heteronym=True)
print(f"pinyin('中', heteronym=True) = {result}")
print()

# Example 4: Creating URL slug
print("Example 4: Creating URL slug")
print("=" * 40)
result = slug('你好世界')
print(f"slug('你好世界') = {result}")
print()

# Example 5: Error handling
print("Example 5: Error handling")
print("=" * 40)
text = '你好123'

print(f"Original text: '{text}'")
print(f"errors='default' : {lazy_pinyin(text, errors='default')}")
print(f"errors='ignore'  : {lazy_pinyin(text, errors='ignore')}")
print(f"errors='replace' : {lazy_pinyin(text, errors='replace')}")
print()

# Example 6: Custom pinyin dictionary
print("Example 6: Custom dictionary loading")
print("=" * 40)
from pypinyin import load_single_dict, load_phrases_dict

# Load custom single character pronunciation
load_single_dict({ord('桔'): 'jú,jié'})
print("Loaded custom pronunciation for '桔'")

# Load custom phrase
load_phrases_dict({'同行': [['tóng'], ['xíng']]})
print("Loaded custom phrase for '同行'")

result = lazy_pinyin('同行')
print(f"lazy_pinyin('同行') with custom dict = {result}")
print()

# Example 7: Converting pinyin styles
print("Example 7: Converting pinyin styles")
print("=" * 40)
from pypinyin.contrib.tone_convert import tone3_to_tone, tone3_to_normal

print(f"tone3_to_tone('ni3') = {tone3_to_tone('ni3')}")
print(f"tone3_to_normal('ni3') = {tone3_to_normal('ni3')}")
print()

print("=" * 40)
print("Examples completed successfully!")
