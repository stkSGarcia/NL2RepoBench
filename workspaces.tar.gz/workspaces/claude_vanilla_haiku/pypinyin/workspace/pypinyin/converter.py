"""Converter classes for pinyin conversion."""

from pypinyin.constants import Style
from pypinyin.pinyin_dict import pinyin_dict
from pypinyin.phrases_dict import phrases_dict
from pypinyin.style._tone_convert import to_tone2, to_tone3, to_normal, to_initials, to_finals
from pypinyin.contrib.tone_convert import tone2_to_tone
import re


class Converter(object):
    """Base converter class."""

    def convert(self, words, style, heteronym, errors, strict=True, **kwargs):
        """Convert words to pinyin."""
        raise NotImplementedError


class DefaultConverter(Converter):
    """Default pinyin converter implementation."""

    def __init__(self, **kwargs):
        self.pinyin_dict = pinyin_dict
        self.phrases_dict = phrases_dict

    def convert(self, words, style, heteronym, errors, strict, **kwargs):
        """Convert words to pinyin."""
        result = []

        for i, word in enumerate(words):
            if isinstance(word, str) and len(word) > 1:
                # Try phrase dictionary first
                if word in self.phrases_dict:
                    phrase_pinyins = self.phrases_dict[word]
                    pinyin_list = self._convert_style_list(phrase_pinyins, style, strict, **kwargs)
                    result.append(pinyin_list)
                else:
                    # Fall back to character-by-character
                    pinyin_lists = []
                    for char in word:
                        char_pinyin = self._convert_char(char, style, heteronym, errors, strict, **kwargs)
                        if char_pinyin:
                            pinyin_lists.append(char_pinyin[0] if isinstance(char_pinyin[0], list) else char_pinyin)
                    result.append(pinyin_lists)
            else:
                # Single character
                char = word[0] if isinstance(word, str) else word
                pinyin_list = self._convert_char(char, style, heteronym, errors, strict, **kwargs)
                if pinyin_list:
                    result.append(pinyin_list)

        return result

    def _convert_char(self, char, style, heteronym, errors, strict, **kwargs):
        """Convert a single character."""
        code = ord(char)

        if code in self.pinyin_dict:
            pinyin_str = self.pinyin_dict[code]
            pinyins = pinyin_str.split(',')

            if not heteronym and pinyins:
                pinyins = [pinyins[0]]

            # Convert style
            result = []
            for py in pinyins:
                converted = self._convert_style(py, style, strict, **kwargs)
                result.append(converted)

            return [result]
        else:
            # No pinyin found
            return self._handle_no_pinyin(char, style, heteronym, errors, strict, **kwargs)

    def _handle_no_pinyin(self, char, style, heteronym, errors, strict, **kwargs):
        """Handle characters without pinyin."""
        if errors == 'default':
            return [[char]]
        elif errors == 'ignore':
            return [[]]
        elif errors == 'replace':
            return [[f'u{ord(char):x}']]
        elif errors == 'exception':
            from pypinyin.exceptions import PinyinNotFoundException
            raise PinyinNotFoundException(f'No pinyin found for {char}')
        elif callable(errors):
            result = errors(char)
            return [[result]] if result else [[]]
        else:
            return [[char]]

    def _convert_style(self, pinyin, style, strict, **kwargs):
        """Convert pinyin to specified style."""
        # The dictionary format is TONE3 (tone numbers at the end)
        # So we first normalize to TONE style

        # Check what format the pinyin is in
        has_tone_marks = any(c in pinyin for c in 'āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ')
        has_tone_numbers = any(c in pinyin for c in '12345')

        # First convert to TONE if needed
        if has_tone_numbers and not has_tone_marks:
            # It's in TONE3 or TONE2 format, convert to TONE
            from pypinyin.contrib.tone_convert import tone3_to_tone
            pinyin = tone3_to_tone(pinyin)

        # Now convert to target style
        if style == Style.TONE:
            return pinyin

        elif style == Style.TONE2:
            return to_tone2(pinyin)

        elif style == Style.TONE3:
            return to_tone3(pinyin, **kwargs)

        elif style == Style.NORMAL:
            return to_normal(pinyin)

        elif style == Style.INITIALS:
            return to_initials(pinyin, strict)

        elif style == Style.FIRST_LETTER:
            return to_initials(pinyin, strict)[0] if to_initials(pinyin, strict) else ''

        elif style == Style.FINALS:
            return to_finals(pinyin, strict)

        elif style == Style.FINALS_TONE:
            from pypinyin.contrib.tone_convert import to_finals_tone
            return to_finals_tone(pinyin, strict)

        elif style == Style.FINALS_TONE2:
            from pypinyin.contrib.tone_convert import to_finals_tone2
            return to_finals_tone2(pinyin, strict, **kwargs)

        elif style == Style.FINALS_TONE3:
            from pypinyin.contrib.tone_convert import to_finals_tone3
            return to_finals_tone3(pinyin, strict, **kwargs)

        else:
            return pinyin

    def _convert_style_list(self, pinyin_list, style, strict, **kwargs):
        """Convert a list of pinyins."""
        result = []
        for pinyin_item in pinyin_list:
            if isinstance(pinyin_item, list):
                converted_sublist = [self._convert_style(py, style, strict, **kwargs) for py in pinyin_item]
                result.append(converted_sublist)
            else:
                converted = self._convert_style(pinyin_item, style, strict, **kwargs)
                result.append([converted])

        return [item for sublist in result for item in (sublist if isinstance(sublist[0], str) else sublist)]


class _v2UConverter(DefaultConverter):
    """Converter with v to ü conversion."""

    def _convert_style(self, pinyin, style, strict, **kwargs):
        """Convert with v to ü."""
        result = super()._convert_style(pinyin, style, strict, **kwargs)
        return result.replace('v', 'ü') if 'v' in result else result


class _neutralToneWith5Converter(DefaultConverter):
    """Converter with neutral tone marked as 5."""

    def _convert_style(self, pinyin, style, strict, **kwargs):
        """Convert with neutral tone as 5."""
        result = super()._convert_style(pinyin, style, strict, **kwargs)

        if style in (Style.TONE2, Style.TONE3, Style.FINALS_TONE2, Style.FINALS_TONE3):
            if not re.search(r'[1-4]', result):
                result += '5'

        return result


class _toneSandhiConverter(DefaultConverter):
    """Converter with tone sandhi rules."""

    def convert(self, words, style, heteronym, errors, strict, **kwargs):
        """Convert with tone sandhi."""
        result = super().convert(words, style, heteronym, errors, strict, **kwargs)

        # Apply third-tone sandhi (3+3 becomes 2)
        for i in range(len(result) - 1):
            if result[i] and result[i + 1]:
                curr_pinyin = result[i][0] if isinstance(result[i][0], str) else result[i][0][0]
                next_pinyin = result[i + 1][0] if isinstance(result[i + 1][0], str) else result[i + 1][0][0]

                if '3' in curr_pinyin and '3' in next_pinyin:
                    # Convert first character's tone 3 to tone 2
                    if isinstance(result[i][0], str):
                        result[i][0] = result[i][0].replace('3', '2')
                    else:
                        result[i][0][0] = result[i][0][0].replace('3', '2')

        return result


class UltimateConverter(DefaultConverter):
    """Ultimate converter with all features."""

    def __init__(self, v_to_u=False, neutral_tone_with_five=False, tone_sandhi=False, **kwargs):
        super().__init__(**kwargs)
        self.v_to_u = v_to_u
        self.neutral_tone_with_five = neutral_tone_with_five
        self.tone_sandhi = tone_sandhi

    def _convert_style(self, pinyin, style, strict, **kwargs):
        """Convert with all features."""
        result = super()._convert_style(pinyin, style, strict, **kwargs)

        if self.v_to_u:
            result = result.replace('v', 'ü')

        if self.neutral_tone_with_five and style in (Style.TONE2, Style.TONE3, Style.FINALS_TONE2, Style.FINALS_TONE3):
            if not re.search(r'[1-4]', result):
                result += '5'

        return result


__all__ = [
    'Converter',
    'DefaultConverter',
    '_v2UConverter',
    '_neutralToneWith5Converter',
    '_toneSandhiConverter',
    'UltimateConverter',
]
