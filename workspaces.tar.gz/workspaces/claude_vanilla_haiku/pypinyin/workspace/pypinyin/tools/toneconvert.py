"""Tone conversion tools."""

import re


def prepare(input_text):
    """Prepare input text by replacing multi-char phonetic symbols."""
    # This is a simplified version
    return input_text


def re_sub(action, match_obj):
    """Helper for regex substitution with action."""
    return action(match_obj.group(0))


__all__ = ['prepare', 're_sub']
