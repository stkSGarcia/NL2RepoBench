"""Tools module for pypinyin."""

__all__ = []
