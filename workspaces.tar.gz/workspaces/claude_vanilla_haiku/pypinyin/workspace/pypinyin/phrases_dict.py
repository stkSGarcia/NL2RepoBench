"""Phrase dictionary management."""

import json
import os

_current_dir = os.path.dirname(os.path.realpath(__file__))
_json_path = os.path.join(_current_dir, 'phrases_dict.json')

phrases_dict = {}


def _load_phrases_dict():
    """Load phrases dictionary from JSON file."""
    global phrases_dict
    if os.path.exists(_json_path):
        with open(_json_path, 'r', encoding='utf-8') as f:
            phrases_dict = json.load(f)
    else:
        _generate_default_dict()


def _generate_default_dict():
    """Generate a default phrases dictionary."""
    global phrases_dict

    phrases_dict = {
        '中国': [['zhōng'], ['guó']],
        '你好': [['nǐ'], ['hǎo']],
        '谢谢': [['xiè'], ['xie']],
        '对不起': [['duì'], ['bu'], ['qǐ']],
        '再见': [['zài'], ['jiàn']],
        '早上好': [['zǎo'], ['shang'], ['hǎo']],
        '晚安': [['wǎn'], ['ān']],
        '谢谢你': [['xiè'], ['xie'], ['nǐ']],
        '同行': [['tóng'], ['xíng']],
    }

    # Save to JSON
    if not os.path.exists(_json_path):
        with open(_json_path, 'w', encoding='utf-8') as f:
            json.dump(phrases_dict, f, ensure_ascii=False, indent=2)


_load_phrases_dict()


__all__ = ['phrases_dict', '_load_phrases_dict']
