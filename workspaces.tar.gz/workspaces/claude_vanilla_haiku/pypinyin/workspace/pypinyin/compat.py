"""Compatibility utilities for Python 2/3."""

import sys

SUPPORT_UCS4 = len('\U00020000') == 1
PY2 = sys.version_info < (3, 0)


def callable_check(obj):
    """Check if an object is callable."""
    return callable(obj)


__all__ = ['SUPPORT_UCS4', 'PY2', 'callable_check']
