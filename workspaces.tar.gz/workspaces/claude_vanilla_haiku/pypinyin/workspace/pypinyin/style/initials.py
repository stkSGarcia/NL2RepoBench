"""Initials style converter."""


def to_initials(pinyin, strict=True):
    """Extract initials from pinyin."""
    from pypinyin.style._tone_convert import to_initials as _to_initials
    return _to_initials(pinyin, strict)


__all__ = ['to_initials']
