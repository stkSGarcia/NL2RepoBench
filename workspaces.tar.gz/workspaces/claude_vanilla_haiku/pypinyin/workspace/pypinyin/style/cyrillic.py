"""Cyrillic style converter."""


class CyrillicConverter(object):
    """Converter for Cyrillic style."""

    def to_cyrillic(self, pinyin, **kwargs):
        """Convert to Cyrillic."""
        return pinyin  # Placeholder

    def to_cyrillic_first(self, pinyin, **kwargs):
        """Convert to Cyrillic first letter."""
        return pinyin[0] if pinyin else ''


__all__ = ['CyrillicConverter']
