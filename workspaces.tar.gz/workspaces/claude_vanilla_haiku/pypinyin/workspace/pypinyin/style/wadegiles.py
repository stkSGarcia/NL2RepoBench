"""Wade-Giles romanization converter."""


def to_wade_glides(pinyin, **kwargs):
    """Convert to Wade-Giles romanization."""
    return pinyin  # Placeholder


def _fixed_result(pinyin):
    """Fix Wade-Giles conversion result."""
    return pinyin


def _convert_whole(chars, table):
    """Convert using a conversion table."""
    return chars


__all__ = ['to_wade_glides', '_fixed_result', '_convert_whole']
