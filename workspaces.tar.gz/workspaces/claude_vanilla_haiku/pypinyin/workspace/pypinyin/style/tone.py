"""Tone style converter."""


class ToneConverter(object):
    """Converter for tone-related styles."""

    def to_tone(self, pinyin, **kwargs):
        """Convert to TONE style."""
        from pypinyin.style._tone_convert import to_tone
        return to_tone(pinyin, **kwargs)

    def to_tone2(self, pinyin, **kwargs):
        """Convert to TONE2 style."""
        from pypinyin.style._tone_convert import to_tone2
        return to_tone2(pinyin, **kwargs)

    def to_tone3(self, pinyin, **kwargs):
        """Convert to TONE3 style."""
        from pypinyin.style._tone_convert import to_tone3
        return to_tone3(pinyin, **kwargs)


__all__ = ['ToneConverter']
