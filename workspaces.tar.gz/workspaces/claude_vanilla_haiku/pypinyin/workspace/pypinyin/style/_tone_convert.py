"""Tone conversion utilities."""

import re

# Tone mark mapping
TONE_MARKS = {
    'a': {1: 'ā', 2: 'á', 3: 'ǎ', 4: 'à'},
    'e': {1: 'ē', 2: 'é', 3: 'ě', 4: 'è'},
    'i': {1: 'ī', 2: 'í', 3: 'ǐ', 4: 'ì'},
    'o': {1: 'ō', 2: 'ó', 3: 'ǒ', 4: 'ò'},
    'u': {1: 'ū', 2: 'ú', 3: 'ǔ', 4: 'ù'},
    'ü': {1: 'ǖ', 2: 'ǘ', 3: 'ǚ', 4: 'ǜ'},
    'v': {1: 'ǖ', 2: 'ǘ', 3: 'ǚ', 4: 'ǜ'},
    'n': {1: 'n', 2: 'n', 3: 'n', 4: 'n'},
    'm': {1: 'm', 2: 'm', 3: 'm', 4: 'm'},
}

REVERSE_TONE_MARKS = {}
for char, tones_dict in TONE_MARKS.items():
    for tone, marked in tones_dict.items():
        REVERSE_TONE_MARKS[marked] = (char, tone)


def _get_number_from_pinyin(pinyin):
    """Extract tone number from pinyin string."""
    match = re.search(r'[1-5]', pinyin)
    if match:
        return int(match.group(0))
    return None


def _v_to_u(pinyin, replace=False):
    """Convert v to ü in pinyin."""
    if not replace or not pinyin:
        return pinyin
    return pinyin.replace('v', 'ü')


def _fix_v_u(origin_py, new_py, v_to_u):
    """Ensure consistency between v and ü."""
    if v_to_u and 'ü' in new_py:
        return new_py
    if not v_to_u and 'v' in origin_py:
        return new_py.replace('ü', 'v')
    return new_py


def _replace(match):
    """Replace tone numbers with tone marks."""
    text = match.group(0)
    tone = int(text[-1])
    pinyin = text[:-1]

    for vowel in 'aeoiüvnm':
        if vowel in pinyin:
            marked = TONE_MARKS.get(vowel, {}).get(tone)
            if marked:
                return pinyin.replace(vowel, marked, 1)

    return text


def to_tone(pinyin, **kwargs):
    """Convert to TONE style (tone marks)."""
    if not pinyin:
        return pinyin

    # Already has tone marks
    if any(c in pinyin for c in REVERSE_TONE_MARKS):
        return pinyin

    # Has tone numbers
    match = re.search(r'[1-5]$', pinyin)
    if match:
        tone = int(match.group(0))
        pinyin_no_tone = pinyin[:-1]

        # Find right position for tone mark
        vowel_order = 'aeoiü'
        pos = -1
        for i, vowel in enumerate(vowel_order):
            if vowel in pinyin_no_tone:
                pos = pinyin_no_tone.index(vowel)
                if vowel in 'aoe':
                    break
                if 'a' in pinyin_no_tone or 'e' in pinyin_no_tone:
                    continue
                if vowel == 'i' and 'u' in pinyin_no_tone:
                    break

        if pos >= 0:
            target_vowel = pinyin_no_tone[pos]
            marked = TONE_MARKS.get(target_vowel, {}).get(tone)
            if marked:
                return pinyin_no_tone[:pos] + marked + pinyin_no_tone[pos+1:]

    return pinyin


def to_tone2(pinyin, **kwargs):
    """Convert to TONE2 style (tone numbers after vowels)."""
    if not pinyin:
        return pinyin

    # Already in tone2 format
    if re.search(r'[1-5]$', pinyin):
        return pinyin

    # Has tone marks, extract tone
    tone = None
    pinyin_no_tone = pinyin

    for marked_char, (base_char, tone_num) in REVERSE_TONE_MARKS.items():
        if marked_char in pinyin:
            tone = tone_num
            pinyin_no_tone = pinyin.replace(marked_char, base_char)
            break

    if tone:
        # Place tone number after the appropriate vowel (using tone placement rules)
        # Rule: a, e always get the mark
        # In ou, o gets the mark
        # Otherwise the last vowel gets the mark

        vowels = 'aeiouü'
        pos = -1

        # Find a or e
        for i, char in enumerate(pinyin_no_tone):
            if char in 'ae':
                pos = i
                break

        # If no a or e, check for ou (o gets it)
        if pos == -1 and 'ou' in pinyin_no_tone:
            pos = pinyin_no_tone.index('o')

        # Otherwise use last vowel
        if pos == -1:
            for i in range(len(pinyin_no_tone) - 1, -1, -1):
                if pinyin_no_tone[i] in vowels:
                    pos = i
                    break

        if pos >= 0:
            return pinyin_no_tone[:pos+1] + str(tone) + pinyin_no_tone[pos+1:]

    return pinyin


def to_tone3(pinyin, v_to_u=False, neutral_tone_with_five=False):
    """Convert to TONE3 style (tone number at end)."""
    if not pinyin:
        return pinyin

    # Extract tone number
    tone = None
    pinyin_no_tone = pinyin

    # Check for tone marks
    for marked_char, (base_char, tone_num) in REVERSE_TONE_MARKS.items():
        if marked_char in pinyin:
            tone = tone_num
            pinyin_no_tone = pinyin.replace(marked_char, base_char)
            break

    # Check for tone2 format
    match = re.search(r'([aeoiüvnm])([1-4])(.*)$', pinyin)
    if match:
        tone = int(match.group(2))
        vowel = match.group(1)
        rest = match.group(3)
        pinyin_no_tone = pinyin[:match.start()] + vowel + rest

    result = pinyin_no_tone + (str(tone) if tone else '5' if neutral_tone_with_five else '')
    if v_to_u:
        result = result.replace('v', 'ü')

    return result


def to_initials(pinyin, strict=True):
    """Extract initial consonants from pinyin."""
    if not pinyin:
        return ''

    # Remove tone marks/numbers
    cleaned = pinyin
    for marked_char, (base_char, _) in REVERSE_TONE_MARKS.items():
        cleaned = cleaned.replace(marked_char, base_char)
    cleaned = re.sub(r'[1-5]', '', cleaned)

    # Check for multi-character initials first
    for initial in ['zh', 'ch', 'sh']:
        if cleaned.startswith(initial):
            return initial

    # Single character initials
    if cleaned and cleaned[0] not in 'aeiouü':
        return cleaned[0]

    return ''


def to_finals(pinyin, strict=True, v_to_u=False):
    """Extract final vowels from pinyin."""
    if not pinyin:
        return ''

    # Remove tone marks/numbers
    cleaned = pinyin
    for marked_char, (base_char, _) in REVERSE_TONE_MARKS.items():
        cleaned = cleaned.replace(marked_char, base_char)
    cleaned = re.sub(r'[1-5]', '', cleaned)

    # Remove initials
    initials = to_initials(pinyin, strict)
    finals = cleaned[len(initials):]

    if v_to_u:
        finals = finals.replace('v', 'ü')

    return finals


def to_normal(pinyin, v_to_u=False):
    """Convert to NORMAL style (no tones, no tone marks)."""
    if not pinyin:
        return pinyin

    # Remove tone marks
    result = pinyin
    for marked_char, (base_char, _) in REVERSE_TONE_MARKS.items():
        result = result.replace(marked_char, base_char)

    # Remove tone numbers
    result = re.sub(r'[1-5]', '', result)

    if v_to_u:
        result = result.replace('v', 'ü')

    return result


def _improve_tone3(tone3, neutral_tone_with_five=False):
    """Enhance TONE3 style by marking neutral tone."""
    if not tone3:
        return tone3

    if neutral_tone_with_five and not re.search(r'[1-5]$', tone3):
        return tone3 + '5'

    return tone3


__all__ = [
    'to_tone',
    'to_tone2',
    'to_tone3',
    'to_initials',
    'to_finals',
    'to_normal',
    '_get_number_from_pinyin',
    '_v_to_u',
    '_fix_v_u',
    '_replace',
    '_improve_tone3',
]
