"""Gwoyeu romanization converter."""


class GwoyeuConverter(object):
    """Converter for Gwoyeu romanization."""

    def to_gwoyeu(self, pinyin, **kwargs):
        """Convert to Gwoyeu romanization."""
        return pinyin  # Placeholder

    def _pre_convert(self, pinyin):
        """Pre-process before Gwoyeu conversion."""
        return pinyin


__all__ = ['GwoyeuConverter']
