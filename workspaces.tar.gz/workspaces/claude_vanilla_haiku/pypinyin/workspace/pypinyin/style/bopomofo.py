"""Bopomofo style converter."""


class BopomofoConverter(object):
    """Converter for Bopomofo style."""

    def to_bopomofo(self, pinyin, **kwargs):
        """Convert to Bopomofo style."""
        return pinyin  # Placeholder

    def to_bopomofo_first(self, pinyin, **kwargs):
        """Convert to Bopomofo first letter style."""
        return pinyin[0] if pinyin else ''


__all__ = ['BopomofoConverter']
