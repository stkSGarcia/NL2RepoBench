"""Constants for style conversion."""

_INITIALS = ['b', 'p', 'm', 'f', 'd', 't', 'n', 'l', 'g', 'k', 'h',
             'j', 'q', 'x', 'zh', 'ch', 'sh', 'r', 'z', 'c', 's']
_INITIALS_NOT_STRICT = _INITIALS + ['y', 'w']

_FINALS = ['i', 'u', 'ü', 'a', 'ia', 'ua', 'o', 'uo', 'e', 'ie', 'üe',
           'ai', 'uai', 'ei', 'uei', 'ao', 'iao', 'ou', 'iou', 'an',
           'ian', 'uan', 'üan', 'en', 'in', 'uen', 'ün', 'ang', 'iang',
           'uang', 'eng', 'ing', 'ueng', 'ong', 'iong', 'er', 'ê']

__all__ = ['_INITIALS', '_INITIALS_NOT_STRICT', '_FINALS']
