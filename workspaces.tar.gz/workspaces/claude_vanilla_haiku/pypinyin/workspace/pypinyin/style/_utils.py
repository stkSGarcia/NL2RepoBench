"""Style conversion utilities."""

import re
from pypinyin.style._constants import _INITIALS, _INITIALS_NOT_STRICT, _FINALS


def get_initials(pinyin, strict=True):
    """Get initials from pinyin."""
    if not pinyin:
        return ''

    # Remove tone marks/numbers
    cleaned = pinyin
    for marked in 'āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ':
        cleaned = cleaned.replace(marked, cleaned.replace(marked, ''))

    cleaned = re.sub(r'[1-5]', '', cleaned)

    initials_list = _INITIALS if strict else _INITIALS_NOT_STRICT

    # Check for multi-character initials first
    for initial in sorted(initials_list, key=len, reverse=True):
        if cleaned.startswith(initial):
            return initial

    return ''


def get_finals(pinyin, strict=True):
    """Get finals from pinyin."""
    if not pinyin:
        return ''

    # Remove tone marks
    cleaned = pinyin
    for marked in 'āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ':
        cleaned = cleaned.replace(marked, '')

    cleaned = re.sub(r'[1-5]', '', cleaned)

    initials = get_initials(pinyin, strict)
    return cleaned[len(initials):]


def replace_symbol_to_number(pinyin):
    """Replace tone symbols with numbers."""
    tone_map = {
        'ā': 'a1', 'á': 'a2', 'ǎ': 'a3', 'à': 'a4',
        'ē': 'e1', 'é': 'e2', 'ě': 'e3', 'è': 'e4',
        'ī': 'i1', 'í': 'i2', 'ǐ': 'i3', 'ì': 'i4',
        'ō': 'o1', 'ó': 'o2', 'ǒ': 'o3', 'ò': 'o4',
        'ū': 'u1', 'ú': 'u2', 'ǔ': 'u3', 'ù': 'u4',
        'ǖ': 'v1', 'ǘ': 'v2', 'ǚ': 'v3', 'ǜ': 'v4',
    }

    result = pinyin
    for marked, numbered in tone_map.items():
        result = result.replace(marked, numbered)

    return result


def replace_symbol_to_no_symbol(pinyin):
    """Remove tone symbols from pinyin."""
    tone_marks = 'āáǎàēéěèīíǐìōóǒòūúǔùǖǘǚǜ'
    base_chars = 'aaaaaeeeeiiiioooosuuuuüüüü'

    result = pinyin
    for marked, base in zip(tone_marks, base_chars):
        result = result.replace(marked, base)

    return result


def has_finals(pinyin):
    """Check if pinyin has finals."""
    cleaned = pinyin.lower()
    cleaned = re.sub(r'[^a-zü]', '', cleaned)

    if not cleaned:
        return False

    initials = get_initials(pinyin, True)
    return len(cleaned) > len(initials)


__all__ = [
    'get_initials',
    'get_finals',
    'replace_symbol_to_number',
    'replace_symbol_to_no_symbol',
    'has_finals',
]
