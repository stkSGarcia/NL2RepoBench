"""Style conversion module."""

_style_registry = {}


def register(style, func=None):
    """Register a style converter function."""
    def decorator(f):
        _style_registry[style] = f
        return f
    if func is None:
        return decorator
    else:
        _style_registry[style] = func
        return func


def auto_discover():
    """Auto-discover and register built-in style converters."""
    pass


def get_style_converter(style):
    """Get a registered style converter."""
    return _style_registry.get(style)


__all__ = ['register', 'auto_discover', 'get_style_converter']
