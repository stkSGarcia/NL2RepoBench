"""Other style converters."""


class OthersConverter(object):
    """Converter for other styles."""

    def to_normal(self, pinyin, **kwargs):
        """Convert to NORMAL style."""
        from pypinyin.style._tone_convert import to_normal
        return to_normal(pinyin, **kwargs)

    def to_first_letter(self, pinyin, **kwargs):
        """Convert to first letter style."""
        from pypinyin.style._tone_convert import to_initials
        initials = to_initials(pinyin, True)
        return initials[0] if initials else ''


__all__ = ['OthersConverter']
