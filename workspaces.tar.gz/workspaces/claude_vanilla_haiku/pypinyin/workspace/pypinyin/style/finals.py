"""Finals style converter."""


class FinalsConverter(object):
    """Converter for finals-related styles."""

    def to_finals(self, pinyin, **kwargs):
        """Convert to FINALS style."""
        from pypinyin.style._tone_convert import to_finals
        return to_finals(pinyin, **kwargs)

    def to_finals_tone(self, pinyin, **kwargs):
        """Convert to FINALS_TONE style."""
        from pypinyin.contrib.tone_convert import to_finals_tone
        return to_finals_tone(pinyin, **kwargs)

    def to_finals_tone2(self, pinyin, **kwargs):
        """Convert to FINALS_TONE2 style."""
        from pypinyin.contrib.tone_convert import to_finals_tone2
        return to_finals_tone2(pinyin, **kwargs)

    def to_finals_tone3(self, pinyin, **kwargs):
        """Convert to FINALS_TONE3 style."""
        from pypinyin.contrib.tone_convert import to_finals_tone3
        return to_finals_tone3(pinyin, **kwargs)


__all__ = ['FinalsConverter']
