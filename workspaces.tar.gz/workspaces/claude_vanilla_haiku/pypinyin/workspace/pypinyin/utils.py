"""Utility functions for pypinyin."""

import re
from pypinyin.contrib.tone_convert import tone2_to_tone


def _replace_tone2_style_dict_to_default(string):
    """Convert tone2 style pinyin to default tone style."""
    if not string:
        return string

    # Find tone2 pattern and convert
    def replace_fn(m):
        tone2 = m.group(0)
        return tone2_to_tone(tone2)

    pattern = r'[a-zü]+[1-4]'
    return re.sub(pattern, replace_fn, string)


def _remove_dup_items(lst, remove_empty=False):
    """Remove duplicate items from list while preserving order."""
    seen = set()
    result = []
    for item in lst:
        if remove_empty and not item:
            continue
        if item not in seen:
            seen.add(item)
            result.append(item)
    return result


def _remove_dup_and_empty(lst_list):
    """Remove duplicates and empty items from list of lists."""
    result = []
    for sublist in lst_list:
        if not isinstance(sublist, list):
            continue
        cleaned = _remove_dup_items(sublist, remove_empty=True)
        if cleaned:
            result.append(cleaned)
    return result


__all__ = [
    '_replace_tone2_style_dict_to_default',
    '_remove_dup_items',
    '_remove_dup_and_empty',
]
