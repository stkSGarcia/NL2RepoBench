"""Command-line runner for pypinyin."""

import sys
from io import StringIO


class NullWriter(object):
    """Data stream blackhole that discards output."""

    def write(self, string):
        """Discard the string."""
        pass

    def flush(self):
        """Flush operation (does nothing)."""
        pass


def main():
    """Main command-line entry point."""
    from pypinyin import pinyin, lazy_pinyin, Style

    if len(sys.argv) < 2:
        print('Usage: pypinyin <text> [style]')
        sys.exit(1)

    text = sys.argv[1]
    style = Style.TONE

    if len(sys.argv) >= 3:
        style_name = sys.argv[2]
        style_map = {
            'normal': Style.NORMAL,
            'tone': Style.TONE,
            'tone2': Style.TONE2,
            'tone3': Style.TONE3,
            'initials': Style.INITIALS,
            'first_letter': Style.FIRST_LETTER,
            'finals': Style.FINALS,
            'finals_tone': Style.FINALS_TONE,
            'finals_tone2': Style.FINALS_TONE2,
            'finals_tone3': Style.FINALS_TONE3,
        }
        style = style_map.get(style_name, style)

    result = pinyin(text, style=style)
    print(result)


if __name__ == '__main__':
    main()


__all__ = ['NullWriter', 'main']
