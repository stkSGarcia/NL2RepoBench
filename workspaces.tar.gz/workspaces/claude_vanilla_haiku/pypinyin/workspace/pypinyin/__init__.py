"""pypinyin: Chinese character pinyin conversion library."""

__title__ = 'pypinyin'
__version__ = '0.55.0'
__author__ = 'mozillazg, 闲耘'
__license__ = 'MIT'
__copyright__ = 'Copyright (c) 2016 mozillazg, 闲耘'

from pypinyin.core import pinyin, lazy_pinyin, slug, load_single_dict, load_phrases_dict
from pypinyin.constants import (
    Style,
    NORMAL, STYLE_NORMAL,
    TONE, STYLE_TONE,
    TONE2, STYLE_TONE2,
    TONE3, STYLE_TONE3,
    INITIALS, STYLE_INITIALS,
    FIRST_LETTER, STYLE_FIRST_LETTER,
    FINALS, STYLE_FINALS,
    FINALS_TONE, STYLE_FINALS_TONE,
    FINALS_TONE2, STYLE_FINALS_TONE2,
    FINALS_TONE3, STYLE_FINALS_TONE3,
    BOPOMOFO, STYLE_BOPOMOFO,
    BOPOMOFO_FIRST, STYLE_BOPOMOFO_FIRST,
    CYRILLIC, STYLE_CYRILLIC,
    CYRILLIC_FIRST, STYLE_CYRILLIC_FIRST,
    WADEGILES, STYLE_WADEGILES,
    GWOYEU, STYLE_GWOYEU,
    BRAILLE_MAINLAND, STYLE_BRAILLE_MAINLAND,
    BRAILLE_MAINLAND_TONE, STYLE_BRAILLE_MAINLAND_TONE,
)

__all__ = [
    'pinyin',
    'lazy_pinyin',
    'slug',
    'load_single_dict',
    'load_phrases_dict',
    'Style',
    'NORMAL', 'STYLE_NORMAL',
    'TONE', 'STYLE_TONE',
    'TONE2', 'STYLE_TONE2',
    'TONE3', 'STYLE_TONE3',
    'INITIALS', 'STYLE_INITIALS',
    'FIRST_LETTER', 'STYLE_FIRST_LETTER',
    'FINALS', 'STYLE_FINALS',
    'FINALS_TONE', 'STYLE_FINALS_TONE',
    'FINALS_TONE2', 'STYLE_FINALS_TONE2',
    'FINALS_TONE3', 'STYLE_FINALS_TONE3',
    'BOPOMOFO', 'STYLE_BOPOMOFO',
    'BOPOMOFO_FIRST', 'STYLE_BOPOMOFO_FIRST',
    'CYRILLIC', 'STYLE_CYRILLIC',
    'CYRILLIC_FIRST', 'STYLE_CYRILLIC_FIRST',
    'WADEGILES', 'STYLE_WADEGILES',
    'GWOYEU', 'STYLE_GWOYEU',
    'BRAILLE_MAINLAND', 'STYLE_BRAILLE_MAINLAND',
    'BRAILLE_MAINLAND_TONE', 'STYLE_BRAILLE_MAINLAND_TONE',
]
