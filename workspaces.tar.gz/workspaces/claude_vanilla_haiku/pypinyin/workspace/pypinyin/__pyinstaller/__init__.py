"""PyInstaller support for pypinyin."""

import os


def get_hook_dirs():
    """Return directories containing PyInstaller hooks."""
    return [os.path.dirname(__file__)]


__all__ = ['get_hook_dirs']
