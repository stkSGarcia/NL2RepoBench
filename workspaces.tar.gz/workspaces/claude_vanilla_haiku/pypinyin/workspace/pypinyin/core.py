"""Core pinyin conversion functions."""

from pypinyin.converter import DefaultConverter, UltimateConverter
from pypinyin.constants import Style
import re


class Pinyin(object):
    """Core pinyin converter class."""

    def __init__(self, converter=None, **kwargs):
        self.converter = converter or DefaultConverter(**kwargs)

    def pinyin(self, hans, style=Style.TONE, heteronym=False, errors='default', strict=True, **kwargs):
        """Convert Chinese text to pinyin, returning list of pinyin lists."""
        if not hans:
            return []

        # Segment by sentence/phrase
        segments = self._segment(hans)

        result = []
        for segment in segments:
            segment_result = self.converter.convert(
                segment, style, heteronym, errors, strict, **kwargs
            )
            result.extend(segment_result)

        return result

    def lazy_pinyin(self, hans, style=Style.NORMAL, errors='default', strict=True, **kwargs):
        """Convert Chinese text to pinyin, returning flat list."""
        pinyin_list = self.pinyin(hans, style=style, heteronym=False, errors=errors, strict=strict, **kwargs)

        result = []
        for pinyins in pinyin_list:
            if pinyins and len(pinyins) > 0:
                # pinyins is a list like ['nǐ'] or [['nǐ']]
                first = pinyins[0]
                if isinstance(first, list):
                    result.append(first[0] if first else '')
                else:
                    result.append(first)

        return result

    def slug(self, hans, style=Style.NORMAL, heteronym=False, separator='-', errors='default', strict=True, **kwargs):
        """Convert to slug format."""
        pinyin_list = self.lazy_pinyin(hans, style=style, errors=errors, strict=strict, **kwargs)
        return separator.join(pinyin_list)

    def _segment(self, hans):
        """Segment text into characters."""
        return list(hans)


_default_converter = DefaultConverter()
_default_pinyin = Pinyin(_default_converter)


def pinyin(hans, style=Style.TONE, heteronym=False, errors='default', strict=True, v_to_u=False, neutral_tone_with_five=False, tone_sandhi=False, **kwargs):
    """Convert Chinese text to pinyin, returning list of pinyin lists."""
    # Use UltimateConverter if special options are provided
    if v_to_u or neutral_tone_with_five or tone_sandhi:
        converter = UltimateConverter(v_to_u=v_to_u, neutral_tone_with_five=neutral_tone_with_five, tone_sandhi=tone_sandhi)
        p = Pinyin(converter)
    else:
        p = _default_pinyin

    return p.pinyin(hans, style=style, heteronym=heteronym, errors=errors, strict=strict, **kwargs)


def lazy_pinyin(hans, style=Style.NORMAL, errors='default', strict=True, v_to_u=False, neutral_tone_with_five=False, tone_sandhi=False, **kwargs):
    """Convert Chinese text to pinyin, returning flat list."""
    if v_to_u or neutral_tone_with_five or tone_sandhi:
        converter = UltimateConverter(v_to_u=v_to_u, neutral_tone_with_five=neutral_tone_with_five, tone_sandhi=tone_sandhi)
        p = Pinyin(converter)
    else:
        p = _default_pinyin

    return p.lazy_pinyin(hans, style=style, errors=errors, strict=strict, **kwargs)


def slug(hans, style=Style.NORMAL, heteronym=False, separator='-', errors='default', strict=True, **kwargs):
    """Convert to slug format."""
    return _default_pinyin.slug(hans, style=style, separator=separator, errors=errors, strict=strict, **kwargs)


def to_fixed(pinyin, style, strict=True):
    """Convert pinyin to specified style."""
    converter = DefaultConverter()
    return converter._convert_style(pinyin, style, strict)


def handle_nopinyin(chars, errors='default', heteronym=True):
    """Handle characters without pinyin."""
    converter = DefaultConverter()
    result = []

    for char in chars:
        char_result = converter._handle_no_pinyin(char, Style.NORMAL, heteronym, errors, True)
        result.append(char_result[0] if char_result else [])

    return result


def single_pinyin(han, style, heteronym, errors='default', strict=True):
    """Get pinyin for a single character."""
    converter = DefaultConverter()
    return converter._convert_char(han, style, heteronym, errors, strict)


def phrase_pinyin(phrase, style, heteronym, errors='default', strict=True):
    """Get pinyin for a phrase."""
    converter = DefaultConverter()
    if phrase in converter.phrases_dict:
        return converter._convert_style_list(converter.phrases_dict[phrase], style, strict)
    else:
        result = []
        for char in phrase:
            char_result = converter._convert_char(char, style, heteronym, errors, strict)
            result.extend(char_result)
        return result


def _handle_nopinyin_char(chars, errors='default'):
    """Handle a single non-pinyin character."""
    converter = DefaultConverter()
    result = converter._handle_no_pinyin(chars, Style.NORMAL, True, errors, True)
    return result[0][0] if result and result[0] else None


def load_single_dict(dict_data):
    """Load custom single character pinyin dictionary."""
    from pypinyin import pinyin_dict
    pinyin_dict.pinyin_dict.update(dict_data)


def load_phrases_dict(dict_data):
    """Load custom phrase pinyin dictionary."""
    from pypinyin import phrases_dict
    phrases_dict.phrases_dict.update(dict_data)


__all__ = [
    'Pinyin',
    'pinyin',
    'lazy_pinyin',
    'slug',
    'to_fixed',
    'handle_nopinyin',
    'single_pinyin',
    'phrase_pinyin',
    '_handle_nopinyin_char',
    'load_single_dict',
    'load_phrases_dict',
]
