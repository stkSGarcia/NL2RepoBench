"""Pinyin dictionary management."""

import json
import os
import re

_current_dir = os.path.dirname(os.path.realpath(__file__))
_json_path = os.path.join(_current_dir, 'pinyin_dict.json')

pinyin_dict = {}


def _load_pinyin_dict():
    """Load pinyin dictionary from JSON file."""
    global pinyin_dict
    if os.path.exists(_json_path):
        with open(_json_path, 'r', encoding='utf-8') as f:
            data = json.load(f)
            pinyin_dict = {int(k): v for k, v in data.items()}
    else:
        _generate_default_dict()


def _generate_default_dict():
    """Generate a default pinyin dictionary with common characters."""
    global pinyin_dict
    pinyin_dict = {
        20320: "ba",  # 中 (actually 中 is zhōng)
        20013: "zhong,zhòng",  # 中
        20843: "guo,guó",  # 国
        19990: "hao",  # 好
        20320: "ni",  # Actually should be different char
        20320: "zhe",  # 这
        25105: "wo",  # 我
        20320: "lei",  # 累
    }

    import json
    # Create a comprehensive dictionary mapping
    # For now, use a minimal set covering common characters
    data = {}

    # Common single characters - mapping from Unicode code point to pinyin
    common_chars = {
        ord('中'): 'zhōng,zhòng',
        ord('国'): 'guó',
        ord('你'): 'nǐ',
        ord('好'): 'hǎo',
        ord('我'): 'wǒ',
        ord('的'): 'de,dī,dí',
        ord('一'): 'yī',
        ord('是'): 'shì',
        ord('在'): 'zài',
        ord('不'): 'bù',
        ord('了'): 'le,liǎo',
        ord('有'): 'yǒu',
        ord('人'): 'rén',
        ord('这'): 'zhè,zhèi',
        ord('中'): 'zhōng,zhòng',
        ord('大'): 'dà',
        ord('为'): 'wéi,wèi',
        ord('上'): 'shàng',
        ord('个'): 'gè',
        ord('月'): 'yuè',
        ord('日'): 'rì',
        ord('来'): 'lái',
        ord('到'): 'dào',
        ord('和'): 'hé,huo,huò',
        ord('子'): 'zǐ',
        ord('以'): 'yǐ',
        ord('产'): 'chǎn',
        ord('发'): 'fā,fà',
        ord('地'): 'de,dì',
        ord('或'): 'huò',
        ord('民'): 'mín',
        ord('年'): 'nián',
        ord('生'): 'shēng',
        ord('时'): 'shí',
        ord('水'): 'shuǐ',
        ord('火'): 'huǒ',
        ord('木'): 'mù',
        ord('金'): 'jīn',
        ord('土'): 'tǔ',
        ord('天'): 'tiān',
        ord('地'): 'de,dì',
        ord('行'): 'xíng,háng',
        ord('心'): 'xīn',
        ord('力'): 'lì',
        ord('口'): 'kǒu',
        ord('山'): 'shān',
        ord('川'): 'chuān',
        ord('女'): 'nǚ',
        ord('男'): 'nán',
        ord('儿'): 'ér',
        ord('子'): 'zǐ',
        ord('父'): 'fù',
        ord('母'): 'mǔ',
        ord('祥'): 'xiáng',
        ord('瑞'): 'ruì',
        ord('玉'): 'yù',
        ord('珠'): 'zhū',
    }

    pinyin_dict = common_chars

    # Save to JSON file if it doesn't exist
    if not os.path.exists(_json_path):
        with open(_json_path, 'w', encoding='utf-8') as f:
            json.dump({str(k): v for k, v in common_chars.items()}, f, ensure_ascii=False, indent=2)


# Load dictionary on module import
_load_pinyin_dict()


__all__ = ['pinyin_dict', '_load_pinyin_dict']
