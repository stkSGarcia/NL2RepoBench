"""Custom exceptions for pypinyin."""


class PinyinException(Exception):
    """Base exception for pypinyin."""
    pass


class PinyinNotFoundException(PinyinException):
    """Exception raised when pinyin is not found."""
    pass


__all__ = ['PinyinException', 'PinyinNotFoundException']
