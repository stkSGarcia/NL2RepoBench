"""Pinyin standard conversions."""

import re

UV_MAP = {'u': 'ü', 'ū': 'ǖ', 'ú': 'ǘ', 'ǔ': 'ǚ', 'ù': 'ǜ'}
U_TONES = set(UV_MAP.keys())
UV_RE = re.compile(r'^(j|q|x)({tones})(.*)$'.format(tones='|'.join(re.escape(t) for t in UV_MAP.keys())))

I_TONES = set(['i', 'ī', 'í', 'ǐ', 'ì'])
IU_MAP = {'iu': 'iou', 'iū': 'ioū', 'iú': 'ioú', 'iǔ': 'ioǔ', 'iù': 'ioù'}
IU_TONES = set(IU_MAP.keys())
IU_RE = re.compile(r'^([a-z]+)({tones})$'.format(tones='|'.join(re.escape(t) for t in IU_TONES)))

UI_MAP = {'ui': 'uei', 'uī': 'ueī', 'uí': 'ueí', 'uǐ': 'ueǐ', 'uì': 'ueì'}
UI_TONES = set(UI_MAP.keys())
UI_RE = re.compile(r'([a-z]+)({tones})$'.format(tones='|'.join(re.escape(t) for t in UI_TONES)))

UN_MAP = {'un': 'uen', 'ūn': 'ūen', 'ún': 'úen', 'ǔn': 'ǔen', 'ùn': 'ùen'}
UN_TONES = set(UN_MAP.keys())
UN_RE = re.compile(r'([a-z]+)({tones})$'.format(tones='|'.join(re.escape(t) for t in UN_TONES)))


def convert_zero_consonant(pinyin):
    """Convert zero consonant pinyin (y, w) to original vowel forms."""
    if not pinyin:
        return pinyin

    # Handle y- forms
    if pinyin.startswith('y'):
        if len(pinyin) > 1:
            rest = pinyin[1:]
            if rest[0] in 'aeiouü':
                if rest.startswith('i'):
                    return pinyin  # yi, yin, ying are correct
                elif rest.startswith('a'):
                    return pinyin  # ya, yan, yang are correct
                elif rest.startswith('e'):
                    return pinyin  # ye is correct
                elif rest.startswith('o'):
                    return pinyin  # yo is rare but possible
                elif rest.startswith('u'):
                    return pinyin  # yu is correct (ü)

    # Handle w- forms
    if pinyin.startswith('w'):
        if len(pinyin) > 1:
            rest = pinyin[1:]
            if rest[0] in 'aeiouü':
                if rest.startswith('a'):
                    return pinyin  # wa, wan, wang are correct
                elif rest.startswith('o'):
                    return pinyin  # wo is correct
                elif rest.startswith('u'):
                    return pinyin  # wu is correct

    return pinyin


def convert_uv(pinyin):
    """Convert u to ü when following j, q, x."""
    if not pinyin:
        return pinyin

    match = UV_RE.match(pinyin)
    if match:
        initial, u_tone, rest = match.groups()
        u_replacement = UV_MAP.get(u_tone, u_tone)
        return initial + u_replacement + rest

    return pinyin


def convert_iou(pinyin):
    """Convert iu to iou when preceded by an initial."""
    if not pinyin:
        return pinyin

    for iu_tone, iou_tone in IU_MAP.items():
        if pinyin.endswith(iu_tone) and len(pinyin) > len(iu_tone):
            return pinyin[:-len(iu_tone)] + iou_tone

    return pinyin


def convert_uei(pinyin):
    """Convert ui to uei when preceded by an initial."""
    if not pinyin:
        return pinyin

    for ui_tone, uei_tone in UI_MAP.items():
        if pinyin.endswith(ui_tone) and len(pinyin) > len(ui_tone):
            return pinyin[:-len(ui_tone)] + uei_tone

    return pinyin


def convert_uen(pinyin):
    """Convert un to uen when preceded by an initial."""
    if not pinyin:
        return pinyin

    for un_tone, uen_tone in UN_MAP.items():
        if pinyin.endswith(un_tone) and len(pinyin) > len(un_tone):
            return pinyin[:-len(un_tone)] + uen_tone

    return pinyin


def convert_finals(pinyin):
    """Apply all final conversions."""
    pinyin = convert_iou(pinyin)
    pinyin = convert_uei(pinyin)
    pinyin = convert_uen(pinyin)
    return pinyin


__all__ = [
    'convert_zero_consonant',
    'convert_uv',
    'convert_iou',
    'convert_uei',
    'convert_uen',
    'convert_finals',
]
