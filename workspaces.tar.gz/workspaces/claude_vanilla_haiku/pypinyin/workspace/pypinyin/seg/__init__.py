"""Segmentation module."""

__all__ = []
