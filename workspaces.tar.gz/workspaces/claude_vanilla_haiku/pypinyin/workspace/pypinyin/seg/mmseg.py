"""MMSEG-style segmentation wrapper."""


class PrefixSet(object):
    """Prefix set for word matching."""

    def __init__(self):
        self.prefixes = set()

    def train(self, words):
        """Train with a list of words."""
        for word in words:
            for i in range(1, len(word) + 1):
                self.prefixes.add(word[:i])

    def __contains__(self, key):
        """Check if key is in prefix set."""
        return key in self.prefixes


class Seg(object):
    """Segmenter using forward maximum matching."""

    def __init__(self, prefix_set):
        self.prefix_set = prefix_set

    def cut(self, text):
        """Segment text using maximum matching."""
        if not text:
            return []

        result = []
        i = 0

        while i < len(text):
            # Try to find longest matching word
            j = len(text)
            while j > i:
                word = text[i:j]
                if word in self.prefix_set:
                    result.append(word)
                    i = j
                    break
                j -= 1
            else:
                # No match found, use single character
                result.append(text[i])
                i += 1

        return result

    def train(self, words):
        """Train the segmenter."""
        self.prefix_set.train(words)


__all__ = ['PrefixSet', 'Seg']
