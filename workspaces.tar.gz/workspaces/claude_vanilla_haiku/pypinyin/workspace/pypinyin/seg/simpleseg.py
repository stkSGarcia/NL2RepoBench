"""Simple segmentation for Chinese text."""

import re


def simple_seg(hans):
    """Segment text by separating Chinese characters from non-Chinese."""
    if not hans:
        return []

    result = []
    current = []
    is_chinese = False

    for char in hans:
        char_is_chinese = _is_chinese(char)

        if char_is_chinese == is_chinese:
            current.append(char)
        else:
            if current:
                result.append(''.join(current))
            current = [char]
            is_chinese = char_is_chinese

    if current:
        result.append(''.join(current))

    return result


def _is_chinese(char):
    """Check if character is Chinese."""
    code = ord(char)
    return (0x4e00 <= code <= 0x9fff or  # CJK Unified Ideographs
            0x3400 <= code <= 0x4dbf or  # CJK Unified Ideographs Extension A
            0x20000 <= code <= 0x2a6df or  # CJK Unified Ideographs Extension B
            code == 0x3007)  # CJK symbol


def _seg(chars):
    """Segment characters."""
    return simple_seg(chars)


__all__ = ['simple_seg', '_seg', '_is_chinese']
