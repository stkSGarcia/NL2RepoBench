"""V/Ü conversion module."""


class V2UMixin(object):
    """Mixin for converting v to ü."""

    def post_convert_style(self, han, orig_pinyin, converted_pinyin, style, strict, **kwargs):
        """Convert v to ü."""
        return converted_pinyin.replace('v', 'ü') if 'v' in converted_pinyin else converted_pinyin


__all__ = ['V2UMixin']
