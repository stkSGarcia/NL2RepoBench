"""Public tone conversion API."""

import re
from pypinyin.style._tone_convert import (
    to_tone, to_tone2, to_tone3, to_normal,
    TONE_MARKS, REVERSE_TONE_MARKS
)


def tone_to_tone3(tone, v_to_u=False, neutral_tone_with_five=False, **kwargs):
    """Convert pinyin from TONE to TONE3 style."""
    return to_tone3(tone, v_to_u=v_to_u, neutral_tone_with_five=neutral_tone_with_five)


def tone2_to_normal(tone2, v_to_u=False):
    """Convert pinyin from TONE2 to NORMAL style."""
    if not tone2:
        return tone2

    result = to_normal(tone2, v_to_u=False)
    if v_to_u:
        result = result.replace('v', 'ü')
    return result


def tone2_to_tone(tone2):
    """Convert pinyin from TONE2 to TONE style."""
    if not tone2:
        return tone2

    # TONE2 format: tone number comes after the vowel
    # Find all vowels with numbers after them
    for match in re.finditer(r'([aeoiüv])([1-5])', tone2):
        vowel = match.group(1)
        tone = int(match.group(2))
        marked = TONE_MARKS.get(vowel, {}).get(tone)
        if marked:
            return tone2[:match.start()] + marked + tone2[match.end():]

    return tone2


def tone2_to_tone3(tone2, v_to_u=False):
    """Convert pinyin from TONE2 to TONE3 style."""
    if not tone2:
        return tone2

    # Extract tone number
    match = re.search(r'[1-5]', tone2)
    if match:
        tone = match.group(0)
        # Remove the tone number from its current position
        result = re.sub(r'[1-5]', '', tone2)
        result += tone
        if v_to_u:
            result = result.replace('v', 'ü')
        return result

    return tone2


def tone3_to_normal(tone3, v_to_u=False):
    """Convert pinyin from TONE3 to NORMAL style."""
    if not tone3:
        return tone3

    result = re.sub(r'[1-5]$', '', tone3)
    if v_to_u:
        result = result.replace('v', 'ü')
    return result


def tone3_to_tone(tone3):
    """Convert pinyin from TONE3 to TONE style."""
    if not tone3:
        return tone3

    # Extract tone at end
    match = re.match(r'^([a-zü]+)([1-5])$', tone3)
    if match:
        pinyin_base = match.group(1)
        tone = int(match.group(2))

        # Find vowel position
        for vowel in 'aeoiü':
            if vowel in pinyin_base:
                idx = pinyin_base.index(vowel)
                marked = TONE_MARKS.get(vowel, {}).get(tone)
                if marked:
                    return pinyin_base[:idx] + marked + pinyin_base[idx+1:]

    return tone3


def tone3_to_tone2(tone3, v_to_u=False):
    """Convert pinyin from TONE3 to TONE2 style."""
    if not tone3:
        return tone3

    # Extract tone at end
    match = re.match(r'^([a-zü]+)([1-5])$', tone3)
    if match:
        pinyin_base = match.group(1)
        tone = match.group(2)

        # Find right vowel for tone number placement
        for vowel in 'aeoiü':
            if vowel in pinyin_base:
                idx = pinyin_base.index(vowel)
                result = pinyin_base[:idx+1] + tone + pinyin_base[idx+1:]
                if v_to_u:
                    result = result.replace('v', 'ü')
                return result

    return tone3


def to_finals_tone(pinyin, strict=True):
    """Extract finals with tone marks."""
    from pypinyin.style._tone_convert import to_initials, to_finals

    initials = to_initials(pinyin, strict)
    finals = to_finals(pinyin, strict, v_to_u=False)

    # If finals is empty, it's likely a zero-initial (y, w)
    if not finals:
        finals = to_normal(pinyin, v_to_u=False)
        return finals[len(initials):] if initials else finals

    return finals


def to_finals_tone2(pinyin, strict=True, v_to_u=False, neutral_tone_with_five=False):
    """Extract finals with tone numbers."""
    from pypinyin.style._tone_convert import to_initials

    initials = to_initials(pinyin, strict)
    pinyin_no_initial = pinyin[len(initials):]

    # Convert to tone2
    tone2 = to_tone2(pinyin_no_initial)

    if v_to_u:
        tone2 = tone2.replace('v', 'ü')

    return tone2


def to_finals_tone3(pinyin, strict=True, v_to_u=False, neutral_tone_with_five=False):
    """Extract finals with tone numbers at end."""
    from pypinyin.style._tone_convert import to_initials

    initials = to_initials(pinyin, strict)
    pinyin_no_initial = pinyin[len(initials):]

    # Convert to tone3
    tone3 = to_tone3(pinyin_no_initial, v_to_u=v_to_u, neutral_tone_with_five=neutral_tone_with_five)

    return tone3


__all__ = [
    'tone_to_tone3',
    'tone2_to_normal',
    'tone2_to_tone',
    'tone2_to_tone3',
    'tone3_to_normal',
    'tone3_to_tone',
    'tone3_to_tone2',
    'to_finals_tone',
    'to_finals_tone2',
    'to_finals_tone3',
]
