"""Tone sandhi rules for Mandarin Chinese."""


class ToneSandhiMixin(object):
    """Mixin for applying tone sandhi rules."""

    def post_pinyin(self, han, heteronym, pinyin, **kwargs):
        """Post-process pinyin with tone sandhi rules."""
        # Apply third-tone sandhi (3+3 becomes 2)
        if len(pinyin) > 1:
            for i in range(len(pinyin) - 1):
                curr = pinyin[i]
                next_item = pinyin[i + 1]

                if curr and next_item:
                    curr_py = curr[0] if isinstance(curr, list) else curr
                    next_py = next_item[0] if isinstance(next_item, list) else next_item

                    if isinstance(curr_py, str) and isinstance(next_py, str):
                        if '3' in curr_py and '3' in next_py:
                            # Change first tone 3 to tone 2
                            if isinstance(curr, list):
                                curr[0] = curr_py.replace('3', '2')
                            else:
                                pinyin[i] = [curr_py.replace('3', '2')]

        return pinyin


__all__ = ['ToneSandhiMixin']
