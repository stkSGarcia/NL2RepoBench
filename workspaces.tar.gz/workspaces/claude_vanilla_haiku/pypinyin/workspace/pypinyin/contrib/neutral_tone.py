"""Neutral tone handling."""

from pypinyin.constants import Style
import re


class NeutralToneWith5Mixin(object):
    """Mixin for marking neutral tone with 5."""

    NUMBER_TONE = (Style.TONE2, Style.TONE3, Style.FINALS_TONE2, Style.FINALS_TONE3)
    NUMBER_AT_END = (Style.TONE3, Style.FINALS_TONE3)

    def post_convert_style(self, han, orig_pinyin, converted_pinyin, style, strict, **kwargs):
        """Mark neutral tone with 5 in numeric styles."""
        if style in self.NUMBER_TONE:
            if not re.search(r'[1-4]', converted_pinyin):
                if style in self.NUMBER_AT_END:
                    return converted_pinyin + '5'
                else:
                    # For TONE2 and FINALS_TONE2, add 5 after the vowel
                    for i, char in enumerate(converted_pinyin):
                        if char in 'aeiouü':
                            return converted_pinyin[:i+1] + '5' + converted_pinyin[i+1:]

        return converted_pinyin


__all__ = ['NeutralToneWith5Mixin']
