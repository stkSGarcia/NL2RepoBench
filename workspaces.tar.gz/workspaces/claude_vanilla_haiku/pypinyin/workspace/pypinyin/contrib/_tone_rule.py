"""Tone mark placement rules."""


def right_mark_index(pinyin_no_tone):
    """Determine the correct position to place tone marks."""
    if not pinyin_no_tone:
        return -1

    # Rule: a and e always take the mark
    for i, char in enumerate(pinyin_no_tone):
        if char in 'ae':
            return i

    # Rule: in ou, o takes the mark
    if 'ou' in pinyin_no_tone:
        return pinyin_no_tone.index('o')

    # Rule: otherwise, the last vowel takes the mark
    for i in range(len(pinyin_no_tone) - 1, -1, -1):
        if pinyin_no_tone[i] in 'iuü':
            return i

    return -1


__all__ = ['right_mark_index']
