"""MMSEG support for pypinyin."""

from pypinyin.seg.mmseg import Seg, PrefixSet


def retrain(seg_instance):
    """Retrain a segmenter instance."""
    if hasattr(seg_instance, 'train'):
        from pypinyin.phrases_dict import phrases_dict
        seg_instance.train(phrases_dict.keys())


__all__ = ['retrain']
