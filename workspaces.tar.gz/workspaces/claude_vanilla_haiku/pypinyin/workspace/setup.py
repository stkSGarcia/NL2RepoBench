"""Setup configuration for pypinyin package."""

import os
import re
from setuptools import setup, find_packages

_current_dir = os.path.dirname(os.path.realpath(__file__))
_init_path = os.path.join(_current_dir, 'pypinyin', '__init__.py')


def get_meta():
    """Extract metadata from __init__.py."""
    meta = {}
    with open(_init_path, 'r', encoding='utf-8') as f:
        content = f.read()

    meta['version'] = re.search(r"__version__ = ['\"]([^'\"]*)['\"]", content).group(1)
    meta['author'] = re.search(r"__author__ = ['\"]([^'\"]*)['\"]", content).group(1)
    meta['license'] = re.search(r"__license__ = ['\"]([^'\"]*)['\"]", content).group(1)

    return meta


def long_description():
    """Get long description from README."""
    readme_path = os.path.join(_current_dir, 'README.rst')
    if os.path.exists(readme_path):
        with open(readme_path, 'r', encoding='utf-8') as f:
            return f.read()
    return 'Chinese character pinyin conversion library'


meta = get_meta()

setup(
    name='pypinyin',
    version=meta['version'],
    description='Chinese character pinyin conversion library',
    long_description=long_description(),
    author=meta['author'],
    url='https://github.com/mozillazg/python-pinyin',
    license=meta['license'],
    packages=find_packages(),
    include_package_data=True,
    package_data={
        'pypinyin': [
            '*.json',
            'py.typed',
        ]
    },
    install_requires=[
        'jieba==0.42.1',
        'typing-extensions==4.12.2',
        'chardet==5.2.0',
    ],
    extras_require={
        'dev': [
            'pytest>=8.4.1',
            'pytest-cov>=6.2.1',
            'mypy>=1.17.1',
        ]
    },
    entry_points={
        'console_scripts': [
            'pypinyin=pypinyin.runner:main',
        ]
    },
    classifiers=[
        'Development Status :: 5 - Production/Stable',
        'Intended Audience :: Developers',
        'License :: OSI Approved :: MIT License',
        'Programming Language :: Python',
        'Programming Language :: Python :: 3',
        'Programming Language :: Python :: 3.10',
        'Topic :: Software Development :: Libraries :: Python Modules',
        'Topic :: Text Processing :: Linguistics',
    ],
    python_requires='>=3.10',
)
