"""Test API functions from the usage guide."""

import sys
sys.path.insert(0, '.')

from pypinyin import (
    pinyin, lazy_pinyin, slug, Style,
    load_single_dict, load_phrases_dict,
)
from pypinyin.core import to_fixed, handle_nopinyin, single_pinyin, phrase_pinyin
from pypinyin.constants import Style
from pypinyin.converter import DefaultConverter
from pypinyin.standard import convert_zero_consonant, convert_uv
from pypinyin.utils import _remove_dup_items
from pypinyin.contrib.tone_convert import (
    tone_to_tone3, tone2_to_normal, tone2_to_tone, tone3_to_normal
)
from pypinyin.seg.simpleseg import simple_seg
from pypinyin.runner import NullWriter


def test_core_functions():
    """Test core pinyin functions."""
    print("Testing core functions...")

    # pinyin function
    result = pinyin('你好')
    assert len(result) == 2, "pinyin() should return 2 characters"
    print("✓ pinyin() works")

    # lazy_pinyin function
    result = lazy_pinyin('你好')
    assert isinstance(result, list) and len(result) == 2, "lazy_pinyin() should return flat list"
    print("✓ lazy_pinyin() works")

    # slug function
    result = slug('你好')
    assert isinstance(result, str) and '-' in result, "slug() should return dash-separated string"
    print("✓ slug() works")


def test_style_conversions():
    """Test different style conversions."""
    print("\nTesting style conversions...")

    styles = [
        Style.TONE,
        Style.TONE2,
        Style.TONE3,
        Style.NORMAL,
        Style.INITIALS,
        Style.FIRST_LETTER,
        Style.FINALS,
    ]

    for style in styles:
        result = pinyin('中', style=style)
        assert len(result) > 0, f"Style {style} should produce results"

    print(f"✓ All {len(styles)} styles work")


def test_converter_class():
    """Test DefaultConverter class."""
    print("\nTesting DefaultConverter...")

    converter = DefaultConverter()
    result = converter.convert('中', Style.TONE, False, 'default', True)
    assert len(result) > 0, "Converter should return results"
    print("✓ DefaultConverter works")


def test_utility_functions():
    """Test utility functions."""
    print("\nTesting utility functions...")

    # _remove_dup_items
    result = _remove_dup_items(['a', 'b', 'a', 'c'])
    assert result == ['a', 'b', 'c'], "Should remove duplicates preserving order"
    print("✓ _remove_dup_items works")


def test_tone_conversions():
    """Test tone conversion functions."""
    print("\nTesting tone conversions...")

    # tone3_to_normal
    result = tone3_to_normal('ni3')
    assert result == 'ni', f"tone3_to_normal('ni3') should be 'ni', got '{result}'"
    print("✓ tone3_to_normal works")

    # tone2_to_normal
    result = tone2_to_normal('ni3')
    assert result == 'ni', f"tone2_to_normal('ni3') should be 'ni', got '{result}'"
    print("✓ tone2_to_normal works")


def test_segmentation():
    """Test text segmentation."""
    print("\nTesting segmentation...")

    result = simple_seg('你好world')
    assert len(result) >= 2, "Should segment mixed text"
    print("✓ simple_seg works")


def test_error_handling():
    """Test error handling."""
    print("\nTesting error handling...")

    # Test different error modes
    errors_modes = ['default', 'ignore', 'replace']
    for mode in errors_modes:
        try:
            result = pinyin('你好123', errors=mode)
            print(f"✓ error mode '{mode}' works")
        except Exception as e:
            print(f"✗ error mode '{mode}' failed: {e}")


def test_nullwriter():
    """Test NullWriter class."""
    print("\nTesting NullWriter...")

    writer = NullWriter()
    writer.write("test")
    writer.flush()
    print("✓ NullWriter works")


def test_heteronym():
    """Test heteronym (polyphone) handling."""
    print("\nTesting heteronym handling...")

    result = pinyin('中', heteronym=True)
    pinyins = result[0][0] if result and result[0] else []
    assert len(pinyins) > 1, "中 should have multiple pronunciations"
    print(f"✓ Heteronym handling works (中 has {len(pinyins)} pronunciations)")


def test_custom_dictionaries():
    """Test custom dictionary loading."""
    print("\nTesting custom dictionaries...")

    # Load custom single character
    load_single_dict({ord('㐍'): 'test'})
    print("✓ load_single_dict works")

    # Load custom phrase
    load_phrases_dict({'测试': [['ce'], ['shi']]})
    print("✓ load_phrases_dict works")


def run_all_tests():
    """Run all API tests."""
    print("=" * 50)
    print("Testing pypinyin API Functions")
    print("=" * 50)

    try:
        test_core_functions()
        test_style_conversions()
        test_converter_class()
        test_utility_functions()
        test_tone_conversions()
        test_segmentation()
        test_error_handling()
        test_nullwriter()
        test_heteronym()
        test_custom_dictionaries()

        print("\n" + "=" * 50)
        print("✓ All API tests passed!")
        print("=" * 50)

    except Exception as e:
        print(f"\n✗ Test failed with error: {e}")
        import traceback
        traceback.print_exc()


if __name__ == '__main__':
    run_all_tests()
