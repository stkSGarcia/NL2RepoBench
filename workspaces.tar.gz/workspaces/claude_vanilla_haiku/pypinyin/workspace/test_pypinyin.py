"""Test cases for pypinyin."""

import sys
sys.path.insert(0, '.')

from pypinyin import pinyin, lazy_pinyin, slug, Style


def test_basic_pinyin():
    """Test basic pinyin conversion."""
    result = pinyin('你好')
    print(f"pinyin('你好') = {result}")
    assert len(result) == 2
    assert len(result[0]) >= 1
    assert len(result[1]) >= 1


def test_lazy_pinyin():
    """Test lazy pinyin conversion."""
    result = lazy_pinyin('你好')
    print(f"lazy_pinyin('你好') = {result}")
    assert len(result) == 2
    assert isinstance(result[0], str)
    assert isinstance(result[1], str)


def test_slug():
    """Test slug conversion."""
    result = slug('你好')
    print(f"slug('你好') = {result}")
    assert isinstance(result, str)
    assert '-' in result or len(result) > 0


def test_style_tone():
    """Test TONE style."""
    result = pinyin('你好', style=Style.TONE)
    print(f"pinyin('你好', style=TONE) = {result}")
    assert len(result) == 2


def test_style_tone2():
    """Test TONE2 style."""
    result = pinyin('你好', style=Style.TONE2)
    print(f"pinyin('你好', style=TONE2) = {result}")
    assert len(result) == 2


def test_style_initials():
    """Test INITIALS style."""
    result = pinyin('你好', style=Style.INITIALS)
    print(f"pinyin('你好', style=INITIALS) = {result}")
    assert len(result) == 2


def test_style_finals():
    """Test FINALS style."""
    result = pinyin('你好', style=Style.FINALS)
    print(f"pinyin('你好', style=FINALS) = {result}")
    assert len(result) == 2


def test_heteronym():
    """Test heteronym (polyphone) handling."""
    result = pinyin('中', heteronym=True)
    print(f"pinyin('中', heteronym=True) = {result}")
    assert len(result) >= 1


def test_error_handling():
    """Test error handling."""
    result = pinyin('你好123', errors='ignore')
    print(f"pinyin('你好123', errors='ignore') = {result}")
    # Should only have pinyin for Chinese characters
    assert len(result) >= 2


def test_phrase_dict():
    """Test phrase dictionary."""
    result = pinyin('中国')
    print(f"pinyin('中国') = {result}")
    assert len(result) == 2


def run_all_tests():
    """Run all tests."""
    print("Testing pypinyin...")
    print()

    try:
        test_basic_pinyin()
        print("✓ test_basic_pinyin passed")
    except Exception as e:
        print(f"✗ test_basic_pinyin failed: {e}")

    try:
        test_lazy_pinyin()
        print("✓ test_lazy_pinyin passed")
    except Exception as e:
        print(f"✗ test_lazy_pinyin failed: {e}")

    try:
        test_slug()
        print("✓ test_slug passed")
    except Exception as e:
        print(f"✗ test_slug failed: {e}")

    try:
        test_style_tone()
        print("✓ test_style_tone passed")
    except Exception as e:
        print(f"✗ test_style_tone failed: {e}")

    try:
        test_style_tone2()
        print("✓ test_style_tone2 passed")
    except Exception as e:
        print(f"✗ test_style_tone2 failed: {e}")

    try:
        test_style_initials()
        print("✓ test_style_initials passed")
    except Exception as e:
        print(f"✗ test_style_initials failed: {e}")

    try:
        test_style_finals()
        print("✓ test_style_finals passed")
    except Exception as e:
        print(f"✗ test_style_finals failed: {e}")

    try:
        test_heteronym()
        print("✓ test_heteronym passed")
    except Exception as e:
        print(f"✗ test_heteronym failed: {e}")

    try:
        test_error_handling()
        print("✓ test_error_handling passed")
    except Exception as e:
        print(f"✗ test_error_handling failed: {e}")

    try:
        test_phrase_dict()
        print("✓ test_phrase_dict passed")
    except Exception as e:
        print(f"✗ test_phrase_dict failed: {e}")

    print()
    print("Tests complete!")


if __name__ == '__main__':
    run_all_tests()
