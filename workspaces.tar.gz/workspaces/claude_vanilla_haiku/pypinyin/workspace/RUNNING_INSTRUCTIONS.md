# pypinyin - Running Instructions

## Project Structure

```
workspace/
├── pypinyin/              # Main package directory
│   ├── __init__.py        # Main API entry point
│   ├── core.py            # Core conversion logic
│   ├── converter.py       # Converter classes
│   ├── constants.py       # Constants and Style enum
│   ├── pinyin_dict.py     # Character dictionary
│   ├── phrases_dict.py    # Phrase dictionary
│   ├── pinyin_dict.json   # Dictionary data file
│   ├── phrases_dict.json  # Phrase data file
│   ├── style/             # Style conversion modules
│   ├── contrib/           # Extended functionality
│   ├── seg/               # Segmentation modules
│   ├── tools/             # Tools and utilities
│   └── ...                # Other modules
├── setup.py              # Package setup and configuration
├── README.rst            # Package documentation
├── design.md             # Design and architecture notes
├── example_usage.py      # Usage examples
├── test_pypinyin.py      # Basic tests
└── test_api_functions.py # Comprehensive API tests
```

## Quick Start

### 1. Basic Usage (No Installation Required)

The project can be used directly from the workspace directory:

```bash
# Navigate to workspace
cd /Users/samuel/Projects/NL2RepoBench/workspaces/claude_vanilla_haiku/pypinyin/workspace

# Run a simple test
python3 << 'EOF'
import sys
sys.path.insert(0, '.')
from pypinyin import pinyin, lazy_pinyin, slug, Style

print("Basic usage examples:")
print("1. pinyin('你好') =", pinyin('你好'))
print("2. lazy_pinyin('你好') =", lazy_pinyin('你好'))
print("3. slug('你好') =", slug('你好'))
EOF
```

### 2. Run Test Suite

```bash
# Basic functionality tests
python3 test_pypinyin.py

# Comprehensive API tests
python3 test_api_functions.py

# Usage examples
python3 example_usage.py
```

### 3. Install the Package

```bash
# Install in development mode
python3 setup.py develop

# Or regular install
python3 setup.py install

# After installation, use from anywhere
python3 -c "from pypinyin import pinyin; print(pinyin('你好'))"
```

## Core API Reference

### Main Functions

```python
from pypinyin import pinyin, lazy_pinyin, slug, Style

# Get pinyin with tone marks
pinyin('你好')  # [['nǐ'], ['hǎo']]

# Get flat list of pinyin
lazy_pinyin('你好')  # ['ni', 'hao']

# Create URL slug
slug('你好')  # 'ni-hao'

# Different output styles
pinyin('你好', style=Style.TONE2)    # [['ni3'], ['ha3o']]
pinyin('你好', style=Style.INITIALS)  # [['n'], ['h']]
pinyin('你好', style=Style.FINALS)    # [['i'], ['ao']]

# Handle multiple pronunciations
pinyin('中', heteronym=True)  # [['zhōng', 'zhòng']]

# Error handling
pinyin('你好123', errors='ignore')   # Ignore non-Chinese
pinyin('你好123', errors='replace')  # Replace with unicode
```

### Custom Dictionaries

```python
from pypinyin import load_single_dict, load_phrases_dict

# Add custom character pronunciation
load_single_dict({ord('桔'): 'jú,jié'})

# Add custom phrase
load_phrases_dict({'同行': [['tóng'], ['xíng']]})

# Now use the custom pronunciation
lazy_pinyin('桔子')  # Uses custom dict
```

### Tone Conversions

```python
from pypinyin.contrib.tone_convert import (
    tone3_to_tone,
    tone3_to_normal,
    tone2_to_tone,
)

tone3_to_tone('ni3')      # 'nǐ'
tone3_to_normal('ni3')    # 'ni'
tone2_to_tone('ni3')      # 'nǐ'
```

## Supported Pinyin Styles

The library supports 18 different pinyin styles:

| Style | Value | Example | Description |
|-------|-------|---------|-------------|
| NORMAL | 0 | ni hao | No tones |
| TONE | 1 | nǐ hǎo | Tone marks |
| TONE2 | 2 | ni3 ha3o | Numbers after vowel |
| TONE3 | 8 | ni3 hao3 | Numbers at end |
| INITIALS | 3 | n h | Initial consonants |
| FIRST_LETTER | 4 | n h | First letter only |
| FINALS | 5 | i ao | Final vowels |
| FINALS_TONE | 6 | ǐ ǎo | Finals with marks |
| FINALS_TONE2 | 7 | i3 a3o | Finals with numbers |
| FINALS_TONE3 | 9 | i3 ao3 | Finals with numbers at end |
| BOPOMOFO | 10 | ㄋㄧˇ | Bopomofo/Zhuyin |
| BOPOMOFO_FIRST | 11 | ㄋ | Bopomofo first |
| CYRILLIC | 12 | ни хао | Cyrillic |
| CYRILLIC_FIRST | 13 | н х | Cyrillic first |
| WADEGILES | 14 | ni hao | Wade-Giles |
| GWOYEU | 15 | ni hau | Gwoyeu |
| BRAILLE_MAINLAND | 16 | ⠝⠑ | Braille |
| BRAILLE_MAINLAND_TONE | 17 | ⠝⠑ | Braille with tone |

## File Manifest

### Core Modules (11 files)
- pypinyin/__init__.py - API entry point
- pypinyin/core.py - Core conversion
- pypinyin/converter.py - Converter implementations
- pypinyin/constants.py - Constants and enums
- pypinyin/pinyin_dict.py - Character dictionary
- pypinyin/phrases_dict.py - Phrase dictionary
- pypinyin/standard.py - Standard conversions
- pypinyin/utils.py - Utilities
- pypinyin/compat.py - Compatibility
- pypinyin/exceptions.py - Custom exceptions
- pypinyin/phonetic_symbol.py - Phonetic mappings

### Style Modules (10 files)
- pypinyin/style/_tone_convert.py - Core tone conversion
- pypinyin/style/_utils.py - Style utilities
- pypinyin/style/_constants.py - Style constants
- pypinyin/style/tone.py - Tone style
- pypinyin/style/initials.py - Initials extraction
- pypinyin/style/finals.py - Finals extraction
- pypinyin/style/bopomofo.py - Bopomofo
- pypinyin/style/cyrillic.py - Cyrillic
- pypinyin/style/wadegiles.py - Wade-Giles
- pypinyin/style/others.py - Other styles

### Contrib Modules (5 files)
- pypinyin/contrib/__init__.py
- pypinyin/contrib/tone_convert.py - Public tone API
- pypinyin/contrib/tone_sandhi.py - Tone sandhi
- pypinyin/contrib/neutral_tone.py - Neutral tone
- pypinyin/contrib/uv.py - V/Ü conversion

### Segmentation Modules (3 files)
- pypinyin/seg/__init__.py
- pypinyin/seg/simpleseg.py - Simple segmentation
- pypinyin/seg/mmseg.py - MMSEG interface

### Supporting Files (11+ files)
- pypinyin/tools/
- pypinyin/legacy/
- pypinyin/__pyinstaller/
- setup.py
- README.rst
- design.md
- example_usage.py
- test_pypinyin.py
- test_api_functions.py
- IMPLEMENTATION_SUMMARY.md

## Environment

- **Python Version**: 3.10.11 (compatible with 3.10+)
- **Current Working Directory**: `/Users/samuel/Projects/NL2RepoBench/workspaces/claude_vanilla_haiku/pypinyin/workspace`
- **Key Directories**:
  - Package: `./pypinyin/`
  - Dictionaries: `./pypinyin/pinyin_dict.json`, `./pypinyin/phrases_dict.json`
  - Tests: `./test_pypinyin.py`, `./test_api_functions.py`

## Troubleshooting

### Import Errors
If you get import errors, ensure:
1. You're in the workspace directory
2. Python path includes the current directory: `sys.path.insert(0, '.')`
3. All dependencies are installed

### Dictionary Not Found
The JSON dictionary files should be in the `pypinyin/` directory:
```bash
ls -la pypinyin/*.json
# Should show: pinyin_dict.json, phrases_dict.json
```

### Tests Failing
Run the tests individually to see which one fails:
```bash
python3 test_pypinyin.py -v
python3 test_api_functions.py -v
```

## Dependencies

Core dependencies (automatically installed via setup.py):
- jieba==0.42.1
- typing-extensions==4.12.2
- chardet==5.2.0

Development dependencies:
- pytest>=8.4.1
- pytest-cov>=6.2.1
- mypy>=1.17.1

## Output Guarantee

The project is ready to use and can be run in the current directory with:

```bash
python3 -c "from pypinyin import pinyin, lazy_pinyin; print('✓ pypinyin is working')"
```

All functionality specified in the start.md requirements has been implemented and tested.
