python-pinyin
=============

Chinese character pinyin conversion library.

A Python library for converting Chinese characters to pinyin with support for multiple output styles,
heteronym/polyphone handling, tone sandhi rules, and customizable dictionaries.

Features
--------

- Intelligent Pinyin Conversion: Convert Chinese characters to pinyin with support for multiple pronunciations (polyphones)
- Multiple Output Styles: Support for 18+ different pinyin styles including:
  - Tone marks (nǐ hǎo)
  - Tone numbers (ni3 hao3)
  - Initials/Finals (n h, i ao)
  - Bopomofo, Cyrillic, Wade-Giles, and more
- Simplified and Traditional Chinese: Support for both simplified and traditional characters
- Tone Sandhi Rules: Handle tone changes in continuous speech (e.g., 你好 → ní hǎo)
- Highly Customizable: Load custom single-character or phrase dictionaries
- Easy-to-use API: Simple functions for common use cases

Installation
------------

Install using pip::

    pip install pypinyin

Quick Start
-----------

Basic usage::

    from pypinyin import pinyin, lazy_pinyin, Style

    # Get pinyin with tone marks
    pinyin('你好')  # [['nǐ'], ['hǎo']]

    # Get pinyin without tones
    lazy_pinyin('你好')  # ['ni', 'hao']

    # Different styles
    pinyin('你好', style=Style.TONE2)    # [['ni3'], ['ha3o']]
    pinyin('你好', style=Style.INITIALS)  # [['n'], ['h']]
    pinyin('你好', style=Style.FINALS)    # [['i'], ['ao']]

    # Create URL slug
    from pypinyin import slug
    slug('你好')  # 'ni-hao'

Advanced Features
-----------------

Handle multiple pronunciations (polyphones)::

    pinyin('中', heteronym=True)  # [['zhōng', 'zhòng']]

Custom pinyin dictionary::

    from pypinyin import load_single_dict, load_phrases_dict
    load_single_dict({ord('桔'): 'jú,jié'})
    load_phrases_dict({'同行': [['tóng'], ['xíng']]})

Tone sandhi rules::

    pinyin('你好', tone_sandhi=True)  # Apply third-tone sandhi

Error handling::

    pinyin('你好123', errors='ignore')    # Skip non-Chinese characters
    pinyin('你好123', errors='replace')   # Replace with unicode encoding

Supported Styles
----------------

- **NORMAL**: Plain pinyin without tones (ni hao)
- **TONE**: Tone marks on vowels (nǐ hǎo)
- **TONE2**: Tone numbers after vowels (ni3 ha3o)
- **TONE3**: Tone numbers at syllable end (ni3 hao3)
- **INITIALS**: Initial consonants only (n h)
- **FIRST_LETTER**: First letter only (n h)
- **FINALS**: Final vowels only (i ao)
- **FINALS_TONE**: Finals with tone marks (ǐ ǎo)
- **FINALS_TONE2**: Finals with tone numbers (i3 a3o)
- **FINALS_TONE3**: Finals with tone numbers at end (i3 ao3)
- **BOPOMOFO**: Bopomofo/Zhuyin representation
- **CYRILLIC**: Cyrillic alphabet representation
- **WADEGILES**: Wade-Giles romanization
- **GWOYEU**: Gwoyeu Romatzyh
- **BRAILLE_MAINLAND**: Mainland Chinese Braille

License
-------

MIT License

Authors
-------

- mozillazg
- 闲耘
